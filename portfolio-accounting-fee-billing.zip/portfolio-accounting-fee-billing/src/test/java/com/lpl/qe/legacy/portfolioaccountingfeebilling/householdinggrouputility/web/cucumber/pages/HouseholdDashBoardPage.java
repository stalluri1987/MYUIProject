package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreUtil;

public class HouseholdDashBoardPage extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 872;
	Map<String, HashMap<String, String>> pageObjectMap;
	String  strdashboardpagexpath;
	String strVotgraphxpath;
	String strVotgraphxaxisxpath;
	String strVotgraphyaxisxpath;
	String strclickEditHHGsummarybuttonxpath;
	String strAccounttilexpath;
	String strclickEditbillingratebuttonXPATH;
	String strshowfulldetailshyperlinkxpath;
	String strhidefulldetailshyperlinkxpath;
	String strassetallocationbreakdownPanelxpath;
	String strnotessectionxpath;
	String straddnotehyperlinkxpath;
	String strnewnotewindowxpath;
	String strenternotetitlexpath;
	String strenternotetextxpath;
	String strtypedropdownxpath;
	String strsavenotebuttonxpath;
	String strcreatednotexpath;
	String strPositionBalancesUpdateFrequencyxpath;
	String strintradayupdatedbalancesxpath;
	String strupdatefrequencydropdownbuttonsxpath;
	String strpreviousMarketClosexpath;
	String strintradaydropdownoptionxpath;
	String strpreviousmarketplacedropdownoptionxpath;
	String strTotalAccountValueInDollarsXpath;
	String strBillingRateNameXpath;
	String strBalanceAndInverstSectionXpath;
	String strDeleteNoteHyperLinkXpath;
	String strDeleteNotePopupXpath;
	String strDeleteNoteNoXpath;
	String strDeleteNoteYesXpath;
	String strUpgradeHouseholdXpath;
	String strPrimaryClientRadioButtonXpath;
	String strCancelUpgradeHyperlinkXpath;
	String strContinueToUpgradeButtonXpath;
	String strCompleteUpgradeButtonXpath;
	String strReviewUpgradePageXpath;
	String strCapabilityTileTextXpath;
	String strCapabilityTileXpath;
	String strActiveUponUpgradeStatusXpath;
	String strAutomaticallyStreamlinedXpath;
	String strOutsideCapabilityTileTextXpath;
	String strRecentActivityXpath;
	String strRecentActivitiesXpath;
	String strSeeForAllThisGroupHyperlinkXpath;
	String strActivityTabXpath;
	
	public static final String DOLLAR_SYMBOL = "$";
	public static final String STATIC_TEXT_UPGRADE = "Once you complete this upgrade, you may focus on the other capabilities for this 2.0 household.";


	public HouseholdDashBoardPage(WebDriver driver) {
		super(driver);
		lplCoreUtil = new LPLCoreUtil();
		/** Fetching page objects from FARM */
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		checkForLocatorTypeAndInitializeFields(pageObjectMap, this.getClass().getDeclaredFields(), PAGE_IDENTIFIER);
	}
	
	/**
	 * This method is used to check if household Dashboard page is loaded
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean isDashboardPageDisplayed() {
		return isElementPresentUsingXpath(strdashboardpagexpath, lplCoreConstents.HIGH,
				"Household Dashboard Page Header");

	}

	/**
	 * This method is used to validate balance and investment section fields
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean BalanceAndInvestmentSectionVisible(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator(strBalanceAndInverstSectionXpath, field), field);
	}

	/**
	 * This method is used to check VOT graph
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean VOTGraphDisplayed() {

		return isElementPresentUsingXpath(strVotgraphxpath, lplCoreConstents.HIGH, "VOT Graph");
	}

	/**
	 * This method is used to check VOT graph axis data
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean VOTGraphAxisDisplayed() {

		if (isElementPresentUsingXpath(strVotgraphxaxisxpath, lplCoreConstents.HIGH,
				"Time over 1 year in VOT graph x axis ")) {

			return (isElementPresentUsingXpath(strVotgraphyaxisxpath, lplCoreConstents.HIGH,
					"account values in VOT Y axis "));

		}else {
			return false;
		}

		
	}

	/**
	 * This method is used to click on Edit Household Summary Button
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickEditHouseholdSummaryButton() {
		wait(5);
		return clickElementUsingXpath(strclickEditHHGsummarybuttonxpath, "Edit Household summary Button is clicked");

	}

	/**
	 * This method is used to check if account tile is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean AccountTileDisplayed() {

		return isElementPresentUsingXpath(strAccounttilexpath, lplCoreConstents.HIGH, "Account tile Displayed");

	}

	/**
	 * This method is used to validate Account tile fields
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean AccountTileFieldVisible(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator(strBalanceAndInverstSectionXpath, field), field);
	}
	
	/**
	 * This method is used to click on Edit Billing Rate Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickEditbillingratebutton() {
		return clickElementUsingXpath(strclickEditbillingratebuttonXPATH, "Edit billing rate Button is clicked");
	}
	
	
	/**
	 * This method is used to click on show full details
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickshowfulldetailshyperlink() {

		return clickElementUsingXpath(strshowfulldetailshyperlinkxpath, "show full details hyperlink is clicked");

	}

	/**
	 * This method is used to check hide full details hyperlink is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean hidefulldetailshyperlinkDisplayed() {
		return isElementPresentUsingXpath(strhidefulldetailshyperlinkxpath, lplCoreConstents.HIGH,
				"Hide full details hyperlink Displayed");

	}

	/**
	 * This method is used to check asset allocation breakdown Panel is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean assetallocationbreakdownPanelDisplayed() {
		return isElementPresentUsingXpath(strassetallocationbreakdownPanelxpath, lplCoreConstents.HIGH,
				"Hide full details hyperlink Displayed");

	}

	/**
	 * This method is used to validate Asset allocation breakdown fields
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean Assetallocationbreakdown(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
	}

	/**
	 * This method is used to click on hide full details hyperlink
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickshidefulldetailshyperlink() {
		return clickElementUsingXpath(strhidefulldetailshyperlinkxpath, "Hide full details hyperlink is clicked");

	}

	/**
	 * This method is used to check show full details hyperlink is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean showfulldetailshyperlinkDisplayed() {

		return isElementPresentUsingXpath(strshowfulldetailshyperlinkxpath, lplCoreConstents.HIGH,
				"show full details hyperlink Displayed");

	}

	/**
	 * This method is used to check Notes Section is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean notessectionDisplayed() {

		return isElementPresentUsingXpath(strnotessectionxpath, lplCoreConstents.HIGH, "Notes section Displayed");

	}

	/**
	 * This method is used to Validate Add Note hyperlink is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean addnotehyperlinkDisplayed() {

		return isElementPresentUsingXpath(straddnotehyperlinkxpath, lplCoreConstents.HIGH,
				"Add Note Hyperlink Displayed");

	}

	/**
	 * This method is used to click on add note hyperlink
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickaddnotehyperlink() {

		return clickElementUsingXpath(straddnotehyperlinkxpath, "Add Note hyperlink is clicked");

	}

	/**
	 * This method is used to Validate New Note Window is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean newnotewindowDisplayed() {

		return isElementPresentUsingXpath(strnewnotewindowxpath, lplCoreConstents.HIGH, "New Note window Displayed");

	}

	/**
	 * This method is used to enter the Title and Text of note
	 *
	 * @return boolean
	 * @param�Enter note title and note text Values
	 * @author awaeza
	 */

	public boolean enternotefields() {

		String notetitle = testData.get("Title");
		String notetext = testData.get("Text");
		if (enterTextUsingXpath(strenternotetitlexpath, notetitle, "Enter Note Title")) {
			enterTextUsingXpath(strenternotetextxpath, notetext, "Enter Note Text");
		}

		return true;
	}

	/**
	 * This method is used to Select Note Type
	 *
	 * @return boolean
	 * @param�Select Note Type
	 * @author awaeza
	 */

	public boolean selectnotetype() {
		String noteType = testData.get("NoteType");
		return selectValueFromDropdownUsingXpath(strtypedropdownxpath, noteType, "Select Note Type");
	}

	/**
	 * This method is used to click on save note Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clicknotesavebutton() {

		return clickElementUsingXpath(strsavenotebuttonxpath, "save note button is clicked");

	}

	/**
	 * This method is used to Validate Created Note is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean createdNoteDisplayed() {

		String notetitle = testData.get("Title");
		return isElementPresentUsingXpath(strcreatednotexpath.replace("xxx", notetitle), lplCoreConstents.HIGH,
				"Created Note Displayed");

	}

	/**
	 * This method is used to check selected Position Balances Update Frequency
	 * hyperlink is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean PositionBalancesUpdateFrequencyDisplayed() {

		return isElementPresentUsingXpath(strPositionBalancesUpdateFrequencyxpath, lplCoreConstents.HIGH,
				"Selected Position Balances Update Frequency hyperlink is Displayed");

	}

	/**
	 * This method is used to check default Intraday Updated Balances option is
	 * displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean defaultIntradayUpdatedBalancesoptionDisplayed() {

		return isElementPresentUsingXpath(strintradayupdatedbalancesxpath, lplCoreConstents.HIGH,
				"default Intraday Updated Balances option Displayed");

	}

	/**
	 * This method is used to click on Position Balances Update Frequency dropdown
	 * Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickupdatefrequencydropdownbutton() {

		return clickElementUsingXpath(strupdatefrequencydropdownbuttonsxpath,
				"Position Balances Update Frequency dropdown Button button is clicked");

	}

	/**
	 * This method is used to validate position Balances Update Frequency drop down
	 * options
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean updateFrequencydropdownoptions(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
	}

	/**
	 * This method is used to click on default Previous Market Close option
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickpreviousMarketCloseoption() {

		return clickElementUsingXpath(strpreviousMarketClosexpath, "Default Previous Market Close option is clicked");

	}

	/**
	 * This method is used to click on Intraday Updated Balances option from
	 * dropdown
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickintradaydropdownoption() {

		return clickElementUsingXpath(strintradaydropdownoptionxpath,
				"Intraday Updated Balances option is clicked from dropdown");

	}

	/**
	 * This method is used to click on Intraday Updated Balances option
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickintradayupdatedbalancesoption() {

		return clickElementUsingXpath(strintradayupdatedbalancesxpath, "Intraday Updated Balances option is clicked");

	}

	/**
	 * This method is used to click on Previous Market Close option from dropdown
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickPreviousMarketPlaceDropdownOption() {
		return clickElementUsingXpath(strpreviousmarketplacedropdownoptionxpath,
				"Previous Market Close option is clicked from dropdown");

	}
	
	/**
	 * This method is used to validate Billing name and edit icon is displayed
	 * billing rate section in dashbaord
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean billingratenamewithediticonDisplayed() {
		boolean blnResult = false;
	blnResult = isElementPresentUsingXpath(strBillingRateNameXpath, lplCoreConstents.HIGH,
				"Billing Rate name is displayed in Billing rate section of dashboard");
		if (blnResult)
			blnResult = isElementPresentUsingXpath(strclickEditbillingratebuttonXPATH, lplCoreConstents.HIGH,
					"billing rate edit icon is displayed in Billing rate section of dashboard");
		return blnResult;
	}
	
	/**
	 * This method is used to validate Total Account Value in Dollars under show full details
	 * @return boolean
	 * @author awaeza
	 */
	
public boolean seeTotalAccountValueInDollars()
{
	return(getTextUsingXpath(strTotalAccountValueInDollarsXpath,"Total Account value is displayed in Dollars")).startsWith(DOLLAR_SYMBOL);
}
/**
 * This method is used to click on delete note  hyperlink
 *
 *
 * @return boolean
 * @author awaeza
 */

public boolean clickDeleteNoteHyperlink() {

	return clickElementUsingXpath(strDeleteNoteHyperLinkXpath,"Delete note hyperlink is clicked");

}

/**
	* This method is used to validate delete note popup displayed
	*
	* @return boolean
	* @author awaeza
	*/
	public boolean deleteNotePopupDisplayed() {
	
return isElementPresentUsingXpath(strDeleteNotePopupXpath, lplCoreConstents.HIGH, "delete note popup is displayed");
	
		
}
	
/**
	 * This method is used to click on No  button  in delete note popup
	 *
	 *
	 * @return boolean
	 * @author awaeza
	 */
		
public boolean clickNoButtonDeletePopup() {
		
return clickElementUsingXpath(strDeleteNoteNoXpath,"No  button is clicked in delete note popup");
		
			}
			
/**
					 * This method is used to click on YES  button  in delete note popup
					 *
					 *
					 * @return boolean
					 * @author awaeza
					 */
				
					public boolean clickYesButtonDeletePopup() {
				
		return clickElementUsingXpath(strDeleteNoteYesXpath,"Yes  button is clicked in delete note popup");
				
					}
			/**
					 * This method is used to validate deleted  note is not displayed in notes section
					 * 
					 * 
					 * @return boolean
					 * @author awaeza
					 */
			
					public boolean deleteNoteNotPresent() {
			
					
		return isElementNotPresentUsingXpath(strcreatednotexpath.replace("xxx",testData.get("Title")));
						
					
			
					}
					
					
					/**
					* This method is used to validate Review Upgrade Page is displayed
					*
					* @return boolean
					* @author awaeza
					*/
					public boolean reviewUpgradePageDisplayed() {
					
				return isElementPresentUsingXpath(strReviewUpgradePageXpath, lplCoreConstents.HIGH, "Review Upgrade Page is displayed");
					
						
				}
					
				/**
					 * This method is used to click on upgrade household to 2.0 button
					 *
					 * @return boolean
					 * @author awaeza
					 */
						
				public boolean clickUpgradeHouseholdButton() {
						
				return clickElementUsingXpath(strUpgradeHouseholdXpath,"upgrade Household 2.0 button is clicked");
						
							}
				
				/**
				 * This method is used to click on primary radio button
				 *
				 * @return boolean
				 * @author awaeza
				 */
					
			public boolean clickPrimaryClientRadioButton() {
					
			return clickElementUsingXpath(strPrimaryClientRadioButtonXpath,"Primary client radio button is clicked");
					
						}
			
			/**
			 * This method is used to click on cancel upgrade hyperlink
			 *
			 * @return boolean
			 * @author awaeza
			 */
				
		public boolean clickCancelUpgradeHyperlink() {
				
		return clickElementUsingXpath(strCancelUpgradeHyperlinkXpath,"Cancel Upgrade hyperlink is clicked");
				
					}
				
		/**
		 * This method is used to click on continue to upgrade household button
		 *
		 * @return boolean
		 * @author awaeza
		 */
			
	public boolean clickContinueToUpgradeButton() {
			
	return clickElementUsingXpath(strContinueToUpgradeButtonXpath,"Continue to upgrade button is clicked");
			
				}
	
	/**
	 * This method is used to click on complete upgrade button
	 *
	 * @return boolean
	 * @author awaeza
	 */
		
public boolean clickCompleteUpgradeButton() {
		
return clickElementUsingXpath(strCompleteUpgradeButtonXpath,"Complete Upgrade button is clicked");
		
			}

/**
* This method is used to validate Capability tile with text in review upgrade page
*
* @return boolean
* @author awaeza
*/
public boolean capabilitytileWithTextDisplayed() {

return isElementPresentUsingXpath(strCapabilityTileXpath, lplCoreConstents.HIGH, "Capability Tile is displayed")
&& isElementPresentUsingXpath(strCapabilityTileTextXpath, lplCoreConstents.HIGH, "Capability Tile text is displayed");
	
}


/**
* This method is used to validate Active Upon Upgrade Status in the Capability tile of the review upgrade page
*
* @return boolean
* @author awaeza
*/
public boolean activeUponUpgradeStatusDisplayed() {

return isElementPresentUsingXpath(strActiveUponUpgradeStatusXpath, lplCoreConstents.HIGH, "Active Upon Upgrade Status is displayed");

	
}

/**
* This method is used to validate Active Upon Upgrade Status in the Capability tile of the review upgrade page
*
* @return boolean
* @author awaeza
*/
public boolean automaticallyStreamlinedDisplayed() {

return isElementPresentUsingXpath(strAutomaticallyStreamlinedXpath, lplCoreConstents.HIGH, "Automatically Streamlined verbiage is displayed");

	
}

/**
 * This method is used to verify static verbiage outside capability tile in review upgrade page
 * 
 * @return boolean
 * @author awaeza
 */
public boolean outsideCapabilityTileTextDisplayed() {
	return getTextUsingXpath(strOutsideCapabilityTileTextXpath, "Static text outside capability tile is displayed in review upgrade page")
			.equalsIgnoreCase(STATIC_TEXT_UPGRADE);
}

/**
* This method is used to validate Recent Activity Section in Dashboard Page
*
* @return boolean
* @author awaeza
*/
public boolean recentActivityDisplayed() {

return isElementPresentUsingXpath(strRecentActivityXpath, lplCoreConstents.HIGH, "Recent Activity Section is displayed");

	
}

/**
* This method is used to validate two recent activities in Dashboard Page
*
* @return boolean
* @author awaeza
*/
public boolean twoRecentActivitiesDisplayed() {

return isElementPresentUsingXpath(strRecentActivitiesXpath, lplCoreConstents.HIGH, "Two Recent Activities are displayed");

	
}

/**
	 * This method is used to click on see for all this group hyperlink
	 *
	 * @return boolean
	 * @author awaeza
	 */
		
public boolean clickSeeForAllThisGroupHyperlink() {
		
return clickElementUsingXpath(strSeeForAllThisGroupHyperlinkXpath,"Complete Upgrade button is clicked");
		
			}

/**
* This method is used to validate new activity tab
*
* @return boolean
* @author awaeza
*/
public boolean activityTabDisplayed() {

return isElementPresentUsingXpath(strActivityTabXpath, lplCoreConstents.HIGH, "New Activity tab is displayed");

	
}





}