package com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TAFSReadOnlyGroupDisabledUserStepDef extends CommonStepDef {
	Common commonMethods = new Common(driver);

	@When("^I select a CORP Rep$")
	public void selectCORPRep() {
		boolean blnResult = tafsAdminGroupPage.selectRep();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Rep from Search results",
				"User should able to Select Rep from Search results ",
				"Successfully able to Select Rep from Search results ",
				"Failed to Select Rep from Search results  :" + commonMethods.strError);
	}

	@When("^I select a Non CORP Rep$")
	public void selectNonCORPRep() {
		boolean blnResult = tafsAdminGroupPage.selectRep();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Rep from Search results",
				"User should able to Select Rep from Search results ",
				"Successfully able to Select Rep from Search results ",
				"Failed to Select Rep from Search results  :" + commonMethods.strError);
	}

	@Then("^I dont see the hint message - What are default flat fees\\?$")
	public void hintMessageForWhatAreDefaultFlatFee() {
		boolean blnResult = tafsAdminGroupPage.hintMessageForWhatAreDefaultFlatFeeDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that What are default flat fees hint message is not displayed",
				"User should not be able to see What are default flat fees hint message",
				"Successfully not able to see What are default flat fees hint message",
				"User can see What are default flat fees hint message : " + commonMethods.strError);
	}

	@Then("^I dont see the hint message - What is my default\\?$")
	public void hintMessageForWhatIsMyDefault() {
		boolean blnResult = tafsAdminGroupPage.hintMessageForWhatIsMyDefaultFlatFeeDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that What is my default hint message is not displayed",
				"User should not be able to see What is my default hint message",
				"Successfully not able to see What is my default hint message",
				"User can see What is my default hint message : " + commonMethods.strError);
	}

	@Then("^I dont see the hint message - How would I edit a schedule\\?$")
	public void hintMessageForHowWouldIEditASchedule() {
		boolean blnResult = tafsAdminGroupPage.hintMessageForHowWouldIEditAScheduleDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that How would I edit a schedule hint message is not displayed",
				"User should see How would I edit a schedule hint message",
				"Successfully not able to see How would I edit a schedule hint message",
				"User can see How would I edit a schedule hint message : " + commonMethods.strError);
	}

	@Then("^I dont see the section - Create Your First Flat Fee$")
	public void isCreateYourFirstFlatFeeScetionDisplayed() {
		boolean blnResult = tafsAdminGroupPage.createYourFirstFlatFeeScetionDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Create Your First Flat Fee section is not displayed",
				"User should not see Create Your First Flat Fee section",
				"Successfully not able to see Create Your First Flat Fee section ",
				"User can see Create Your First Flat Fee section : " + commonMethods.strError);
	}

	@Then("^I verify that following option is not listed - Select or Manage Platform Default$")
	public void isSelectOrManagePlatformDefaultOptionDisplayed() {
		boolean blnResult = tafsAdminGroupPage.selectOrManagePlatformDefaultOptionDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Select or Manage Platform Default option is not displayed",
				"User should not see Select or Manage Platform Default option ",
				"Successfully not able to see Select or Manage Platform Default option  ",
				"User can see Select or Manage Platform Default option  : " + commonMethods.strError);
	}

	@Then("^I verify that following column is not listed in grid - Default Platform$")
	public void isDefaultPlatformColumnDisplayed() {
		boolean blnResult = tafsAdminGroupPage.defaultPlatformColumnDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Default Platform column is not displayed", "User should not see Default Platform column",
				"Successfully not able to see Default Platform column ",
				"User can see Default Platform column : " + commonMethods.strError);
	}
}