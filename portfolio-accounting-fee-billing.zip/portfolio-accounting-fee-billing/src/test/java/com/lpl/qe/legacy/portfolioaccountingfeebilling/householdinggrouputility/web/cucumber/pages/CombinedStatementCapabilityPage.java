package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreUtil;

public class CombinedStatementCapabilityPage extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 872;
	Map<String, HashMap<String, String>> pageObjectMap;
	String strDeleteCapabilityXpath;
	String strEditCSiconXpath;
	String strPopUpDeleteCScapabilityTitleXpath;
	String strPopUpDeleteCScapabilitySubHeaderXpath;
	String strDeleteCSbutton1Xpath;
	String strDeleteCSbutton2Xpath;
	String strCStileXpath;
	String strDeleteCSStreamlinePageTitleXpath;
	String strCombinedStatementsubgroupDashboardXpath;
	String strCombinedStatementSingleDashboardXpath;
	String strNewCStileReviewHHXpath;
	String strNewCSmailingAddressReviewHHXpath;
	String strNewCSstatusLabelReviewHHXpath;
	String strClickCreateNewCSOverlayModalXpath;
	String strEditHHCombinedStatemnetDetailspageXpath;
	String strEditHouseholdCombinedStatemnetDetailsSectionHeaderXpath;
	String strHouseholdCombinedStatemnetNameXpath;
	String strCombinedStatementLinkXpath;
	String strEditHouseholdCombinedStatementAccountTileXpath;
	String strSelectPrimaryCombinedStatementXpath;
	String strClickCSDoneEditingButtonXpath;
	String strReviewHouseholdCombinedStatemnetDetailsPageXpath;
	String strReviewHouseholdCombinedStatemnetPrimaryAccXpath;
	String strCreateCombinedStatementBtnXpath;
	String strCombinedStatementCreatedXpath;
	String strCombinedStatementEditIconXpath;
	String strTitleNewCombinedStatementSubgroupPageXpath;
	String strCSsubgroupSectionTitleXpath;
	String strDeleteCSsubgroupXpath;
	String strYesDeleteCSsubgroupXpath;
	String strDoNotDeleteCSsubgroupXpath;
	String strCombinedStatementSubgroupTileXpath;
	String strCombinedStatementTitleInTrackerXpath;
	String strCombinedStatementNameInTrackerXpath;
	//String streditCombinedStatementalertpopupxpath;
	String strclickEditcombinedstatementbuttonxpath;
	String strEditCombinedstatementpagexpath;
	String strEditCombinedStatementAlertTextXpath;
	String strCombinedStatementContentslabelXpath;
	String strOverlayModalContentsPanelXpath;
	String strClickOverlayModalContentsPanelXpath;
	String strForACombinedStatementSubgroupXpath;
	String strSetupCombinedStatementSubgroupXpath;
	String strNoOfClientsInSetUpCombinedStatementPageXpath;
	String strMoveToXpath;
	String strNewCombinedStatementXpath;
	String strSeperateClientCombinedStatementXpath;
	String strEachCombinedStatementNameXpath;
	String strEachCombinedStatementClientNameXpath;
	String strExistingCSdropdownOptionXpath;
	String strNewCombinedStatementNameXpath;
	String strExistingCSnameXpath;
	String strClickExistingCSdropdownMenuXpath;
	String strCreateCombinedStatementSubgroupXpath;
	String strNewCombinedStatementSubgroupDetailsPageXpath;
	String strClickEditCSsubgroupXpath;
	String strSetUpCombinedStatementPageXpath;
	String strContentsAndAccountsChevronXpath;
	String strAccountsChevronXpath;
	String strAccountListSectionXpath;
	String strCSpageHeaderXpath;
	String strCSsubHeaderXpath;
	String strCSbuttonOneXpath;
	String strCSbuttonTwoXpath;
	String strPageVerbiageXpath;
	String strSelectPrimaryForMultipleCombinedStmtXpath;
	String strReviewCSSubgroupDetailsPagexpath;
	String strStatementTilesReviewPageXpath;
	String strNewCSsubgroupCreateCSxpath;
	String strContentsLabelXpath;
	String strCategotyLevelEditXpath;
	String strEditCombinedStatementAlertEditOptionXpath;
	String strEditCombinedStatementAlertDeleteOptionXpath;
	String strDeleteCombinedStatementAlertPopupXpath;
	String strCombinedStatementAlertYesDeleteOptionXpath;
	String strCombinedStatementAlertNoDeleteOptionXpath;
	String strDeleteCombinedStatementAlertTextXpath;
	String strTitleEditCombinedStmtXpath;
	String strCombinedStmtSummaryBannerFieldsXpath;
	String strEditOrDeleteCScapabilityXpath;
	String strPopUpDeleteCScapabilityXpath;
	String strCombinedStmtOverlayModalXpath;
	String strClickAddClientExistingStatementXpath;
	String strCSPromptMessageXpath;
	String strOverlayPageCloseBtnXpath;
	String strCSEditModalClickNoOptionXpath;
	String strCSEditModalClickYesOptionXpath;
	String strDeleteCombinedStatemnetTitleBannerXpath;
	String strErrorMsgOutsideAccountCombinedStatementXpath;
	String strNoOfCombinedStmtDashboardXpath;
	String strDashboardCStileXpath;
	String strConfirmationPageXpath;
	String strRemoveClientButtonXpath;
	String strCombineStatementReviewXpath;
	String strCombineStatementEditBtnXpath;
	String strEditCombineStatementNameXpath;
	String strCombinedStatementTileXpath;
	String strHouseholdCapabilityTrackerNameXpath;
	String strHouseholdCapabilityTrackerChevronXpath;
	String strSubGroupCombineStatementTileXpath;
	String strSubgroupCombineStatementStatusXpath;
	String strCancelAndReturnLinkCombinedStatementXpath;
	String strCombinedStatementRadioButtonXpath;
	String strDoneEditingButtonXpath;
	String strCancelReturnCombinedStatementXpath;
	String strCombinedStatementRemovemodalXpath;
	String strCombinedStatementRemoveModalHeaderXpath;
	String strCombinedStatementRemoveModalSubHeaderXpath;
	String strAccountDetailsInRemoveModalXpath;
	String strSectionHeaderCombinedStatementGroupXpath;
	String strCancelHyperlinkXpath;
	String strRemoveAccountsAndSetUpCombinedStatementButtonXpath;
	String strAddClientToAnExistingStatementXpath;
	String strSubGroupCombinedStatementHeaderXpath;
	String strSubGroupCombinedStatementXpath;
	String strCSEditModalContentsChevronXpath;
	String strEditCSCloseModalButtonXpath;
	String strYesButtonCSCloseModalXpath;
	String strEditCombinedStatementAlertPopupXpath;
	String strHHCombinedStatementSubmitButtonXpath;
	String strTitleSetUpCombinedStatementPageXpath;
	String strTrackerCombinedStatementSubgroupNameXpath;
	String strTextOnPromptXpath;
	String strSelectCSOverlayPageXpath;
	String strEditButtonCSSubgroupXpath;
	String strNoOfCombinedStatementXpath;
	String strSubgroupCombinedStatementRadioButtonXpath;
	String strCombinedStatementContentsChevronXpath;
	String strCombinedStatementAccountDetailsXpath;
	String strCombinedStatementClientAccountPanelXpath;
	String StrCombinedStatementAccountNameXpath;
	String StrCombinedStatementAccountClassXpath;
	String StrCombinedStatementAccountNumberXpath;
	String StrCombinedStatementAccountValueXpath;
	String strmodalmessagexpath;
	String strokbuttonxpath;
	String strEditCombinedStatementPageSingleStmtXpath;
	String strColumnNamesCSXpath;
	String strCombinedStatementTBDXpath;
	String strCSNameTrackerXpath;
	String strCSNameTitleXpath;
	String strCSsubgroupActiveLabelXpath;
	String strsubgroupcombinedstatementtileXpath;
	
	public static final String NEW_COMBINED_STMT_PAGE_HEADER = "New Combined Statement Subgroup(s) Details";
	public static final String NEW_COMBINED_STMT_PAGE_HEADER_SINGLE = "New Combined Statement Details";
	public static final String NEW_COMBINED_STMT_PAGE_SUBHEADER = "HOW WOULD YOU LIKE TO SET UP THE COMBINED STATEMENT(S)?";
	public static final String EDIT_COMBINED_STMT_PAGE_TITLE = "Edit Combined Statement Subgroup(s) Details";
	public static final String COMBINED_STMT_NAME = " HOUSEHOLD COMBINED STATEMENT";
	public static final String DELETE_PANEL_HEADER = "Deletion of"+testData.get("GroupName")+" COMBINED STATEMENT successfully completed!";
	public static final String SETUP_COMBINED_STMT_PAGE_TITLE = "Set up Combined Statements";
	public static final String PROMPT_TEXT_LEAVE_CS = "Are you sure you want to leave this page? If you do, all data entered will be lost.";
	public String COMBINED_STATEMENT_PRIMARY_REMOVE_MSG = "By removing this client, a primary account will no longer be associated with " + testData.get("Groupname") + " COMBINED STATEMENT subgroup. Please select a new primary account for this subgroup to continue";

	public CombinedStatementCapabilityPage(WebDriver driver) {
		super(driver);
		lplCoreUtil = new LPLCoreUtil();
		/** Fetching page objects from FARM */
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		checkForLocatorTypeAndInitializeFields(pageObjectMap, this.getClass().getDeclaredFields(), PAGE_IDENTIFIER);
	}
	
	/**
	 * This method is used to validate pop-up message on Edit Combined Statement
	 * page after clicking on Delete capability option
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validatePopUpMessage_DeleteCScapability() {
		return isElementPresentUsingXpath(strPopUpDeleteCScapabilityXpath, "Pop-Up message is displayed");	}

	/**
	 * This method is used to verify pop-up title after clicking on Delete
	 * capability on Edit Combined Statement page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validatePopUpTitle_DeleteCScapability() {
		String str1 = getTextUsingXpath(strPopUpDeleteCScapabilityTitleXpath, "Pop-Up Title");
		String str2 = testData.get("popUpTitle") + testData.get("HHname") + testData.get("CombinedStatement");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to verify pop-up sub header after clicking on Delete
	 * capability on Edit Combined Statement page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validatePopUpSubHeader_DeleteCScapability() {
		return getTextUsingXpath(strPopUpDeleteCScapabilitySubHeaderXpath, "Pop-Up Title")
				.equalsIgnoreCase(testData.get("popUpSubHeader"));
	}

	/**
	 * This method is used to validate two side by side button on Pop-up after
	 * clicking on Delete capability option
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validatePopUpButtons_DeleteCScapability() {
		return isElementPresentUsingXpath(strDeleteCSbutton1Xpath, "No, Do Not Delete Combined Statement button")
				&& isElementPresentUsingXpath(strDeleteCSbutton2Xpath, "Yes, Delete Combined Statement button");
	}
	
	/**
	 * This method is used to click on Edit Combined Statement icon on Streamline
	 * Page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickCSEditIcon_StreamlinePage() {
		return clickElementUsingXpath(strEditCSiconXpath, "Edit Combined Statement icon clicked on streamline page");
	}

	/**
	 * This method is used to validate Delete Capability option on Edit Combined
	 * Statement page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateDeleteCapability() {
		return isElementPresentUsingXpath(strDeleteCapabilityXpath, "Delete Capability Option displayed");
	}

	/**
	 * This method is used to click on Delete Capability option
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickDeleteCapability() {
		return clickElementUsingXpath(strDeleteCapabilityXpath, "Delete Capability option clicked");

	}
	
	/**
	 * This method is used to click on Yes Delete combined statement Capability option
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickDeleteCSCapability() {
		return clickElementUsingXpath(strDeleteCSbutton2Xpath, "Delete Combined Statement Capability option clicked");

	}
	
	/**
	 * This method is used to validate CS capability tile is not present on Streamline page after deleting the capability
	 * Statement page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean verifyCStileNotPresent() {
		return isElementNotPresentUsingXpath(strCStileXpath);

	}
	
	/**
	 * This method is used to validate Deleted combined statement title on Streamline Confirmation page
	 * Statement page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean verifyStreamlinePageTitle_DeleteCS() {
		return getTextUsingXpath(strDeleteCSStreamlinePageTitleXpath, "Pop-Up Title")
				.equalsIgnoreCase((testData.get("HHname") + testData.get("CombinedStatement")+ testData.get("DeleteCStitle")));
	}
	
	/**
	 * This method is used to click on No Do Not Delete CS Capability
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickDoNoDeleteCSCapabilityOption() {
		
		return clickElementUsingXpath(strDeleteCSbutton1Xpath, "Delete Combined Statement Capability option clicked");

	}
	
	/**
	 * This method is used to validate Delete CS pop-up closes after clicking on No do not delete combined statement
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean verifyDeleteCSpopUpCloses() {
		return isElementPresentUsingXpath(strEditOrDeleteCScapabilityXpath, "Edit or Delete tile for Combined Statement");

	}
	
	/**
	 * This method is used to click on Edit option for multiple subgroup combined statement 
	 * in household dashboard  page
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickEditOptionCombinedStatementDashboardPage() {
		wait(7);
		return clickElementUsingXpath(strCombinedStatementsubgroupDashboardXpath,
				"Click on Edit for multiple subgroup combined statement from dashboard page");
		
	}
	
	/**
	 * This method is used to click on Edit option for multiple subgroup combined statement 
	 * in household dashboard  page
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickEditOptionCombinedStatementSingleDashboardPage() {
		return clickElementUsingXpath(strCombinedStatementSingleDashboardXpath,
				"Click on Edit pencil icon for single combined statement from dashboard page");
		
	}
	
	/**
	 * This method is used to validate Delete CS pop-up closes after clicking on No do not delete combined statement
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateNewCStile_ReviewHHPage() {
		return isElementPresentUsingXpath(strNewCStileReviewHHXpath, "New CS Tile displayed on Review HH page");

	}
	
	/**
	 * This method is used to validate mailing address on CS tile on Review HH page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateNewCSmailingAddress_ReviewHHPage() {
		return isElementPresentUsingXpath(strNewCSmailingAddressReviewHHXpath, "New CS mailing address displayed on Review HH page");

	}
	
	/**
	 * This method is used to validate status label as Active upon submission on New CS tile on Review HH page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateNewCSstatusLabel_ReviewHHPage() {
		return isElementPresentUsingXpath(strNewCSstatusLabelReviewHHXpath, "New CS status label displayed on Review HH page");

	}
	
	/**
	 * This method is used to click on Create a New Combined Statement for Client option on CS Overlay Modal
	 * 
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickCreateNewCS_OverlayModal() {
		return clickElementUsingXpath(strClickCreateNewCSOverlayModalXpath,"Create a New Combined Statement for client option clicked");
		
	}
	
	/**
	 * This method is used to check if Edit Household Combined Statement Details
	 * Page is displayed
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean editHouseholdCombinedStatementDetailsPageDisplayed() {
		return isElementPresentUsingXpath(strEditHHCombinedStatemnetDetailspageXpath, lplCoreConstents.HIGH,
				"Edit Household Combined Statement Details Page Displayed");

	}
	
	/**
	 * This method is used to Validate section Header on Edit Household Combined
	 * Statement Details page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateEditHouseholdSectionHeader() {
		return (getTextUsingXpath(strEditHouseholdCombinedStatemnetDetailsSectionHeaderXpath,
				"Edit HH Combined Statemnet Details Section Header").equalsIgnoreCase(NEW_COMBINED_STMT_PAGE_HEADER_SINGLE));
	}

	
	/**
	 * This method is used to Validate Combined Statement Name on Edit Household
	 * Combined Statement Details page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateHouseholdCombinedStatementName() {
		String[] clientName = testData.get("firstName").split(" ");
		System.out.println(getTextUsingXpath(strHouseholdCombinedStatemnetNameXpath, "Household Combined Statement Name"));
		System.out.println(clientName[1]+COMBINED_STMT_NAME);
		return (getTextUsingXpath(strHouseholdCombinedStatemnetNameXpath, "Household Combined Statement Name").equalsIgnoreCase(clientName[1]+COMBINED_STMT_NAME));
	}
	
	/**
	 * This method is used to click on Combined Statement streamline
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickCombinedStatement() {
		waitTillVisibleUsingXpath(strCombinedStatementLinkXpath, "combinedstatementhyperlink");
		return clickElementUsingXpath(strCombinedStatementLinkXpath, "Click on Combined statement hyperlink");
	}

	
	/**
	 * This method is used to check edit combined statement alert popup is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean editCombinedStatementalertpopupDisplayed() {
		
		return isElementPresentUsingXpath(strEditCombinedStatementAlertPopupXpath, lplCoreConstents.HIGH,
				"Edit combined statement alert popup Displayed");
	} 


	/**
	 * This method is used to Validate is Contents panel is expanded on Edit
	 * Household Combined Statement Details page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateEditHouseholdCombinedStatementContentsPanelExpanded() {
		//String strEditHouseholdCombinedStatemnetAccountTileXpath = "//div[@class='card client-account-tile']//div[@class='card-body']";
		return isElementPresentUsingXpath(strEditHouseholdCombinedStatementAccountTileXpath, lplCoreConstents.HIGH,
				"Edit Household Combined Statement Details Page Displayed");
	}
	
	/**
	 * This method is used to click on radio button on Edit Combined Statement
	 * Details page
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean selectRadioButton() {

		return clickElementUsingXpath(strSelectPrimaryCombinedStatementXpath,
				"Radio Button on Edit Combined Statement Details page is clicked");

	}
	
	/**
	 * This method is used to click on Done Editing Button on Edit Combined
	 * Statement Details page
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickCombinedStatementDoneEditing() {
		return clickElementUsingXpath(strClickCSDoneEditingButtonXpath,
				"Done Editing Button on Edit Combined Statement Details page is clicked");
	}
	
	/**
	 * This method is used to check if Review Household Combined Statement Details
	 * Page is displayed
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean reviewHouseholdCombinedStatementDetailsPageDisplayed() {
		return isElementPresentUsingXpath(strReviewHouseholdCombinedStatemnetDetailsPageXpath, lplCoreConstents.HIGH,
				"Edit Household Combined Statement Details Page Displayed");

	}
	
	/**
	 * This method is used to check if Primary Account Information is displayed
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validatePrimaryAccountInformation() {
		return isElementPresentUsingXpath(strReviewHouseholdCombinedStatemnetPrimaryAccXpath, lplCoreConstents.HIGH,
				"Primary Account Information Displayed");

	}
	
	/**
	 * This method is used to click on Create Combined statement button
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickCreateCombinedStatementBtn() {
		return clickElementUsingXpath(strCreateCombinedStatementBtnXpath, "Create combined statement");

	}
	
	/**
	 * This method is used to verify Combined Statement Capability is created
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateCombinedStatementCapability() {
		return isElementPresentUsingXpath(strCombinedStatementCreatedXpath, lplCoreConstents.HIGH,
				"Primary Account Information Displayed");

	}
	
	/**
	 * This method is used to click on Edit Icon for combined statement in confirmation page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickCombinedStatementEditIcon() {
		return clickElementUsingXpath(strCombinedStatementEditIconXpath, "Accounts panel chevron is clicked");
	}

	
	/**
	 * This method is used to validate combined statement section title on
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateCSsectionTitle() {
		return isElementPresentUsingXpath(strCSsubgroupSectionTitleXpath, "Displayed combined statement section title");
	}
	
	/**
	 * This method is used to click on Delete button on Edit Combined Statement subgroups page
	 * Page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */
	
	public boolean clickDeleteCSsubgroupsButton() {
		wait(5);
		return clickElementUsingXpath(strDeleteCSsubgroupXpath, "Delete combined statement subgroups button is clicked");
	}

	
	/**
	 * This method is used to check if New combined statement details page is
	 * displayed
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean newHouseholdCombinedStatementDetailsPageDisplayed() {
		return isElementPresentUsingXpath(strTitleNewCombinedStatementSubgroupPageXpath, lplCoreConstents.HIGH,
				"New Household Combined Statement Displayed");
	}
	
	
	/**
	 * This method is used to click on Yes Delete Combined Statement button on Edit Combined Statement subgroups page
	 * Page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickYesDeletebutton_CSsubgroup() {
		return clickElementUsingXpath(strYesDeleteCSsubgroupXpath, "Delete combined statement subgroups button is clicked");
	}
	
	/**
	 * This method is used to click on NO Delete Combined Statement button on Edit Combined Statement subgroups page
	 * Page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickDoNotDeletebutton_CSsubgroup() {
		wait(5);
		return clickElementUsingXpath(strDoNotDeleteCSsubgroupXpath, "Delete combined statement subgroups button is clicked");
	}

	/**
	 * This method is used to validate combined statement tile is not present on Streamline/Confirmation page after deleting CS subgroups
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateCombinedStatementTileNotPresent() {
		
		return isElementNotPresentUsingXpath(strCombinedStatementSubgroupTileXpath);
	}
	
	/**
	 * This method is used to validate Combined Statement Title in Capability
	 * Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCapabilityTrackerCombinedStatementTitle() {
		return isElementPresentUsingXpath(strCombinedStatementTitleInTrackerXpath, lplCoreConstents.HIGH,
				"Combined Statement Title displayed");

	}
	
	/**
	 * This method is used to validate Combined Statement Name in Capability Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCapabilityTrackerCombinedStatementName() {
		String[] clientName = testData.get("firstName").split(" ");
		return (getTextUsingXpath(strCombinedStatementNameInTrackerXpath,
				"Capability Tracker Combined Statement Name").equalsIgnoreCase(clientName[1] + COMBINED_STMT_NAME));

	}
	
	/**
	 * This method is used to check edit combined statement alert popup is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
/*	public boolean editCombinedStatementAlertPopupDisplayed() {
		
		return isElementPresentUsingXpath(streditCombinedStatementalertpopupxpath, lplCoreConstents.HIGH,
				"Edit combined statement alert popup Displayed");
	}  */
	
	
	/**
	 * This method is used to click on Edit combined statement Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickEditCombinedStatementButton() {

		return clickElementUsingXpath(strclickEditcombinedstatementbuttonxpath,
				"Edit combined statement Button is clicked");

	}
	
	/**
	 * This method is used to check if Edit combined statement page is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean EditcombinedstatementPageDisplayed() {
		return isElementPresentUsingXpath(strEditCombinedstatementpagexpath, lplCoreConstents.HIGH,
				"Edit combined statement Page Displayed");

	}
	
	/**
	 * This method is used to check if Edit combined statement page is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean EditcombinedstatementPageDisplayedForSingleStmt() {
		System.out.println(getTextUsingXpath(strEditCombinedStatementPageSingleStmtXpath,"Combined Statement Total Account Value"));
		return(getTextUsingXpath(strEditCombinedStatementPageSingleStmtXpath,"Combined Statement Total Account Value").equals("Edit Household Combined Statement Details"));
		//return isElementPresentUsingXpath(strEditCombinedStatementPageSingleStmtXpath, lplCoreConstents.HIGH,	"Edit combined statement Page Displayed");

	}
	
	
	/**
	 * This method is used to check edit combined statement alert message text is
	 * displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean editCombinedStatementAlertTextDisplayed() {
		
		return isElementPresentUsingXpath(strEditCombinedStatementAlertTextXpath, lplCoreConstents.HIGH,
				"Edit combined statement alert message Displayed");

	}
	
	
	
	/**
	 * This method is used to validate Total Account Value in Dollars in Combined Statement Section
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeTotalAccountValueUnderCombinedStatementSection() {
		return (getTextUsingXpath(strCombinedStatementContentslabelXpath,"Combined Statement Total Account Value")).toString().contains("$");
	
}
	
	/**
	 * This method is used to validate Total Number Of Accounts in Combined Statement Section
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeTotalNumberOfAccountsUnderCombinedStatementSection() {
	return (getTextUsingXpath(strCombinedStatementContentslabelXpath,"Combined Statement Total Number of Accounts")).toString().contains("ACCT");
	
}

	/**
	 * This method is used to validate contents panel is displayed for each group on combined statement edit modal
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateContentsPanel_OverlayModal() {
		
		if(isElementPresentUsingXpath(strOverlayModalContentsPanelXpath, "Contents Panel displayed on Combined statement overlay modal"))
		{
			return clickElementUsingXpath(strClickOverlayModalContentsPanelXpath,"Contents Panel clicked on Combined statement overlay modal");
		}
		else
			return false;
	}
	
	/**
	 * This method is used to click on click on For A Combined Statement Subgroup(s)
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickCombinedStatementSubgroup() {
		return clickElementUsingXpath(strForACombinedStatementSubgroupXpath,
				"For A Combined Statement Subgroup(s) is clicked");
	}

	/**
	 * This method is used to click on SET UP COMBINED STATEMENT SUBGROUP(S) button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickSetupCombinedStatementSubgroup() {
		return clickElementUsingXpath(strSetupCombinedStatementSubgroupXpath,
				"SET UP COMBINED STATEMENT SUBGROUP(S) button is clicked");
	}
	
	/**
	 * This method is used to click on New Combined Statement option on tile
	 * breakdown on Set Up combined Statement page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickNewCombinedStatementOption() {
		boolean result=false;;
		//String noOfClientsInSetUpCombinedStatementPageXpath= "//section[@title='Client title']/div";
		String noOfCombinedStatementSubgroup = testData.get("noOfSubgroupToBeCreated");
		int noOfClients =   getWebElementsSizeUsingXpath(strNoOfClientsInSetUpCombinedStatementPageXpath);
		if(Integer.parseInt(noOfCombinedStatementSubgroup)<=noOfClients) {
			for(int i=1; i<=Integer.parseInt(noOfCombinedStatementSubgroup)-1; i++) {
				result = (clickElementUsingXpath(strMoveToXpath.replace("x", Integer.toString(i)), "Move To button clicked") &&
				clickElementUsingXpath(strNewCombinedStatementXpath.replace("x",  Integer.toString(i)), "Click on New Combined statement"));
			}
			return result;
		}else {
			return result;
		}
	}
	
	/**
	 * This method is used to validate separate Client CS subgroups are created
	 * after clicking on New Combined Statement dropdown
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateSeparateClientCSsubgroups() {
		int noOfStatements = getWebElementsSizeUsingXpath(strSeperateClientCombinedStatementXpath);
		if(noOfStatements-1==Integer.parseInt(testData.get("noOfSubgroupToBeCreated"))){
			return true;
		}else {
			return false;
		}
		//return isElementPresentUsingXpath(strSeperateClientCombinedStatementXpath, lplCoreConstents.HIGH, "Client one CS Subgroup")
			//	&& isElementPresentUsingXpath(strSeperateClientCS2Xpath, lplCoreConstents.HIGH,
				//		"Client two CS Subgroup");

	}
	
	/**
	 * This method is used validate CS Subgroups name is by default same as client
	 * name
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateCSsubgroupName() {
		int flag = 0;
		int noOfStatements = getWebElementsSizeUsingXpath(strSeperateClientCombinedStatementXpath);
		for(int i=1; i<=noOfStatements-1; i++) {
			String combinedStatementName = getTextUsingXpath(strEachCombinedStatementNameXpath.replace("x", Integer.toString(i)),"Each Combined Statement Name");
			for(int j=1; j<noOfStatements; j++) {
				String clientName = getTextUsingXpath(strEachCombinedStatementClientNameXpath.replace("x", Integer.toString(i)),"Each Combined Statement Name");
				if(combinedStatementName.contains(testData.get("groupName")) || combinedStatementName.contains(clientName)) {
					//return true;
					flag = 1;
					break;
				}
				
			}
			}
		if(flag==1) {
			return true;
		}else {
			return false;
			
		}
		//String strCSsubgroup1Name = testData.get("Subgroup1Name");
		//String strCSsubgroup2Name = testData.get("Subgroup2Name");
		//return isElementPresentUsingXpath(strCSsubgroup1xpath.replace("xxx", strCSsubgroup1Name), lplCoreConstents.HIGH,
			//	"CS Subgroup2 Name")
				//&& isElementPresentUsingXpath(strCSsubgroup2xpath.replace("xxx", strCSsubgroup2Name),
					//	lplCoreConstents.HIGH, "CS Subgroup2 Name");
	}
	
	/**
	 * This method is used to click on dropdown menu for existing C/S
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickExistingCSdropdownMenu() {
		return clickElementUsingXpath(strClickExistingCSdropdownMenuXpath,
				"New Combined Statement is clicked for mentioned client");
	}
	
	/**
	 * This method is used to validate New Combined Statement as dropdown option for
	 * existng combined statement
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateExistingCS_DropdownOption() {
		return isElementPresentUsingXpath(strExistingCSdropdownOptionXpath, lplCoreConstents.HIGH,
				"New Combined Statement option is Displayed");
	}
	
	/**
	 * This method is used to validate New Combined Statement Name as dropdown
	 * option for existng combined statement
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateExistingCS_dropdownOption_NewCSname() {
		return isElementPresentUsingXpath(strNewCombinedStatementNameXpath, lplCoreConstents.HIGH,
				"New Combined Statement option is Displayed");
	}
	
	/**
	 * This method is used to validate existing Combined Statement Name as dropdown
	 * option for new combined statement
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateNewCS_DropdownMenu_ExistingCSname() {
		return isElementPresentUsingXpath(strExistingCSnameXpath, lplCoreConstents.HIGH,
				"New Combined Statement option is Displayed");
	}
	
	/**
	 * This method is used to click on COMPLETE DETAILS FOR 1 COMBINED STATEMENT
	 * button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickCreateCombinedStatementSubgroup() {
		return clickElementUsingXpath(strCreateCombinedStatementSubgroupXpath,
				"COMPLETE DETAILS FOR 1 COMBINED STATEMENT button is clicked");
	}
	
	/**
	 * This method is used to Validate New Combined Statement Subgroup(s) Details
	 * Page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean newCombinedStatementSubgroupDetailsPage() {
		return isElementPresentUsingXpath(strNewCombinedStatementSubgroupDetailsPageXpath, lplCoreConstents.HIGH,
				"New Combined Statement Subgroup(s) Details page is Displayed");

	}
	
	/**
	 * This method is used to click on Edit CS subgroup pencil icon on New Combined
	 * Statement Subgroup(s) Details page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickEditCSsubgroupButton() {
		return clickElementUsingXpath(strClickEditCSsubgroupXpath, "Edit CS Subgroup button is clicked");

	}
	
	/**
	 * This method is used to validate Set Up Combined Statement Page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateSetUpCombinedStatementPage() {
		return clickElementUsingXpath(strSetUpCombinedStatementPageXpath, "Edit CS Subgroup button is clicked");

	}
	
	/**
	 * This method is used to validate accounts section under contents and accounts panel chevron on Set Up
	 * combined Statement page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickContentsandAccountsChevron_CSSetUpCSpage() {
		String noOfStatements = testData.get("noOfSubgroupToBeCreated");
		boolean blnResult = false;
		for(int i=1; i<=Integer.parseInt(noOfStatements); i++) {
			//String strContentsAndAccountsChevronXpath = "//section[@class='container-fluid']/div/section[1]/div[x]/app-cs-subgroup/div/div/div[2]/app-combined-statement-tile-wrapper/section/div/div/div[2]//button[@title='client and account  detail']/i";
			clickElementUsingXpath(strContentsAndAccountsChevronXpath.replace("x", Integer.toString(i)),
					"Contents and accounts chevron is clicked on Set up CS page");
			//String strAccountsChevronXpath = "//section[@class='container-fluid']/div/section[1]/div[x]/app-cs-subgroup/div/div/div[2]/app-combined-statement-tile-wrapper/section/div/div/div[2]//section[@class='card-body']/div[2]/button/i";
			//clickElementUsingXpath(strAccountsChevronXpath.replace("x", Integer.toString(i)),"Accounts chevron is clicked on Set up CS page");
			//String strAccountListSectionXpath = "//section[@class='container-fluid']/div/section[1]/div[x]/app-cs-subgroup/div/div/div[2]/app-combined-statement-tile-wrapper/section/div/div/div[2]//section[@class='card-body']/div[2]/div[1]";
			if(isElementPresentUsingXpath(strAccountListSectionXpath.replace("x", Integer.toString(i)), "Displayed combined statement section title")) {
				blnResult = true;
			}else {
				blnResult = false;
				break;
			}
			
		}
		return blnResult;

	}
	
	/**
	 * This method is used to validate account panel details on Set Up Combined
	 * Statement page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
/*	public boolean validateAccountDetailsPanel_CSSetUpCSpage() {
		return isElementPresentUsingXpath(strCSaccountPanelXpath, "Displayed combined statement section title");
	} */

	
	/**
	 * This method is used to validate New Combined Statement Subgroup(s) Details
	 * Page Header statement
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateNewCSsubgroupsPageHeader() {
		return (getTextUsingXpath(strCSpageHeaderXpath,
				"New Combined Statement Subgroup(s) Details Page Header Displayed").equalsIgnoreCase(NEW_COMBINED_STMT_PAGE_HEADER));
	}
	
	/**
	 * This method is used to validate New Combined Statement Subgroup(s) Details
	 * Page Sub-Header statement
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateNewCSsubgroupsPageSubHeader() {
		return (getTextUsingXpath(strCSsubHeaderXpath,
				"New Combined Statement Subgroup(s) Details Page Sub-Header Displayed").equalsIgnoreCase(NEW_COMBINED_STMT_PAGE_SUBHEADER));

	}
	
	/**
	 * This method is used to validate Button 1-For Entire Household on New Combined
	 * Statement Subgroup(s) Details page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateNewCSsubgroupsPageButton1() {
		return isElementPresentUsingXpath(strCSbuttonOneXpath, lplCoreConstents.HIGH, "Button 1 displayed");

	}

	/**
	 * This method is used to validate Button 2-For a Combined Statement Subgroup(s)
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateCSsubgroupsPageButton2() {
		return isElementPresentUsingXpath(strCSbuttonTwoXpath, lplCoreConstents.HIGH, "Button 2 displayed");

	}
	
	/**
	 * This method is used to validate box verbiage below buttons on New Combined
	 * Statement Subgroup(s) Details page
	 *
	 * @return boolean
	 * @author vsharmastrCSbuttonOneXpath
	 */
	public boolean validateCSsubgroupsPageVerbiage() {
		return isElementPresentUsingXpath(strPageVerbiageXpath, lplCoreConstents.HIGH, "Box verbiage is displayed");

	}
	
	/**
	 * This method is used to select primary accounts for combined statement sub
	 * Groups
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectPrimaryAccountsForCSsubgroups() {
		String noOfStatements = testData.get("noOfSubgroupToBeCreated");
		boolean blnResult = false;
		for(int i=1; i<=Integer.parseInt(noOfStatements); i++) {
			//String strSelectPrimaryForMultipleCombinedStmtXpath = "//section[@class='container-fluid']/div/section[1]/div[x]/div[2]//div[@title='client and account details']//tr[1]/td/input";
			if(clickElementUsingXpath(strSelectPrimaryForMultipleCombinedStmtXpath.replace("x", Integer.toString(i+1)),
					"primary account for CS subgroup1 clicked")) {
				blnResult=true;
			}else {
				blnResult=false;
				break;
			}
		}
		return blnResult;
	}
	
	/**
	 * This method is used to Validate Review Combined Statement Subgroup(s) Details
	 * Page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeReviewCombinedStatementSubgroupDetailsPage() {
		return isElementPresentUsingXpath(strReviewCSSubgroupDetailsPagexpath, lplCoreConstents.HIGH,
				"Review Combined Statement Subgroup(s) Details page is Displayed");

	}
	
	/**
	 * This method is used to validate Review panel for each CS subgroup on Review
	 * Combined Statement Subgroup(s) Details page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateCSsubgroupReviewPanel() {
		return(getWebElementsSizeUsingXpath(strStatementTilesReviewPageXpath)==Integer.parseInt(testData.get("noOfSubgroupToBeCreated")));
	}
	
	/**
	 * This method is used to click on Create Combined Statement button on Review
	 * Combined Statement Subgroup(s) Details page statement
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickCreateCombinedStatementButton() {
		return clickElementUsingXpath(strNewCSsubgroupCreateCSxpath, "Create Combined Statement button is clicked");
	}
	
	/**
	 * This method is used to validate Contents Label sub-header on
	 * Streamline/Confirmation page for Combined Statement capability
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateContentsLabelSubHeader() {
		return isElementPresentUsingXpath(strContentsLabelXpath, "Displayed Contents label");
	}
	
	/**
	 * This method is used to click on Category-level edit option for C/S subgroups
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnCategoryLevelEditOptionForCS() {
		return clickElementUsingXpath(strCategotyLevelEditXpath, "Click on No option on promt message");
	}
	
	
	/**
	 * This method is used to check edit combined statement alert message options
	 * are displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean editCombinedStatementAlertOptionsDisplayed() {

		
		return (isElementPresentUsingXpath(strEditCombinedStatementAlertTextXpath, lplCoreConstents.HIGH,
				"Edit combined statement alert message Displayed" ) && isElementPresentUsingXpath (strEditCombinedStatementAlertEditOptionXpath, lplCoreConstents.HIGH,
			"Edit combined statement alert popup edit option Displayed")&& isElementPresentUsingXpath (strEditCombinedStatementAlertDeleteOptionXpath, lplCoreConstents.HIGH,
					"Edit combined statement alert popup delete option Displayed")); 
		
	}
	
	/**
	 * This method is used to click on delete option from edit combined statement
	 * alert popup
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickdeleteoptioneditcombinestatement() {

		//String strdeleteoptioneditCSxpath = "//button[contains(text(),' Delete ')]";
		return clickElementUsingXpath(strEditCombinedStatementAlertDeleteOptionXpath,
				"Delete option is clicked from edit combined statement alert popup");
	}

	/**
	 * This method is used to check delete combined statement alert popup is
	 * displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean deleteCombinedStatementalertpopupDisplayed() {

		//String strdeleteCStalertpopupxpath = "//div[@class='modal-body text-center']";
		return isElementPresentUsingXpath(strDeleteCombinedStatementAlertPopupXpath, lplCoreConstents.HIGH,
				"Delete combined statement alert popup Displayed");

	}

	/**
	 * This method is used to check delete combined statement alert message options
	 * are displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean deleteCombinedStatementalertoptionsDisplayed() {

//button[contains(text(),'NO')]
//button[contains(text(),'YES')]
			return (isElementPresentUsingXpath(strCombinedStatementAlertYesDeleteOptionXpath, lplCoreConstents.HIGH,
					"delete combined statement alert popup PROCEED TO DELETE option Displayed")
				
				&& isElementPresentUsingXpath(strCombinedStatementAlertNoDeleteOptionXpath, lplCoreConstents.HIGH,
						"delete combined statement alert popup GO BACK option Displayed"));
			

	}
	
	/**
	 * This method is used to check delete combined statement alert message text is
	 * displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean deleteCombinedStatementalerttextDisplayed() {

		//String strdeleteCSalerttextxpath = "//p[contains(text(),'Are you sure ')]";
		//*[contains(text(),'Are you sure ')]
		return isElementPresentUsingXpath(strDeleteCombinedStatementAlertTextXpath, lplCoreConstents.HIGH,
				"Delete combined statement alert message Displayed");

	}
	
	
	/**
	 * This method is used to validate whether the user is in Edit Combined
	 * Statement Subgroup(s) Details page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeEditCombinedStatementPage() {
		return (EDIT_COMBINED_STMT_PAGE_TITLE.equalsIgnoreCase(getTextUsingXpath(strTitleEditCombinedStmtXpath,
				"Edit Combined Statement Subgroup(s) Details page")));
	}

	/**
	 * This method is used to validate CS summary banner fields on
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCSSummaryBannerFields(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator(strCombinedStmtSummaryBannerFieldsXpath, field), field);

	}
	
	/**
	 * This method is used to verify whether combined statement overlay modal page
	 * is displayed
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displayOverlayModalCSPage() {
		String COMBINED_STMT_OVERLAY_PAGE_TITLE = "Adding " + testData.get("firstName") + " to "+ testData.get("groupName") + " & its capabilities";
		System.out.println( COMBINED_STMT_OVERLAY_PAGE_TITLE);
		System.out.println(getTextUsingXpath(strCombinedStmtOverlayModalXpath, "Overlay page title"));
		return (COMBINED_STMT_OVERLAY_PAGE_TITLE.equalsIgnoreCase(getTextUsingXpath(strCombinedStmtOverlayModalXpath, "Overlay page title")));
	}
	
	/**
	 * This method is used to select combined statement from overlay page for
	 * combined statement
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectCSFromOvelayPage() {
		String combinedStatementName = testData.get("combinedStatementName");
		//strSelectCSOverlayPageXpath = "//div[contains(text(),'Select which combined statement')]/..//*[@title='HOUSEHOLD COMBINED STATEMENT']/section/div/div//h2[@title='"+ combinedStatementName + "']";
		return clickElementUsingXpath(strSelectCSOverlayPageXpath.replace("xxx", combinedStatementName), "Combined statement from overlay page");
	}
	
	/**
	 * This method is used to validate text on Prompt when I click on click on
	 * Cancel without adding client button on Overlay page for Combined statements
	 * strSelectCSOverlayPage
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyTextOnPromptForCS() {
		//strTextOnPromptXpath = "//div[@class='dx-template-wrapper']/p";
		return (getTextUsingXpath(strTextOnPromptXpath,"Are you sure you want to leave this page? If you do, all data entered will be lost.").equalsIgnoreCase(PROMPT_TEXT_LEAVE_CS));
	}
	/**
	 * This method is used to click on existing combined statement on C/S Edit modal
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickAddClientToAnExistingStatementOption() {
		return clickElementUsingXpath(strClickAddClientExistingStatementXpath,
				"Existing combined statement is clicked on C/S Edit modal");
	}
	
	/**
	 * This method is used to validate prompt message on C/S Edit Modal page after
	 * clicking on close button
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validatePromptMessage() {
		return isElementPresentUsingXpath(strCSPromptMessageXpath, "Promt message available on C/S Edit modal page");
	}

	/**
	 * This method is used to validate prompt message on C/S Edit Modal page after
	 * clicking on close button
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickEditModalCloseButton() {
		return clickElementUsingXpath(strOverlayPageCloseBtnXpath, "Click on Close button in C/S overlay page");
	}
	
	/**
	 * This method is used to click on No option on promt after clicking on close
	 * button on C/S Edit Modal
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickNoOption() {
		return clickElementUsingXpath(strCSEditModalClickNoOptionXpath, "Click on No option on promt message");
	}
	
	/**
	 * This method is used to click on Yes option on promt after clicking on close
	 * button on C/S Edit Modal
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickYesOption() {
		return clickElementUsingXpath(strCSEditModalClickYesOptionXpath, "Click on Yes option on promt message");
	}
	
	/**
	 * This method is used to Validate title banner on Streamline/Confirmation page
	 * after deleting combined statement capability
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateDeleteCombinedStatementTitleBanner() {
		String str1 = getTextUsingXpath(strDeleteCombinedStatemnetTitleBannerXpath,
				"Delete HH Combined Statemnet Title Banner");
		return (str1.equalsIgnoreCase(DELETE_PANEL_HEADER));
	}

	/**
	 * This method is used to verify error message for outside investment account
	 * 
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean errorMsgOutsideAccountCombinedStatement() {
		return isElementPresentUsingXpath(strErrorMsgOutsideAccountCombinedStatementXpath, lplCoreConstents.HIGH,
				"New Combined Statement Subgroup(s) Details page is Displayed");

	}
	
	/**
	 * This method is used to verify Combined Statement subgroup tile on Dashboard
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyDashboardCombinedStatamentSubgroupTile() {
		int noOfCombinedStatement = getWebElementsSizeUsingXpath(strNoOfCombinedStmtDashboardXpath);
		return getTextUsingXpath(strDashboardCStileXpath,
				"Error message when household group name exceeding 40 characters")
						.equalsIgnoreCase(noOfCombinedStatement + " " +testData.get("DashboardCSsubgroupTile"));
	}
	
	/**
	 * This method is used to validate Active Label on CS Subgroup Tile on Dashboard
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean verifyDashboardCombinedStatamentSubgroupTileActiveLabel() {
		return isElementPresentUsingXpath(strCSsubgroupActiveLabelXpath, "CS Subgroup Active Label on Dashboard");
	}
	
	
	/**
	 * This method is used to check confirmation Page is displayed after deleting
	 * combined Statement
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean confirmationPageDisplayed() {

		
		return isElementPresentUsingXpath(strConfirmationPageXpath, lplCoreConstents.HIGH,
				"Confirmation Page is Displayed");

	}

	/**
	 * This method is used to remove primary client of combined statement sub group
	 * in edit  household  page
	 * 
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean removeCombinedStatementSubGroupPrimaryClient() {
		
		
		return clickElementUsingXpath(strRemoveClientButtonXpath.replace("xxx",testData.get("primaryClientName") ),
				"remove client  button is clicked");
		
	}
	
	/**
	 * This method is used to validate modal message while deleting sub group combined client 
	 * 
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seemodalmessagewithtext() {
		
	//isElementPresentUsingXpath(strmodalmessagexpath, lplCoreConstents.HIGH, "Modal message is  Displayed");
		System.out.println(getTextUsingXpath(strmodalmessagexpath,"Modal message text"));
		System.out.println(COMBINED_STATEMENT_PRIMARY_REMOVE_MSG);
	return (getTextUsingXpath(strmodalmessagexpath,"Modal message text").equals(COMBINED_STATEMENT_PRIMARY_REMOVE_MSG));
		
	}
	
	/**
	 * This method  is used to click on ok button in modal  message
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickokbutton() {

		return clickElementUsingXpath(strokbuttonxpath,lplCoreConstents.HIGH,"ok button is clicked");
	}
	
	/**
	 * This method is used to verify Review Household combined statement details
	 * page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean verifyReviewHouseholdCombinedStatementDetailsPage() {
		return isElementPresentUsingXpath(strCombineStatementReviewXpath, lplCoreConstents.HIGH,
				"Review Household combinedstatementdetails page");
	}
	
	/**
	 * This method is used to click on combined statemnent Edit icon
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickCombinedStatementNameEditButton() {

		return clickElementUsingXpath(strCombineStatementEditBtnXpath, "Click combined statement edit button");
		}
	
	/**
	 * This method is used to clear and Edit Group Combined statement Name
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clearAndEnterCombinedstatementName(String combinedstatementName) {
		//clearTextUsingXpath(strEditCombineStatementNameXpath, "Combined Statement Name");
		return enterTextUsingXpath(strEditCombineStatementNameXpath, combinedstatementName, "Combined Statement Name");
	}
	
	public boolean verifyCombinedStatementCreated() {
		return isElementPresentUsingXpath(strCombinedStatementTileXpath, "Combined Statement created");
	}
	
	/**
	 * This method is used to validate blank combined name error message
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean blankcombinedstatementnameerrormessage() {
		String strblankcserrormessagexpath = "//*[text()='Combined Statement Name is required.']";
		String str1 = getTextUsingXpath(strblankcserrormessagexpath,
				"Blank combined statement error message displayed");
		String str2 = testData.get("Blankerrormessage");
		return str1.equalsIgnoreCase(str2);

	}
	
	/**
	 * This method is used to validate household Capability tracker name with
	 * chevron in Edit Household Page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean householdCapabilityTrackerNameWithChevron() {

		return (isElementPresentUsingXpath(strHouseholdCapabilityTrackerNameXpath, lplCoreConstents.HIGH,
				"Household Capability tacker name is displayed")&&isElementPresentUsingXpath(strHouseholdCapabilityTrackerChevronXpath, lplCoreConstents.HIGH,
						"Household Capability tacker chevron is displayed"));

	}
	
	/**
	 * This method is used to Validate sub group combined statement tile
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean displaySubgroupCombineStatementTile() {
		return isElementPresentUsingXpath(strSubGroupCombineStatementTileXpath, lplCoreConstents.HIGH,
				"sub group combined statement tile is Displayed");

	}
	
	/**
	 * This method is used to Validate sub group combined statement title with
	 * status
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean displaySubgroupCombinedStatementTitleWithStatus() {
		return isElementPresentUsingXpath(strSubgroupCombineStatementStatusXpath, lplCoreConstents.HIGH,
						"sub group combined statement status is Displayed");
	}
	
	/**
	 * This method is used to check if Cancel & Return to Dashboard Hyperlink in
	 * Edit Combined Statement page is displayed
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyCancelReturnToDashboardHyperLinkinCombinedStatement() {
		return isElementPresentUsingXpath(strCancelAndReturnLinkCombinedStatementXpath, lplCoreConstents.HIGH,
				"Cancel & Return to Dashboard hyperlink is displayed");

	}
	
	/**
	 * This method is used to select primary for combined statement
	 * 
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectPrimaryClientForCombinedStatement(String clientName) {
		//String strCombinedStatementRadioButtonXpath = "//div[text() = '" + clientName
			//	+ "']/../label/../../../../div/div/div/div/table/tbody/tr/td[1]/input";
		return clickElementUsingXpath(strCombinedStatementRadioButtonXpath.replace("xxx", clientName), "Select client name");
	}
	
	/**
	 * This method is used to click on Combined Statement Contents panel
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickCombinedStatementContentsPanel() {
		return clickElementUsingXpath(strCombinedStatementContentsChevronXpath,"Combined Statement contents panel chevron is clicked");
	}
	
	
	/**
	 * This method is used to validate Account Details are displayed on Combined
	 * Statement tile
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateAccountDetails() {
		return isElementPresent(DISPLAYED, "XPATH", strCombinedStatementAccountDetailsXpath,"Page expands to show list of account details");
	}
	
	/**
	 * This method is used to validate Account Details are displayed on Combined
	 * Statement tile
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean ValidateColumnNamesCSConfPage(String field) {
		wait(3);
	//return isElementPresent(DISPLAYED, "XPATH", strColumnNamesCSXpath,"Page expands to show list of account details");
		return isElementPresentUsingXpath(getFormattedLocator(strColumnNamesCSXpath, field), field);
	}
	
	/**
	 * This method is used to click on Accounts Panel chevron to expand in combined
	 * statement capability tile
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickAccountPanelExpandChevron() {
		return clickElementUsingXpath(strCombinedStatementClientAccountPanelXpath,"Accounts panel chevron is clicked");
	}
	
	/**
	 * This method is used to verify Account name in combined statement section of the 
	 * confirmation page
	 * 
	 * @return boolean
	 * @author  awaeza
	 */
	public boolean verifyCSAccountname() {
		return isElementPresentUsingXpath(StrCombinedStatementAccountNameXpath,"Account name is displayed in combined statement section of the confirmation page");


	}
	
	/**
	 * This method is used to verify Account class in combined statement section of the 
	 * confirmation page
	 * 
	 * @return boolean
	 * @author  awaeza
	 */
	public boolean verifyCSAccountclass() {
		return isElementPresentUsingXpath(StrCombinedStatementAccountClassXpath,"Account class is displayed in combined statement section of the confirmation page");

	}
	
	/**
	 * This method is used to verify Account Number in combined statement section of the 
	 * confirmation page
	 * 
	 * @return boolean
	 * @author  awaeza
	 */
	public boolean verifyCSAccountnumber() {
		return isElementPresentUsingXpath(StrCombinedStatementAccountNumberXpath,"Account Number is displayed in combined statement section of the confirmation page");

	}
	
	/**
	 * This method is used to verify total account value in dollars in combined statement section of the 
	 * confirmation page
	 * 
	 * @return boolean
	 * @author  awaeza
	 */
	public boolean verifyCStotalaccountvalue() {
		
	return(getTextUsingXpath(StrCombinedStatementAccountValueXpath, "Total account value in dollars")).contains("$"); 
	
	}
	
	/**
	 * This method is used to select primary for combined statement
	 * 
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectPrimaryClientForSubgroupCombinedStatement() {
		int noOfCombinedStatement =   getWebElementsSizeUsingXpath(strNoOfCombinedStatementXpath);
		boolean blnResult = false;
		//noOfCombinedStatement=noOfCombinedStatement+1;
		for(int i=2; i<=noOfCombinedStatement+1; i++) {
			clickElementUsingXpath(strSubgroupCombinedStatementRadioButtonXpath.replace("x", Integer.toString(i)), "Select client name for primary");
			blnResult = true;
		}
		return blnResult;
		
		
	}
	
	/**
	 * This method is used to click on done editing button
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickCSdoneditingbutton() {
		return clickElementUsingXpath(strDoneEditingButtonXpath, "done editing button is clicked");
	}
	
	/**
	 * This method is used to check if Cancel & Return to Dashboard Hyperlink in
	 * Review Combined Statement page is displayed
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyCancelReturntoDashboardHyperlink() {
		return isElementPresentUsingXpath(strCancelReturnCombinedStatementXpath, lplCoreConstents.HIGH,
				"Cancel & Return to Dashboard hyperlink is displayed");

	}
	
	/**
	 * This method is used to click on Cancel & Return to Dashboard Hyperlink in
	 * Review Combined Statement page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickCancelReturntoDashboardHyperlink() {
		return clickElementUsingXpath(strCancelReturnCombinedStatementXpath, lplCoreConstents.HIGH,
				"Cancel & Return to Dashboard hyperlink is displayed");
	}
	
	/**
	 * This method is used to verify 1.0 Combined Statement Accounts To Be Removed modal
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	public boolean verifyCombinedStatementAccountsToBeRemovedModal()
	{
		return isElementPresentUsingXpath(strCombinedStatementRemovemodalXpath, lplCoreConstents.HIGH,
				"Combined Statement Accounts To Be Removed modal is displayed");
	}
	
	/**
	 * This method is used to verify 1.0 Combined Statement Accounts To Be Removed Modal Header
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	public boolean verifyCombinedStatementAccountsToBeRemovedModalHeader()
	{
		return isElementPresentUsingXpath(strCombinedStatementRemoveModalHeaderXpath, lplCoreConstents.HIGH,
				"1.0 Combined Statement Accounts To Be Removed Modal Header is displayed");
	}
	
	/**
	 * This method is used to verify 1.0 Combined Statement Accounts To Be Removed Sub-header
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	public boolean verifyCombinedStatementAccountsToBeRemovedModalSubHeader()
	{
		return isElementPresentUsingXpath(strCombinedStatementRemoveModalSubHeaderXpath, lplCoreConstents.HIGH,
				"1.0 Combined Statement Accounts To Be Removed Sub-header is displayed");
	}

/**
	 * This method is used to verify account details for each 1.0 combined statement group
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	public boolean verifyAccountDetailsInRemoveModal()
	{
		return isElementPresentUsingXpath(strAccountDetailsInRemoveModalXpath, lplCoreConstents.HIGH,
				"Account details for each 1.0 combined statement group is displayed");
	}

/**
	 * This method is used to verify section header of 1.0 Combined Statement Group
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	public boolean verifySectionHeaderCombinedStatementGroup()
	{
		return isElementPresentUsingXpath(strSectionHeaderCombinedStatementGroupXpath, lplCoreConstents.HIGH,
				"section header of 1.0 Combined Statement Group is displayed");
	}
/**
	 * This method is used to verify cancel hyperlink at footer
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	public boolean verifyCancelHyperlinkAtFooter()
	{
		return isElementPresentUsingXpath(strCancelHyperlinkXpath, lplCoreConstents.HIGH,
				"cancel hyperlink at footer is displayed");
	}

/**
	 * This method is used to verify REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	public boolean verifyRemoveAccountsAndSetUpCombinedStatementButton()
	{
		return isElementPresentUsingXpath(strRemoveAccountsAndSetUpCombinedStatementButtonXpath, lplCoreConstents.HIGH,
				"REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button is displayed");
	}

/**
	 * This method is used to click on REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	
	public boolean clickRemoveAccountsAndSetUpCombinedStatementButton() {

			return clickElementUsingXpath(strRemoveAccountsAndSetUpCombinedStatementButtonXpath, "Click REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button");
			}

	/**
	 * This method is used to validate Add Client to an Existing Statement button in
	 * selected state
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeAddClientToAnExistingStatementButton() {
		return isElementPresentUsingXpath(strAddClientToAnExistingStatementXpath,
				"Add Client to an Existing Statement button in selected state is displayed");

	}
	
	/**
	 * This method is used to validate sub group combined statement header along
	 * with sub group combined statements
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeSubGroupCombinedStatementsWithHeader() {
		return isElementPresentUsingXpath(strSubGroupCombinedStatementHeaderXpath,
				"Sub group combined statement header is displayed")
				&& isElementPresentUsingXpath(strSubGroupCombinedStatementXpath,
						"Sub group combined statements is displayed");
	}
	
	/**
	 * This method is used to click on contents Chevron in combined statement edit
	 * modal
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickContentsChevronCSEditModal() {
		wait(2);
		return clickElementUsingXpath(strCSEditModalContentsChevronXpath,
				"Click on contents chevron in combined  statement edit modal");
	}
	
	/**
	 * This method is used to click on close modal option in CS edit modal page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickedCSCloseModalButton() {
		return clickElementUsingXpath(strEditCSCloseModalButtonXpath, "Click on edit CS close modal button");
	}
	
	/**
	 * This method is used to click on yes button present in edit CS close modal
	 * popup
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickYesButtonCSCloseModal() {
		return clickElementUsingXpath(strYesButtonCSCloseModalXpath, "Click on edit CS close modal button");
	}
	
	/**
	 * This method is used to click on submit changes button in the review combined
	 * statement details Page
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickHHCombinedStatementSubmitButton() {
		return clickElementUsingXpath(strHHCombinedStatementSubmitButtonXpath,
				"Submit changes button in review combined statement details page is clicked");

	}
	
	/**
	 * This method is used to check combined statement tile is displayed in
	 * confirmation Page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean combinedStatementTileDisplayed() {
		String strcombinedstatementtilexpath = "//div[@title='HOUSEHOLD COMBINED STATEMENT']";
		return isElementPresentUsingXpath(strcombinedstatementtilexpath, lplCoreConstents.HIGH,
				"combined statement tile displayed");
	}
	
	/**
	 * This method is used to verify whether landed in the SET UP COMBINED
	 * STATEMENTS page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displaySetUpCombinedStatementPage() {
		return (getTextUsingXpath(strTitleSetUpCombinedStatementPageXpath, "Set up Combined Statements page").equals(SETUP_COMBINED_STMT_PAGE_TITLE));
	}
	
	/**
	 * This method is used to validate COMBINED STATEMENTS TBD in the Tracker
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displayCombinedStatementSubgroupNameInTracker(String clientName) {
		System.out.println(getTextUsingXpath(strTrackerCombinedStatementSubgroupNameXpath, "Combine Statement Subgroup Name").trim());
		System.out.println(clientName + " COMBINED STATEMENT");
		return (getTextUsingXpath(strTrackerCombinedStatementSubgroupNameXpath, "Combine Statement Subgroup Name").trim().equals(clientName + " COMBINED STATEMENT"));
	}
	/**
	 * This method is used to click on edit combined statement option
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickEditCSSubgroup() {
		return (clickElementUsingXpath(strEditButtonCSSubgroupXpath, "Combine Statement Subgroup Name"));
	}
	
	/**
	 * This method is to verify address in CS review page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyClientAddressCSReviewPage() {
		System.out.println(getTextUsingXpath("//div[@class='primary-addr-accnts']/div[2]/div[2]/div[2]", "Combine Statement Subgroup Name"));	
		System.out.println(getTextUsingXpath("//div[@class='primary-addr-accnts']/div[2]/div[2]/div[3]", "Combine Statement Subgroup Name"));	 
		return getTextUsingXpath("//div[@class='primary-addr-accnts']/div[2]/div[2]/div[2]", "Combine Statement Subgroup Name").contains(testData.get("mailingAddress1")) &&
				getTextUsingXpath("//div[@class='primary-addr-accnts']/div[2]/div[2]/div[3]", "Combine Statement Subgroup Name").contains(testData.get("mailingAddress2"));
	}
	
	
	/**
	 * This method is to verify address in CS Registration address
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyCSAccountAddress() {
        
        System.out.println(getTextUsingXpath("//*[@class='account-mask']/*[contains(text(),'4944')]//following::ul[1]", "Combine Statement Account Address")); 
        return testData.get("accountRegistrAddrs").contains(getTextUsingXpath("//*[@class='account-mask']/*[contains(text(),'4944')]//following::ul/li[1]", "Combine Statement Account Address")) &&
               testData.get("accountRegistrAddrs").contains(getTextUsingXpath("//*[@class='account-mask']/*[contains(text(),'4944')]//following::ul/li[2]", "Combine Statement Account Address"));
  
  }
	
	/**
	 * This method is used to verify Letter widget
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyLetterWidget() {
		String titleLetterWidget = "//div[@class='card content-sidebar-info']/p[1]";
		String str1 = getTextUsingXpath(titleLetterWidget, "Letter Widget Combined statement subgroup");
		String str2 = "Letter";
		return (str1.equals(str2));
	}

	/**
	 * This method is used to verify content in Letter widget
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyLetterWidgetContent() {
		String contentLetterWidget = "//div[@class='card content-sidebar-info']/p[2]";
		String str1 = getTextUsingXpath(contentLetterWidget, "Letter Widget Combined statement subgroup content");
		String str2 = "We will be sending out a letter about any changes to these clients that is read only once household is submitted View Letter";
		return (str1.equals(str2));
	}
	
	/**
	 * This method is used to validate COMBINED STATEMENTS TBD in the Tracker
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displayCombinedStatementTBD() {
		waitForPageLoading();
		String strCombinedStatmentText = getTextUsingXpath(strCombinedStatementTBDXpath, "Combined Statements TBD");
		String strTBDText = "COMBINED STATEMENTS TBD";
		return (strCombinedStatmentText.equals(strTBDText));
	}
	
	
	/**
	 * This method is used to validate COMBINED STATEMENTS TBD in the Tracker
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displayCombinedStatementNameInTracker() {
		String str1 = getTextUsingXpath(strCSNameTrackerXpath, "Combined Statements Name in tracker").trim();
		String str2 = getTextUsingXpath(strCSNameTitleXpath, "Combine Statement Name").trim();
		return (str1.equals(str2));
	}
	
	/**
	 * This method is used to click on sub group combined statement tile in CS edit
	 * modal
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clicksubgroupcombinedstatementtile() {
	/*	boolean result = false;
		while(true) {
			click(driver.findElement(By.xpath("//div[@class='card card-margin capability-cs-client-modal']//*[contains(@title,'Jfdkjfdklfd HOUSEHOLD')]/../../..")));
			result = true;
			break;
		}
		return result; */
		
		System.out.println(strsubgroupcombinedstatementtileXpath.replace("xxx", testData.get("groupName")));
		return clickElementUsingXpath(strsubgroupcombinedstatementtileXpath.replace("xxx", testData.get("groupName")),
				"Sub group combined statement tile is clicked");   
	}

}