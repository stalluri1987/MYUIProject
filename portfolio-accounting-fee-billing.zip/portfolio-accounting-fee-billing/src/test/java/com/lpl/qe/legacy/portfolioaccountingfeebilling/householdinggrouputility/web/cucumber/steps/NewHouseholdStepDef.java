package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.steps;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.Common;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.NewHouseholdPage;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import LPLCoreDriver.LPLCoreUtil;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class NewHouseholdStepDef extends CommonStepDef {

	public static final String MODALFRAME = "iframe-modal-frame";
	static final String TEST_DATA_PATH = "\\\\qa2000server\\QTP_Repository\\Grouping\\TestData\\Client_TestData.xlsx";
	public static final String FIELDS = "fields";
	public static final String USERNAME = "Username";
	public static final String PASSWORD = "Password";
	public static final String AXALOGIN = "strAXALogin";
	public static final String SUPPORTVIEWOPTION = "strSupportViewOption";
	public static final String SUPPORTVIEWDATA = "strSupportViewData";
	String firstName = "";

	// New call
	@Before
	public void startSession(Scenario sc) {
		String[] scenarioTags = sc.getSourceTagNames().toArray(new String[0]);
		String scriptID = LPLCoreDriver.getScriptTagID(scenarioTags);
		if (scriptID != null) {
			LPLCoreDriver.StartSession(scriptID);
		} else {
			LPLCoreDriver.StartSession();
		}
	}
	@Given("^I login to ClientWorks AXA Application$")
	public void ilogintoClientWorksAXAApplication() {
		initialize();
	}

	@Given("^I login to Householding Group Utility application$")
	public void ilaunchtheNewHouseholdpage() {
		//LPLCoreDriver.StartSession();
		//initialize();
		boolean blnResult = loginPage.login(loginCredentials.get("Username"), loginCredentials.get("Password"));
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Loginto Householding Group Utility Application",
				"User should be able to login to Householding Group Utility Application",
				"Successfully logged in to Householding Group Utility Application",
				"Failed To Login to ClientWorks Householding Group Utility. Error message: " + loginPage.strError);
	}

	@Given("^User logs in to ClientWorks AXA using (.+)$")
	public void userLogsInToClientWorksAXA(String username) {
		boolean blnResult = false;
		common.loadURL(common.getAXAURL());
		homePage.waitForPageLoading(homePage.lplCoreConstents.LOW);
		// login through SSO or through Non SSO portal to AXA
		if (testData.get(AXALOGIN).equalsIgnoreCase(Common.SSO))
			blnResult = homePage.performCWSupportView(testData.get(SUPPORTVIEWOPTION), testData.get(SUPPORTVIEWDATA));
		else
			blnResult = common.AXA_Login(driver, username);

		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Login to ClientWorks AXA Application",
				"User should be able to login to ClientWorks AXA Application",
				"Successfully logged in to ClientWorks AXA Application",
				"Failed To Login to ClientWorks AXA Application.Error message: " + loginPage.strError);
	}

	@Given("^I login into ClientWorks application$")
	public void ilogintoClientworksApplication() {
		//LPLCoreDriver.StartSession();
		initialize();
		boolean blnResult = loginPage.login(loginCredentials.get("Username"), loginCredentials.get("Password"));
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Login to Householding Group Utility Application",
				"User should be able to login to Householding Group Utility Application",
				"Successfully logged in to Householding Group Utility Application",
				"Failed To Login to ClientWorks Householding Group Utility. Error message: " + loginPage.strError);

	}

	@Then("^I should view Client Management Page is displayed$")
	public void ishouldseeClientManagementPageisdisplayed() {

		LPLCoreSync.waitTillVisible(driver, By.cssSelector(homePage.strApplauncher_CSS),
				LPLCoreConstents.getInstance().MEDIUM);
		boolean blnResult = LPLCoreUtil.isElementPresent("DISPLAYED",
				driver.findElement(By.cssSelector(homePage.strApplauncher_CSS)));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate Client Management Page is displayed",
				"User should be able to see Client Management Page is displayed", "Client Management Page is displayed",
				"Failed To see Client Management Page. Error message:" + LPLCoreUtil.strError);
	}

	@And("^I should navigate into Groups tab$")
	public void inavigatetopage() {
		String pageName = testData.get("pageName");
		System.out.println(pageName);
		boolean blnResult = navigation.navigateToPage(pageName);
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Navigate to " + pageName + " page",
				pageName + " Page should be loaded", pageName + " Page is loaded",
				"Failed to load " + pageName + " Page.Error message: " + common.getStrError());
	}

	@Then("^I should land on New Household page$")
	public void isNewHouseholdPageDisplayed() {

		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.isPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Check if the New Household page is loaded", "New Household page should be loaded",
				"New Household page is loaded",
				"Failed to load the New Household page. Error message: " + common.getStrError());
	}
	
	@Then("^I should land on New Household page on clicking verbiage$")
	public void isNewHouseholdPageDisplayedAfterClickingVerbiage() {

		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.isHHPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Check if the New Household page is loaded", "New Household page should be loaded",
				"New Household page is loaded",
				"Failed to load the New Household page. Error message: " + common.getStrError());
	}

	@Then("^I should select household from create drop down$")
	public void ishouldselecthouseholdfromcreatehouseholddropdown() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.isHouseholdPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Check if the New Household page is loaded", "New Household page should be loaded",
				"New Household page is loaded",
				"Failed to load the New Household page. Error message: " + common.getStrError());
	}

	@When("^I enter the first name in the search text box$")
	public void ienterthefirstnameinthesearchtextbox() {
		common.waitForPageLoading();
		firstName = testData.get("firstName");
		System.out.println(firstName);
		boolean blnResult = newHouseholdPage.enterSearchTextInClientPrimarySearchBox(firstName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the first name[" + firstName + "]",
				"First name should be entered", "First name[" + firstName + "] is entered",
				"Failed To enter the first name." + common.getStrError());
	}
	
	@Then("^I should see results of client names containing that first name for new client$")
	public void i_should_see_results_of_client_names_containing_that_first_name_for_new_client() {
		List<String> searchResults = newHouseholdPage.getSearchResultsForNewClientPrimary();
		System.out.println(searchResults);
		boolean blnResult = !searchResults.isEmpty();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the search results are retrived", "Search results should be retrieved",
				"Search results are retrieved. Results - [" + java.lang.String.join(",", searchResults) + "]",
				"Search result does not contains any results");
		for (String result : searchResults) {
			if (!result.toLowerCase().contains(firstName.toLowerCase()))
				LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
						"Validate if each search result contains the search string[" + firstName + "]",
						"Search result contains the search string[" + firstName + "]",
						"Search result[" + result + "] contains the search string[" + firstName + "]",
						"Search result[" + result + "] does not contain the search string[" + firstName + "]");
		}
	}
	
	@Then("I verify Household created successfully message in the confirmation page")
	public void i_verify_household_created_successfully_message_in_the_confirmation_page() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.seeHouseholdSuccessMsgConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Streamline Billing Edit pencil icon",
				"User should able to click streamline billing edit pencil icon successfully",
				"User is able to click streamline billing edit pencil icon successfully",
				"Failed to click on streamline billing edit pencil icon in confirmation page" + common.getStrError());
	}
	
	@Then("I verify household details in the confiramtion page")
	public void i_verify_household_details_in_the_confiramtion_page() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.seeHouseholdDetailsConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Streamline Billing Edit pencil icon",
				"User should able to click streamline billing edit pencil icon successfully",
				"User is able to click streamline billing edit pencil icon successfully",
				"Failed to click on streamline billing edit pencil icon in confirmation page" + common.getStrError());
	}

	@When("^I enter the Group name in the search text box$")
	public void ienterthegrouptnameinthesearchtextbox() {
		String groupName = testData.get("groupName");
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.enterSearchTextInGroupSearchBox(groupName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the group name[" + groupName + "]",
				"First name should be entered", "Group name[" + groupName + "] is entered",
				"Failed To enter the Group name." + common.getStrError());
	}

	@When("^I enter the other first name in the search text box$")
	public void ientertheotherfirstnameinthesearchtextbox() {
		String otherfirstName = testData.get("otherfirstName");
		boolean blnResult = newHouseholdPage.enterSearchTextInClientPrimarySearchBox(otherfirstName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter the first name[" + otherfirstName + "]", "First name should be entered",
				"First name[" + otherfirstName + "]  entered",
				"Failed To enter the first name." + common.getStrError());
	}

	

	@When("^I click streamline billing edit icon$")
	public void iclickstreamlinebillingediticon() {
		boolean blnResult = billingPage.clickOnEditStreamlineBillingPencilIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Streamline Billing Edit pencil icon",
				"User should able to click streamline billing edit pencil icon successfully",
				"User is able to click streamline billing edit pencil icon successfully",
				"Failed to click on streamline billing edit pencil icon in confirmation page" + common.getStrError());
	}

	@Then("^I should view the edit billing details page$")
	public void ishouldviewtheeditbillingdetailspage() {
		boolean blnResult = newHouseholdPage.verifyEditBillingDetailsPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Streamline Billing Edit pencil icon",
				"User should able to view edit billing details page successfully",
				"User is able to view edit billing details page successfully",
				"Failed to view edit billing details page " + common.getStrError());

	}

	@Then("^I should see results of client names containing that first name$")
	public void ishouldseeresultsofclientnamescontainingthatfirstname() {
		common.wait(3);
		List<String> searchResults = newHouseholdPage.getSearchResultsForClientPrimary();
		boolean blnResult = !searchResults.isEmpty();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the search results are retrived", "Search results should be retrieved",
				"Search results are retrieved. Results - [" + java.lang.String.join(",", searchResults) + "]",
				"Search result does not contains any results");
		for (String result : searchResults) {
			if (!result.toLowerCase().contains(firstName.toLowerCase()))
				LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
						"Validate if each search result contains the search string[" + firstName + "]",
						"Search result contains the search string[" + firstName + "]",
						"Search result[" + result + "] contains the search string[" + firstName + "]",
						"Search result[" + result + "] does not contain the search string[" + firstName + "]");
		}
	}
	
	@Then("^I should see results of other client names containing that first name$")
	public void ishouldseeresultsofclientothernamescontainingthatfirstname() {
		String otherfirstName = testData.get("otherfirstName");
		List<String> searchResults = newHouseholdPage.getSearchResultsForNewClientPrimary();
		System.out.println(searchResults);
		boolean blnResult = !searchResults.isEmpty();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the search results are retrived", "Search results should be retrieved",
				"Search results are retrieved. Results - [" + java.lang.String.join(",", searchResults) + "]",
				"Search result does not contains any results");
		for (String result : searchResults) {
			if (!result.toLowerCase().contains(otherfirstName.toLowerCase()))
				LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
						"Validate if each search result contains the search string[" + firstName + "]",
						"Search result contains the search string[" + firstName + "]",
						"Search result[" + result + "] contains the search string[" + firstName + "]",
						"Search result[" + result + "] does not contain the search string[" + firstName + "]");
		}
	}

	@When("^I select one of the client name from search result$")
	public void iselectoneoftheclientnamefromsearchresult() {
		String clientPrimaryName = newHouseholdPage.getClientPrimaryNameFromSearchResult();
		boolean blnResult = newHouseholdPage.selectClientPrimary();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on any one of the client name",
				"Client name should be clicked", "Client name[" + clientPrimaryName + "] is clicked",
				"Failed to click the client name." + common.getStrError());
	}
	
	@When("^I select one of the other client name from search result$")
	public void iselectoneoftheotherclientnamefromsearchresult() {
		String clientOtherPrimaryName = newHouseholdPage.getClientsPrimaryNameFromSearchResult();
		boolean blnResult = newHouseholdPage.selectClientsPrimary();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on any one of the client name",
				"Client name should be clicked", "Client name[" + clientOtherPrimaryName + "] is clicked",
				"Failed to click the client name." + common.getStrError());
	}

	@Then("^I should close the browser$")
	public void ishouldclosethebrowser() {
		boolean blnResult = newHouseholdPage.closeBrowser();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User try to close the browser",
				"User should able to see the pop up",
				"User is able to close the browser and able to see pop up successfully",
				"Failed to close the browser" + common.getStrError());
	}

	

	@Then("^I should see a tile indicating that client has been added$")
	public void ishouldseeatileindicatingthatclienthasbeenadded() {
		boolean blnResult = newHouseholdPage.isTileDisplayed(firstName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the tile containing the client name[" + firstName + "] is displayed",
				"Tile containing the client primary name should be displayed",
				"Tile containing the client primary name[" + firstName + "] is displayed",
				"Failed to display the client name in the tile" + common.getStrError());

	}

	@Then("^I Should able to click on Primary radio button$")
	public void ishouldabletoclickonprimaryradiobutton() {
		boolean blnResult = newHouseholdPage.clickOnPrimaryRadioButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Primary Radio Button for client",
				"User should able to click Primary Radio button successfully",
				"User is able to click Primary Radio button successfully",
				"Failed to click on Primary Radio button in Household setup page" + common.getStrError());

	}

	@When("^I click on the close button$")
	public void iclickclosebutton() {
		common.wait(3);
		boolean blnResult = newHouseholdPage.clickCloseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate Close button is displayed in create Household set up page",
				"Close button should be displayed in create Household set up page",
				"Close button is displayed in create Household set up page",
				"Failed to display the close button in create Household set up page" + common.getStrError());
	}

	@When("^I click the confirmation close button$")
	public void iclicktheconfirmationclosebutton() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickConfirmationCloseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate Close button is displayed in create Household set up page",
				"Close button should be displayed in create Household set up page",
				"Close button is displayed in create Household set up page",
				"Failed to display the close button in create Household set up page" + common.getStrError());
	}

	@Then("^I should view warnning popup$")
	public void ishouldviewwarnnigpopup() {
		boolean blnResult = newHouseholdPage.verifyWarningPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on close button into create household setup page able to view Warnning popup",
				"User should able to view Close button Warnning popup successfully",
				"User is able to view Close button Warnning popup successfully",
				"Failed to view Close button Warnning popup in create Household setup page." + common.getStrError());

	}

	@When("^I click on warning pop NO button$")
	public void iclickonnobutton() {
		boolean blnResult = newHouseholdPage.clickNoButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click NO button in Close Warnning popup",
				"No button should be click successfully", "No button is clicked sucessfully",
				"Failed to click the No button in close warning popup" + common.getStrError());
	}

	@When("^I click on review button$")
	public void iclickonreviewbutton() {
		boolean blnResult = newHouseholdPage.clickReviewButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click Review button in edit householdgroup page",
				"Review button should be click successfully", "Review button is clicked sucessfully",
				"Failed to click the Review button in edit householdgroup page" + common.getStrError());
		common.waitForPageLoading();

	}

	@When("^I should able to see Edit Household page tile$")
	public void ishouldaletoseeedithouseholdpagetile() {
		boolean blnResult = newHouseholdPage.verifyEditHouseholdPageTile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit button into household confirmation page able to view Edit details tile",
				"User should able to view edit tile successfully", "User is able to view Edit tile successfully",
				"Failed to view Edit tile into edit household page." + common.getStrError());

	}

	@Then("^I should able to click on submit changes$")
	public void ishouldabletoclickonsubmitchangesbutton() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickSubmitChangesButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click Submit Changes button in edit householdgroup page",
				"Submit Changes button should be click successfully", "Submit Changes button is clicked sucessfully",
				"Failed to click the Submit Changes button in edit householdgroup page" + common.getStrError());
		common.waitForPageLoading();
	}

	@When("^I click on warning pop YES button$")
	public void iclickonyesbutton() {
		boolean blnResult = newHouseholdPage.clickYesButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click Yes button in Close Warnning popup",
				"Yes button should be click successfully", "Yes button is clicked sucessfully",
				"Failed to click the Yes button in close warning popup" + common.getStrError());
	}

	@Then("I should come out from create Household page")
	public void ishouldcomeoutfromcreateHouseholdpage() {

		boolean blnResult = newHouseholdPage.verifyCameoutFromCreateHouseholdSetUpPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Yes button in close button warning pop up , user came out from create Household page",
				"User should able to come out from create Household set up page successfully",
				"User is able to come out from create Household set up page successfully",
				"Failed to come out from create Household setup page." + common.getStrError());
	}

	@When("^I should see tooltip for Primary Client$")
	public void ishouldseetooltipforpimaryclient() {
		boolean blnResult = newHouseholdPage.isTooltipDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the tooltip content of the Primary client is displayed",
				"Tooltip content of the  primary client should be displayed",
				"Primary client Tooltip content  is displayed",
				"Failed to display the Primary Client Tooltip content" + common.getStrError());
	}

	@Then("^I Should view Primary Client tooltip content$")
	public void ishouldviewpimaryclienttooltipcontent() {
		boolean blnResult = newHouseholdPage.isTooltipContentDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the tooltip of the Primary client is displayed",
				"Tooltip of the  primary client should be displayed", "Primary client Tooltip is displayed",
				"Failed to display the Primary Client Tooltip" + common.getStrError());
	}

	@When("^I should see the (.+) verbiage in the search box$")
	public void ienterthelastnameinthesearchtextbox(String verbiage) {
		String actualVerbiage = newHouseholdPage.getPlaceholderForSearchBox();
		boolean blnResult = actualVerbiage.equals(verbiage);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Check if the search box contains the verbiage[" + verbiage + "]",
				"Search box should contain the verbiage", "Search box contains the verbiage[" + actualVerbiage + "]",
				"Failed to contain the verbiage." + common.getStrError());

	}

	@When("^I click on edit group name$")
	public void iclickoneditgroupname() {
		boolean blnResult = newHouseholdPage.clickEditGroupNameButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on edit group name button in create Household setup page",
				"edit group name button should be click successfully", "edit group name button is clicked sucessfully",
				"Failed to click the edit group name button in create Household setup page" + common.getStrError());
	}

	@Then("^I should able to clear and enter new group name$")
	public void ishouldabletoclearandenternewgroupname() {

		String clientGroupName = testData.get("clientGroupName");
		boolean blnResult = newHouseholdPage.clearAndEnterGroupName(clientGroupName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and edit group name in create Household setup page",
				"user should able to clear and edit group name successfully",
				"Group name cleared and edited sucessfully",
				"Failed to clear and edit the group name button in create Household setup page" + common.getStrError());
	}

	@Then("^I click on View Letter of Combined statement$")
	public void iclickoneditcombinedstatementname() {
		boolean blnResult = newHouseholdPage.clickViewLetterCombineStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on View Letter of combined statement ",
				"View letter combined statement  should be click successfully",
				"View Letter of combined statement  is clicked sucessfully",
				"Failed to click the view letter of combined statement " + common.getStrError());
	}

	@Then("^I click create combined statement button$")
	public void ishouldabletoclearandentercombinedstatementname() {
		boolean blnResult = combinedStatementPage.clickCreateCombinedStatementBtn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click into create combined statement button",
				"user should able to click create combined statement button successfully",
				"Combined statement created sucessfully",
				"Failed to click create combined statement button" + common.getStrError());
	}

	@Then("^I should see Review combined Statement Page$")
	public void ishouldseereviewcombinedstatementpage() {
		boolean blnResult = combinedStatementPage.verifyReviewHouseholdCombinedStatementDetailsPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on combined statement streamline hyperlink",
				"User should able to see page title as Review Household combined statement details",
				"User is able to see review combined statement details page",
				"Failed to see review combined statement details page." + common.getStrError());
	}

	@When("^I click on Combined statement name edit icon$")
	public void iclickonCombinedstatementnameediticon() {
		boolean blnResult = combinedStatementPage.clickCombinedStatementNameEditButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on edit group name button in Review combined statement details page",
				"edit combined statement group name button should be click successfully",
				"edit combined statement group name button is clicked sucessfully",
				"Failed to click the edit group name button in review combined statement details page"
						+ common.getStrError());
	}

	@Then("^I should able to clear and enter combine statement Name$")
	public void ishouldabletoclearandentercombinestatementName() {

		String combinedstatementName = testData.get("combinedstatementName");
		boolean blnResult = combinedStatementPage.clearAndEnterCombinedstatementName(combinedstatementName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and edit combined statement group name in Review combined statement details page",
				"user should able to clear and edit combined statement group name successfully",
				"Combined statement group name cleared and edited sucessfully",
				"Failed to clear and edit the combined statement group name in Review combined statement details page"
						+ common.getStrError());
	}

	@When("^I click on delete client button$")
	public void iclickondeleteclientbutton() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickDeleteButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click Delete button in create Household setup page",
				"Delete button should be click successfully", "Delete button is clicked sucessfully",
				"Failed to click the Delete button in create Household setup page" + common.getStrError());

	}

	@Then("^I should see a tile indecating that New Combined Statement Created Successsfully$")
	public void ishouldabletoseetilecombinedstatementcreated() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.verifyCombinedStatementCreated();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on create combined statement",
				"User should view BNew Combined Statement created successfully",
				"User is able to view tile New Combined Statement Created successfully",
				"Failed to view New Combined Statement created." + common.getStrError());

	}

	@Then("^I should able to see tile is blank$")
	public void ishouldabletoseetileisbalnk() {
		boolean blnResult = newHouseholdPage.viewBlanktile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User (X)Delete client view Blank tile", "User should view blank tile",
				"User is able to view tile blank after delete the client successfully",
				"Failed to view blank tile after delete the client." + common.getStrError());

	}

	@Then("^I click on Create Household Button$")
	public void iclickoncreatehousHoldbutton() {
		common.wait(3); 
		boolean blnResult = newHouseholdPage.clickCreateHouseholdButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on create Household Button", "User should create successfully Household Group",
				"User is able to create Household successfully",
				"Failed to create Household group." + common.getStrError());
	}

	@When("^I verify Streamline ToolTip$")

	public void verifystreamlinetooltip() {
		boolean blnResult = newHouseholdPage.verifyStreamlineTooltip();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User land into Household confirmation page",
				"User should able to view Why Streamline? Tooltip successfully",
				"User is able to view Why Streamline ToolTip successfully",
				"Failed to view Why Streamline Tooltip in Household confirmation page." + common.getStrError());
	}

	@When("^I select Combined Statement$")
	public void iselectcombinedstatement() {
		common.wait(3);
		boolean blnResult = combinedStatementPage.clickCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on Combined Statement",
				"User should successfully land into Combined Statement page",
				"User is able to click Combined Statement successfully",
				"Failed to click Combined Statement." + common.getStrError());
	}

	@Then("^I should able to view Streamline ToolTip text$")
	public void ishouldabletoviewStreamlineToolTiptext() {
		boolean blnResult = newHouseholdPage.verifyStreamlineTooltipText();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User land into Household Group confirmation page",
				"User should able to view Why Streamline? Tooltip Text successfully",
				"User is able to view Why Streamline ToolTip Text successfully",
				"Failed to view Why Streamline Tooltip Text in Household confirmation page." + common.getStrError());
	}

	@When("I soulde able to click on close button$")
	public void iclickonclosebutton() {
		boolean blnResult = newHouseholdPage.clickOnCloseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User land into Household Group utility confirmation page",
				"User should able to click close button successfully",
				"User is able to click close button successfully",
				"Failed to click on close button in Household confirmation page." + common.getStrError());

	}
	
	@Then("I should be able to view given Household capabilities")
	public void i_should_be_able_to_view_given_household_capabilities() {
		boolean blnResult = newHouseholdPage.seeHouseholdCapabilitiesConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User land into Household Group utility confirmation page",
				"User should able to click close button successfully",
				"User is able to click close button successfully",
				"Failed to click on close button in Household confirmation page." + common.getStrError());
	}
	
	@When("I see Household Banksweep section in the confirmation page")
	public void i_see_household_banksweep_section_in_the_confirmation_page() {
		boolean blnResult = newHouseholdPage.seeBankSweepTileConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User land into Household Group utility confirmation page",
				"User should able to click close button successfully",
				"User is able to click close button successfully",
				"Failed to click on close button in Household confirmation page." + common.getStrError());
	}


	@Then("^I should able to view PopUps$")
	public void ishouldabletoviewpopsup() {
		boolean blnResult = newHouseholdPage.verifyPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click into close button in Household confirmation page",
				"User should able to view PopUp successfully", "User is able to view close button popup successfully",
				"Failed to view popup for close button in Household confirmation page." + common.getStrError());

	}

	@When("^I verify the Recommended Next Step: Streamline Household Capabilities$")
	public void iverifyrecommendednextstep() {
		boolean blnResult = newHouseholdPage.verifyRecommendedNextStep();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User land into household confirmation page able to view Recommended Next Step",
				"User should able to view Recommended Next Step successfully",
				"User is able to view Recommended Next Step successfully",
				"Failed to view Recommended Next Step in Household confirmation page." + common.getStrError());

	}

	@Then("^I should able to view Household Combined Statement$")
	public void iverifyhouseholdcombinestatement() {
		boolean blnResult = newHouseholdPage.verifyHouseholdCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User View household combined statement",
				"User should able to view Household Combined Statement successfully",
				"User is able to view Household Combined Statement successfully",
				"Failed to view Household Combined Statement  in Household confirmation page." + common.getStrError());

	}

	@When("^I View confirmation page$")
	public void ishouldabletoseeconfirmationpage() {
		boolean blnResult = newHouseholdPage.verifyHouseholdGroupCreated();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on create Household Button,New Household Group created",
				"User should create successfully Household Group",
				"User is able to see New household successfully created",
				"Failed to create Household group." + common.getStrError());

	}

	@When("^I should able to click x close icon on confirmation banner$")
	public void ishouldabletoclickxcloseiconforconfirmationbanner() {
		boolean blnResult = newHouseholdPage.clickXCloseIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on x Close icon",
				"User should able to click x icon successfully for new Household confirmation banner",
				"User is able to click x icon successfully ",
				"Failed to click x close icon on Household confirmation banner." + common.getStrError());
	}

	@When("^I should able to click on contents chevron$")
	public void ishouldabletoclickoncontentschevron() {
		boolean blnResult = newHouseholdPage.clickContentChevron();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on content chevron",
				"User should able to click on content chevron successfully on new Household confirmation page",
				"User is able to click on content chevron successfully ",
				"Failed to click on content chevron on Household confirmation page." + common.getStrError());
	}
	
	@When("^I should be able to click on bank sweep content chveron$")
	public void ishouldbeabletoclickonbanksweeepcontentchevron() {
		boolean blnResult = newHouseholdPage.clickContentChevronBankSweep();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on content chevron",
				"User should able to click on content chevron successfully on new Household confirmation page",
				"User is able to click on content chevron successfully ",
				"Failed to click on content chevron on Household confirmation page." + common.getStrError());
	}

	@When("^I select Streamline Billing$")
	public void iselectstreamlinebilling() {
		boolean blnResult = billingPage.clickStreamlineBillingButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Streamline Billing link", "User should click successfully Streamline Billing",
				"User is able to click Streamline Billing successfully",
				"Failed to click Streamline Billing." + common.getStrError());
	}

	@Then("^I should able to click Flat Fee Button$")
	public void ishouldabletoclickFlatFeeButton() {
		boolean blnResult = billingPage.clickFlatFeeTypeButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on Fee Type as Flat Fee",
				"User should click successfully Flat Fee", "User is able to click on Flat Fee type successfully",
				"Failed to click Flat Fee Type." + common.getStrError());
	}

	@When("^I click on Submit Changes button$")
	public void iclickonsubmitchangesbutton() {
		boolean blnResult = billingPage.clickBillingEditSubmitChangesButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Submit Changes Button", "User should click Submit changes button successfully ",
				"User is able to click on submit changes button successfully",
				"Failed to click on submit changes button in Edit billing page." + common.getStrError());

	}

	@Then("^I should able to click on Group context menu and select the delete option$")
	public void ishouldabletoclickonGroupcontextmeu() {
		common.wait(5);
		boolean blnResult = newHouseholdPage.clickGroupContextMenuDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on Group Context menu",
				"User should click on group context menu dropdown successfully ",
				"User is able to click on group context menu dropdown successfully",
				"Failed to click on group context menu dropdown." + common.getStrError());

	}

	@When("^I click on Delete this household$")
	public void iclickonDeletethishousehold() {
		boolean blnResult = newHouseholdPage.clickDeleteHousehold();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Delete this Household button",
				"User should click on Delete this Household button successfully ",
				"User is able to click on gDelete this Household button successfully",
				"Failed to click on Delete this Household button." + common.getStrError());

	}

	@When("^I enter What will the flat fee be for this household's assets$")
	public void ienterWhatwilltheflatfeebeforthishouseholdassets() {
		String flatFee = testData.get("flatFee");
		boolean blnResult = billingPage.enterFlatFeeValue(flatFee);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the Flat Fee Vlaue",
				"Flat Fee should be entered", "Flat Fee[" + flatFee + "] is entered",
				"Failed to Enter the Flat Fee Value." + common.getStrError());
	}

	@When("^I click on edit household group$")
	public void iclickonedithouseholdgroup() {
		boolean blnResult = newHouseholdPage.clickOnEditHouseholdIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Edit household group",
				"Edit household group icon should be clicked", "Edit household group icon is clicked",
				"Failed To click edit household group icon." + common.getStrError());
	}

	@When("^I should able to click Flat Fee value$")
	public void ishouldclickflatfeevalue() {
		boolean blnResult = billingPage.clickFlatFeeValue();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Flat Fee Value",
				"Flat Fee should be selected", "Flat Fee slider is selected",
				"Failed To select the Flat Fee." + common.getStrError());
	}

	@When("^I click the done button$")
	public void ishouldclickdonebutton() {
		boolean blnResult = billingPage.clickDoneButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Done button",
				"Done Button should be click successfully", "Done Button is clicked successfully",
				"Failed To click Done button." + common.getStrError());
	}

	@When("^I enter into the Billing Review page$")
	public void ishouldabletoviewbillingreviewheader() {
		boolean blnResult = newHouseholdPage.verifyBillingReviewHeader();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Done ,Billing Review Header page should display",
				"User should abl to see successfully Billing Review page",
				"User is able to see Billing Review page successfully",
				"Failed to view Billing review page." + common.getStrError());
	}

	@Then("^I click billing edit details button$")
	public void iclickbillingeditdetails() {
		boolean blnResult = newHouseholdPage.clickBillingEditDetails();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on edit details ,edit Billing page should display",
				"User should abl to see successfully edit Billing page",
				"User is able to edit Billing page successfully",
				"Failed to view edit Billing page." + common.getStrError());
	}

	@Then("^I click Progressive Tiered Button$")
	public void ishouldabletoclickProgressiveTieredFeeButton() {
		boolean blnResult = newHouseholdPage.clickProgressiveTieredFeeTypeButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Fee Type as Progressive Tiered",
				"User should click successfully Progressive Tiered",
				"User is able to click on Progressive Tiered type successfully",
				"Failed to click Progressive Tiered Fee Type." + common.getStrError());
	}

	@When("^I select Additional Schedule from dropdown$")
	public void iselectAdditionalScheduleFromDropdown() {
		String additionalScheduleName = testData.get("additionalScheduleName");
		boolean blnResult = newHouseholdPage.selectAdditionalSchedule(additionalScheduleName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User select additional Schedule",
				"User should select successfully additional Schedule from Drop down",
				"User is able to select the additional Schedule value successfully",
				"Failed to select additional Schedule value." + common.getStrError());

	}

	@When("^I clicked on Create House Hold Billing Setup button$")
	public void clickCreateHouseHoldBillingSetUpButton() {
		boolean blnResult = billingPage.clickCreateHouseHoldBillingSetUpButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on create household billing setup ,Billing Setup page created",
				"User should able to see successfully Billing Setup page",
				"User is able to see Billing Setup page successfully created",
				"Failed to create the Billing setup page." + common.getStrError());
	}

	@When("^I should able to see Billing setup Confirmation page$")
	public void ishouldabletoseebillingsetupconfirmationpage() {
		boolean blnResult = billingPage.verifyHouseholdGroupBillingCreated();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on create Household Billing Set up Button,New Household Billing Set created",
				"User should able to see successfully Household Group Billing Setup page",
				"User is able to see New household Billing set up Confirmation page",
				"Failed to view Household group Billing Setup page." + common.getStrError());

	}

	@Then("^I should able to see Edit Billing Confirmation page$")
	public void ishouldabletoseebillingupdatedconfirmationpage() {
		boolean blnResult = newHouseholdPage.verifyBillingUpdatedConfirmationPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Submit Changes for Billing",
				"User should able to see successfully Billing changes updated",
				"User is able to see successfully billing updated Confirmation page",
				"Failed to view updated billing confirmation page." + common.getStrError());

	}

	@Then("^I Enter the RepID in Supportview$")
	public void ienterrepidinsupportview() {
		String repID = testData.get("repID");
		boolean blnResult = homePage.performCWSupportView("RepID", repID);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User Select the Suppportview",
				"User should able to Enter RepID successfully in Supportview",
				"User is able to entered RepID successfully supportview page",
				"Failed to enter the RepID in supportview page." + common.getStrError());
		driver.get(testData.get("HHURL"));
	}

	@And("^I click on Groups Tab$")
	public void iclickongroupstab() {
		boolean blnResult = newHouseholdPage.clickGroupsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Groups Tab ,Groups grid got displayed", "User should able to see Groups Page",
				"User is able to see Household Groups", "Failed to see Household Groups." + common.getStrError());
	}

	@When("^I enter Groupname$")
	public void ientergroupname() {
		String groupName = testData.get("groupName");
		boolean blnResult = newHouseholdPage.enterGroupname(groupName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the Groupname",
				"Groupname should be entered", "Group name is entered",
				"Failed to Enter Group Name." + common.getStrError());
	}

	@Then("^I click on search button$")
	public void iclickonsearchbutton() {
		boolean blnResult = newHouseholdPage.clicksearch();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on search Button",
				"User should click successfully on search button",
				"User is able to click on search button successfully",
				"Failed to click search button" + common.getStrError());
	}

	@Then("^I see Billing Rate section$")
	public void iseebillingratesection() {
		boolean blnResult = newHouseholdPage.verifybillingrate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User land on summmary page of Household Group name",
				"User should see successfully billing rate for Household Group",
				"User is able to view billing rate on Household Group summary page successfully",
				"Failed to view billing rate on summary page of Household Group ." + common.getStrError());

	}

	@Then("^I click on Open All$")
	public void iclickonopenall() {
		boolean blnResult = newHouseholdPage.verifyopenallchevroncontent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on open all chevron content in billing rate",
				"User should see successfully billing rate chevron open for Household Group",
				"User is able to view content chevron open all for billing rate on Household Group summary page successfully",
				"Failed to view open all content chevron for billing rate on summary page of Household Group ."
						+ common.getStrError());

	}

	@Then("^I should view Advisory Fee value$")
	public void ishouldviewadvisoryfee() {
		boolean blnResult = newHouseholdPage.verifyadvisoryfee();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on open all chevron content in billing rate",
				"User should see successfully advisory fee for Household Group billing client",
				"User is able to view advisory fee for billing of Household Group on summary page successfully",
				"Failed to view advisory fee for billing on summary page of Household Group ." + common.getStrError());

	}

	@When("^I click on a hyperlinked Household Group name$")
	public void iclickonahyperlinkedhouseholdgroupname() {
		common.wait(5);
		boolean blnResult = newHouseholdPage.clickHHGroupName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hyperlinked Household Group name",
				"User should click successfully on Hyperlinked Household Group name",
				"User is able to click on Hyperlinked Household Group name successfully",
				"Failed to click Hyperlinked Household Group name." + common.getStrError());

	}

	@When("^I click on a Household Group name$")
	public void iclickonhouseholdgroupname() {
		boolean blnResult = newHouseholdPage.clickGroupName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hyperlinked Household Group name",
				"User should click successfully on Hyperlinked Household Group name",
				"User is able to click on Hyperlinked Household Group name successfully",
				"Failed to click Hyperlinked Household Group name." + common.getStrError());

	}

	@Then("^I should see household group Dashboard page$")
	public void ishouldseehouseholdgroupdashboardpage(){
		common.waitForPageLoading();
		boolean blnResult = householdDashBoardPage.isDashboardPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Household Groupname,Household group dashboard page displayed",
				"User should able to see selected household dashbaord page",
				"User is able to see Household Dashboard Page",
				"Failed to see Household Dashboard page." + common.getStrError());
	}

	@Then("^I need to see following values$")
	public void iNeedToSeeFollowingValues(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = householdDashBoardPage.BalanceAndInvestmentSectionVisible(data.get("fields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("fields") + " available",
					"User should able to see the  " + data.get("fields") + "fields",
					" listed field values is " + data.get("fields") + " visible",
					"Failed : listed field values " + data.get("fields") + "are NOT visible");

		}
	}

	@When("^I should see VOT graph$")
	public void ishouldseeVOTgraph() {
		boolean blnResult = householdDashBoardPage.VOTGraphDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User navigates to dashboard Page,Balances and investmention section displayed",
				"User should able to see VOT graph", "User is able to see VOT graph",
				"Failed to see VOT graph" + common.getStrError());
	}

	@Then("^I should see both X axis and Y axis$")
	public void ishouldseebothXaxisandYaxis() {
		boolean blnResult = householdDashBoardPage.VOTGraphAxisDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User navigates to Balances and investmention section ,VOT graph is displayed",
				"User should able to see time over 1-year in X axis and account values in Y  axis",
				"User is able to see time over 1-year in X axis and account values in Y  axis",
				"Failed to see time over 1-year in X axis and account values in Y  axis" + common.getStrError());
	}

	@When("^I click on Edit Summary Button$")
	public void iClickOnEditSummaryButton() {
		common.waitForPageLoading();
		boolean blnResult = householdDashBoardPage.clickEditHouseholdSummaryButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit household summary Button",
				"User should click successfully on  Edit household summary Button",
				"User is able to click on Edit household summary Button successfully",
				"Failed to click  Edit household summary Button " + common.getStrError());

	}

	@Then("^I should see Edit Household Page$")
	public void ishouldseeEditHouseholdPage() {
		boolean blnResult = newHouseholdPage.EditHouseholdPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Household summary Button,Edit Household page displayed",
				"User should able to see edit household page", "User is able to see edit Household Page",
				"Failed to see edit Household page." + common.getStrError());
	}

	@When("^I see Account tiles$")
	public void i_see_Account_tiles() {
		boolean blnResult = householdDashBoardPage.AccountTileDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Household summary Button,Edit Household page displayed",
				"User should able to see account tile", "User is able to see account tile",
				"Failed to see account tile" + common.getStrError());
	}

	@Then("^I should see following account tile fields$")
	public void ishouldseefollowingaccounttilefields(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = householdDashBoardPage.AccountTileFieldVisible(data.get("Accounttilefields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("Accounttilefields") + " available",
					"User should able to see the  " + data.get("Accounttilefields") + "fields",
					" listed field values is " + data.get("Accounttilefields") + " visible",
					"Failed : listed field values " + data.get("Accounttilefields") + "are NOT visible");

		}
	}
	
	@Then("^I should see following account tile fields for CS on confirmation page$")
	public void ishouldseefollowingaccounttilefieldsForCSOnConfiramtionPage(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = combinedStatementPage.ValidateColumnNamesCSConfPage(data.get("Accounttilefields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("Accounttilefields") + " available",
					"User should able to see the  " + data.get("Accounttilefields") + "fields",
					" listed field values is " + data.get("Accounttilefields") + " visible",
					"Failed : listed field values " + data.get("Accounttilefields") + "are NOT visible");

		}
	}

	@When("^I click on Edit combined statement Button$")
	public void iclickonEditcombinedstatementButton() {
		boolean blnResult = combinedStatementPage.clickEditCombinedStatementButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit combined Statement Button",
				"User should click successfully on Edit combined Statement Button",
				"User is able to click on Edit combined statement Button successfully",
				"Failed to click  Edit combined statement Button " + common.getStrError());

	}

	@Then("^I should see Edit combined statement Page$")
	public void ishouldseeEditcombinedstatementPage() {
		boolean blnResult = combinedStatementPage.EditcombinedstatementPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit combined statement Button,Edit combined statement page displayed",
				"User should able to see edit combined statement page",
				"User is able to see edit combined statement Page",
				"Failed to see edit combined statement page." + common.getStrError());
	}

	@When("^I click on Edit Billing Rate Button$")
	public void iclickonEditBillingRateButton() {
		boolean blnResult = householdDashBoardPage.clickEditbillingratebutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Billing Rate Button",
				"User should click successfully on EditBilling Rate Button",
				"User is able to click on Edit Billing Rate Button successfully",
				"Failed to click  Edit Billing Rate Button " + common.getStrError());
	}

	@Then("^I should see Edit Billing details Page$")
	public void ishouldseeEditBillingdetailsPage() {
		boolean blnResult = billingPage.EditbillingPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Billing Rate Button,Edit billing page displayed",
				"User should able to see Edit billing page", "User is able to see edit billing Page",
				"Failed to see edit billing page." + common.getStrError());
	}

	@When("^I click on Show Full Details hyperlink$")
	public void iclickonShowFullDetailshyperlink() {
		boolean blnResult = householdDashBoardPage.clickshowfulldetailshyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Show Full Details hyperlink ",
				"User should click successfully on Show Full Details hyperlink",
				"User is able to click on Show Full Details hyperlink successfully",
				"Failed to click Show Full Details hyperlink" + common.getStrError());

	}

	@Then("^I should see Hide Full Details hyperlink$")
	public void ishouldseeHideFullDetailshyperlink() {
		boolean blnResult = householdDashBoardPage.hidefulldetailshyperlinkDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Show Full Details hyperlink,Hide Full Details hyperlink displayed",
				"User should able to see Hide Full Details hyperlink",
				"User is able to see Hide Full Details hyperlink",
				"Failed to see Hide Full Details hyperlink" + common.getStrError());

	}

	@When("^I see groups value and cash accounts breakdown panel$")
	public void iseegroupsvalueandcashaccountsbreakdownpanel() {
		boolean blnResult = householdDashBoardPage.assetallocationbreakdownPanelDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Show Full Details hyperlink,groups value and cash accounts breakdown panel displayed",
				"User should able to see groups value and cash accounts breakdown panel",
				"User is able to see groups value and cash accounts breakdown panel",
				"Failed to see groups value and cash accounts breakdown panel" + common.getStrError());
	}

	@Then("^I should see following fields in groups breakdown cash values$")
	public void ishouldseefollowingfieldsingroupsbreakdowncashvalues(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = householdDashBoardPage.Assetallocationbreakdown(data.get("assetallocationbreakdownFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("assetallocationbreakdownFields") + " available",
					"User should able to see the  " + data.get("assetallocationbreakdownFields") + "fields",
					" listed field values is " + data.get("assetallocationbreakdownFields") + " visible",
					"Failed : listed field values " + data.get("assetallocationbreakdownFields") + "are NOT visible");
		}
	}

	@When("^I click on Hide Full Details hyperlink$")
	public void iclickonHideFullDetailshyperlink() {
		boolean blnResult = householdDashBoardPage.clickshidefulldetailshyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hide Full Details hyperlink ",
				"User should click successfully on Hide Full Details hyperlink",
				"User is able to click on Hide Full Details hyperlink successfully",
				"Failed to click Hide Full Details hyperlink" + common.getStrError());

	}

	@Then("^I see Show Full Details hyperlink$")
	public void iseeShowFullDetailshyperlink() {
		boolean blnResult = householdDashBoardPage.showfulldetailshyperlinkDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hide Full Details hyperlink,Show Full Details hyperlink displayed",
				"User should able to see Show Full Details hyperlink displayed",
				"User is able to see Show Full Details hyperlink displayed",
				"Failed to see Show Full Details hyperlink displayed" + common.getStrError());

	}

	@When("^I see Notes Section$")
	public void iseeNotesSection() {
		boolean blnResult = householdDashBoardPage.notessectionDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User navigates to dashboard Page,Notes section displayed",
				"User should able to see Notes section displayed", "User is able to see notes section displayed",
				"Failed to see notes sections displayed" + common.getStrError());

	}

	@Then("^I should see Add Notes hyperlink$")
	public void ishouldseeAddNoteshyperlink() {
		boolean blnResult = householdDashBoardPage.addnotehyperlinkDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User see notes section,Add Note hyperlink displayed",
				"User should able to see Add Note hyperlink displayed", "User is able to see Add Note displayed",
				"Failed to see Add Note displayed" + common.getStrError());

	}

	@When("^I click on Add Note hyperlink$")
	public void iclickonAddNotehyperlink() {
		boolean blnResult = householdDashBoardPage.clickaddnotehyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on Add Note hyperlink ",
				"User should click successfully on Add Note hyperlink",
				"User is able to click on Add Note hyperlink successfully",
				"Failed to click Add Note hyperlink" + common.getStrError());
	}

	@Then("^I should see New Note Window$")
	public void ishouldseeNewNoteWindow() {
		boolean blnResult = householdDashBoardPage.newnotewindowDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Add Note hyperlink,New note window displayed",
				"User should able to see New note window displayed", "User is able to see New note window displayed",
				"Failed to see New note window displayed" + common.getStrError());
	}

	@When("^I enter mandatory note fields$")
	public void ientermandatorynotefields() {
		boolean blnResult = householdDashBoardPage.enternotefields();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User enter note fields",
				"User should able to Enter note title and note text", "User is able to enter note title and note text",
				"Failed to enter the enter note title and note text" + common.getStrError());
	}

	@Then("^I select Note Type$")
	public void iselectNoteType() {
		boolean blnResult = householdDashBoardPage.selectnotetype();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on note type dropdown",
				"User should select successfully note type", "User is able to select note type successfully",
				"Failed to select note type" + common.getStrError());
	}

	@When("^I click on save button$")
	public void iclickonsavebutton() {
		boolean blnResult = householdDashBoardPage.clicknotesavebutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on save note button",
				"User should click successfully on save note button",
				"User is able to click on save note button successfully",
				"Failed to click on save note button" + common.getStrError());

	}

	@Then("^I should see Created Note$")
	public void ishouldseeCreatedNote() {
		boolean blnResult = householdDashBoardPage.createdNoteDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on save note button,Created note displayed",
				"User should able to see created note displayed", "User is able to see created note displayed",
				"Failed to see created Note" + common.getStrError());
	}

	@After
	public void report() {
		driver.close();
		driver.quit();
		LPLCoreReporter.writeSummary();
	}

	@When("^User has expanded the CONTENTS panel in the Billing Rate section of Household Capabilities on Dashboard$")
	public void iclickonBillingRateContentsPanel() {
		boolean blnResult = newHouseholdPage.clickBillingRateContentsPanel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hyperlinked Billing Rate Contents Panel",
				"User should click successfully on Hyperlinked Billing Rate Contents Panel",
				"User is able to click on Hyperlinked Billing Rate Contents Panel successfully",
				"Failed to click Hyperlinked Billing Rate Contents Panel" + common.getStrError());

	}

	@Then("^Open all hyperlink is displayed$")
	public void iseeOpenAllHyperlink() {
		boolean blnResult = newHouseholdPage.isOpenAllHyperlinkDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Contents panel on Dashboard in Billing Rate section",
				"User should successfully able to see Open All hyperlink",
				"User is able to see Open All hyperlink in Billing Rate section on Dashboard successfully",
				"Failed to see Open All hyperlink in Billing Rate section" + common.getStrError());

	}

	@When("^Open all hyperlink is selected$")
	public void iclickonOpenAllHyperlink() {
		boolean blnResult = newHouseholdPage.clickOpenAllHyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Open All Hyperlink on Dashboard in Billing Rate section",
				"User should click successfully on Open All hyperlink in Billing Rate section",
				"User is able to click on Open All hyperlink in Billing Rate section successfully",
				"Failed to click Open All hyperlink in Billing Rate section" + common.getStrError());

	}

	@Then("^The Open all  hyperlink label changes to Close all$")
	public void iseeCloseAllHyperlink() {
		boolean blnResult = newHouseholdPage.isCloseAllHyperlinkDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Billing Rate Open all Hyperlink on Dashboard Page",
				"User should successfully see Close All hyperlink",
				"User is able to see Close All Hyperlink in Billing Rate section on Dashboard Page successfully",
				"User failed to see Close All hyperlink in Billing Rate section on Dashboard page "
						+ common.getStrError());

	}

	@When("^a client name is selected in the account details in the Billing Rate section of Household Capabilities$")
	public void iSelectClientName() {
		boolean blnResult = newHouseholdPage.ClientNameHyperlinkSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Client name Hyperlink in Billing Rate section on Dashboard Page",
				"User should successfully click on Client Name hyperlink",
				"User is able to click on Client Name hyperlink in Billing Rate section on Dashboard Page successfully",
				"User failed to click on Client Name hyperlink in Billing Rate section on Dashboard page "
						+ common.getStrError());

	}

	@Then("^User is navigated to the Client Summary page for that client within the same browser tab$")
	public void iSeeClientSummaryPage() {
		boolean blnResult = newHouseholdPage.isClientSummaryPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Client Name hyperlink in Billing Rate Household Capability section",
				"User should successfully see selected Client Summary page",
				"User is able to see Client Summary page successfully",
				"User failed to see Client Summary page " + common.getStrError());

	}

	@When("^Account number is selected in the account details in the Billing Rate section of Household Capabilities$")
	public void iSelectAccountNumber() {
		boolean blnResult = billingPage.AccountNumberHyperlinkSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Account Number Hyperlink in Billing Rate section on Dashboard Page",
				"User should successfully click on Account Number hyperlink",
				"User is able to click on Account Number hyperlink in Billing Rate section on Dashboard Page successfully",
				"User failed to click on Account Number hyperlink in Billing Rate section on Dashboard page "
						+ common.getStrError());

	}

	@Then("^User is navigated to the Account Summary page for that client within the same browser tab$")
	public void iSeeAccountSummaryPage() {
		boolean blnResult = newHouseholdPage.isAccountSummaryPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Account Number hyperlink in Billing Rate Household Capability section",
				"User should successfully see selected Account Summary page",
				"User is able to see Account Summary page successfully",
				"User failed to see Account Summary page " + common.getStrError());

	}

	@When("^User is on Bank Sweep Capability Tile")
	public void iseeBankSweepTile() {
		boolean blnResult = newHouseholdPage.isBankSweepDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Dashboard",
				"User should see Bank Sweep Capability Tile successfully",
				"User is successfully able to see Bank Sweep Capability tile",
				"User failed to see Bank Sweep capability tile" + common.getStrError());

	}

	@Then("^User should not see edit pencil icon on bank Sweep Tile")
	public void validateEditIconDisplayed() {
		boolean blnResult = newHouseholdPage.isEditPencilIconisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Bank Sweep Capability Tile on dashboard  ",
				"User should not see Edit Pencil Icon on Bank Sweep Capability tile",
				"User is unable to see Edit pencil icon on Bank Sweep Capability tile successfully ",
				"User failed to not see Edit pencil icon on Bank Sweep capability tile" + common.getStrError());

	}

	@Then("^User will see link on top of the dashboard to move between the household groups grid and the summary tab$")
	public void ishouldseedashboardbacklink()

	{
		boolean blnResult = newHouseholdPage.isDashboardBackLinkDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Household Groupname,Household group dashboard page displayed",
				"User should able to see selected household dashbaord page",
				"User is able to see Back Link on Dashboard Page",
				"Failed to see Back Link on Dashboard Page" + common.getStrError());
	}

	@When("^User click on Back Link$")
	public void iclickonbacklink() {
		boolean blnResult = newHouseholdPage.clickBackLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hyperlinked Back Link On Dashboard Page",
				"User should successfully click on Hyperlinked Back Link",
				"User is able to click on Hyperlinked Back Link successfully",
				"Failed to click Hyperlinked Back Link" + common.getStrError());
	}

	@Then("^User is navigated to groups grid$")
	public void iseegroupsgrid() {
		boolean blnResult = newHouseholdPage.isGroupsGridDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hyperlinked Back Link On Dashboard Page",
				"User should successfully land on Groups Grid page of CW",
				"User is able to navigate back on Groups Grid successfully",
				"Failed to navigate back to Groups Grid" + common.getStrError());

	}

	@Then("^The advisory fee details panel is opened for all clients that are displayed$")
	public void iSeePanelOpen() {
		boolean blnResult = newHouseholdPage.isPanelOpen();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Open All link On Dashboard Page",
				"User should successfully see The advisory fee details panel is opened for all client�s that are displayed",
				"User is able to see The advisory fee details panel is opened for all client�s that are displayed successfully",
				"Failed to see The advisory fee details panel" + common.getStrError());

	}

	@When("^Close all hyperlink is selected$")
	public void iClickCloseAllLink() {
		boolean blnResult = newHouseholdPage.clickCloseAllLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Close All link On Dashboard Page",
				"User should successfully able to click on Close All link in Billing Tile on Dashboard",
				"User is able to click on Close All link in Billing Tile on Dashboard successfully",
				"Failed to click on Close All link in Billing Tile on Dashboard" + common.getStrError());

	}

	@Then("^all the open panels close$")
	public void iSeePanelClosed() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.isPanelClosed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Close All link On Dashboard Page",
				"User should successfully see The advisory fee details panel is closed for all client�s that are displayed",
				"User is able to see The advisory fee details panel is closed for all client�s that are displayed successfully",
				"Failed to see The advisory fee details panel closed" + common.getStrError());

	}

	@Then("^I should switch to the MODAL Frame$")
	public void iswitchtoModalFrame() {
		// Switching to the Frame
		boolean blnResult = newHouseholdPage.switchToFrame(MODALFRAME);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Switch to the MODAL Frame.",
				"User should be able to Switch to the MODAL Frame.", "Switch to the MODAL Frame was successfull",
				"Failed to Switch to the MODAL Frame. Error" + common.getStrError());
	}

	@Then("^I should see a Pop-up box$")
	public void iverifypopupbox() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.verifyPopupbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When Primary Client is not eligible for Billing then Pop-up box is displayed",
				"User should be able to view Pop-up box successfully", "User is able to view Pop-up box successfully",
				"Failed to view Pop-up box in Household confirmation page." + common.getStrError());
	}

	@Then("^I should see the text present in Pop-up box$")
	public void iverifypopupboxText() {
		boolean blnResult = newHouseholdPage.verifyPopupboxText();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When Primary Client is not eligible for Billing then Pop-up box is displayed",
				"User should be able to view the text message present in Pop-up box successfully",
				"User is able to view the text message present in Pop-up box successfully",
				"Failed to view the text message present in Pop-up box in Household confirmation page."
						+ common.getStrError());
	}

	@Then("^I click on OK button in Pop-up box$")
	public void clickOKButtoninpopupbox() {
		boolean blnResult = newHouseholdPage.clickOKButtonPopupbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When Primary Client is not eligible for Billing then Pop-up box is displayed",
				"User should be able to click on OK button in Pop-up box successfully",
				"User is able to click on OK button in Pop-up box",
				"Failed to click on OK button in Pop-up box." + common.getStrError());
	}

	@Then("^I should land on Streamline/Confirmation page$")
	public void ishouldlandonconfirmationpage() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.validateConfirmationPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on OK button in Pop-up box, Pop-up box should disappear",
				"User should land on Streamline/Confirmation page successfully",
				"User is able to land on Streamline/Confirmation page successfully",
				"Failed to land on Streamline/Confirmation page." + common.getStrError());

	}

	@Then("^I should view changes not saved popup$")
	public void ishouldviewchangesnotsavedpopup() {
		boolean blnResult = newHouseholdPage.verifyChangesNotSavedPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on close button into edit household setup page able to view Changes not saved popup",
				"User should able to view Close button Changes not saved popup successfully",
				"User is able to view Close button Changes not saved popup successfully",
				"Failed to view Close button Changes not saved popup in edit Household setup page."
						+ common.getStrError());

	}

	@When("^I click on changes not saved pop GO BACK button$")
	public void iclickongobackbutton() {
		boolean blnResult = newHouseholdPage.clickGoBackButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click GO BACK button in Close Changes not saved popup",
				"GO BACK button should be click successfully", "GO BACK button is clicked sucessfully",
				"Failed to click the GO BACK button in close Changes not saved popup" + common.getStrError());
	}

	@When("^I click on changes not saved pop PROCEED TO CLOSE button$")
	public void iclickonproceedtoclosebutton() {
		boolean blnResult = newHouseholdPage.clickProceedToCloseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click PROCEED TO CLOSE button in Close Changes not saved popup",
				"PROCEED TO CLOSE button should be click successfully",
				"PROCEED TO CLOSE button is clicked sucessfully",
				"Failed to click the PROCEED TO CLOSE button in close Changes not saved popup" + common.getStrError());
	}

	@Then("^I should able to see Please select a primary client error message$")
	public void iverifyPleaseSelectPrimaryClientText() {
		boolean blnResult = newHouseholdPage.verifyPleaseSelectPrimaryClientText();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When Primary Client is not selected then Please select a primary client. error message is displayed",
				"User should be able to view Please select a primary client. error message successfully",
				"User is able to view Please select a primary client. error message successfully",
				"Failed to view the Please select a primary client. error message in Household setup page."
						+ common.getStrError());
	}

	@Then("^I should able to see No results found. message$")
	public void iverifyNoResultFoundText() {
		common.wait(5);
		boolean blnResult = newHouseholdPage.verifyNoResultFoundText();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When Search term results no result then No results found. message is displayed",
				"User should be able to view No results found. message successfully",
				"User is able to view No results found. message successfully",
				"Failed to view the No results found. message in Household setup page." + common.getStrError());
	}

	@When("^I click on remove client button$")
	public void iclickonremoveclientbutton() {
		boolean blnResult = newHouseholdPage.clickRemoveClientButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click Remove button in create Household setup page",
				"Remove button should be click successfully", "Remove button is clicked sucessfully",
				"Failed to click the Remove button in create Household setup page" + common.getStrError());

	}

	@Then("^I should see tooltip for Forms$")
	public void ishouldseetooltipforforms() {
		boolean blnResult = newHouseholdPage.isFormsTooltipDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the tooltip of the Forms is displayed", "Tooltip of the Forms should be displayed",
				"Forms Tooltip is displayed", "Failed to display the Forms Tooltip" + common.getStrError());
	}

	@Then("^I Should view Forms tooltip content$")
	public void ishouldviewformstooltipcontent() {
		boolean blnResult = newHouseholdPage.isFormstipContentDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the tooltip content of the Forms is displayed",
				"Tooltip content of the Forms should be displayed", "Forms Tooltip content is displayed",
				"Failed to display the Forms Tooltip content" + common.getStrError());
	}

	@When("^I click on Billing Form PDF button in Forms tooltip$")
	public void iclickonbillingformbuttoninFormsTooltip() {
		boolean blnResult = newHouseholdPage.clickBillingFormPDFBtnFormsTooltip();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to click on Billing Form PDF button in Forms Tooltip",
				"Billing Form PDF button in Forms Tooltip should be clicked successfully",
				"Billing Form PDF button in Forms Tooltip is clicked sucessfully",
				"Failed to click on Billing Form PDF button in Forms Tooltip" + common.getStrError());

	}

	@Then("^I Should view Forms tooltip content When Outstanding DocGrid is Present$")
	public void ishouldviewformstooltipwhenoutstandingDocGridpresent() {
		boolean blnResult = newHouseholdPage.isFormsContentWhenOutstandingDocGridPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the tooltip content of the Forms is displayed When Outstanding DocGrid is Present",
				"Tooltip content of the Forms should be displayed When Outstanding DocGrid is Present",
				"Forms Tooltip content is displayed When Outstanding DocGrid is Present",
				"Failed to display the Forms Tooltip content When Outstanding DocGrid is Present"
						+ common.getStrError());
	}

	@When("^I Should view Prepare Form For Signature Button$")
	public void ishouldviewPrepareFormForSignatureButton() {
		boolean blnResult = newHouseholdPage.isPrepareFormForSignatureButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to see Prepare Form For Signature Button in Streamline/Confirmation page",
				"Prepare Form For Signature Button should be Present", "Prepare Form For Signature Button is Present",
				"Failed to view Prepare Form For Signature Button in Streamline/Confirmation page"
						+ common.getStrError());

	}

	@When("^I click on Prepare Form For Signature Button$")
	public void iclickonPrepareFormForSignatureButton() {
		boolean blnResult = newHouseholdPage.clickPrepareFormForSignatureButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click Prepare Form For Signature Button in Streamline/Confirmation page",
				"Prepare Form For Signature Button should be click successfully",
				"Prepare Form For Signature Button is clicked sucessfully",
				"Failed to click the Prepare Form For Signature Button in Streamline/Confirmation page"
						+ common.getStrError());

	}

	@Then("^I should scroll down to Form Ready to Sign Panel$")
	public void ishouldviewformreadytosignpanel() {
		boolean blnResult = newHouseholdPage.isFormReadyToSignPanelDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Form Ready to Sign Panel is displayed", "Form Ready to Sign Panel should be displayed",
				"Form Ready to Sign Panel is displayed",
				"Failed to display Form Ready to Sign Panel" + common.getStrError());
	}

	@Then("^I should see Form Ready to Sign Label$")
	public void ishouldseeformreadytosignlabel() {
		boolean blnResult = newHouseholdPage.isFormReadytoSignLabel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the Form Ready to Sign Label is displayed", "Form Ready to Sign Label should be displayed",
				"Form Ready to Sign Label is displayed",
				"Failed to display tForm Ready to Sign Label" + common.getStrError());
	}

	@Then("^I should see the !ACTIVATION REQUIRES FORMS indicator in Form Ready to Sign Panel$")
	public void ishouldseeActivationIndicatorinFormReadytoSign() {
		boolean blnResult = newHouseholdPage.isActivationIndicatorInFormReadyToSign();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if !ACTIVATION REQUIRES FORMS indicator in Form Ready to Sign Panel is displayed",
				"!ACTIVATION REQUIRES FORMS indicator in Form Ready to Sign Panel should be displayed",
				"!ACTIVATION REQUIRES FORMS indicator in Form Ready to Sign Panel is displayed",
				"Failed to display !ACTIVATION REQUIRES FORMS indicator in Form Ready to Sign Panel"
						+ common.getStrError());
	}

	@Then("^I Should view Form Ready to Sign Panel content When Outstanding DocGrid is Present$")
	public void ishouldviewformreadytosignwhenoutstandingDocGridpresent() {
		boolean blnResult = newHouseholdPage.isFormReadytoSignWhenOutstandingDocGridPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Form Ready to Sign content is displayed When Outstanding DocGrid is Present",
				"Form Ready to Sign content should be displayed When Outstanding DocGrid is Present",
				"Form Ready to Sign content is displayed When Outstanding DocGrid is Present",
				"Failed to display the Form Ready to Sign content When Outstanding DocGrid is Present"
						+ common.getStrError());
	}

	@When("^I click on Billing Form PDF button in Form Ready to Sign Panel$")
	public void iclickonbillingformbuttoninFormReadytoSignPanel() {
		boolean blnResult = newHouseholdPage.clickBillingFormPDFBtnFormReadytoSign();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to click on Billing Form PDF button in Form Ready to Sign Panel",
				"Billing Form PDF button in Form Ready to Sign Panel should be clicked successfully",
				"Billing Form PDF button in Form Ready to Sign Panel is clicked sucessfully",
				"Failed to click on Billing Form PDF button in Form Ready to Sign Panel" + common.getStrError());

	}

	@When("^I click on drop down available in Form Ready to Sign Panel$")
	public void iclickondropdowninformreadytosignpanel() {
		boolean blnResult = newHouseholdPage.clickDropDownFormReadytoSign();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on drop down in available in Form Ready to Sign Panel",
				"Drop down in available in Form Ready to Sign Panel should be click successfully",
				"Drop down in available in Form Ready to Sign Panel is clicked sucessfully",
				"Failed to click drop down in available in Form Ready to Sign Panel" + common.getStrError());

	}

	@When("^I select drop down value in Form Ready to Sign Panel$")
	public void iselectdropdownvalueinformreadytosignpanel() {
		boolean blnResult = newHouseholdPage.clickDropDownValueFormReadytoSign();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to select drop down value in Form Ready to Sign Panel",
				"Drop down value in Form Ready to Sign Panel should be selected successfully",
				"Drop down value in Form Ready to Sign Panel is selected sucessfully",
				"Failed to select drop down value in Form Ready to Sign Panel" + common.getStrError());

	}

	@Then("^I click on Prepare Form For Signature Button in Form Ready to Sign Panel$")
	public void iclickonPrepareFormForSignatureBtnForm() {
		boolean blnResult = newHouseholdPage.clickPrepareFormForSignatureBtnForm();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click Prepare Form For Signature Button in Form Ready to Sign Panel",
				"Prepare Form For Signature Button in Form Ready to Sign Panel should be click successfully",
				"Prepare Form For Signature Button in Form Ready to Sign Panel is clicked sucessfully",
				"Failed to click the Prepare Form For Signature Button in Form Ready to Sign Panel"
						+ common.getStrError());

	}

	@When("^I see selected Position Balances Update Frequency hyperlink$")
	public void iseeselectedPositionBalancesUpdateFrequencyhyperlink() {
		boolean blnResult = householdDashBoardPage.PositionBalancesUpdateFrequencyDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User scrolls down from Balances and investment section,Selected hyperlink position Balances Update Frequency Displayed",
				"User should able to see Selected hyperlink position Balances Update Frequency displayed",
				"User is able to see Selected hyperlink position Balances Update Frequency displayed",
				"Failed to see Selected hyperlink position Balances Update Frequency" + common.getStrError());
	}

	@Then("^I should see default Intraday Updated Balances option$")
	public void ishouldseedefaultIntradayUpdatedBalancesoption() {
		boolean blnResult = householdDashBoardPage.defaultIntradayUpdatedBalancesoptionDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User scrolls down from Balances and investment section",
				"User should able to see default Intraday Updated Balances option displayed",
				"User is able to see default Intraday Updated Balances option displayed",
				"Failed to see default Intraday Updated Balances option" + common.getStrError());
	}

	@And("^I select Previous Market Close option from dropdown$")
	public void iselectPreviousMarketCloseoptionfromdropdown() {
		boolean blnResult = householdDashBoardPage.clickPreviousMarketPlaceDropdownOption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Previous Market Close option displayed in dropdown",
				"User should able to see Previous Market Close option displayed",
				"User is able to see Previous Market Close option displayed",
				"Failed to see Previous Market Close option" + common.getStrError());
	}

	@When("^I click on selected Previous Market Close option$")
	public void iclickonselectedPreviousMarketCloseoption() {
		boolean blnResult = householdDashBoardPage.clickpreviousMarketCloseoption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on selected Previous Market Close option",
				"Default Previous Market Close option should be click successfully",
				"Default Previous Market Close option is clicked sucessfully",
				"Failed to click on selected Previous Market Close option" + common.getStrError());

	}

	@Then("^I should toggle to Intraday Updated Balances option$")
	public void ishouldtoggletoIntradayUpdatedBalancesoption() {
		boolean blnResult = householdDashBoardPage.clickintradaydropdownoption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Intraday Updated Balances option from dropdown",
				"User should able to see Intraday Updated Balances option displayed",
				"User is able to see Intraday Updated Balances option displayed",
				"Failed to see see Intraday Updated Balances option" + common.getStrError());
	}

	@When("^I click on Intraday Updated Balances option$")
	public void iclickonIntradayUpdatedBalancesoption() {
		boolean blnResult = householdDashBoardPage.clickintradayupdatedbalancesoption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Intraday Updated Balances option,Previous Market Close option displayed",
				"User should able to see Previous Market Close option displayed",
				"User is able to see Previous Market Close option displayed",
				"Failed to see Previous Market Close option" + common.getStrError());
	}

	@Then("^I should toggle to Previous Market Close option$")
	public void ishouldtoggletoPreviousMarketCloseoption() {
		boolean blnResult = householdDashBoardPage.clickPreviousMarketPlaceDropdownOption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Previous Market Close option displayed in dropdown",
				"User should able to see Previous Market Close option displayed",
				"User is able to see Previous Market Close option displayed",
				"Failed to see Previous Market Close option" + common.getStrError());
	}

	@When("^I click on Position Balances Update Frequency dropdown$")
	public void iclickonPositionBalancesUpdateFrequencydropdown() {
		boolean blnResult = householdDashBoardPage.clickupdatefrequencydropdownbutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on Position Balances Update Frequency dropdown",
				"Position Balances Update Frequency dropdown should be click successfully",
				"Position Balances Update Frequency dropdown is clicked sucessfully",
				"Failed to click on Position Balances Update Frequency dropdown" + common.getStrError());
	}

	@Then("^I should see below mention Position Balances Update Frequency options$")
	public void ishouldseebelowmentionPositionBalancesUpdateFrequencyoptions(DataTable field) {

		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = householdDashBoardPage.updateFrequencydropdownoptions(data.get("FrequencyFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("FrequencyFields") + " available",
					"User should able to see the  " + data.get("FrequencyFields") + "fields",
					" listed field values is " + data.get("FrequencyFields") + " visible",
					"Failed : listed field values " + data.get("FrequencyFields") + "are NOT visible");

		}
	}

	@Then("^I should see edit combined statement alert popup$")
	public void ishouldseeeditcombinedstatementalertpopup() {
		boolean blnResult = combinedStatementPage.editCombinedStatementalertpopupDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on edit combined Statement pencil icon",
				"User should able to see edit combined statement alert popup displayed",
				"User is able to see edit combined statement alert popup displayed",
				"Failed to see edit combined statement alert popup" + common.getStrError());
	} 

	@When("^I see edit combined statement alert popup text$")
	public void iseeeditcombinedstatementalertpopuptext() {
		boolean blnResult = combinedStatementPage.editCombinedStatementAlertTextDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User see edit combined statement alert popup",
				"User should able to see edit combined statement alert popup text displayed",
				"User is able to see edit combined statement alert popup text displayed",
				"Failed to see edit combined statement alert popup text" + common.getStrError());

	}

	@Then("^I should see edit combined statement alert popup options$")
	public void ishouldseeeditcombinedstatementalertpopupoptions() {
		boolean blnResult = combinedStatementPage.editCombinedStatementAlertOptionsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User see edit combined statement alert popup",
				"User should able to see EDIT and DELETE options displayed",
				"User is able to see EDIT and DELETE options displayed",
				"Failed to see EDIT and DELETE options displayed" + common.getStrError());
	}

	@Then("^I click on Edit button present in Banner in Combined Statement details Page$")
	public void iclickoneditoptionfromeditcombinedstatementalertpopup() {
		boolean blnResult = newHouseholdPage.clickediteditingbuttoncombinestatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User see edit combined statement alert popup",
				"User should able to see EDIT and DELETE options displayed",
				"User is able to see EDIT and DELETE options displayed",
				"Failed to see EDIT and DELETE options displayed" + common.getStrError());
	}

	@When("^I click on delete option from edit combined statement alert popup$")
	public void iclickondeleteoptionfromeditcombinedstatementalertpopup() {
		boolean blnResult = newHouseholdPage.clickdeleteeditingbuttoncombinestatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on DELETE option from edit combined statement alert popup",
				"DELETE option from edit combined statement alert popup should be click successfully",
				"Delete option from edit combined statement alert popup  is clicked sucessfully",
				"Failed to click on DELETE option from edit combined statement alert popup" + common.getStrError());

	}

	@Then("^I should see delete combined statement alert popup$")
	public void ishouldseedeletecombinedstatementalertpopup() {
		boolean blnResult = combinedStatementPage.deleteCombinedStatementalertpopupDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on DELETE option from edit combined statement alert popup",
				"User should able to see delete combined statement alert popup displayed",
				"User is able to see delete combined statement alert popup displayed",
				"Failed to see delete combined statement alert popup" + common.getStrError());

	}

	@When("^I see delete combined statement alert popup text$")
	public void iseedeletecombinedstatementalertpopuptext() {
		boolean blnResult = combinedStatementPage.deleteCombinedStatementalerttextDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on DELETE option from edit combined statement alert popup",
				"User should able to see delete combined statement alert popup text displayed",
				"User is able to see delete combined statement alert popup text displayed",
				"Failed to see delete combined statement alert popup text" + common.getStrError());

	}

	@Then("^I should see delete combined statement alert popup options$")
	public void ishouldseedeletecombinedstatementalertpopupoptions() {
		boolean blnResult = combinedStatementPage.deleteCombinedStatementalertoptionsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on DELETE option from edit combined statement alert popup",
				"User should able to see PROCEED TO DELETE and GO BACK options displayed",
				"User is able to see PROCEED TO DELETE and GO BACK options displayed",
				"Failed to see PROCEED TO DELETE and GO BACK options" + common.getStrError());
	}

	@When("^I click on proceed to delete option$")
	public void iclickonproceedtodeleteoption() {
		boolean blnResult = newHouseholdPage.clickproceedtodeleteoptiondeletecombinestatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on PROCEED TO DELETE option",
				"PROCEED TO DELETE option should be click successfully",
				"PROCEED TO DELETE option is clicked sucessfully",
				"Failed to click on PROCEED TO DELETE option" + common.getStrError());

	}

	@Then("^I should see done deleting button$")
	public void ishouldseedonedeletingbutton() {
		boolean blnResult = newHouseholdPage.deleteeditingbuttonCombinedstatementDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on DELETE option from edit combined statement alert popup",
				"User should able to see DELETE EDITING button displayed",
				"User is able to see DELETE EDITING button displayed",
				"Failed to see DELETE EDITING button" + common.getStrError());

	}

	@When("^I click on done deleting button$")
	public void iclickondonedeletingbutton() {
		boolean blnResult = newHouseholdPage.clickdeleteeditingbuttoncombinestatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to click on DELETE EDITING Button",
				"DELETE EDITING Button should be click successfully", "DELETE EDITING Button is clicked sucessfully",
				"Failed to click on DELETE EDITING Button" + common.getStrError());

	}

	@Then("^I  should see confirmation Page$")
	public void ishouldseeconfirmationPage() {
		boolean blnResult = combinedStatementPage.confirmationPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on DELETE EDITING Button", "User should able to see confirmation page displayed",
				"User is able to see confirmation page displayed",
				"Failed to see confirmation page" + common.getStrError());

	}

	@When("^I see Household Accounts Section$")
	public void iseeHouseholdAccountsSection() {
		boolean blnResult = newHouseholdPage.householdaccountsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User navigates to household DashBoardPage",
				"User should able to see Household Accounts section displayed",
				"User is able to see Household Accounts section displayed",
				"Failed to see Household Accounts section displayed" + common.getStrError());

	}

	@Then("^I should see below mention Household accounts breakdown Columns$")
	public void IshouldseebelowmentionHouseholdaccountsbreakdownColumns(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = newHouseholdPage.householdaccountscolumns(data.get("householdaccountsfields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("householdaccountsfields") + " available",
					"User should able to see the  " + data.get("householdaccountsfields") + "fields",
					" listed field values is " + data.get("householdaccountsfields") + " visible",
					"Failed : listed field values " + data.get("householdaccountsfields") + "are NOT visible");
		}
	}

	@Then("^I should see Billing details Page$")
	public void ishouldseeBillingdetailsPage() {
		boolean blnResult = newHouseholdPage.billingDetailsPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Billing Rate Button, Billing details page displayed",
				"User should able to see Billing details page", "User is able to see Billing details Page",
				"Failed to see Billing details page." + common.getStrError());
	}

	@Then("^I should see Banner in Billing details Page$")
	public void ishouldseeBannerinBillingdetailsPage() {
		boolean blnResult = newHouseholdPage.bannerinBillingDetailsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Billing Rate Button, in Billing details page Banner is displayed",
				"User should able to see Banner in Billing details page",
				"User is able to see Banner in Billing details Page",
				"Failed to see Banner in Billing details page." + common.getStrError());
	}

	@Then("^I should see Edit and Delete button in Banner in Billing details Page$")
	public void ishouldseeEditandDeletebuttoninBanner() {
		boolean blnResult = newHouseholdPage.editAndDeleteinbannerDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Billing details page, Edit and Delete button in Banner is displayed",
				"User should able to see Edit and Delete button in Banner of Billing details page",
				"User is able to see Edit and Delete button in Banner of Billing details Page",
				"Failed to see Edit and Delete button in Banner of Billing details page." + common.getStrError());
	}

	@When("^I click on Edit button present in Banner in Billing details Page$")
	public void iclickonEditbuttoninBillingDetailsBanner() {
		boolean blnResult = newHouseholdPage.clickEditbuttoninBanner();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to click on Edit button present in Banner in Billing details Page",
				"Edit button present in Banner in Billing details Page should be clicked successfully",
				"Edit button present in Banner in Billing details Page is clicked sucessfully",
				"Failed to click on Edit button present in Banner in Billing details Page" + common.getStrError());

	}

	@When("^I click on Done Editing button in Edit Billing Details Page$")
	public void ishouldclickdoneeditingbutton() {
		boolean blnResult = billingPage.clickDoneButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Done button",
				"Done Button should be click successfully", "Done Button is clicked successfully",
				"Failed To click Done button." + common.getStrError());
	}

	@When("^I click on Delete button present in Banner in Billing details Page$")
	public void iclickonDeletebuttoninBillingDetailsBanner() {
		boolean blnResult = newHouseholdPage.clickDeletebuttoninBanner();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to click on Delete button present in Banner in Billing details Page",
				"Delete button present in Banner in Billing details Page should be clicked successfully",
				"Delete button present in Banner in Billing details Page is clicked sucessfully",
				"Failed to click on Delete button present in Banner in Billing details Page" + common.getStrError());

	}

	@Then("^I should see Delete Billing Pop-up message$")
	public void ishouldseeDeleteBillingPopup() {
		boolean blnResult = newHouseholdPage.deleteBillingPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Delete button present in Banner, Delete billing Pop-up is displayed",
				"User should able to see Delete billing Pop-up", "User is able to see Delete billing Pop-up",
				"Failed to see Delete billing Pop-up." + common.getStrError());
	}

	@Then("^I should see Proceed to Delete and Go Back button in Pop-up message$")
	public void ishouldseeProceedtoDeleteandGoBackbuttoninPopup() {
		boolean blnResult = newHouseholdPage.proceedtoDeleteandGoBackbtninPopupDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Delete button present in Banner, Proceed to Delete and Go Back button in Pop-up is displayed",
				"User should able to see Proceed to Delete and Go Back button in Pop-up",
				"User is able to see Proceed to Delete and Go Back button in Pop-up",
				"Failed to see Proceed to Delete and Go Back button in Pop-up." + common.getStrError());
	}

	@When("^I click on GO BACK button present in Pop-up message$")
	public void iclickonGoBackbuttoninPopupmessage() {
		boolean blnResult = newHouseholdPage.clickGoBackbuttoninPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to click on GO BACK button present in Pop-up message",
				"GO BACK button present in Pop-up message should be clicked successfully",
				"GO BACK button present in Pop-up message is clicked sucessfully",
				"Failed to click on GO BACK button present in Pop-up message" + common.getStrError());

	}

	@When("^I click on PROCEED TO DELETE button present in Pop-up message$")
	public void iclickonProceedToDeletebuttoninPopupmessage() {
		boolean blnResult = newHouseholdPage.clickProceedtoDeletebuttoninPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to click on PROCEED TO DELETE button present in Pop-up message",
				"PROCEED TO DELETE button present in Pop-up message should be clicked successfully",
				"PROCEED TO DELETE button present in Pop-up message is clicked sucessfully",
				"Failed to click on PROCEED TO DELETE button present in Pop-up message" + common.getStrError());

	}

	@When("^I click the Done Deleting button$")
	public void ishouldclickdonedeletingbutton() {
		boolean blnResult = newHouseholdPage.clickDoneDeletingButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Done Deleting button",
				"Done Deleting Button should be click successfully", "Done Deleting Button is clicked successfully",
				"Failed To click Done Deleting button." + common.getStrError());
	}

	@Then("^I should able to see Delete Billing Confirmation page$")
	public void ishouldabletoseedeletebillingupdatedconfirmationpage() {
		boolean blnResult = newHouseholdPage.verifyDeleteBillingUpdatedConfirmationPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Done Deleting for Billing",
				"User should able to see successfully Billing Deleted updated",
				"User is able to see successfully billing Deleted Confirmation page",
				"Failed to view Deleted billing confirmation page." + common.getStrError());

	}

	@Then("^I should able to view Streamline Billing$")
	public void iverifyhouseholdstreamlinebilling() {
		boolean blnResult = newHouseholdPage.verifyHouseholdStreamlineBilling();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User View household Streamline Billing",
				"User should able to view Household Streamline Billing successfully",
				"User is able to view Household Streamline Billing successfully",
				"Failed to view Household Streamline Billing in Household confirmation page." + common.getStrError());
	}

	@When("^I remove a client$")
	public void iremoveaclient() {
		boolean blnResult = newHouseholdPage.clickHouseholdRemoveClientButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click the household remove client button", "remove client button should be click successfully",
				"remove client button is clicked successfully",
				"Failed To click on remove client button" + common.getStrError());
	}

	@Then("^I click on review household button$")
	public void iclickonreviewhouseholdbutton() {
		common.waitForPageLoading(100);
		boolean blnResult = newHouseholdPage.clickReviewHouseholdButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the  button",
				"review household button should be click successfully",
				"review household button is clicked successfully",
				"Failed To click on review household button" + common.getStrError());
	}

	@When("^I click on submit household button$")
	public void iclickonsubmithouseholdbutton() {
		boolean blnResult = newHouseholdPage.clickSubmitHouseholdButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the submit household button",
				"submit household button should be click successfully",
				"submit household button is clicked successfully",
				"Failed To click on submit household button" + common.getStrError());
	}

	@Then("^I should see remove clienttool tip$")
	public void ishouldseeremoveclienttooltip() {
		boolean blnResult = newHouseholdPage.removedClientToolTipDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User removes client in the Household DashBoard Page",
				"User should able to view removed client tool tip successfully",
				"User is able to removed client tool tip successfully",
				"Failed to view removed client tool tip." + common.getStrError());

	}

	@When("^I click  on remove client tool verbiage$")
	public void iclickonremoveclienttoolverbiage() {
		boolean blnResult = newHouseholdPage.clickRemoveToolTipVerbiage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click the here link present in the removed client tool tip",
				"here link present in the removed client tool tip should be click successfully",
				"here link present in the removed client tool tip is clicked successfully",
				"Failed To click on here link present in the removed client tool tip" + common.getStrError());
	}

	@When("^I click on Jump To Details$")
	public void iClickOnJumpToDetails() {
		boolean blnResult = newHouseholdPage.clickJumpToDetails();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Jump To Details on Dashboard", "User should successfully click on Jump to Details",
				"User is able to click on Jump To Details link on dashboard successfully",
				"Failed to click on Jump To Details link on dashboard" + common.getStrError());
	}

	@Then("^I should be directed to the capabilities tile$")
	public void iSeeCapabilitiesSection() {
		boolean blnResult = newHouseholdPage.capabilitiesSectionDisplayed();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Jump To Details on Dashboard",
				"User should successfully directed to capabilities tile on Dashboard",
				"User is able to see capabilities tile on dashboard successfully",
				"Failed to see capabilities tile on dashboard" + common.getStrError());
	}

	@Then("^I should land on Edit Household Combined Statement Details page$")
	public void iseeEditHHcombinedStatementDetailsPage() {
		boolean blnResult = combinedStatementPage.editHouseholdCombinedStatementDetailsPageDisplayed();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on Combined Statement on Streamline/Confirmation page",
				"User should successfully see Edit Household Combined Statement Details page",
				"User is able see Edit Household Combined Statement Details page successfully",
				"Failed to see Edit Household Combined Statement Details" + common.getStrError());
	}

	@Then("^I should see section header$")
	public void iseeEditHHcombinedStatementDetailsSectionHeader() {
		boolean blnResult = combinedStatementPage.validateEditHouseholdSectionHeader();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Household Combined Statement Details page",
				"User should successfully see Combined Statement section header as New Combined Statement",
				"User is able see Combined Statement section header as New Combined Statement successfully",
				"Failed to see Combined Statement section header as New Combined Statement" + common.getStrError());
	}

	@Then("^I should see household combined Statement name displayed$")
	public void iseeHouseholdCombinedStatementName() {
		boolean blnResult = combinedStatementPage.validateHouseholdCombinedStatementName();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Household Combined Statement Details page",
				"User should successfully see Combined Statement Name",
				"User is able see Combined Statement Name successfully",
				"Failed to see Combined Statement Name" + common.getStrError());
	}

	@Then("^I should see static text present$")
	public void iseeEditHHCombinedStatementStaticText() {
		boolean blnResult = newHouseholdPage.validateEditHHCombinedStatementStaticText();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Household Combined Statement Details page",
				"User should successfully see primary note static text present",
				"User is able see primary note static text present successfully",
				"Failed to see primary note static text present" + common.getStrError());
	}

	@When("^I see contents panel Expanded$")
	public void iseeEditHHCombinedStatementContentsPanelExpanded() {
		boolean blnResult = combinedStatementPage.validateEditHouseholdCombinedStatementContentsPanelExpanded();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Household Combined Statement Details page",
				"User should successfully see Contents Panel in expanded state",
				"User is able see Contents Panel in expanded state successfully",
				"Failed to see Contents Panel in expanded state" + common.getStrError());
	}

	@Then("^I select radio button$")
	public void iSelectRadioButton() {
		boolean blnResult = combinedStatementPage.selectRadioButton();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement Details Page", "User should successfully select radio button",
				"User is able to select radio button on Edit Combined Statement Details page successfully",
				"Failed to select radio button on Edit Combined Statement Details page" + common.getStrError());
	}

	@Then("^I click on Done Editing Button$")
	public void iclickCombinedStatementDoneEditing() {
		boolean blnResult = combinedStatementPage.clickCombinedStatementDoneEditing();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement Details Page",
				"User should successfully click Done Editing button",
				"User is able click on Done Editing button on Edit Combined Statement Details page successfully",
				"Failed to click on Done Editing button on Edit Combined Statement Details page"
						+ common.getStrError());
	}

	@Then("^I see Review Household Combined Statement Details page$")
	public void iseeReviewHHCombinedStatementDetailsPage() {
		boolean blnResult = combinedStatementPage.reviewHouseholdCombinedStatementDetailsPageDisplayed();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User clicks on Done Editing button",
				"User should successfully see Review Household Combined Statement Details page",
				"User is able see Review Household Combined Statement Details page successfully",
				"Failed to see Review Household Combined Statement Details" + common.getStrError());
	}

	@Then("^I see Primary Account information$")
	public void iseePrimaryAccountInformation() {
		boolean blnResult = combinedStatementPage.validatePrimaryAccountInformation();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User clicks on Done Editing button",
				"User should successfully see Primary Account Information",
				"User is able see Primary Account Information successfully",
				"Failed to see Primary Account Information" + common.getStrError());
	}

	@Then("^I see Combined Statement capability on Streamline Confirmation page$")
	public void iseeCombinedStatementCapability() {
		boolean blnResult = combinedStatementPage.validateCombinedStatementCapability();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on Create Combined Statement button",
				"User should successfully see Combined Statement Capability on Streamline Confirmation page",
				"User is able see Combined Statement Capability on Streamline Confirmation page successfully",
				"Failed to see Combined Statement Capability on Streamline Confirmation page" + common.getStrError());
	}

	@Then("^I should able to see Flat Rate value in Dashboard Page$")
	public void ivalidateFlatRateinDashboardPage() {
		boolean blnResult = newHouseholdPage.validateFlatRateinDasboardPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate Flat Rate value in Dashboard Page",
				"User should able to view Flat Rate value in Dashboard Page successfully",
				"User is able to view Flat Rate value in Dashboard Page successfully",
				"Failed to view Flat Rate value in Dashboard Page." + common.getStrError());
	}

	@Then("^I should able to see Flat Rate value in Edit Billing Details Page$")
	public void ivalidateFlatRateinEditBillingDetailsPage() {
		boolean blnResult = newHouseholdPage.validateFlatRateinEditBillingDetailsPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate Flat Rate value in Edit Billing Details Page",
				"User should able to view Flat Rate value in Edit Billing Details Page successfully",
				"User is able to view Flat Rate value in Edit Billing Details Page successfully",
				"Failed to view Flat Rate value in Edit Billing Details Page." + common.getStrError());

	}

	@Then("^I should able to see Flat Rate value in Review Billing Details Page$")
	public void ivalidateFlatRateinReviewBillingDetailsPage() {
		boolean blnResult = newHouseholdPage.validateFlatRateinReviewBillingDetailsPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate Flat Rate value in Review Billing Details Page",
				"User should able to view Flat Rate value in Review Billing Details Page successfully",
				"User is able to view Flat Rate value in Review Billing Details Page successfully",
				"Failed to view Flat Rate value in Review Billing Details Page." + common.getStrError());

	}

	@Then("^I should able to see Flat Rate value in Streamline Confirmation Page$")
	public void ivalidateFlatRateinStreamlineConfirmationPage() {
		boolean blnResult = newHouseholdPage.validateFlatRateinStreamlineConfirmationPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate Flat Rate value in Streamline Confirmation Page",
				"User should able to view Flat Rate value in Streamline Confirmation Page successfully",
				"User is able to view Flat Rate value in Streamline Confirmation Page successfully",
				"Failed to view Flat Rate value in Streamline Confirmation Page." + common.getStrError());

	}

	@When("^I click  on edit button of edit combined statement alert popup$")
	public void iclickoneditbuttonofeditcombinedstatementalertpopup() {
		boolean blnResult = newHouseholdPage.clickeditHHcombinedstatementbutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on edit button present in edit combined statement alert",
				"User should successfully click on edit button present in edit combined statement alert",
				"User is able to click on edit button present in edit combined statement alert successfully",
				"Failed to click on  edit button present in edit combined statement alert" + common.getStrError());
	}

	@When("^I edit combined Statement details$")
	public void ieditcombinedStatementdetails() {
		boolean blnResult = newHouseholdPage.clickeditHHcombinedstatementradiobutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on radio button present in the edit combined details page",
				"User should successfully click on radio button present in the edit combined details page",
				"User is able to click on radio button present in the edit combined details page successfully",
				"Failed to click on radio button present in the edit combined details page" + common.getStrError());
	}

	@Then("^I click  on Done Editing Button$")
	public void iclickonDoneEditingButton() {

		boolean blnResult = combinedStatementPage.clickCSdoneditingbutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on done editing button in the edit combined details page",
				"User should successfully click on done editing button in the edit combined details page",
				"User is able to click on done editing button in the edit combined details page successfully",
				"Failed to click on done editing button in the edit combined details page" + common.getStrError());
	}

	@When("^I see Review Household Combined Statement Details Page$")
	public void iseeReviewHouseholdCombinedStatementDetailsPage() {
		boolean blnResult = combinedStatementPage.reviewHouseholdCombinedStatementDetailsPageDisplayed();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User clicks on Done Editing button",
				"User should successfully see Review Household Combined Statement Details page",
				"User is able see Review Household Combined Statement Details page successfully",
				"Failed to see Review Household Combined Statement Details" + common.getStrError());
	}

	@Then("^I click on submit review combined statement button$")
	public void iclickonsubmitreviewcombinedstatementbutton() {
		boolean blnResult = combinedStatementPage.clickHHCombinedStatementSubmitButton();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on submit changes button in the review combined statement details page",
				"User should successfully click on submit changes button in the review combined statement details page",
				"User is able to click on submit changes button in the review combined statement details page successfully",
				"Failed to click on submit changes button in the review combined statement details page"
						+ common.getStrError());

	}

	@When("^I see confirmation Page$")
	public void iSee() {
		boolean blnResult = combinedStatementPage.confirmationPageDisplayed();
		common.waitForPageLoading(100);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on submit changes button in review combined statement details page",
				"User should able to see confirmation page displayed",
				"User is able to see confirmation page displayed",
				"Failed to see confirmation page" + common.getStrError());

	}

	@Then("^I should see combined statement tile$")
	public void ishouldseecombinedstatementtile() {
		boolean blnResult = combinedStatementPage.combinedStatementTileDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on submit changes button in review combined statement details page",
				"User should able to see combined statement tile displayed in confirmation Page",
				"User is able to see combined statement tile  displayed",
				"Failed to see combined statement tile" + common.getStrError());
	}

	@When("^I click on client context menu$")
	public void iClickOnContextMenu() {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		boolean blnResult = newHouseholdPage.clickClientsContextMenu();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on Client Context menu",
				"User should successfully click on Client context menu",
				"User is able to click on Client context menu successfully",
				"Failed to click on client context menu" + common.getStrError());
	}
	
	@When("^I click on account context menu$")
	public void iClickOnAccountContextMenu() {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		boolean blnResult = newHouseholdPage.clickAccountsContextMenu();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on Client Context menu",
				"User should successfully click on Client context menu",
				"User is able to click on Client context menu successfully",
				"Failed to click on client context menu" + common.getStrError());
	}

	@Then("^I click on Delete option$")
	public void iClickOnDeleteOption() {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		boolean blnResult = newHouseholdPage.clickDeleteOption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click is in Context menu",
				"User should successfully click on Delete option in context menu",
				"User is able to click on Delete option successfully",
				"Failed to click on Delete option" + common.getStrError());
	}

	@When("^The Household Details page is displayed$")
	public void iseeHHDetailsPage() {
		boolean blnResult = newHouseholdPage.deleteHouseholdPageDisplayed();
		common.waitForPageLoading(500);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on delete option",
				"User should successfully see Household Details Page",
				"User is able to see Household Details page successfully",
				"Failed to see Household Details page" + common.getStrError());
	}

	@Then("^I see Banner Title as Delete household name$")
	public void iseeDeleteHHBannerTitle() {
		boolean blnResult = newHouseholdPage.deleteHHBannerTitleDisplayed();
		common.waitForPageLoading(500);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Delete Household Details page", "User should successfully see Banner Title",
				"User is able to see Delete  Household Banner Title successfully",
				"Failed to see Delete Household Banner Title" + common.getStrError());
	}

	@Then("^I see Household label$")
	public void iseeDeleteHHLabel() {
		boolean blnResult = newHouseholdPage.deleteHHLabelDisplayed();
		common.waitForPageLoading(500);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Delete HH details page",
				"User should successfully see Delete HH Label", "User is able to see Delete HH Label successfully",
				"Failed to see Delete HH Label" + common.getStrError());
	}

	@Then("^I see A Cancel & Return to Household Dashboard button is displayed$")
	public void iseeCanvelAndReturnButton() {
		boolean blnResult = newHouseholdPage.cancelAndReturnButtonDisplayed();
		common.waitForPageLoading(500);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Delete HH details page",
				"User should successfully see Cancel and return button",
				"User is able to see Cancel and return button successfully",
				"Failed to see Cancel and return button" + common.getStrError());
	}

	@When("^I click on Delete Household button$")
	public void iclickHHButton() {
		boolean blnResult = newHouseholdPage.clickDeleteHHButton();
		common.waitForPageLoading(500);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on delete household button",
				"User should successfully able to click on Delete household button",
				"User is able to click on Delete household button successfully",
				"Failed to click on Delete household button" + common.getStrError());
	}

	@Then("^A pop-up window appears$")
	public void iseeDeleteHHPopUpWindow() {
		boolean blnResult = newHouseholdPage.DeleteHHPopUpDisplayed();
		common.waitForPageLoading(500);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on delete household button ", "User should successfully see pop up window",
				"User is able to see pop up window successfully", "Failed to see pop up window" + common.getStrError());
	}

	@Then("^I click on Return to Client Management Groups$")
	public void iclickReturnClientManagementButton() {
		boolean blnResult = newHouseholdPage.clickReturnClientManagementButton();
		common.waitForPageLoading(500);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Return Client Management button ",
				"User should successfully click on Return ClientManagement button",
				"User is able to click on Return ClientManagement button successfully",
				"Failed to click on Return ClientManagement button" + common.getStrError());
	}

	@Then("^I should see Cancel & Return to Dashboard hyperlink in Edit Billing details Page$")
	public void ishouldviewBackhyperlinkinEditBillingDetails() {
		boolean blnResult = newHouseholdPage.verifyCancelReturntoDashboardHyperlinkinBillingDetails();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Billing Rate Button in Dashboard",
				"User should able to view Back hyperlink in Edit Billing details Page successfully",
				"User is able to view Back hyperlink in Edit Billing details Page successfully",
				"Failed to view Back hyperlink in Edit Billing details Page " + common.getStrError());

	}

	@Then("^I click on Cancel & Return to Dashboard hyperlink in Edit Billing details Page$")
	public void iclickBackhyperlinkEditBillingDetailsPage() {
		boolean blnResult = newHouseholdPage.clickCancelReturntoDashboardHyperlinkinBillingDetails();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Billing Rate Button in Dashboard",
				"User should successfully click on Back hyperlink in Edit Billing details Page",
				"User is able to click on Back hyperlink in Edit Billing details Page successfully",
				"Failed to click on Back hyperlink in Edit Billing details Page" + common.getStrError());
	}

	@Then("^I should see Cancel & Return to Dashboard hyperlink in Edit Combined Statement Page$")
	public void ishouldviewCancelAndReturntoDashboardHyperlink() {
		boolean blnResult = combinedStatementPage.verifyCancelReturnToDashboardHyperLinkinCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Combined Statement Button in Dashboard",
				"User should able to view Cancel & Return to Dashboard hyperlink successfully",
				"User is able to view Cancel & Return to Dashboard hyperlink successfully",
				"Failed to view Cancel & Return to Dashboard hyperlink" + common.getStrError());
	}

	@Then("^I click on Cancel & Return to Dashboard hyperlink in Edit Combined Statement Page$")
	public void iclickCancelAndReturntoDashboardHyperlink() {
		boolean blnResult = newHouseholdPage.clickCancelReturntoDashboardHyperlinkinCominedStmt();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Combined Statement Button in Dashboard",
				"User should successfully click on Cancel & Return to Dashboard hyperlink",
				"User is able to click on Cancel & Return to Dashboard hyperlink successfully",
				"Failed to click on Cancel & Return to Dashboard hyperlink" + common.getStrError());
	}

	@Then("^I should see Cancel & Return to Dashboard hyperlink in Review Combined Statement Page$")
	public void ishouldviewCancelAndReturntoDashboardHyperlinkCombinedStmt() {
		boolean blnResult = combinedStatementPage.verifyCancelReturntoDashboardHyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Combined Statement Button in Dashboard",
				"User should able to view Cancel & Return to Dashboard hyperlink successfully",
				"User is able to view Cancel & Return to Dashboard hyperlink successfully",
				"Failed to view Cancel & Return to Dashboard hyperlink" + common.getStrError());
	}

	@Then("^I click on Cancel & Return to Dashboard hyperlink in Review Combined Statement Page$")
	public void iclickCancelAndReturntoDashboardHyperlinkCombinedStmt() {
		boolean blnResult = combinedStatementPage.clickCancelReturntoDashboardHyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Combined Statement Button in Dashboard",
				"User should successfully click on Cancel & Return to Dashboard hyperlink",
				"User is able to click on Cancel & Return to Dashboard hyperlink successfully",
				"Failed to click on Cancel & Return to Dashboard hyperlink" + common.getStrError());
	}

	@When("^I see Investment Management tile$")
	public void iseeInvestmentManagementtile() {
		boolean blnResult = investmentManagementPage.investmentmanagementtileDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User adds investment capability and navigtaes to Dashboard Page",
				"User should able to view investment management tile successfully",
				"User is able to view investment management tile successfully",
				"Failed to view investment management tile" + common.getStrError());

	}

	@Then("^I should see Investment Management name with edit icon$")
	public void ishouldseeInvestmentManagementnamewithediticon() {
		boolean blnResult = investmentManagementPage.investmentmanagementnamewithediticonDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees investment management tile in the Dashboard page",
				"User should able to see investment management name with edit icon successfully",
				"User is able to see investment management name with edit icon successfully",
				"Failed  to see investment management name with edit icon" + common.getStrError());

	}

	@And("^I should see investment management label as active$")
	public void ishouldseeinvestmentmanagementlabelasactive() {
		boolean blnResult = investmentManagementPage.investmentmanagementactivelabelDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees investment management tile in the Dashboard page",
				"User should able to active label in investment management tile successfully",
				"User is able to see active label in investment management tile successfully",
				"Failed  to see active label in investment management tile" + common.getStrError());

	}

	@Then("^I should see Client Name preselcted on New Household Page$")
	public void iSeeClientNamePreseleted() {
		boolean blnResult = newHouseholdPage.preselectedClientNameDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on New Household Page",
				"User should successfully see Clients Name preselected",
				"User is able to see Client Name preselected on New Household Page successfully",
				"Failed to see Client Name preselected on New Household page" + common.getStrError());
	}

	@Then("^I click on Create New Household Option$")
	public void iClickOnCreateNewHousehold() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickCreateNewHousehold();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Groups option in Client Context menu",
				"User should successfully click on Create New Household submenu",
				"User is able to click on Create New Household submenu successfully",
				"Failed to click on Create New Household submenu in client context menu" + common.getStrError());
	}
	

	@Then("^I click on Groups option$")
	public void iClickOnGroups() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickGroupsOption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Groups option in Client Context menu",
				"User should successfully click on groups option Client context menu",
				"User is able to click on groups option in Client context menu successfully",
				"Failed to click on groups option in client context menu" + common.getStrError());
	}

	@Then("^I click on Clients Page search tab$")
	public void iClickOnClientsTabSearchButton() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickClientsPageSearchButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Clients page search Button",
				"User should click successfully on Clients Page search button",
				"User is able to click on Clients Page search button successfully",
				"Failed to click on Clients Page search button" + common.getStrError());
	}

	@When("^I enter Client name$")
	public void iEnterClientName() {
		common.waitForPageLoading();
		String enterClientName = testData.get("EnterclientName");
		boolean blnResult = newHouseholdPage.enterPreselectClientname(enterClientName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the Client name",
				"Client name should be entered", "Client name is entered",
				"Failed to Enter Client Name." + common.getStrError());
	}
	
	@When("^I enter Account number$")
	public void iEnterAccountNumber() {
		common.waitForPageLoading();
		String enterAccountNumber = testData.get("enterAccountNumber");
		boolean blnResult = newHouseholdPage.enterPreselectClientname(enterAccountNumber);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the Client name",
				"Client name should be entered", "Client name is entered",
				"Failed to Enter Client Name." + common.getStrError());
	}

	@Then("^I click on Clients Tab$")
	public void iClickOnClientstab() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickClientsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Clients Tab ,Clients grid got displayed", "User should able to see Clients Page",
				"User is able to see Clients Page successfully", "Failed to see Clients page" + common.getStrError());
	}
	
	@Then("^I click on Accounts Tab$")
	public void iClickOnAccountstab() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickAccountsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Accounts Tab ,Accounts grid got displayed", "User should able to see Clients Page",
				"User is able to see Accounts Page successfully", "Failed to see Accounts page" + common.getStrError());
	}

	@When("^I click on contents panel chevron on Review Combined Statement page$")
	public void clickOnReviewCombinedStatementExpandContentsPanel() {
		boolean blnResult = newHouseholdPage.clickReviewCombinedStatementExpandContentsPanel();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on contents panel on combined statement tile on streamline confirmation page",
				"User should able to click successfully on contents panel",
				"User is able to click on contents panel expand/collapse chevron successfully",
				"Failed to click on contents panel expand/collapse chevron" + common.getStrError());
	}

	@Then("^The Review Combined Statement page expands to show account details$")
	public void displayAccountDetails() {
		boolean blnResult = newHouseholdPage.validateReviewCombinedStatementAccountDetails();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on contents panel on combined statement tile",
				"User should able to see list of account details for all clients",
				"User is able to see list of account details for all clients successfully",
				"Failed to see list of account details for all clients" + common.getStrError());
	}

	@And("^I should see a collapsible account panel on Review Combined Statement page$")
	public void displayAccountPanelChevron() {
		boolean blnResult = newHouseholdPage.validateReviewCombinedStatementAccountPanelChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded contents panel on combined statement tile",
				"User should able to see expand/collapse accounts chevron",
				"User is able to see expand/collapse accounts chevron successfully",
				"Failed to see expand/collapse accounts chevron" + common.getStrError());
	}

	@When("^I click on accounts panel chevron on Review Combined Statement page$")
	public void clickAccountPanelExpandChevron() {
		boolean blnResult = newHouseholdPage.clickReviewCombinedStatementAccountPanelExpandChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded contents panel on combined statement tile",
				"User should able to click on expand accounts chevron",
				"User is able to click on expand accounts chevron successfully",
				"Failed to click on expand accounts chevron" + common.getStrError());
	}

	@When("^I click on Accounts Panel chevron to collapse on Review Combined Statement page$")
	public void clickAccountPanelCollapseChevron() {
		boolean blnResult = newHouseholdPage.clickReviewCombinedStatementAccountPanelCollapseChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User collapsed contents panel on combined statement tile",
				"User should able to click on collapse accounts chevron",
				"User is able to click on collapse accounts chevron successfully",
				"Failed to click on collapse accounts chevron" + common.getStrError());
	}

	@Then("^Accounts Panel should collapse on Review Combined Statement page$")
	public void displayAccountPanelCollapsed() {
		boolean blnResult = newHouseholdPage.validateAccountPanelCollapsed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on accounts panel collapse chevron",
				"User should able to see accounts chevron collapse",
				"User is able to see accounts chevron collapse successfully",
				"Failed to see accounts chevron collapse" + common.getStrError());
	}

	@When("^I click on Contents Panel chevron to collapse on Review Combined Statement page$")
	public void iclickContentsPanelCollapsed() {
		boolean blnResult = newHouseholdPage.clickReviewCombinedStatementContentsPanelCollapsedChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Combined Statement tile",
				"User should able to click on collapse contents panel chevron",
				"User is able to click on collapse contents panel chevron successfully",
				"Failed to click on collapse contents panel chevron" + common.getStrError());
	}

	@Then("^Contents Panel should collapse on Review Combined Statement page$")
	public void ivalidateContentsPanelCollapsed() {
		boolean blnResult = newHouseholdPage.validateContentsPanelCollapsed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on collapse contents panel chevron on combined statement tile",
				"User should not be able to see list of account details for all clients and contents panel should collapse",
				"User is able not be able to see list of account details for all clients successfully",
				"Failed to collapse contents panel chevron" + common.getStrError());
	}

	@When("^I click on Delete button on Edit combined statement Page$")
	public void iClickDeleteCombinedStatementButton() {
		boolean blnResult = newHouseholdPage.clickDeleteCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement page",
				"User should be able to click on Delete button on Edit Combined Statement page ",
				"User is able to click on Delete button on Edit Combined Statement page successfully",
				"Failed to click on Delete button on Edit Combined Statement page" + common.getStrError());
	}

	@And("^I click on Proceed To Delete option in popup$")
	public void iClicProceedToDeleteOption() {
		boolean blnResult = newHouseholdPage.clickProceedToDeleteCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Delete button on Edit Combined Statement page",
				"User should be able to click on to see popup ",
				"User is able to click on Proceed To Delete option successfully",
				"Failed to click on Proceed To Delete option" + common.getStrError());
	}

	@And("^I click on Done Deleting button$")
	public void iClickDoneDeletingButton() {
		boolean blnResult = newHouseholdPage.clickDoneDeletingCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Done Deleting button on Edit Combined Statement page",
				"User should be able to click Done Deleting button on Edit Combined Statement page",
				"User is able to click Done Deleting button on Edit Combined Statement page successfully",
				"Failed to click on Done Deleting button on Edit Combined Statement page" + common.getStrError());
	}

	@Then("^I see Streamline/Confirmation page with combined statement tile removed$")
	public void validateNoCombinedStatementTile() {
		boolean blnResult = newHouseholdPage.validateNoCombinedStatementTile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Done Deleting button on Edit Combined Statement page",
				"User should be able see Streamline/Confirmation page",
				"User is able to see Streamline/Confirmation page successfully",
				"Failed to see Streamline/Confirmation page" + common.getStrError());
	}

	@Then("^I see title banner$")
	public void displayTitleBanner() {
		boolean blnResult = combinedStatementPage.validateDeleteCombinedStatementTitleBanner();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Done Deleting button on Edit Combined Statement page",
				"User should be able see Title Banner", "User is able to see Title Banner successfully",
				"Failed to see Title Banner" + common.getStrError());
	}

	@Then("^I cannot see EST UPCOMING FEE column$")
	public void validateEstAnnualFeeNotDisplayed() {
		boolean blnResult = newHouseholdPage.validateEstAnnualFeeNotDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Done Deleting button on Edit Combined Statement page",
				"User should be able see Title Banner", "User is able to see Title Banner successfully",
				"Failed to see Title Banner" + common.getStrError());
	}

	@When("^I click on contents panel on combined statement tile$")
	public void iClickOnCombinedStatementContentsPanel() {
		boolean blnResult = combinedStatementPage.clickCombinedStatementContentsPanel();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on contents panel on combined statement tile on streamline confirmation page",
				"User should able to click successfully on contents panel",
				"User is able to click on contents panel expand/collapse chevron successfully",
				"Failed to click on contents panel expand/collapse chevron" + common.getStrError());
	}

	@Then("^The page expands to show a list of account details for all clients that are in the household$")
	public void iseeAccountDetails() {
		boolean blnResult = combinedStatementPage.validateAccountDetails();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on contents panel on combined statement tile",
				"User should able to see list of account details for all clients",
				"User is able to see list of account details for all clients successfully",
				"Failed to see list of account details for all clients" + common.getStrError());
	}

	@And("^I should see a collapsible account panel$")
	public void iseeAccountPanelChevron() {
		boolean blnResult = newHouseholdPage.validateAccountPanelChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded contents panel on combined statement tile",
				"User should able to see expand/collapse accounts chevron",
				"User is able to see expand/collapse accounts chevron successfully",
				"Failed to see expand/collapse accounts chevron" + common.getStrError());
	}

	@When("^I click on Accounts Panel chevron to expand$")
	public void iclickAccountPanelExpandChevron() {
		boolean blnResult = combinedStatementPage.clickAccountPanelExpandChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded contents panel on combined statement tile",
				"User should able to click on expand accounts chevron",
				"User is able to click on expand accounts chevron successfully",
				"Failed to click on expand accounts chevron" + common.getStrError());
	}

	@When("^I click on Accounts Panel chevron to collapse$")
	public void iclickAccountPanelCollapseChevron() {
		boolean blnResult = newHouseholdPage.clickAccountPanelCollapseChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User collapsed contents panel on combined statement tile",
				"User should able to click on collapse accounts chevron",
				"User is able to click on collapse accounts chevron successfully",
				"Failed to click on collapse accounts chevron" + common.getStrError());
	}

	@Then("^Accounts Panel should collapse$")
	public void iseeAccountPanelCollapsed() {
		boolean blnResult = newHouseholdPage.accountPanelCollapsed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on accounts panel collapse chevron",
				"User should able to see accounts chevron collapse",
				"User is able to see accounts chevron collapse successfully",
				"Failed to see accounts chevron collapse" + common.getStrError());
	}

	@When("^I click on Contents Panel chevron to collapse$")
	public void iClickPanelCollapsed() {
		boolean blnResult = newHouseholdPage.clickContentsPanelCollapsedChevron();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Combined Statement tile",
				"User should able to click on collapse contents panel chevron",
				"User is able to click on collapse contents panel chevron successfully",
				"Failed to click on collapse contents panel chevron" + common.getStrError());
	}

	@Then("^Contents Panel should collapse$")
	public void iseeContentsPanelCollapsed() {
		boolean blnResult = newHouseholdPage.contentsPanelCollapsed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on collapse contents panel chevron on combined statement tile",
				"User should not be able to see list of account details for all clients and contents panel should collapse",
				"User is able not be able to see list of account details for all clients successfully",
				"Failed to collapse contents panel chevron" + common.getStrError());
	}

	@When("^I click on edit Combined Statement pencil icon on Streamline page$")
	public void iClickCombinedStatementEditIcon() {
		boolean blnResult = combinedStatementPage.clickCombinedStatementEditIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Streamline/Confirmation page",
				"User clicks on Edit pencil icon on Combined Statement Tile",
				"User is able to click on Edit pencil icon on Combined Statement Tile successfully",
				"Failed to click on Edit pencil icon on Combined Statement Tile" + common.getStrError());
	}

	@When("^I see error message$")
	public void iSeeBankSweepErrorMessage() {
		boolean blnResult = newHouseholdPage.validateBankSweepErrorMessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on Create Household bbutton",
				"User is able to see error message if account is already present in Bank sweep",
				"User is able to able to see error message successfully",
				"Failed to able to see error message" + common.getStrError());
	}

	@When("^I see  Billing Rate section$")
	public void iseeBillingRate() {
		boolean blnResult = newHouseholdPage.billingratesectionDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User navigates to household dashboard Page", "User is able to see Billing Rate section",
				"User is able to able to see Billing Rate section successfully",
				"Failed to able to see Billing Rate section" + common.getStrError());
	}

	@Then("^I should see household billing name with edit icon$")
	public void ishouldseehouseholdbillingnamewithediticon() {
		boolean blnResult = householdDashBoardPage.billingratenamewithediticonDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees Billing Rate section in dashbaord",
				"User is able to see household billing name with edit icon in Billing Rate secton",
				"User is able to able to see household billing name with edit icon in Billing Rate secton successfully",
				"Failed to able to see household billing name with edit icon in Billing Rate secton"
						+ common.getStrError());
	}

	@When("^I see  billing tile$")
	public void iseebillingtile() {
		boolean blnResult = newHouseholdPage.billingratetileDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees Billing Rate section in dashbaord",
				"User is able to see billing tile in Billing Rate secton",
				"User is able to able to see billing tile in Billing Rate secton sucessfullly",
				"Failed to able to see billing tile in Billing Rate secton" + common.getStrError());
	}

	@Then("^I should see  following billing tile fields$")
	public void ishouldseefollowingbillingtilefields(DataTable field)

	{

		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = newHouseholdPage.billingratetilefields(data.get("BillingTileFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("BillingTileFields") + " available",
					"User should able to see the  " + data.get("BillingTileFields") + "fields",
					" listed field values is " + data.get("BillingTileFields") + " visible",
					"Failed : listed field values " + data.get("BillingTileFields") + "are NOT visible");
		}
	}

	@And("^I should see  View Payout Schedule hyperlink$")
	public void ishouldseeViewPayoutSchedulehyperlink() {
		boolean blnResult = newHouseholdPage.viewPayoutSchedulehyperlinkDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User Billing Rate section in dashbaord",
				"User is able to see View Payout Schedule hyperlink in Billing Rate tile",
				"User is able to able to see View Payout Schedule hyperlink in Billing Rate tile successfully",
				"Failed to able to see View Payout Schedule hyperlink in Billing Rate tile" + common.getStrError());
	}

	@When("^I see SCHEDULE fee type$")
	public void iseeSCHEDULEfeetype() {
		String scheduleFeeType = newHouseholdPage.schedulenamegettext();
		if (scheduleFeeType.equalsIgnoreCase(NewHouseholdPage.FLAT)) {
			boolean blnResult = newHouseholdPage.flatfeeScheduleType();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User sees Billing Rate section in dashbaord",
					"User is able to see SCHEDULE fee type as flat in Billing Rate tile",
					"User is able to able to see flat fee SCHEDULE type successfully",
					"Failed to able to see flat fee SCHEDULE type" + common.getStrError());
		} else {
			boolean blnResult = newHouseholdPage.schedulenameDisplayed();
			common.waitForPageLoading();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User see Billing Rate section in dashbaord",
					"User is able to see progressive tier schedule name in Billing Rate tile",
					"User is able to able to see progressive tier schedule name in Billing Rate tile successfully",
					"Failed to able to see progressive tier schedule name in Billing Rate tile" + common.getStrError());
		}
	}

	@Then("^I should see fee rate as per the fee type$")
	public void ishouldseefeerateasperthefeetype() {
		String feeratetype = newHouseholdPage.feeratetypegettext();
		if (feeratetype.equalsIgnoreCase(NewHouseholdPage.FLAT_RATE)) {
			boolean blnResult = newHouseholdPage.flatbillingrateDisplayed();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User sees flat fee schedule in Billing Rate section in dashbaord",
					"User is able to see FLAT RATE column in Billing Rate tile",
					"User is able to able to see FLAT RATE column successfully",
					"Failed to able to see FLAT RATE column in Billing Tile" + common.getStrError());
		} else {
			boolean blnResult = newHouseholdPage.blendedbillingrateDisplayed();
			common.waitForPageLoading();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User see progressive fee schedule in Billing Rate section in dashbaord",
					"User is able to see BLENDED RATE column in Billing Rate tile",
					"User is able to able to see BLENDED RATE column in Billing Rate tile successfully",
					"Failed to able to see BLENDED RATE column in Billing Rate Tile" + common.getStrError());
		}

	}

	@Then("^I should see CURRENT INVESTMENT MANAGEMENT sub-header under Recommended Next Step$")
	public void ishouldseeCurrentInvestmentManagementSubHeader() {
		boolean blnResult = newHouseholdPage.verifyCurrentInvestmentManagementSubHeader();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if CURRENT INVESTMENT MANAGEMENT sub-header under Recommended Next Step is displayed",
				"CURRENT INVESTMENT MANAGEMENT sub-header under Recommended Next Step should be displayed",
				"CURRENT INVESTMENT MANAGEMENT sub-header under Recommended Next Step is displayed",
				"Failed to display CURRENT INVESTMENT MANAGEMENT sub-header under Recommended Next Step"
						+ common.getStrError());
	}

	@Then("^I should see No current Investment management verbiage under CURRENT INVESTMENT MANAGEMENT sub-header$")
	public void ishouldseeNoCurrentInvestmentManagementVerbiage() {
		boolean blnResult = newHouseholdPage.verifyNoCurrentInvestmentManagementVerbiage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if No current Investment management verbiage under CURRENT INVESTMENT MANAGEMENT sub-header is displayed",
				"No current Investment management verbiage under CURRENT INVESTMENT MANAGEMENT sub-header should be displayed",
				"No current Investment management verbiage under CURRENT INVESTMENT MANAGEMENT sub-header is displayed",
				"Failed to display No current Investment management verbiage under CURRENT INVESTMENT MANAGEMENT sub-header"
						+ common.getStrError());
	}

	@Then("^I should see Investment Management sub-header with OPTIONAL gray-shaded box$")
	public void ishouldseeInvestmentManagementSubheaderwithOPTIONALgrayshadedbox() {
		boolean blnResult = newHouseholdPage.verifyInvestmentManagementSubHeader();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Investment Management sub-header with OPTIONAL gray-shaded box is displayed",
				"Investment Management sub-header with OPTIONAL gray-shaded box should be displayed",
				"Investment Management sub-header with OPTIONAL gray-shaded box is displayed",
				"Failed to display Investment Management sub-header with OPTIONAL gray-shaded box"
						+ common.getStrError());
	}

	@Then("^I should see Requires Billing hyperlink not active for selection$")
	public void ishouldseeRequiresBillingHyperlinknotactiveforselection() {
		boolean blnResult = newHouseholdPage.verifyRequiresBillingHyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Requires Billing hyperlink not active for selection is displayed",
				"Requires Billing hyperlink not active for selection should be displayed",
				"Requires Billing hyperlink not active for selection is displayed",
				"Failed to display Requires Billing hyperlink not active for selection" + common.getStrError());
	}

	@Then("^I should able to see Streamline Investment Management hyperlink under Recommended Next Step$")
	public void ishouldseeStreamlineInvestmentManagementHyperlink() {
		boolean blnResult = newHouseholdPage.verifyStreamlineInvestmentManagementHyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Streamline Investment Management hyperlink under Recommended Next Step is displayed",
				"Streamline Investment Management hyperlink under Recommended Next Step should be displayed",
				"Streamline Investment Management hyperlink under Recommended Next Step is displayed",
				"Failed to display Streamline Investment Management hyperlink under Recommended Next Step"
						+ common.getStrError());
	}

	@When("^I select Streamline Investment Management hyperlink under Recommended Next Step$")
	public void iclickonStreamlineInvestmentManagementHyperlink() {
		boolean blnResult = newHouseholdPage.clickStreamlineInvestmentManagementHyperlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to click on Streamline Investment Management hyperlink under Recommended Next Step",
				"Streamline Investment Management hyperlink under Recommended Next Step should be clicked successfully",
				"Streamline Investment Management hyperlink under Recommended Next Step is clicked sucessfully",
				"Failed to click on Streamline Investment Management hyperlink under Recommended Next Step"
						+ common.getStrError());

	}

	@When("^I View Household Investment Management Details Page$")
	public void ishouldabletoseeHouseholdInvestmentManagementDetailspage() {
		boolean blnResult = newHouseholdPage.verifyHouseholdInvestmentManagementDetails();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Streamline Investment Management hyperlink, Household Investment Management Details Page is displayed",
				"User should able to see Household Investment Management Details Page",
				"User is able to see Household Investment Management Details Page",
				"Failed to see Household Investment Management Details Page." + common.getStrError());

	}

	@When("^I verify Investment Mangement name is same as Household Name$")
	public void ivalidateInvestmentManagementName() {
		boolean blnResult = newHouseholdPage.validateInvestmentManagementName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to see Investment Mangement name is same as Household Name",
				"Investment Mangement name should be same as Household Name",
				"Investment Mangement name is same as Household Name",
				"Failed to see Investment Mangement name is same as Household Name" + common.getStrError());

	}

	@When("^I verify Investment Mangement label is been added to Investment Mangement Name$")
	public void ivalidateInvestmentManagementLabeladdedtoInvestmentMangementName() {
		boolean blnResult = newHouseholdPage.validateInvestmentManagementLabel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to see Investment Mangement label is been added to Investment Mangement Name",
				"Investment Mangement label should be added to Investment Mangement Name",
				"Investment Mangement label is been added to Investment Mangement Name",
				"Failed to see Investment Mangement label is been added to Investment Mangement Name"
						+ common.getStrError());

	}

	@When("^I click on Edit Investment Management Name icon$")
	public void iclickonEditInvestmentManagementNameIcon() {
		boolean blnResult = newHouseholdPage.clickEditIconInvestmentManagementName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to click on Edit Investment Management Name icon",
				"Edit Investment Management Name icon should be clicked successfully",
				"Edit Investment Management Name icon is clicked sucessfully",
				"Failed to click on Edit Investment Management Name icon" + common.getStrError());

	}

	@Then("^I should able to clear and enter more than 50 characters in Investment Management name$")
	public void ishouldabletoclearandentermorethan50charsinvestmentmanagementname() {
		String investmentMgmtName1 = testData.get("investmentMgmtName1");
		boolean blnResult = newHouseholdPage.clearAndEnterInvestmentManagementName(investmentMgmtName1);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and and enter more than 50 characters in Investment Management name",
				"user should able to clear and and enter more than 50 characters in Investment Management name",
				"Investment Management name cleared and and entered more than 50 characters in Investment Management name",
				"Failed to clear and and enter more than 50 characters in Investment Management name"
						+ common.getStrError());
	}

	@Then("^I should see You have reached the max number of characters error message$")
	public void ivalidateErrormsgwhenInvestmentManagementNameismorethan50chars() {
		boolean blnResult = newHouseholdPage.verifyErrorMsgInvestmentManagementMorethanFiftyChars();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to see You have reached the max number of characters error message",
				"User should be able to see You have reached the max number of characters error message",
				"You have reached the max number of characters error message is displayed",
				"Failed to see You have reached the max number of characters error message" + common.getStrError());

	}

	@Then("^I should able to clear and enter special characters in Investment Management name$")
	public void ishouldabletoclearandenterspecialcharsinvestmentmanagementname() {
		String investmentMgmtName2 = testData.get("investmentMgmtName2");
		boolean blnResult = newHouseholdPage.clearAndEnterInvestmentManagementName(investmentMgmtName2);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and and enter special characters in Investment Management name",
				"user should able to clear and and enter special characters in Investment Management name",
				"Investment Management name cleared and and entered special characters in Investment Management name",
				"Failed to clear and and enter special characters in Investment Management name"
						+ common.getStrError());
	}

	@Then("^I should see Only alpha-numeric characters are allowed error message$")
	public void ivalidateErrormsgwhenInvestmentManagementNamecontainsspecialchars() {
		boolean blnResult = newHouseholdPage.verifyErrorMsgInvestmentManagementSpecialChars();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to see Only alpha-numeric characters are allowed error message",
				"User should be able to see Only alpha-numeric characters are allowed error message",
				"Only alpha-numeric characters are allowed error message is displayed",
				"Failed to see Only alpha-numeric characters are allowed error message" + common.getStrError());

	}

	@Then("^I should able to clear and enter new Investment Management name$")
	public void ishouldabletoclearandenternewinvestmentmanagementname() {
		String investmentMgmtName = testData.get("investmentMgmtName");
		boolean blnResult = newHouseholdPage.clearAndEnterInvestmentManagementName(investmentMgmtName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and edit Investment Management name in Household Investment Management Details Page",
				"user should able to clear and edit Investment Management name successfully",
				"Investment Management name cleared and edited sucessfully",
				"Failed to clear and edit Investment Management name in Household Investment Management Details Page"
						+ common.getStrError());
	}

	@Then("^I should able to see Edited Investment Management name$")
	public void ishouldabletoseeEditedInvestmentmanagementname() {
		boolean blnResult = newHouseholdPage.verifyEditedInvestmentManagementName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to see edited Investment Management name in Household Investment Management Details Page",
				"user should able to see edited Investment Management name successfully",
				"Investment Management name edited sucessfully",
				"Failed to see edited Investment Management name in Household Investment Management Details Page"
						+ common.getStrError());
	}

	@Then("^I should not see Outside Business Account as Primary for Combined Statement$")
	public void ishouldnotSeeOutsideBusinessAccount() {
		boolean blnResult = newHouseholdPage.verifyOutsideBusinessAccountNotPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user in on Edit Combined Statement Details page",
				"User should not be able to see Outside business account to select as primary for combined statement",
				"User is unable to see Outside business account on edit combined statement page successfully",
				"Failed to not see Outside Business Account on edit combined statement details page"
						+ common.getStrError());
	}

	@When("^I see  household capability tracker$")
	public void iseehouseholdcapabilitytracker() {
		boolean blnResult = newHouseholdPage.householdCapabilityTrackerDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User sees edit household Page",
				"User is able to see household capability tracker",
				"User is able to able to see household capability tracker successfully",
				"Failed to able to see household capability tracker" + common.getStrError());

	}

	@Then("^I see  household name with expand chevron$")
	public void iseehouseholdnamewithexpandchevron() {
		boolean blnResult = combinedStatementPage.householdCapabilityTrackerNameWithChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees household capability tracker",
				"User is able to see household capability tracker name with chevron",
				"User is able to able to see household capability tracker name with chevron sucessfully",
				"Failed to able to see household capability tracker name with chevron" + common.getStrError());
	}

	@And("^I should see household capability tracker sub header$")
	public void ishouldseehouseholdcapabilitytrackersubheader() {
		boolean blnResult = newHouseholdPage.summarychangessubheader();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees household capability tracker in edit household Page",
				"User is able to see household capability tracker summary sub header",
				"User is able to able to see household capability tracker summary sub headersucessfully",
				"Failed to able to see household capability tracker summary sub header " + common.getStrError());

	}

	@Then("^I should see remove client verbiage in pink box$")
	public void ishouldseeremoveclientverbiageinpinkbox() {
		boolean blnResult = newHouseholdPage.capabilitytrackerremovedclientverbiage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User removes client in the edit household Page",
				"User is able to see removed client verbiage in household capability tracker",
				"User is able to able to see removed client verbiage in household capability tracker sucessfully",
				"Failed to able to see removed client verbiage in household capability tracker" + common.getStrError());
	}

	@And("^I should see removed account information in capabilities tile$")
	public void ishouldseeremovedaccountinformationincapabilitiestile() {
		boolean blnResult = newHouseholdPage.capabilitytrackerremovedclienttiles();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User removes client in edit household Page",
				"User is able to see account tiles information in household capability tracker",
				"User is able to able to see account tile information in household capability tracker sucessfully",
				"Failed to able to see account tile information in household capability tracker"
						+ common.getStrError());
	}

	@When("^I click on review household button after deleting client$")
	public void iclickonreviewhhbutton() {
		boolean blnResult = newHouseholdPage.clickReviewHouseholdButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the  button",
				"review household button should be click successfully",
				"review household button is clicked successfully",
				"Failed To click on review household button" + common.getStrError());
	}

	@And("^I expand household capability tracker$")
	public void iexpandhouseholdcapabilitytracker() {
		boolean blnResult = newHouseholdPage.expnadHHcapabilityracker();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Household Capability chevron",
				"expand household capability chevron should be click successfully",
				"expand household capability chevron is clicked successfully",
				"Failed To click on expand household capability chevron" + common.getStrError());
	}

	@When("^I collapse household capability tracker$")
	public void icollapsehouseholdcapabilitytracker() {

		boolean blnResult = newHouseholdPage.collapseHHcapabilityracker();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Household capability chevron",
				"collapse household capability chevron should be click successfully",
				"collapse household capability chevron is clicked successfully",
				"Failed To collapse household capability chevron" + common.getStrError());

	}

	@Then("^I should see householdname with Billing form$")
	public void ishouldseehouseholdnamewithBillingform() {
		boolean blnResult = billingPage.householdCapabilityTrackerNameWithBillingForm();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User collapse household capability chevron",
				"User is able to see household name with Billing form button in household capability tracker",
				"User is able to able to see household name with Billing form button in household capability tracker sucessfully",
				"Failed to able to see household name with Billing form in household capability tracker"
						+ common.getStrError());
	}

	@Then("^I should see household capabilities tracker on billing details page$")
	public void ishouldseeHouseholdCapabilitiesTrackerinBilling() {
		boolean blnResult = newHouseholdPage.verifyHouseholdCapabilitiesTrackerinBilling();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to see household capabilities tracker along with Bank Sweep capability on billing details page",
				"User should able to see household capabilities tracker on the billing details page successfully",
				"Household capabilities tracker on the billing details page is displayed sucessfully",
				"Failed to see household capabilities tracker on the billing details page" + common.getStrError());
	}

	@Then("^I should see that applying group billing capability is currently in progress$")
	public void ishouldseethatapplyingBillingCapabilityisInProgressinBilling() {
		boolean blnResult = billingPage.verifyBillingCapabilityinBilling();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to see that applying group billing capability is currently in progress on billing details page",
				"User should able to see that applying group billing capability is currently in progress on billing details page successfully",
				"Applying group billing capability is currently in progress on billing details page is displayed sucessfully",
				"Failed to see that applying group billing capability is currently in progress on billing details page"
						+ common.getStrError());
	}

	@Then("^I should see existing Combined Statement capability on billing details page$")
	public void ishouldseeExistingCombinedStatementCapabilityinBilling() {
		boolean blnResult = newHouseholdPage.verifyExistingCombinedStmtCapabilityinBilling();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user is able to see existing Combined Statement capability on billing details page",
				"User should able to see existing Combined Statement capability on billing details page successfully",
				"Existing Combined Statement capability on billing details page is displayed sucessfully",
				"Failed to see existing Combined Statement capability on billing details page" + common.getStrError());
	}

	@Then("^I should see combined statement capability is currently in progress on widget$")
	public void staticInProgressVerbiageDisplayed() {
		boolean blnResult = newHouseholdPage.displayStaticInProgressVerbiage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker",
				"User should be able to see 'IN PROGRESS' static verbiage for current capability",
				"User is able to see 'IN PROGRESS' static verbiage for current capability sucessfully",
				"Failed to see 'IN PROGRESS' static verbiage for current capability" + common.getStrError());
	}

	@Then("^I should see widget title as current household name$")
	public void capabilityTrackerTitle() {
		boolean blnResult = newHouseholdPage.displayCapabilityTrackerTitle();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker",
				"User should be able to see widget title as current household name",
				"User is able to see widget title as current household name sucessfully",
				"Failed to see widget title as current household name" + common.getStrError());
	}

	@Then("^I should see an expansion chevron displayed to the right of the household name$")
	public void capabilityTrackerChevron() {
		boolean blnResult = newHouseholdPage.displayCapabilityTrackerChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker", "User should be able to see capability Tracker Chevron",
				"User is able to see capability Tracker Chevron sucessfully",
				"Failed to see capability Tracker Chevron" + common.getStrError());
	}

	@Then("^I see Sub-section1 title as BANK SWEEP CAPABILITY$")
	public void capabilityTrackerBankSweepTitle() {
		boolean blnResult = newHouseholdPage.displayCapabilityTrackerBankSweepTitle();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker", "User should be able to see Bank Sweep Title",
				"User is able to see capability Tracker Bank Sweep Title sucessfully",
				"Failed to see capability Tracker Bank Sweep Title" + common.getStrError());
	}

	@Then("^I see Household Bank Sweep name displayed below the sub-section title$")
	public void capabilityTrackerBankSweepName() {
		boolean blnResult = newHouseholdPage.displayCapabilityTrackerBankSweepName();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker", "User should be able to see Bank Sweep name",
				"User is able to see capability Tracker Bank Sweep name sucessfully",
				"Failed to see capability Tracker Bank Sweep name" + common.getStrError());
	}

	@Then("^I see Sub-section2 title as COMBINED STATEMENT CAPABILITY$")
	public void capabilityTrackerCombinedStatementTitle() {
		boolean blnResult = combinedStatementPage.displayCapabilityTrackerCombinedStatementTitle();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker", "User should be able to see Combined Statement Title",
				"User is able to see capability Tracker Combined Statement Title sucessfully",
				"Failed to see capability Tracker Combined Statement Title" + common.getStrError());
	}

	@Then("^I see Household Combined Statement name displayed below the sub-section title$")
	public void capabilityTrackerCombinedStatementName() {
		boolean blnResult = combinedStatementPage.displayCapabilityTrackerCombinedStatementName();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker", "User should be able to see Combined Statement name",
				"User is able to see capability Tracker Combined Statement name sucessfully",
				"Failed to see capability Tracker Combined Statement name" + common.getStrError());
	}

	@Then("^I see Sub-section2 title as Billing CAPABILITY$")
	public void billingCapabilityTrackerTitle() {
		boolean blnResult = billingPage.displayBillingCapabilityTrackerTitle();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker", "User should be able to see Billing Capability title",
				"User is able to see capability Tracker Billing Capability title sucessfully",
				"Failed to see capability Tracker Billing Capability title" + common.getStrError());
	}

	@Then("^I see Household Billing name displayed below the sub-section title$")
	public void capabilityTrackerBillingName() {
		boolean blnResult = billingPage.displayCapabilityTrackerBillingName();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker", "User should be able to see Billing Capability name",
				"User is able to see capability Tracker Billing Capability name sucessfully",
				"Failed to see capability Tracker Billing Capability name" + common.getStrError());
	}

	@Then("^I see Verbiage stating FORMS READY TO SIGN displayed below the sub-section box$")
	public void capabilityTrackerFormsVerbiage() {
		boolean blnResult = billingPage.displaycapabilityTrackerFormsVerbiage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker",
				"User should be able to see FORMS READY TO SIGN Verbiage",
				"User is able to see FORMS READY TO SIGN Verbiage sucessfully",
				"Failed to see FORMS READY TO SIGN Verbiage" + common.getStrError());
	}

	@Then("^I see Sub-section applied capability title as Billing CAPABILITY$")
	public void capabilityTrackerAppliedBillingCapability() {
		boolean blnResult = billingPage.displaycapabilityTrackerAppliedBillingCapability();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker",
				"User should be able to see subsection title of applied capability as Billing Capability",
				"User is able to see subsection title of applied capability as Billing Capability sucessfully",
				"Failed to see subsection title of applied capability as Billing Capability" + common.getStrError());
	}

	@When("^I click on Billing form PDF button$")
	public void clickBillingFormButton() {
		boolean blnResult = billingPage.clickBillingFormButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker",
				"User should be able to see subsection title of applied capability as Billing Capability",
				"User is able to see subsection title of applied capability as Billing Capability sucessfully",
				"Failed to see subsection title of applied capability as Billing Capability" + common.getStrError());
	}

	@When("^I should see added client verbiage in green box$")
	public void addedclientverbiage() {
		boolean blnResult = newHouseholdPage.addedclientverbaige();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User adds a new client to the household group",
				"User should be able to see added client verbiage in the capability tracker greeenbox",
				"User is able to see added client verbiage in the capability tracker greeenbox sucessfully",
				"Failed to see added client verbiage in the capability tracker greeenbox" + common.getStrError());

	}

	@Then("^I should see expanded tracker chevron$")
	public void hhexpandedtrackerchevron() {
		boolean blnResult = newHouseholdPage.expandedchevronHHtracker();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User adds or remove client from the Household Group",
				"User should be able to see expanded chevron beside the client name",
				"User is able to see expanded chevron beside the client name sucessfully",
				"Failed to see expanded chevron beside the client name" + common.getStrError());
	}

	@And("^I should see added account information in capabilities tile$")
	public void addedaccountinformation() {
		boolean blnResult = newHouseholdPage.addedclientcapabilities();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is able to see Capability Tracker", "User should be able to see Billing Capability name",
				"User is able to see capability Tracker Billing Capability name sucessfully",
				"Failed to see capability Tracker Billing Capability name" + common.getStrError());

	}

	@Then("^I select client name from search results$")
	public void selectclientname() {
		boolean blnResult = newHouseholdPage.clickclientname();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on any one of the client name",
				"Client name should be clicked", "Client name is clicked",
				"Failed to click the client name." + common.getStrError());
	}

	@When("^I should see Billable Value column in Billing Summary banner$")
	public void ishouldseeBillableValuecolumninBillingSummary() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.verifyBillableValuecolumninBillingSummary();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Dashboard Page",
				"User should be able to see Billable Value column in Billing Summary banner of Billing Rate section",
				"User is able to see Billable Value column in Billing Summary banner of Billing Rate section sucessfully",
				"Failed to see Billable Value column in Billing Summary banner of Billing Rate section"
						+ common.getStrError());
	}

	@When("^I should see Billable Value column in client/account details for group billing$")
	public void ishouldseeBillableValuecolumninclientaccountdetails() {
		boolean blnResult = newHouseholdPage.verifyBillableValuecolumninClientAccountDetails();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Dashboard Page",
				"User should be able to see Billable Value column in client/account details for group billing of Billing Rate section",
				"User is able to see Billable Value column in client/account details for group billing of Billing Rate section sucessfully",
				"Failed to see Billable Value column in client/account details for group billing of Billing Rate section"
						+ common.getStrError());
	}

	@When("^I should see Status column in client/account details for group billing$")
	public void ishouldseeStatuscolumninclientaccountdetails() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.verifyStatuscolumninClientAccountDetails();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Dashboard Page",
				"User should be able to see Status column in client/account details for group billing of Billing Rate section",
				"User is able to see Status column in client/account details for group billing of Billing Rate section sucessfully",
				"Failed to see Status column in client/account details for group billing of Billing Rate section"
						+ common.getStrError());
	}

	@When("^I see sub header$")
	public void iseesubheader() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.subheader();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Dashboard Page",
				"User should be able to see subheader in dashboard Page",
				"User is able to see subheader in dashboard Page sucessfully",
				"Failed to see subheader in dashboard Page" + common.getStrError());
	}

	@Then("^I see  sub header menu options$")
	public void subheadermenuoptions(DataTable field) {

		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = newHouseholdPage.subheadermenufieldVisible(data.get("subheadermenufields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("subheadermenufields") + " available",
					"User should able to see the  " + data.get("subheadermenufields") + "fields",
					" listed field values is " + data.get("subheadermenufields") + " visible",
					"Failed : listed field values " + data.get("subheadermenufields") + "are NOT visible");

		}

	}

	@And("^I see edit button with household group name$")
	public void editbuttonwithhouseholdgroupname() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.subheadernamewitheditbutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Dashboard Page",
				"User should be able to see Subheader name with edit button",
				"User is able to see subheader name with edit button sucessfully",
				"Failed to see subheader name with edit button" + common.getStrError());

	}

	@And("^User is able to see side to side navigation tab$")
	public void sideToSideNavigationTabDisplayed() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.isSideToSideNavigationTabDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Edit HH page",
				"User should be able to see side to side navigation tab",
				"User is able to see side to side navigation tab sucessfully",
				"Failed to see side to side navigation tab" + common.getStrError());

	}

	@And("^User is able to see Household name$")
	public void validateHouseholdClientName() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.validateHouseholdClientName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Edit HH page",
				"User should be able to see Household client name below side to side navigation tab",
				"User is able to see Household client name below side to side navigation tab sucessfully",
				"Failed to see Household client name below side to side navigation tab" + common.getStrError());

	}

	@And("^User is able to see household summary banner$")
	public void validateEditHouseholdPageSummaryBanner() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.validateEditHouseholdSummaryBanner();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Edit HH page",
				"User should be able to see Household client name below side to side navigation tab",
				"User is able to see Household client name below side to side navigation tab sucessfully",
				"Failed to see Household client name below side to side navigation tab" + common.getStrError());

	}

	@Then("^User is able to see following fields in summary banner$")
	public void summaryBannerFields(DataTable field) {

		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = newHouseholdPage.displaySummaryBannerFields(data.get("SummaryBannerFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("SummaryBannerFields") + " available",
					"User should able to see the  " + data.get("SummaryBannerFields") + "fields",
					" listed field values is " + data.get("SummaryBannerFields") + " visible",
					"Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");

		}
	}

	@Then("^a PDF is displayed in a new tab$")
	public void BillingFormPDFDisplayed() {
		boolean blnResult = newHouseholdPage.billingPDFDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on Billing FORM PDF",
				"User should be able to see Billing form PDF displayed in new window",
				"User is able to see Billing form PDF displayed in new window successfully",
				"Failed to see Billing form PDF displayed in new window" + common.getStrError());
	}

	@Then("^I  clear and enter group name with alphanumeric characters$")
	public void iclearandentergroupnamewithalphanumericcharacters() {
		String clientGroupName = testData.get("AlphanumericGroupName");
		boolean blnResult = newHouseholdPage.clearAndEnterGroupName(clientGroupName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and enter alphamumeric characters in group name field of the edit household Page",
				"user should able to clear and enter alphanumeric group name successfully",
				"Group name cleared and enter alphamumeric character sucessfully",
				"Failed to clear and enter alphanumeric character in edit Household page" + common.getStrError());

	}

	@And("^I see alphanumeric character error message$")
	public void alphanumericgroupnameerrormessage() {
		boolean blnResult = newHouseholdPage.alphaNumericGroupNameErrorMessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User enter alphabetic characters in group name field",
				"User should be able to see only alpha-numeric characters are allowed error message ",
				"User is able to see only alpha-numeric characters are allowed error message successfully",
				"Failed to see only alpha-numeric characters are allowed error message" + common.getStrError());
	}

	@When("^I clear and enter group name with exceeding characters$")
	public void groupnameexceedingcharacters() {
		String clientGroupName = testData.get("exceedingCharGroupName");
		boolean blnResult = newHouseholdPage.clearAndEnterGroupName(clientGroupName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and enter more than fourty characters in group name field of the edit household Page",
				"user should able to clear and ente  more than fourty characters group name successfully",
				"Group name cleared and enter more than 40 characters sucessfully",
				"Failed to clear and enter more than fourty characters in edit Household page" + common.getStrError());
	}

	@Then("^I see execeeding length error message$")
	public void exceedinglengtherrormessage() {
		boolean blnResult = newHouseholdPage.exceedinGroupNameErrorMessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User enter more than fourty characters in group name field",
				"User should be able to see You have reached the max number of characters error message ",
				"User is able to see You have reached the max number of characters error message successfully",
				"Failed to see You have reached the max number of characters error message" + common.getStrError());

	}

	@Then("^I clear groupname$")
	public void cleargroupname() {
		boolean blnResult = newHouseholdPage.blankgroupname();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear groupname in edit Household page",
				"user should able to clear group name successfully", "Group name cleared sucessfully",
				"Failed to clear group name in edit Household page" + common.getStrError());

	}

	@And("^I should see  error message household name required$")
	public void blankerrormessage() {
		boolean blnResult = newHouseholdPage.blankgroupnameerrormessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User clears group name field",
				"User should be able to see Household Name is required error message ",
				"User is able to see Household Name is required error message successfully",
				"Failed to see Household Name is required error message" + common.getStrError());
	}

	@Then("^I clear and enter combine statement Name with alphanumeric characters$")
	public void alphanumericcombinedstatementname() {
		String combinedstatementName = testData.get("alphanumericcombinedstatementName");
		boolean blnResult = combinedStatementPage.clearAndEnterCombinedstatementName(combinedstatementName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and edit combined statement group name in edit combined statement details page",
				"user should able to clear and enter alphanumeric combined statement group name successfully",
				" enter alphanumeric combined statement group name sucessfully",
				"Failed to clear and enter the alphanumeric combined statement group name in edit combined statement details page"
						+ common.getStrError());

	}

	@When("^I clear and enter combine statement Name with exceeding characters$")
	public void exceedingcombinedstatementname() {
		String combinedStatementName = testData.get("exceedingCombineStatementName");
		boolean blnResult = combinedStatementPage.clearAndEnterCombinedstatementName(combinedStatementName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear and enter combined statement group name with exceeding characters in edit combined statement details page",
				"user should able to clear and enter combined statement group name with exceeding characters successfully",
				"cleared and enter combined statement group name with exceeding characters sucessfully",
				"Failed to clear and enter the combined statement group name with exceeding characters in edit combined statement details page"
						+ common.getStrError());

	}

	@When("^I clear combined statement Name$")
	public void clearcombinedstatementname() {
		boolean blnResult = newHouseholdPage.clearCombinedstatementName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate user able to clear combined statement name in edit combined statement page",
				"user should able to clear combined statement name successfully",
				"combined statement name cleared sucessfully",
				"Failed to clear combined  statement name in edit combined statement page" + common.getStrError());

	}

	@Then("^I see blank combined statement error message$")
	public void blankCSerrormessage() {
		boolean blnResult = combinedStatementPage.blankcombinedstatementnameerrormessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clears combined statement name field",
				"User should be able to see Combined Statement Name is required message ",
				"User is able to see message Combined Statement Name is required message successfully",
				"Failed to see Combined Statement Name is required message" + common.getStrError());
	}

	@Then("^I should see show more clients hyperlink$")
	public void dashboardShowMoreClients() {
		boolean blnResult = newHouseholdPage.dashboardShowMoreClientsHyperlink();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When user is on dashboard page",
				"User should be able to see show x more clients hyperlink if household has more than 5 clients ",
				"User is able to see show x more clients hyperlink on dashboard successfully",
				"Failed to see show x more clients hyperlink on dashboard" + common.getStrError());
	}

	@When("^I click on show more clients hyperlink$")
	public void clickDashboardShowMoreClientsHyperlink() {
		boolean blnResult = newHouseholdPage.clickDashboardShowMoreClientsHyperlink();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on dashboard page and user is able to see show x more clients hyperlink",
				"User should be able to click on show x more clients hyperlink if household has more than 5 clients ",
				"User is able to click on show x more clients hyperlink on dashboard successfully",
				"Failed to click on show x more clients hyperlink on dashboard" + common.getStrError());
	}

	@Then("^Show more hyperlink changes to hide clients hyperlink$")
	public void DisplayedHideClientsHyperlink() {
		boolean blnResult = newHouseholdPage.DisplayedHideClientsHyperlink();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on dashboard page and user click on show x more clients hyperlink",
				"User should be able to see hyperlink changes to hide x more clients",
				"User is able to see hyperlink changes to hide x more clients successfully",
				"Failed to see hyperlink changes to hide x more clients" + common.getStrError());
	}

	@Then("^I should see Back button on Edit Household Details page$")
	public void displayedEditHouseholdPageBackButton() {
		boolean blnResult = newHouseholdPage.displayedEditHouseholdPageBackButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on dashboard page and user click on Edit Household button on summary panel",
				"User should be able to see back button on Edit Household Details page",
				"User is able to see back button on Edit Household Details page successfully",
				"Failed to see back button on Edit Household Details page" + common.getStrError());
	}

	@Then("^I click on Back button on Edit Household Details page$")
	public void clickEditHouseholdPageBackButton() {
		boolean blnResult = newHouseholdPage.clickEditHouseholdPageBackButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on Edit Household Details page",
				"User should be able to click back button on Edit Household Details page",
				"User is able to click back button on Edit Household Details page successfully",
				"Failed to click back button on Edit Household Details page" + common.getStrError());
	}

	@Then("^I expand group contents menu$")
	public void clickHouseholdGroupContextMenu() {
		boolean blnResult = newHouseholdPage.clickHouseholdGroupContextMenu();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When user is on CW Groups tab",
				"User should be able to click on group context menu",
				"User is able to click on group context menu successfully",
				"Failed to click on group context menu" + common.getStrError());
	}

	@Then("^I click on Edit Household Option$")
	public void clickEditHouseholdOption() {
		boolean blnResult = newHouseholdPage.clickEditHouseholdOption();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When user is on CW Groups tab",
				"User should be able to click on group context menu",
				"User is able to click on group context menu successfully",
				"Failed to click on group context menu" + common.getStrError());
	}

	@Then("^I click on group member context menu$")
	public void clickGroupMemberContextMenu() {
		boolean blnResult = newHouseholdPage.clickGroupMemberContextMenu();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When user is on CW Groups tab",
				"User should be able to click on household group member context menu",
				"User is able to click on household group member context menu successfully",
				"Failed to click on household group member context menu" + common.getStrError());
	}

	@Then("^I click on For A Combined Statement Subgroups option$")
	public void iclickonForACombinedStatementSubgroupsoption() {
		boolean blnResult = combinedStatementPage.clickCombinedStatementSubgroup();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on New combined statement details Page",
				"User should be able to click on For A Combined Statement Subgroup(s)",
				"User is able to click on For A Combined Statement Subgroup(s) successfully",
				"Failed to click on For A Combined Statement Subgroup(s)" + common.getStrError());
	}

	@When("^I see New Combined Statement Subgroups Details Page$")
	public void seeNewCombinedStatementSubgroupsDetailsPage() {
		boolean blnResult = combinedStatementPage.newCombinedStatementSubgroupDetailsPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user clicks on For A Combined Statement Subgroup(s)",
				"User should be able to see New Combined Statement Subgroup(s) Details page",
				"User is able to see New Combined Statement Subgroup(s) Details page successfully",
				"Failed to see New Combined Statement Subgroup(s) Details page" + common.getStrError());
	}

	@When("^I see  sub group combined  statement  tile$")
	public void seesubgroupcombinedstatementtile() {
		boolean blnResult = combinedStatementPage.displaySubgroupCombineStatementTile();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on New Combined Statement Subgroup(s) Details page",
				"User should be able to see sub group combined statement tile",
				"User is able to see sub group combined statement tile successfully",
				"Failed to see sub group combined statement tile" + common.getStrError());
	}

	@When("^I see review Combined Statement Subgroup\\(s\\) Details Page$")
	public void seereviewCombinedStatementSubgroupsDetailsPage() {
		boolean blnResult = combinedStatementPage.seeReviewCombinedStatementSubgroupDetailsPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When user clicks on done editing button",
				"User should be able to see review Combined Statement Subgroup(s) Details Page",
				"User is able to see review Combined Statement Subgroup(s) Details Pagesuccessfully",
				"Failed to see review Combined Statement Subgroup(s) Details Page" + common.getStrError());
	}

	@Then("^I should  see subgroup combined statement title with status$")
	public void subgroupcombinedstatementtitlewithstatus() {
		boolean blnResult = combinedStatementPage.displaySubgroupCombinedStatementTitleWithStatus();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user sees sub group combined statement tile",
				"User should be able to see subgroup combined statement title with status",
				"User is able to see subgroup combined statement title with status successfully",
				"Failed to see subgroup combined statement title with status" + common.getStrError());
	}

	@When("^I click on setup combined statement sub group button$")
	public void iclickonsetupcombinedstatementsubgroupbutton() {
		boolean blnResult = combinedStatementPage.clickSetupCombinedStatementSubgroup();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on New combined statement details Page",
				"User should be able to click on setup combined statement sub group button",
				"User is able to click on setup combined statement sub group button successfully",
				"Failed to click on setup combined statement sub group button" + common.getStrError());
	}

	@Then("^I click on complete details button$")
	public void clickcompletedetailsbutton() {
		boolean blnResult = combinedStatementPage.clickCreateCombinedStatementSubgroup();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on create combined statement sub group Page",
				"User should be able to click on complete details button",
				"User is able to click on complete details button successfully",
				"Failed to click on complete details button" + common.getStrError());
	}

	@Then("^I see cancel and return to dashboard link$")
	public void seecancelandreturnbutton() {

		boolean blnResult = combinedStatementPage.verifyCancelReturnToDashboardHyperLinkinCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit Combined Statement Button in Dashboard",
				"User should able to view Cancel & Return to Dashboard hyperlink successfully",
				"User is able to view Cancel & Return to Dashboard hyperlink successfully",
				"Failed to view Cancel & Return to Dashboard hyperlink" + common.getStrError());
	}

	@When("^I select primary account for combined statement sub group$")
	public void selectprimaryaccountforcombinedstatementsubgroup() {
		boolean blnResult = newHouseholdPage.clickprimaryaccountCSsubgroup();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on New combined statement details Page",
				"User should be able to select primary account for combined statement sub group",
				"User is able to select primary account for combined statement sub group successfully",
				"Failed to select primary account for combined statement sub group" + common.getStrError());
	}

	@And("^I click on New Combined Statement option on tile dropdown$")
	public void selectNewCombinedStatementOption() {
		boolean blnResult = combinedStatementPage.clickNewCombinedStatementOption();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on Set Up combined statement details Page",
				"User should be able to select New Combined Statement option from menu dropdown",
				"User is able to select New Combined Statement option from menu dropdown successfully",
				"Failed to select New Combined Statement option from menu dropdown" + common.getStrError());
	}

	@Then("^The selected client is displayed separately from the other clients as its own combined statement subgroup$")
	public void seperateClient_CombinedStatementSubgroup() {
		boolean blnResult = combinedStatementPage.validateSeparateClientCSsubgroups();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on Set Up combined statement details Page and user selects New Combined option from menu dropdown",
				"User should be able to see selected client seperately as its own combined statement subgroup",
				"User is able to see selected client seperately as its own combined statement subgroup successfully",
				"Failed to see selected client seperately as its own combined statement subgroup"
						+ common.getStrError());
	}

	@And("^The combined statement name for the new subgroup defaults to the clients name$")
	public void CombinedStatementSubgroupName() {
		boolean blnResult = combinedStatementPage.validateCSsubgroupName();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is has added new combined statement",
				"User should be able to see the combined statement name for the new subgroup defaults to the clients name",
				"User is able to see the combined statement name for the new subgroup defaults to the clients name successfully",
				"Failed to see the combined statement name for the new subgroup defaults to the clients name"
						+ common.getStrError());
	}

	@When("^I add three clients to the Household$")
	public void fetchThreeClientNames() {
		for (int i = 0; i < 3; i++) {
			common.waitForPageLoading();
			if (i == 0) {
				firstName = testData.get("firstNameClient1");
				boolean blnResult = newHouseholdPage.enterSearchTextInClientPrimarySearchBox(firstName);
				LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
						"Enter the first name[" + firstName + "]", "First name should be entered",
						"First name[" + firstName + "] is entered",
						"Failed To enter the first name." + common.getStrError());

				newHouseholdPage.selectClientNameUsingKeys();
			} else if (i == 1) {
				newHouseholdPage.clearClientName();
				firstName = testData.get("firstNameClient2");
				boolean blnResult = newHouseholdPage.enterSearchTextInClientPrimarySearchBox(firstName);
				LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
						"Enter the first name[" + firstName + "]", "First name should be entered",
						"First name[" + firstName + "] is entered",
						"Failed To enter the first name." + common.getStrError());
				newHouseholdPage.selectClientNameUsingKeys();
			} else if (i == 2) {
				newHouseholdPage.clearClientName();
				firstName = testData.get("firstNameClient3");
				boolean blnResult = newHouseholdPage.enterSearchTextInClientPrimarySearchBox(firstName);
				LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
						"Enter the first name[" + firstName + "]", "First name should be entered",
						"First name[" + firstName + "] is entered",
						"Failed To enter the first name." + common.getStrError());
				newHouseholdPage.selectClientNameUsingKeys();
			}
		}
	}

	@Then("^I should land on New Household Combined Statement Details page$")
	public void newHouseholdCombinedStatementDetailsPageIsDisplayed() {
		boolean blnResult = combinedStatementPage.newHouseholdCombinedStatementDetailsPageDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User click on Combined Statement",
				"User should able to land on New Household Combined Statement Details",
				"User is able to see New Household Combined Statement Details",
				"Failed to see New Household Combined Statement Details page." + common.getStrError());
	}

	@Then("^I should see Combined statement TBD in the HH tracker$")
	public void combinedStatementTBDTracker() {
		boolean blnResult = combinedStatementPage.displayCombinedStatementTBD();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees household capability tracker in New Combined Statement Subgroup(s) Details Page",
				"User is able to see Combined Statement TBD sub header in the tracker",
				"User is able to see Combined Statement TBD sub header in the tracker sucessfully",
				"Failed to able to see see Combined Statement TBD sub header in the tracker " + common.getStrError());
	}

	@When("^I select Primary account for the Combined Statement$")
	public void i_select_Primary_account_for_the_Combined_Statement() {
		String clientName = testData.get("firstNameClient2");
		boolean blnResult = combinedStatementPage.selectPrimaryClientForCombinedStatement(clientName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is trying to select the Primary client for Combined Statement",
				"User is able to select the Primary client for Combined Statementr",
				"User is able to select the Primary client for Combined Statement sucessfully",
				"Failed to select the Primary client for Combined Statement" + common.getStrError());
	}
	
	@When("^I select Primary for subgroup combined statement$")
	public void i_select_Primary_for_subgroup_Combined_Statement() {
		String clientName = testData.get("firstNameClient2");
		boolean blnResult = combinedStatementPage.selectPrimaryClientForSubgroupCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is trying to select the Primary client for Combined Statement",
				"User is able to select the Primary client for Combined Statementr",
				"User is able to select the Primary client for Combined Statement sucessfully",
				"Failed to select the Primary client for Combined Statement" + common.getStrError());
	}

	@When("^I click on SET UP COMBINED STATEMENT SUBGROUP\\(S\\) button$")
	public void i_click_on_SET_UP_COMBINED_STATEMENT_SUBGROUP_S_button() {
		boolean blnResult = newHouseholdPage.clickSetupsCombinedStatementSubgroup();
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on New combined statement details Page",
				"User should be able to click on For A Combined Statement Subgroup(s)",
				"User is able to click on For A Combined Statement Subgroup(s) successfully",
				"Failed to click on For A Combined Statement Subgroup(s)" + common.getStrError());

	}

	@Then("^I should see Combined statement name as Household name$")
	public void i_should_see_Combined_statement_name_as_Household_name() {
		boolean blnResult = combinedStatementPage.displayCombinedStatementNameInTracker();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees household capability tracker in New Combined Statement Subgroup(s) Details Page",
				"User is able to see Combined Statement name in the tracker",
				"User is able to see Combined Statement name in the tracker sucessfully",
				"Failed to able to see see Combined Statement name in the tracker " + common.getStrError());
	}

	@Then("^I see Set Up Combined Statements page$")
	public void i_see_Set_Up_Combined_Statements_page() {
		boolean blnResult = combinedStatementPage.displaySetUpCombinedStatementPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees household capability Set Up Combined Statements Page",
				"User is able to see Set Up Combined Statements Page",
				"User is able to see CSet Up Combined Statements Page sucessfully",
				"Failed to able to see Set Up Combined Statements Page" + common.getStrError());
	}

	@When("^I create combined statement subgroup for one of the clients$")
	public void i_create_combined_statement_subgroup_for_one_of_the_clients() {
		firstName = testData.get("firstNameClient3");
		boolean blnResult = newHouseholdPage.clickOnMove(firstName);
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on Set Up combined statement Page",
				"User should be able to click on Move for mentioned client",
				"User is able to click on Move successfully", "Failed to click on Move" + common.getStrError());
		boolean blnResult1 = newHouseholdPage.clickOnNewCombinedStatement(firstName);
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When user is on Set Up combined statement Page",
				"User should be able to click on New Combined Statement",
				"User is able to click on New Combined Statement successfully",
				"Failed to click on New Combined Statement" + common.getStrError());

	}

	@Then("^Verify the Combined Statement Subgroup name in the tracker$")
	public void VerifyHouseholdNameInTracker() {
		firstName = testData.get("firstNameClient3");
		boolean blnResult = combinedStatementPage.displayCombinedStatementSubgroupNameInTracker(firstName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees household capability tracker in New Combined Statement Subgroup(s) Details Page",
				"User is able to see Combined Statement name in the tracker",
				"User is able to see Combined Statement name in the tracker sucessfully",
				"Failed to able to see see Combined Statement name in the tracker " + common.getStrError());
	}

	@When("^I select dropdown option for existing Combined Statement$")
	public void selectExistingCSdropdownMenu() {
		boolean blnResult = combinedStatementPage.clickExistingCSdropdownMenu();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Set up combined statement page",
				"User clicks on existing combined statement dropdown menu",
				"User should be able to click on existing combined statement dropdown menu sucessfully",
				"Failed to click on existing combined statement dropdown menu " + common.getStrError());
	}

	@Then("^The dropdown option should have New Combined Statement option$")
	public void validateExistingCS_DropdownOption() {
		boolean blnResult = combinedStatementPage.validateExistingCS_DropdownOption();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on dropdowm menu of existing combined statement",
				"User is able to see New Combined Statement option",
				"User should be able to see New Combined Statement option in dropdown menu sucessfully",
				"Failed to see New Combined Statement option in dropdown menu " + common.getStrError());
	}

	@And("^The dropdown option should display New Combined Statement name$")
	public void validateExistingCS_dropdownOption_NewCSname() {
		boolean blnResult = combinedStatementPage.validateExistingCS_dropdownOption_NewCSname();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on dropdowm menu of existing combined statement",
				"User is able to see New Combined Statement name",
				"User should be able to see New Combined Statement name in dropdown menu sucessfully",
				"Failed to see New Combined Statement name in dropdown menu " + common.getStrError());
	}

	@When("^I select dropdown option for New Combined Statement$")
	public void selectNewCSdropdownMenu() {
		boolean blnResult = newHouseholdPage.clickNewCSdropdownMenu();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Set up combined statement page", "User clicks on new combined statement dropdown menu",
				"User should be able to click on new combined statement dropdown menu sucessfully",
				"Failed to click on new combined statement dropdown menu " + common.getStrError());
	}

	@Then("^The dropdown option should display existing Combined Statement name$")
	public void validateNewCS_DropdownMenu_ExistingCSname() {
		boolean blnResult = combinedStatementPage.validateNewCS_DropdownMenu_ExistingCSname();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Set up combined statement page", "User clicks on new combined statement dropdown menu",
				"User should be able to see existing CS Name in dropdown menu sucessfully",
				"Failed to see existing CS Name in dropdown menu" + common.getStrError());
	}

	@Then("^I select one of the client name from search result for new client$")
	public void selectClientNameForNewlyAddedClient() {
		newHouseholdPage.clearClientName();
		firstName = testData.get("firstName");
		boolean blnResult = newHouseholdPage.clickOnClientToSelect();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select the client name[" + firstName + "]",
				"Client name should be selected", "First name[" + firstName + "] is selected",
				"Failed To enter the first name." + common.getStrError());
		//newHouseholdPage.selectClientNameUsingKeys();
	}

	@Then("^I see Overlay modal page for combined statements$")
	public void displayOverlayModalCombinedStatementPage() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.displayOverlayModalCSPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees Overlay Modal page for Combined Statement",
				"User is able to see Overlay Modal page for Combined Statement",
				"User is in Overlay Modal page for Combined Statement sucessfully",
				"Failed to able to see Overlay Modal page for Combined Statement" + common.getStrError());
	}

	@Then("^Verify texts in the Overlay modal page for combined statements$")
	public void verifyTextInOverlayModalCombinedStatementPage() {
		boolean blnResult = newHouseholdPage.verifyTextOverlayPageStmt();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees the statement This household currently has x combined statements.",
				"User is able to see the statement This household currently has x combined statements.",
				"User sees the statement This household currently has x combined statements. sucessfully",
				"Failed to able to see the statement This household currently has x combined statements."
						+ common.getStrError());

		common.waitForPageLoading();
		boolean blnResult1 = newHouseholdPage.verifyOverlayPageText();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When User sees the statement HOW WOULD YOU LIKE TO ADD THIS CLIENT TO COMBINED STATEMENTS FOR THIS HOUSEHOLD?",
				"User is able to see the statement HOW WOULD YOU LIKE TO ADD THIS CLIENT TO COMBINED STATEMENTS FOR THIS HOUSEHOLD?.",
				"User sees the statement HOW WOULD YOU LIKE TO ADD THIS CLIENT TO COMBINED STATEMENTS FOR THIS HOUSEHOLD? sucessfully",
				"Failed to able to see the statement HOW WOULD YOU LIKE TO ADD THIS CLIENT TO COMBINED STATEMENTS FOR THIS HOUSEHOLD?"
						+ common.getStrError());

		common.waitForPageLoading();
		boolean blnResult2 = newHouseholdPage.OverlayPageSelectCSText();
		LPLCoreReporter.writeStepToReporter(blnResult2, LPLCoreConstents.TRUE,
				"When User sees the statement Select which combined statement you want to add this client to:",
				"User is able to see the statement Select which combined statement you want to add this client to:",
				"User sees the statement Select which combined statement you want to add this client to: sucessfully",
				"Failed to able to see the statement Select which combined statement you want to add this client to:"
						+ common.getStrError());
	}

	@Then("^Verify buttons in the Overlay modal page for combined statements$")
	public void verifyButtonsInOverlayModalCombinedStatementPage() {
		boolean blnResult = false;
		blnResult = newHouseholdPage.verifyAddClientToAnExistingStatementText();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees Add Client to an Existing Statement button is displayed",
				"User is able to see Add Client to an Existing Statement button",
				"User sees Add Client to an Existing Statement button sucessfully",
				"Failed to able to see Add Client to an Existing Statement button" + common.getStrError());

		common.waitForPageLoading();
		blnResult = newHouseholdPage.addClientToAnExistingStatementIsSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees Add Client to an Existing Statement button is selected by default",
				"User is able to see Add Client to an Existing Statement button selected by default",
				"User sees Add Client to an Existing Statement button selected by default sucessfully",
				"Failed to able to see Add Client to an Existing Statement button selected by default"
						+ common.getStrError());

		common.waitForPageLoading();
		blnResult = newHouseholdPage.verifyCreateANewCSForClient();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User sees Create a New Combined Statement for Client button is displayed",
				"User is able to see Create a New Combined Statement for Client button",
				"User sees Create a New Combined Statement for Client button is displayed sucessfully",
				"Failed to able to see Create a New Combined Statement for Client is displayed" + common.getStrError());

	}

	@Then("^I Select a Combined Statement Subgroup to add new client to the existing group$")
	public void selectCS_AddNewClientToExistingCS() {
		boolean blnResult = newHouseholdPage.selectDesiredCombinedStatement();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay Modal page for Combined Statement",
				"User clicks on desired combined statement",
				"User should be able to click on desired combined statement sucessfully",
				"Failed to click on desired combined statement" + common.getStrError());

	}

	@When("^I click on NEXT button$")
	public void click_on_NEXT() {
		boolean blnResult = newHouseholdPage.overlayPage_NextButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay Modal page for Combined Statement", "User clicks on NEXT button",
				"User should be able to click on NEXT button sucessfully",
				"Failed to click on NEXT button" + common.getStrError());

	}

	@Then("^Ensure Edit Household page is displayed$")
	public void ensure_Edit_Household_page_is_displayed() {
		boolean blnResult1 = newHouseholdPage.seeEditHHPage_ClickingNext();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE, "When User sees the Edit Household page",
				"User is able to see Edit Household page", "User sees the Edit Household page",
				"Failed to able to see Edit Household page" + common.getStrError());
	}

	@Then("^I click on Create Combined Statement button$")
	public void iClickCreateCombinedStatementButton() {
		boolean blnResult1 = combinedStatementPage.clickCreateCombinedStatementButton();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When User is on Review Combined Statemenet Subgroup(s) Details page",
				"User is able to click on Create Combined Statement button",
				"User is able to click on Create Combined Statement button successfully",
				"Failed to is able to click on Create Combined Statement button" + common.getStrError());
	}

	@When("^I click on Create a New Combined Statement for Client button$")
	public void clickNewCombinedStatementforClientbutton() {
		boolean blnResult = newHouseholdPage.clickCreateaNewCombinedStatementforClientbutton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User has selected a client in edit household page",
				"User clicks on Create a New Combined Statement for Client button",
				"User should be able to click on New Combined Statement for Client button sucessfully",
				"Failed to click on New Combined Statement for Client button" + common.getStrError());

	}

	@Then("^I should see tile to select primary account$")
	public void seeselectprimaryaccounttile() {
		boolean blnResult1 = newHouseholdPage.tiletoselectprimaryaccountDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When User has clicked on Create a New Combined Statement for Client button in edit household page",
				"User is able to see tile to select primary account", "User sees tile to select primary account",
				"Failed to see tile to select primary account" + common.getStrError());
	}

	@And("^I see New Combined Statement Subgroup\\(s\\) Details Page header$")
	public void iSeeNewCSsubgroupsPageHeader() {
		boolean blnResult1 = combinedStatementPage.validateNewCSsubgroupsPageHeader();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When user is on New Combined Statement Subgroup(s) Details page",
				"User should be able to see page header", "User is able to see page header successfully",
				"Failed to see New Combined Statement Subgroup(s) Details page header" + common.getStrError());
	}

	@Then("^Validate Letter Widget$")
	public void validate_Letter_Widget() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.verifyLetterWidget();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validating the Letter Widget in Combined Statment Subgroup",
				"User is able to see Letter widget in the landing page", "User sees the Letter Widget successfully",
				"Failed to able to see the Letter Widget" + common.getStrError());
		common.waitForPageLoading();
		boolean blnResult1 = combinedStatementPage.verifyLetterWidgetContent();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"Validating the Letter Widget content in Combined Statment Subgroup",
				"User is able to see content in Letter widget in the landing page",
				"User sees the Content in Letter Widget successfully",
				"Failed to able to see the Content in Letter Widget" + common.getStrError());

	}

	@And("^I see New Combined Statement Subgroup\\(s\\) Details Page Subheader$")
	public void iSeeNewCSsubgroupsPageSubHeader() {
		boolean blnResult1 = combinedStatementPage.validateNewCSsubgroupsPageSubHeader();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When user is on New Combined Statement Subgroup(s) Details page Sub-header",
				"User should be able to see page Sub-header", "User is able to see page sub-header successfully",
				"Failed to see New Combined Statement Subgroup(s) Details page sub-header" + common.getStrError());
	}

	@And("^I see Button Option 1 For Entire Household$")
	public void iSeeNewCSsubgroupsPageButton1() {
		boolean blnResult1 = combinedStatementPage.validateNewCSsubgroupsPageButton1();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When user is on New Combined Statement Subgroup(s) Details page Sub-header",
				"User should be able to Button Option 1 as For Entire Household",
				"User is able to see Button Option 1 as For Entire Household successfully",
				"Failed to see Button Option 1 as For Entire Householdsub-header" + common.getStrError());
	}

	@When("^I click on COMPELETE DETAILS FOR 1 COMBINED STATEMENT$")
	public void i_click_on_COMPELETE_DETAILS_FOR_1_COMBINED_STATEMENT() {
		boolean blnResult = newHouseholdPage.clickOnCompleteDetailsFor1CombinedStatement();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay Modal page for Combined Statement", "User clicks on NEXT button",
				"User should be able to click on NEXT button sucessfully",
				"Failed to click on NEXT button" + common.getStrError());
	}

	@And("^I see Button Option 2 For a Combined Statement Subgroup\\(s\\)$")
	public void iSeeNewCSsubgroupsPageButton2() {
		boolean blnResult1 = combinedStatementPage.validateCSsubgroupsPageButton2();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When user is on New Combined Statement Subgroup(s) Details page",
				"User should be able to Button Option 2 as For Entire Household",
				"User is able to see Button Option 2 as For Entire Household successfully",
				"Failed to see Button Option 2 as For Entire Householdsub-header" + common.getStrError());
	}

	@And("^I see A box with verbiage below the button$")
	public void iSeeNewCSsubgroupsPageVerbiage() {
		boolean blnResult1 = combinedStatementPage.validateCSsubgroupsPageVerbiage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When user is on New Combined Statement Subgroup(s) Details page",
				"User should be able to box verbiage below the buttons",
				"User is able to see box verbiage below the buttons successfully",
				"Failed to see box verbiage below the buttons" + common.getStrError());
	}

	@Then("^I see Review Combined Statement Subgroup\\(s\\) Details page$")
	public void i_see_Review_Combined_Statement_Subgroup_s_Details_page() {
		boolean blnResult = newHouseholdPage.validateReviewCSSubgroupDetailsPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validating the Review Combined Statement Subgroup(s) Details page",
				"User is able to see Review Combined Statement Subgroup(s) Details page",
				"User sees the Review Combined Statement Subgroup(s) Details page successfully",
				"Failed to able to see Review Combined Statement Subgroup(s) Details page" + common.getStrError());
	}

	@Then("^I select primary accounts to create combined statement sub group$")
	public void iSelectPrimaryAccountsForCSsubgroups() {
		boolean blnResult = combinedStatementPage.selectPrimaryAccountsForCSsubgroups();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on New Combined Statement subgroups",
				"User is able to select primary accounts for combined statement subgroups",
				"User is able to select primary accounts for combined statement subgroups successfully",
				"Failed to select primary accounts for combined statement subgroups" + common.getStrError());
	}

	@Then("^I see CONTENTS label sub-header$")
	public void iSeeContentsLabelSubheader() {
		boolean blnResult = combinedStatementPage.validateContentsLabelSubHeader();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on CS Streamline/Confirmation page", "User should be able to see CONTENTS sub-header",
				"User is able to see CONTENTS sub-header successfully",
				"Failed to see CONTENTS sub-header" + common.getStrError());
	}

	@Then("^I see section title for combined statements$")
	public void iSeeCSsectionTitle() {
		boolean blnResult = combinedStatementPage.validateCSsectionTitle();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is on CS Streamline/Confirmation page",
				"User should be able to see combined statement section title",
				"User is able to see combined statement section title successfully",
				"Failed to see combined statement section title" + common.getStrError());
	}

	@Then("^User is able to see following fields in combined statement summary banner$")
	public void iSeeCSsummaryBannerFields(DataTable field) {

		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = combinedStatementPage.displayCSSummaryBannerFields(data.get("SummaryBannerFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("SummaryBannerFields") + " available",
					"User should able to see the  " + data.get("SummaryBannerFields") + "fields",
					" listed field values is " + data.get("SummaryBannerFields") + " visible",
					"Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");
		}
	}

	@And("^User is able to see CS sbgroups review panel component$")
	public void iSeeCSsubgroupReviewPanel() {
		boolean blnResult = combinedStatementPage.validateCSsubgroupReviewPanel();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Review Combined Statement Subgroup Details page",
				"User is able to see review panel for each CS",
				"User should be able to see review panel for each CS successfully",
				"Failed to see review panel for each CS" + common.getStrError());
	}

	@When("^I select edit button on New Combined Statement Subgroup\\(s\\) Details Page$")
	public void iClickEditCSsubgroupButton() {
		boolean blnResult = combinedStatementPage.clickEditCSsubgroupButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on New Combined Statement Subgroup Details page",
				"User is able to click on edit CS button",
				"User should be able to click on edit CS button successfully",
				"Failed to click on edit CS button" + common.getStrError());
	}

	@Then("^I see Set Up Combined Statement Subgroup\\(s\\) Page$")
	public void iSeeSetUpCSPage() {
		boolean blnResult = combinedStatementPage.validateSetUpCombinedStatementPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on New Combined Statement Subgroup Details page", "User click on edit CS button",
				"User should be able to see Set Up combined Statement page successfully",
				"Failed to see Set Up combined Statement page" + common.getStrError());
	}

	@Then("^User clicks on contents and accounts panel chevron and validates accounts section$")
	public void iClickContentsandAccountsChevron_SetUpCSpage() {
		boolean blnResult = combinedStatementPage.clickContentsandAccountsChevron_CSSetUpCSpage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Set Up Combined Statement page", "User click on contents and accounts chevron and clicks on Account chevron",
				"User should be able to click on contents and accounts chevron and validate accounts section for each client successfully",
				"Failed to validate on contents and accounts section" + common.getStrError());
	}

/*	@Then("^a panel opens to show a list of account details for that client$")
	public void iSeeAccountDetailsPanel_CSSetUpPage() {
		boolean blnResult = combinedStatementPage.validateAccountDetailsPanel_CSSetUpCSpage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Set Up Combined Statement page", "User click on contents and accounts chevron",
				"User should be able to see a panel displaying account details successfully",
				"Failed to see a panel displaying account details" + common.getStrError());
	} */

	@Then("^user is able to see panel title as Accounts$")
	public void iSeeAccountsPanelTitle_CSSetUpPage() {
		boolean blnResult = newHouseholdPage.validateAccountsPanelTitle_CSSetUpCSpage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Set Up Combined Statement page", "User click on contents and accounts chevron",
				"User should be able to see panel title as accounts successfully",
				"Failed to see a panel title as accounts" + common.getStrError());
	}

	@When("^I see household summary name with repid$")
	public void seehouseholdsummarynamewithrepid() {
		boolean blnResult = newHouseholdPage.summarynamewithrepid();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Household dashboard page", "User navigates to household summary section",
				"User should be able to see household summary  name with repid successfully",
				"Failed to see household summary name with repid" + common.getStrError());
	}

	@Then("^I see Primary client contact information$")
	public void seePrimaryclientcontactinformation() {
		boolean blnResult = newHouseholdPage.primaryclientcontactinformation();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Household dashboard page", "User navigates to household summary section",
				"User should be able to see primary client contact information",
				"Failed to see primary client contact information" + common.getStrError());

	}

	@When("^I see household client section$")
	public void seehouseholdclientsection() {
		boolean blnResult = newHouseholdPage.householdclientsection();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Household dashboard page", "User navigates to household summary section",
				"User should be able to see household clients section",
				"Failed to see household clients section" + common.getStrError());
	}

	@Then("^I should see household primary client tile$")
	public void seehouseholdprimaryclienttile() {
		boolean blnResult = newHouseholdPage.primaryclienthouseholdsection();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Household dashboard page", "User navigates to household clients section",
				"User should be able to see primary client tile",
				"Failed to see primary client tile" + common.getStrError());

	}

	@When("^I expand billing rate chevron$")
	public void expandbillingrate() {
		boolean blnResult = newHouseholdPage.expandbillingratechevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Billing rate section",
				"User click on billing rate chevron", "User should be able to expand billing rate chevron successfully",
				"Failed to expand billing rate chevron" + common.getStrError());
	}

	@Then("^I collapse billing rate chevron$")
	public void collapsebillingrate() {
		boolean blnResult = newHouseholdPage.collapsebillingratechevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Billing rate section",
				"User click on expanded billing rate chevron",
				"User should be able to collapse billing rate chevron successfully",
				"Failed to collapse billing rate chevron" + common.getStrError());
	}

	@Then("^I should see confirmation Page$")
	public void iSeeConfirmationPage() {
		boolean blnResult = newHouseholdPage.validateConfirmationPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Billing rate section",
				"User click on expanded billing rate chevron",
				"User should be able to collapse billing rate chevron successfully",
				"Failed to collapse billing rate chevron" + common.getStrError());
	}

	@When("^I see Bank sweep message$")
	public void seebanksweepmessage() {
		boolean blnResult = newHouseholdPage.validateBankSweepMessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on confirmation page",
				"User navigates to bank sweep section", "User should be able to see bank sweep message",
				"Failed to see bank sweep message" + common.getStrError());
	}

	@When("^I click on edit HH pencil icon$")
	public void iClickEditHHPencilIcon() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickEditHHPencilIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on confirmation page",
				"User clicks on Edit HH pencil icon",
				"User should be able to click on Edit HH pencil icon successfully",
				"Failed to click on Edit HH pencil icon" + common.getStrError());
	}

	@When("^User select Add Client to an Existing Statement option$")
	public void iClickAddClientToAnExistingStatementOption() {
		boolean blnResult = combinedStatementPage.clickAddClientToAnExistingStatementOption();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on C/S Edit Modal",
				"User clicks on Add Client To An Existing Statement Option",
				"User should be able to Add Client To An Existing Statement Option successfully",
				"Failed to click on Add Client To An Existing Statement Option" + common.getStrError());
	}

	@When("^I navigate to Billing rate section and click on content chevron$")
	public void i_navigate_to_Billing_rate_section_and_click_on_content_chevron() {
		boolean blnResult = newHouseholdPage.clickBillingRateContentChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on HH dashboard, Billing Rate section",
				"User clicks on Chevron in billing rate section under a clinet",
				"User should be able to click on Chevron in billing rate section under a clinet successfully",
				"Failed to click on Chevron in billing rate section under a clinet" + common.getStrError());
	}

	@Then("^I click on client name chevron under Billing rate section$")
	public void i_click_on_client_name_chevron_under_Billing_rate_section() {
		boolean blnResult = newHouseholdPage.clickClientNameUnderBillingRateChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on HH dashboard, Billing Rate section",
				"User clicks on Client name chevron under Billing rate section",
				"User should be able to Client name chevron under Billing rate section successfully",
				"Failed to click on Client name chevron under Billing rate section" + common.getStrError());

	}

	@Then("^Verify column names under Billing rate section under a client name$")
	public void verify_column_names_under_Billing_rate_section_under_a_client_name() {
		boolean blnResult = newHouseholdPage.validateNextBillingDateColumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on HH dashboard, Billing Rate section", "User click on contents and client chevron",
				"User should be able to see NEXT BILLING DATE column successfully",
				"Failed to see NEXT BILLING DATE column" + common.getStrError());

		boolean blnResult1 = newHouseholdPage.validateUpcomingFeeColumn();
		LPLCoreReporter.writeStepToReporter(blnResult1, LPLCoreConstents.TRUE,
				"When User is on HH dashboard, Billing Rate section", "User click on contents and client chevron",
				"User should be able to see EST. UPCOMING FEE column successfully",
				"Failed to see EST. UPCOMING FEE column" + common.getStrError());

		boolean blnResult2 = newHouseholdPage.validatePaidFromColumn();
		LPLCoreReporter.writeStepToReporter(blnResult2, LPLCoreConstents.TRUE,
				"When User is on HH dashboard, Billing Rate section", "User click on contents and client chevron",
				"User should be able to PAID FROM column successfully",
				"Failed to see PAID FROM column" + common.getStrError());
		boolean blnResult3 = newHouseholdPage.validateAdvisoryFeesColumn();
		LPLCoreReporter.writeStepToReporter(blnResult3, LPLCoreConstents.TRUE,
				"When User is on HH dashboard, Billing Rate section", "User click on contents and client chevron",
				"User should be able to see ADVISORY FEES FROM THIS ACCOUNT YTD column successfully",
				"Failed to see ADVISORY FEES FROM THIS ACCOUNT YTD column" + common.getStrError());
	}

	@When("^I select a Combined Statement to add the new client to CS$")
	public void i_select_a_Combined_Statement_to_add_the_new_client_to_CS() {
		boolean blnResult = combinedStatementPage.selectCSFromOvelayPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay page for Combined statement", "User clicks on combined statement subgroup",
				"User should be able to clicks on combined statement subgroup successfully",
				"Failed to click on combined statement subgroup" + common.getStrError());
	}

	@Then("^I click on Cancel without adding client to household button$")
	public void i_click_on_Cancel_without_adding_client_to_household_button() {
		boolean blnResult = newHouseholdPage.clickOnCancelWithoutAddingClient();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay page for Combined statement",
				"User clicks on Cancel without adding client button",
				"User should be able to clicks on Cancel without adding client button successfully",
				"Failed to click on Cancel without adding client button" + common.getStrError());
	}

	@Then("^I verify text on Prompt displayed$")
	public void i_verify_text_on_Prompt_displayed() {
		boolean blnResult = combinedStatementPage.verifyTextOnPromptForCS();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay page for Combined statement",
				"User click on Cancel without adding client button",
				"User should be able to see Prompt and Text successfully",
				"Failed to see Prompt and Text" + common.getStrError());
	}

	@Then("^I Select No from prompt$")
	public void i_Select_No_from_prompt() {
		boolean blnResult = newHouseholdPage.clickOnNoInPromtToCancel();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay page for Combined statement",
				"User clicks on Cancel without adding client button",
				"User should be able to clicks on No button in Prompt successfully",
				"Failed to click on No button in Prompt" + common.getStrError());

	}

	@When("^User clicks on close button on CS Edit Modal page$")
	public void iClickEditModalCloseButton() {
		boolean blnResult = combinedStatementPage.clickEditModalCloseButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay page for Combined statement", "User clicks on close button",
				"User should be able to click on close button successfully",
				"Failed to click on close button" + common.getStrError());

	}

	@Then("^I Select Yes from prompt$")
	public void i_Select_Yes_from_prompt() {
		boolean blnResult = newHouseholdPage.clickOnYesInPromtToCancel();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay page for Combined statement",
				"User clicks on Cancel without adding client button",
				"User should be able to clicks on Yes button in Prompt successfully",
				"Failed to click on Yes button in Prompt" + common.getStrError());

	}

	@Then("^User is able to see prompt message$")
	public void iSeePromptMessage() {
		boolean blnResult = combinedStatementPage.validatePromptMessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Overlay page for Combined statement", "User clicks on close button",
				"User should be able to see prompt message successfully",
				"Failed to see prompt message" + common.getStrError());

	}

	@And("^I see household capabilities section$")
	public void seehouseholdcapabilitiessection() {
		boolean blnResult = newHouseholdPage.seehouseholdcapabilitiessection();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on dashboard page",
				"User scrolls down in the dasboard Page", "User should be able to see household capabilities section",
				"Failed to see household capabilities section" + common.getStrError());

	}

	@Then("^User clicks on Yes option on prompt message$")
	public void iClickYesOption_CSeditModal() {
		boolean blnResult = combinedStatementPage.clickYesOption();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on close button on CS Edit Modal Page",
				"User should be able to see No option in prompt message",
				"User should be able to click on No option in promt message successfully",
				"Failed to click on No option in promt message" + common.getStrError());

	}

	@When("^I click on Content chevron in Review household page$")
	public void i_click_on_Content_chevron_in_Review_household_page() {
		boolean blnResult = newHouseholdPage.clickOnContentsReviewHHPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Review Household Page",
				"User clicks on Contents chevron in Review household page",
				"User should be able to clicks on Contents chevron in Review household page successfully",
				"Failed to click on Contents chevron in Review household page" + common.getStrError());
	}

	@Then("^I ensure Show More button is available$")
	public void i_ensure_Show_More_button_is_available() {
		boolean blnResult = newHouseholdPage.verifyShowMoreButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Review Household Page",
				"User clicks on Contents chevron in Review household page",
				"User should be able to see Show More button successfully",
				"Failed to see Show More button/No more than 5 accounts available for clients" + common.getStrError());
	}

	@Then("^User clicks on No option on prompt message$")
	public void iClickNoOption_CSEditModal() {
		boolean blnResult = combinedStatementPage.clickNoOption();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on close button on CS Edit Modal Page",
				"User should be able to see No option in prompt message",
				"User should be able to click on No option in promt message successfully",
				"Failed to click on No option in promt message" + common.getStrError());
	}

	@When("^I click  on Create a New Combined Statement for Client button$")
	public void iclickonCreateaNewCombinedStatementforClientbutton() {
		boolean blnResult = newHouseholdPage.clickcreateanewcombinedstatement();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on CS Edit Modal Page",
				"User clicks on Create a New Combined Statement for Client button",
				"User should be able to click on Create a New Combined Statement for Client button successfully",
				"Failed to click on Create a New Combined Statement for Client button" + common.getStrError());
	}

	@When("^I see combined statement component to review the primary account information$")
	public void iseecombinedstatementcomponenttoreviewtheprimaryaccountinformation() {
		boolean blnResult = newHouseholdPage.seereviewprimayaccountinformation();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on CS Edit Modal Page",
				"User clicks on done editing button",
				"User should be able to see combined statement component to review the primary account information",
				"Failed to see combined statement component to review the primary account information"
						+ common.getStrError());

	}

	@Then("^I see Next button in enabled state$")
	public void seeNextbuttoninenabledstate() {
		boolean blnResult = newHouseholdPage.seeNextButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on CS Edit Modal Page",
				"User sees combined statement component to review the primary account information",
				"User should be able to see Next button in enabled state",
				"Failed to see Next button in enabled  state" + common.getStrError());

	}

	@When("^I click on category-level edit option in confirmation page$")
	public void i_click_on_category_leve_edit_option_in_confirmation_page() {
		boolean blnResult = combinedStatementPage.clickOnCategoryLevelEditOptionForCS();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on Streamline/Confirmation page",
				"User should be able to see Category-level edit option for Combined Statement subgroup",
				"User should be able to click on Category-level edit option for Combined Statement subgroup successfully",
				"Failed to click on Category-level edit option for Combined Statement subgroup" + common.getStrError());
	}

	@Then("^I see Edit Combined Statement Subgroup\\(s\\) Details$")
	public void i_see_Edit_Combined_Statement_Subgroup_s_Details() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.seeEditCombinedStatementPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Edit Combined Statement Subgroup(s) Details page",
				"User click on Category-level edit option for Combined Statement subgroup",
				"User should be able to see Edit Combined Statement Subgroup(s) Details page successfully",
				"Failed to see hEdit Combined Statement Subgroup(s) Details page" + common.getStrError());

	}

	@Then("^I see no account eligible message for each capability$")
	public void seenoaccounteligiblemessageforeachcapability() {
		boolean blnResult = newHouseholdPage.noAccountEligibleMessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User removes client from  household having accounts linked to capabilities",
				"User sees no account eligible message for each capability",
				"User should be able to see no account eligible message for each capability",
				"Failed to see no account eligible message for each capability" + common.getStrError());
	}

	@When("^I click on accounts chevron on Review Billing page$")
	public void iClickAccountsChevron_ReviewBillingPage() {
		boolean blnResult = newHouseholdPage.clickAccountsChevron_ReviewBillingPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Review Billing Page",
				"User clicks on accounts chevron in Review Billing page",
				"User should be able to click on accounts chevron successfully",
				"Failed to click on accounts chevron" + common.getStrError());
	}

	@Then("^I should see account panel on Review Billing Details page$")
	public void iSeeAccountDetails_ReviewBillingPage() {
		boolean blnResult = newHouseholdPage.validateAccountDetails_ReviewBillingPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Review Billing Page",
				"User clicks on accounts chevron in Review Billing page",
				"User should be able to see account details successfully",
				"Failed to see account details" + common.getStrError());
	}

	@And("^I see delete billing tracker in red$")
	public void seereddeletebillingtracker() {

		boolean blnResult = newHouseholdPage.seeredcolourdeletebillingtracker();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on proceed to delete button", "User sees red colour delete billing tracker",
				"User should be able to see red colour delete billing tracker",
				"Failed to see red colour delete billing tracker" + common.getStrError());

	}

	@Then("^I click on show more button$")
	public void iClickShowMoreButton_ReviewBilling() {
		boolean blnResult = newHouseholdPage.clickShowMoreButton_ReviewBillingPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Review Billing Page",
				"User clicks on accounts chevron in Review household page",
				"User should be able to click on Show More button successfully",
				"Failed to click on Show More button on Review Billing page" + common.getStrError());
	}

	@When("^I click contents chevron on Edit HH page$")
	public void iClickContentsChevron_EditHHPage() {
		boolean blnResult = newHouseholdPage.clickContentsChevron_EditHHPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Edit household Page",
				"User clicks on contents chevron in Edit household page",
				"User should be able to click on contents chevron successfully",
				"Failed to click on contents chevron on Edit HH page" + common.getStrError());

	}

	@And("^I click on Accounts chevron on Edit HH page$")
	public void iClickAccountsChevron_EditHHPage() {
		boolean blnResult = newHouseholdPage.clickAccountsChevron_EditHHPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Edit household Page",
				"User clicks on accounts chevron in Edit household page",
				"User should be able to click on accounts chevron successfully",
				"Failed to click on accounts chevron on Edit HH page" + common.getStrError());
	}

	@Then("^I should see account details on Edit HH page$")
	public void iSeeAccountDetails_EditHHPage() {
		boolean blnResult = newHouseholdPage.validateAccountsDetails_EditHHPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Edit household Page",
				"User clicks on accounts chevron in Edit household page",
				"User should be able to see account details successfully",
				"Failed to see account details on Edit HH page" + common.getStrError());
	}

	@Then("^Verify Total number of accounts in the Household in CONTENTS panel$")
	public void verify_Total_number_of_accounts_in_the_Household_in_CONTENTS_panel() {
		boolean blnResult = newHouseholdPage.validateNoOfAcctsInNewHouseholdCSPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in New Household Combined Statement Details page",
				"User sees Contents panel in New Household Combined Statement Details page",
				"User should be able to see number of Accounts in Contents panel matching with the number of Accounts in household successfully",
				"Failed to see number of Accounts in Contents panel matching with the number of Accounts in household"
						+ common.getStrError());
	}

	@Then("^Verify Total number of clients in the Household in CONTENTS panel$")
	public void verify_Total_number_of_clients_in_the_Household_in_CONTENTS_panel() {
		boolean blnResult = newHouseholdPage.validateNoOfClientsInNewHouseholdCSPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in New Household Combined Statement Details page",
				"User sees Contents panel in New Household Combined Statement Details page",
				"User should be able to see number of clients in Contents panel matching with the number of clients in household successfully",
				"Failed to see number of clients in Contents panel matching with the number of clients in household"
						+ common.getStrError());
	}

	@Then("^Verify Total account value for the Household in CONTENTS panel$")
	public void verify_Total_account_value_for_the_Household_in_CONTENTS_panel() {
		boolean blnResult = newHouseholdPage.totalAccountValueInNewHouseholdCSPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in New Household Combined Statement Details page",
				"User sees Contents panel in New Household Combined Statement Details page",
				"User should be able to see total value in Contents panel is Matching to the sum of the value of each client account successfully",
				"Failed to see total value in Contents panel is Matching to the sum of the value of each client account"
						+ common.getStrError());
	}

	@And("^I see Billing summary in confirmation Page$")
	public void seebillingsummary() {
		boolean blnResult = newHouseholdPage.seebillingsummary();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on  confirmation page",
				"User navigates to confirmation page from edit billing page",
				"User should be able to see billing summary", "Failed to see billing summary" + common.getStrError());
	}

	@Then("^Verify the Group Name Pencil Icon Is not Visible$")
	public void verifyTheGroupNamePencilIconIsNotVisible() {
		boolean blnResult = newHouseholdPage.validateElementNotVisisble();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User validate edit button icon",
				"User edit button icon not visible", "User should be able to edit button icon not visible",
				"Failed to edit button icon not visible" + common.getStrError());
	}

	@When("^I see Add Client to an Existing Statement button in selected state$")
	public void seeAddClienttoanExistingStatementbutton() {
		boolean blnResult = combinedStatementPage.seeAddClientToAnExistingStatementButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on edit household Page",
				"User selects a client from search results",
				"User should be able to see Add Client to an Existing Statement button in selected state",
				"Failed to see Add Client to an Existing Statement button in selected state" + common.getStrError());

	}

	@When("^I expand contents chevron in CS edit modal$")
	public void expandcontentschevroninCSeditmodal() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.clickContentsChevronCSEditModal();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User selects a client from search results",
				"User sees Add Client to an Existing Statement button in selected state",
				"User should be able to click on contents chevron in CS edit modal successfully",
				"Failed to click on contents chevron in CS edit modal" + common.getStrError());
	}

	@Then("^I click  on close modal button$")
	public void clickonclosemodalbutton() {
		boolean blnResult = combinedStatementPage.clickedCSCloseModalButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When sees Add Client to an Existing Statement button in selected state",
				"User expands contents chevron", "User should be able to click on close modal button successfully",
				"Failed to click on close modal button" + common.getStrError());
	}

	@When("^I click on yes button from close modal popup$")
	public void clickyesbuttonfromclosemodalpopup() {
		boolean blnResult = combinedStatementPage.clickYesButtonCSCloseModal();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When sees Add Client to an Existing Statement button in selected state",
				"User clicks on close modal button",
				"User should be able to click on yes button present in close modal popup sucessfully",
				"Failed to click on yes button present in close modal popup" + common.getStrError());

	}

	@And("^Verify that the primary client will be listed first in the account details list sectioned by Client Name$")
	public void verifyPrimaryClient() {
		boolean blnResult = newHouseholdPage.verifyPrimaryClientListedFirst();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that the primary client will be listed first in the account details list sectioned by Client Name",
				"Verify that the primary client will be listed first in the account details list sectioned by Client Name",
				"User should Verify that the primary client will be listed first in the account details list sectioned by Client Name",
				"Failed to Verify that the primary client will be listed first in the account details list sectioned by Client Name"
						+ common.getStrError());
	}

	@When("^I see  combined statement header with sub group combined  statements$")
	public void seecombinedstatementheaderwithsubgroupcombinedstatement() {
		boolean blnResult = combinedStatementPage.seeSubGroupCombinedStatementsWithHeader();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on edit combined statement modal",
				"User clicks on Create a New Combined Statement for Client button",
				"User should be able to see combined statement header with sub group combined statements sucessfully  ",
				"Failed to see combined statement header with sub group combined statements" + common.getStrError());

	}

	@Then("^I should see status  as progress$")
	public void seeinprogressstatus() {
		boolean blnResult = newHouseholdPage.seesubgroupcombinedstatementsinprogressstatus();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on edit combined statement modal",
				"User clicks on Create a New Combined Statement for Client button",
				"User should be able to see sub group combined statement INPROGRESS status sucessfully",
				"Failed to see sub group combined statement INPROGRESS status" + common.getStrError());
	}

	@When("^I click on Combined Statement Submit Changes button$")
	public void i_click_on_Combined_Statement_Submit_Changes_button() {
		boolean blnResult = newHouseholdPage.clickCSSubmitChanges();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user is in Review Combined Statement Subgroup(s) Details page",
				"User clicks on SUBMIT CHANGES button",
				"User should be able to click on SUBMIT CHANGES button sucessfully",
				"Failed to click on SUBMIT CHANGES button" + common.getStrError());
	}

	@Then("^I see  X combined statement header with sub group combined  statements$")
	public void seeXcombinedstatementheaderwithsubgroupcombinedstatements() {
		boolean blnResult = combinedStatementPage.seeSubGroupCombinedStatementsWithHeader();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on edit combined statement modal",
				"User clicks on Create a New Combined Statement for Client button",
				"User should be able to see combined statement header with sub group combined statements sucessfully  ",
				"Failed to see combined statement header with sub group combined statements" + common.getStrError());

	}

	@And("^I should see fee rate value$")
	public void seefeeratevalue() {
		boolean blnResult = newHouseholdPage.seefeeratevalue();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on household group dashboard page", "User navigates to billing rate tile",
				"User should be able to see billing fee rate value sucessfully  ",
				"Failed to see billing fee rate value" + common.getStrError());

	}

	@And("^I should see total asset value$")
	public void seetotalassetvalue() {
		boolean blnResult = newHouseholdPage.seetotalassetvalue();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on household group dashboard page", "User navigates to billing rate tile",
				"User should be able to see Total Asset value sucessfully  ",
				"Failed to see Total Asset value" + common.getStrError());
	}

	@And("^I should see billable value$")
	public void seebillablevalue() {
		boolean blnResult = newHouseholdPage.seebillablevalue();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on household group dashboard page", "User navigates to billing rate tile",
				"User should be able to see Billable value sucessfully  ",
				"Failed to see Billable value" + common.getStrError());
	}

	@And("^I should see EST Annual fees along with YTD fees$")
	public void seeESTAnnualfees() {
		boolean blnResult = newHouseholdPage.seebillablevalue();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on household group dashboard page", "User navigates to billing rate tile",
				"User should be able to see EST Annual fees along with YTD fees sucessfully  ",
				"Failed to see EST Annual fees along with YTD fees value" + common.getStrError());
	}

	@When("^I enter the last name in the search text box$")
	public void ienterthelastnameinthesearchtextbox() {
		common.waitForPageLoading();
		String lastName = testData.get("lastName");
		boolean blnResult = newHouseholdPage.enterLastName(lastName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the Last name[" + lastName + "]",
				"Last name should be entered", "Last name[" + lastName + "] is entered",
				"Failed To enter the Last name." + common.getStrError());
	}

	@Then("^I should able to see Billing setup updated in Confirmation page$")
	public void i_should_able_to_see_Billing_setup_updated_in_Confirmation_page() {
		boolean blnResult = newHouseholdPage.seeBillingSetupUpdatedMsgInConfPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Streamline/Confirmation page", "User updated the billing capability",
				"User should be able to see " + testData.get("Groupname")
						+ " BILLING successfully updated! message sucessfully  ",
				"Failed to see BILLING updated successful message" + common.getStrError());

	}

	@Then("^Veify Household billing name displayed correctly$")
	public void veify_Household_billing_name_displayed_correctly() {
		boolean blnResult = newHouseholdPage.verifyHouseholdBillingName();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Streamline/Confirmation page", "User see Billing capability name",
				"User should be able to see " + testData.get("Groupname") + " BILLING sucessfully",
				"Failed to see Household billing name" + common.getStrError());

	}

	@Then("^Ensure that ! ACTIVATION REQUIRES FORMS text is visible$")
	public void ensure_that_ACTIVATION_REQUIRES_FORMS_text_is_visible() {
		boolean blnResult = newHouseholdPage.verifyBillingAlertMessage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Streamline/Confirmation page", "User see text to alert user",
				"User should be able to see !ACTIVATION REQUIRES FORMS alert message sucessfully",
				"Failed to see !ACTIVATION REQUIRES FORMS alert message" + common.getStrError());

	}

	@Then("^Verify column name for Flat rate billing$")
	public void verify_column_name_for_Flat_rate_billing() {
		boolean blnResult = newHouseholdPage.verifyColumnNameInBillingSection();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Streamline/Confirmation page", "User see Columns under Billing summary section",
				"User should be able to see all the column names under billing section correctly",
				"Failed to see column names under billing section correctly" + common.getStrError());

	}

	@Then("^I should see list of Account details$")
	public void AccountDetailsDisplayed() {
		boolean blnResult = newHouseholdPage.isAccountDetailsDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded contents panel on combined statement tile",
				"User should able to click on expand accounts chevron",
				"User is able to click on expand accounts chevron successfully",
				"Failed to click on expand accounts chevron" + common.getStrError());
	}

	@When("^I click on Contents chevron on Billing details page$")
	public void iclickContentChevron() {
		boolean blnResult = newHouseholdPage.clickContentPanelChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded contents panel on Billing summary section",
				"User should able to click on expand Content chevron",
				"User is able to click on expand Content chevron successfully",
				"Failed to click on expand accounts chevron" + common.getStrError());
	}

	@Then("^Verify Column header names under Account Panel of Billing details page$")
	public void HeaderNamesDisplayed() {
		boolean blnResult = newHouseholdPage.isAccountDetailsDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Column names on Billing summary section", "User should able to see column headers",
				"User is able to see Column names under accounts chevron successfully",
				"Failed to see Column names under  accounts chevron" + common.getStrError());
	}

	@When("^I click on Accounts Panel on Billing details page$")
	public void iclickAccountChevron() {
		boolean blnResult = newHouseholdPage.clickAccountChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded account panel on Billing summary section",
				"User should able to click on expand accounts chevron",
				"User is able to click on expand accounts chevron successfully",
				"Failed to click on expand accounts chevron" + common.getStrError());
	}

	@Then("^I expand contents panel of edit household combined  statement section$")
	public void expandedithhcombinedstatementcontentspanel() {
		boolean blnResult = newHouseholdPage.clickcontentchevronCSeditHHpage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User navigates to combined statement section of edit household page",
				"User should able to click on contents chevron of combined statement section",
				"User is able to click on contents chevron of combined statement section successfully",
				"Failed to click on contents chevron of combined statement section" + common.getStrError());
	}

	@And("^I should not see removed client name in content information$")
	public void notseeremovedclientnameincontentinformation() {
		boolean blnResult = newHouseholdPage.removedclientnotDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When user removes clients in edit household page",
				"User should not see removed client in the contents information of the combined statement section",
				"User is not able to see removed client in the contents information of the combined statement section successfully",
				"Able to see removed client in the contents information of the combined statement section"
						+ common.getStrError());

	}

	@Then("^I select desired  subgroup  combined  statement tile$")
	public void selectdesiredsubgroupcombinedstatementtile() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.clicksubgroupcombinedstatementtile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User select Add Client to an Existing Statement",
				"User should able to click on desired subgroup combined statement tile",
				"User is able to click on desired subgroup combined statement tile successfully",
				"Failed to click on desired subgroup combined statement tile" + common.getStrError());

	}

	@When("^I click on enabled next button$")
	public void clickonenablednextbutton() {
		boolean blnResult = newHouseholdPage.clickenablednextbutton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User selects desired subgroup combined statement tile",
				"User should able to click on enabled next button",
				"User is able to click on enabled next button successfully",
				"Failed to click on enabled next button" + common.getStrError());
	}

	@And("^I should see added client in the content information$")
	public void seeaddedclientincontentinformation() {
		boolean blnResult = newHouseholdPage.isCScontentclientinformationDisplayed();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on next button in edit CS modal",
				"User should able to see added client name in the  content information",
				"User is able to see added client name in the content information successfully",
				"Failed to see added client name in the content information" + common.getStrError());
	}

	@When("^Verify title banner present in CombinedStatementDetailsPage$")
	public void iverifyTitleBanner() {
		boolean blnResult = newHouseholdPage.verifyTitleBanner();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded contents panel on Billing summary section",
				"User should able to click on expand Content chevron",
				"User is able to click on expand Content chevron successfully",
				"Failed to click on expand accounts chevron" + common.getStrError());
	}

	@When("^I click on contents panel chevron on Review Changes page$")
	public void clickOnReviewChangesContentsPanel() {
		boolean blnResult = newHouseholdPage.clickReviewChangesContentsPanel();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on contents panel on Review changes page",
				"User should able to click successfully on contents panel",
				"User is able to click on contents panel expand/collapse chevron successfully",
				"Failed to click on contents panel expand/collapse chevron" + common.getStrError());
	}

	@When("^Verify client banner present in Review DetailsPage$")
	public void iverifyClientBanner() {
		boolean blnResult = newHouseholdPage.verifyClientBannerDisplay();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded contents panel on Review section", "User should able to see client banner",
				"User is able to see client banner successfully", "Failed to see client banner" + common.getStrError());
	}

	@And("^I click on Accounts chevron under client$")
	public void clickonAccountChevron() {
		boolean blnResult = newHouseholdPage.clickonAccountChevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"I click on Accounts chevron under client", "I click on Accounts chevron under client",
				"User is able to click on Accounts chevron under client successfully",
				"Failed to click on Accounts chevron under client" + common.getStrError());
	}

	@And("^Verify that by default only five accounts should displayed$")
	public void verifyAccounts() {
		boolean blnResult = newHouseholdPage.strClickAccountxpath();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that by default only five accounts should displayed",
				"Verify that by default only five accounts should displayed",
				"User is able to Verify by default only five accounts is displayed",
				"Failed to Verify that by default only five accounts is displayed" + common.getStrError());
	}

	@When("^I click on Show Full Details Link$")
	public void verifySummaryColumn() {
		boolean blnResult = newHouseholdPage.clickonShowFullDetails();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "I click on Show Full Details",
				"I click on Show Full Details", "User is able to click on Show Full Detailssuccessfully",
				"Failed to click on Show Full Details" + common.getStrError());
	}

	@Then("^Verify values under summary cloumn on Household Dashboard Page$")
	public void clickonShowFullDetails() {
		boolean blnResult = newHouseholdPage.verifySummaryColumn();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "I click on Show Full Details",
				"I click on Show Full Details", "User is able to click on Show Full Detailssuccessfully",
				"Failed to click on Show Full Details" + common.getStrError());
	}

	@When("^I click on clients and account details chevron$")
	public void clickonclientsandaccountdetailschevron() {
		boolean blnResult = newHouseholdPage.clickonclientsandaccountdetailschevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "I navigate to edit details page",
				"I click on clients and account details chevron",
				"User is able to click on clients and account details chevron successfully",
				"Failed to click on clients and account details chevron" + common.getStrError());
	}

	@Then("^I see  client tile with information$")
	public void seeclienttilewithinformation() {
		boolean blnResult = newHouseholdPage.verifyclienttileinformation();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded clients and account details chevron",
				"User should able to see client tile with information",
				"User is able to see client tile with information successfully",
				"Failed to see client tile with information" + common.getStrError());

	}

	@When("^I click on clients accounts chevron$")
	public void clickonclientsaccountschevron() {
		boolean blnResult = newHouseholdPage.clickonclientsaccountschevron();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded clients and account details chevron", "I click on clients account chevron",
				"User is able to click on clients account chevron successfully",
				"Failed to click on clients account chevron" + common.getStrError());
	}

	@Then("^I see client account tiles with information$")
	public void seeclientaccounttileswithinformation() {
		boolean blnResult = newHouseholdPage.verifyclientaccountsinformation();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded clients and account details chevron",
				"User should able to see account related to clients information",
				"User is able to see account related to clients information successfully",
				"Failed to see account related to clients information" + common.getStrError());
	}

	@Then("^Verify accounts are in descending order$")
	public void verify_accounts_are_in_descending_order() {
		boolean blnResult = newHouseholdPage.checkAccountsInDescendingOrder();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded clients and account details chevron in Edit HH page",
				"User should able to see account related to clients information",
				"User is able to see accounts are arranged in descending order",
				"Failed to see accounts arranged in descending order" + common.getStrError());
	}

	@Then("^I should be able to see the below fields for (Household|Billing) section$")
	public void iShouldSeeMentionedFields(String strValue, DataTable data) {
		boolean blnResult = newHouseholdPage.isTableDetailsDisplayed(data, strValue);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "User should be able to see all fields",
				"User should be able to view all fields", "User views all fields",
				"Failed to see all fields" + common.getStrError());
	}

	@Then("^I expand Billing Rate under Household Capabilities$")
	public void iExpandBillingRateUnderHouseholdCapailities() {
		boolean blnResult = newHouseholdPage.expandBillingRateMenu();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "User should be able to see all fields",
				"User should be able to view all fields", "User views all fields",
				"Failed to see all fields" + common.getStrError());
	}

	@Then("^I click on a Show Full Details under Balance and Investment section$")
	public void iClickOnShowFullDetailsButton() {
		boolean blnResult = newHouseholdPage.clickOnShowFullDetailsButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "User should be able to see all fields",
				"User should be able to view all fields", "User views all fields",
				"Failed to see all fields" + common.getStrError());
	}

	@And("^I should be able to see Market Value of Securities$")
	public void iShouldSeeMarketValue() {
		boolean blnResult = newHouseholdPage.isMarketValuesOfSecuritiesDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "User should be able to see all fields",
				"User should be able to view all fields", "User views all fields",
				"Failed to see all fields" + common.getStrError());
	}

	@And("^I see client Account name$")
	public void seeaccountname() {
		boolean blnResult = newHouseholdPage.verifyclientaccountname();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded account chevron under client name in review details page",
				"User should able to see Account Name", "User is able to see successfully Account Name",
				"Failed to see Account Name" + common.getStrError());
	}

	@And("^I see Program name$")
	public void seeprogramname() {
		boolean blnResult = newHouseholdPage.verifyprogramname();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded account chevron under client name in review details page",
				"User should able to see Program Name", "User is able to see successfully Program Name",
				"Failed to see Program Name" + common.getStrError());
	}

	@And("^I see client Account Number$")
	public void seeaccountnumber() {
		boolean blnResult = newHouseholdPage.verifyclientaccountnumber();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded account chevron under client name in review details page",
				"User should able to see Account Number", "User is able to see successfully Account Number",
				"Failed to see Account Number" + common.getStrError());
	}

	@And("^I see Total account value in dollar$")
	public void seetotalaccountvalue() {
		boolean blnResult = newHouseholdPage.verifytotalaccountvalue();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expanded clients and account details chevron",
				"User should able to see Total Account Value in dollars",
				"User is able to see Total Account Value in dollars successfully",
				"Failed to see Total Account Value in dollars" + common.getStrError());
	}

	@Then("^I click on Edit Household name pencil icon$")
	public void i_click_on_Edit_Household_name_pencil_icon() {
		boolean blnResult = newHouseholdPage.clickonEditHHGroupNamePencilIcon();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit button from Household dashboard page",
				"User is able to see Edit household page",
				"User is able to click on Edit Group name pencil Icon successfully",
				"Failed to click on Edit Group name pencil Icon" + common.getStrError());
	}

	@When("^I enter Household name exceeding forty characters$")
	public void i_enter_Household_name_exceeding_characters() {
		boolean blnResult = newHouseholdPage.enterHouseholdNameExceeding40Char();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit household name pencil icon",
				"User is able to see Editable field to change household name",
				"User is able to enter household name exceeding 40 characters successfully",
				"Failed to enter household name exceeding 40 characters" + common.getStrError());

	}

	@Then("^I should see error message displayed$")
	public void i_should_see_error_message_displayed() {
		boolean blnResult = newHouseholdPage.verifyErrorMsgForHHGroupNameExceeding40Char();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User Enter household group name exceeding 40 characters",
				"User is able to enter household name exceeding 40 characters",
				"User is able to see error maessage \"You have reached the max number of characters.\" successfully",
				"Failed to see error maessage" + common.getStrError());
	}

	@Then("^I Ensure that Market values of securities displayed in dollars$")
	public void i_Ensure_that_Market_values_of_securities_displayed_in_dollars() {
		boolean blnResult = newHouseholdPage.verifyMarketValueForSecuritiesInDollars();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in Household dashboard",
				"User is able to click on Show Full details",
				"User is able to see Market value for securities displayed in dollars successfully",
				"Failed to see Market value for securities displayed in dollars" + common.getStrError());
	}

	@Then("^I should see following fields in combined statement tile$")
	public void iSeeCSsummaryBannerFields_Dashboard(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = newHouseholdPage
					.displayCSSummaryBannerFields_dashboard(data.get("SummaryBannerFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("SummaryBannerFields") + " available",
					"User should able to see the  " + data.get("SummaryBannerFields") + "fields",
					" listed field values is " + data.get("SummaryBannerFields") + " visible",
					"Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");

		}
	}

	@Then("^I should see Combined Statement tile on Dashboard$")
	public void Dashboard_CombinedStatamentSubgroupTile() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.verifyDashboardCombinedStatamentSubgroupTile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Household Dashboard",
				"User is able to see Combined Statement Subgroup Tile on Dasboard",
				"User is able to see Combined Statement Subgroup Tile on Dasboard successfully",
				"Failed to see Combined Statement Subgroup Tile on Dasboard" + common.getStrError());
	}

	@Then("^I see Active label on combined statement tile$")
	public void Dashboard_CombinedStatamentSubgroupTile_ActiveLabel() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.verifyDashboardCombinedStatamentSubgroupTileActiveLabel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Household Dashboard",
				"User is able to see Combined Statement Subgroup Tile on Dasboard",
				"User is able to see Active Label on Combined Statement Subgroup Tile on Dasboard successfully",
				"Failed to see Active Label on Combined Statement Subgroup Tile on Dasboard" + common.getStrError());
	}

	@Then("^I see Hyperlink labeled Jump to Details$")
	public void Dashboard_CombinedStatamentSubgroupTile_JumpToDetails() {
		boolean blnResult = newHouseholdPage.verifyDashboardCombinedStatamentSubgroupTile_JumpToDetails();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on Household Dashboard",
				"User is able to see Combined Statement Subgroup Tile on Dasboard",
				"User is able to see Jump To Details link on Combined Statement Subgroup Tile on Dasboard successfully",
				"Failed to see Jump To Details link on Combined Statement Subgroup Tile on Dasboard"
						+ common.getStrError());
	}

	@Then("^I click on Combined Statement edit icon on Streamline page$")
	public void iClickCSEditIcon_StreamlinePage() {
		boolean blnResult = combinedStatementPage.clickCSEditIcon_StreamlinePage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Streamline Confirmation page", "User is able to see Edit Combined Statement icon",
				"User is able to click on edit Combined Statement icon successfully",
				"Failed to click on edit Combined Statement icon" + common.getStrError());
	}

	@Then("^I see Delete Capability option in the upper right navigation$")
	public void iSeeDeleteCapabilityOption() {
		boolean blnResult = combinedStatementPage.validateDeleteCapability();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User is able to see Delete capability option",
				"User is able to see delete capability option successfully",
				"Failed to see delete capability option" + common.getStrError());
	}

	@Then("^I select Delete Capability option$")
	public void iClickDeleteCapabilityOption() {
		boolean blnResult = combinedStatementPage.clickDeleteCapability();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on Delete capability option",
				"User is able to click on delete capability option successfully",
				"Failed to click on delete capability option" + common.getStrError());
	}

	@Then("^a popup message is displayed$")
	public void iSeePopUpMessage_DeleteCScapability() {
		boolean blnResult = combinedStatementPage.validatePopUpMessage_DeleteCScapability();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on Delete capability option",
				"User is able to see a pop-up message successfully",
				"Failed to see pop-up message" + common.getStrError());
	}

	@Then("^I see popup title$")
	public void iSeePopTitle_DeleteCScapability() {
		boolean blnResult = combinedStatementPage.validatePopUpTitle_DeleteCScapability();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on Delete capability option",
				"User is able to see a pop-up title successfully", "Failed to see pop-up title" + common.getStrError());
	}

	@Then("^I see popup subheader$")
	public void iSeePopSubHeader_DeleteCScapability() {
		boolean blnResult = combinedStatementPage.validatePopUpSubHeader_DeleteCScapability();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on Delete capability option",
				"User is able to see a pop-up sub header successfully",
				"Failed to see pop-up sub header" + common.getStrError());
	}

	@Then("^I see two side by side buttons$")
	public void iSeeTwoButtons_DeleteCScapability() {
		boolean blnResult = combinedStatementPage.validatePopUpButtons_DeleteCScapability();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on Delete capability option",
				"User is able to see two side by side buttons successfully",
				"Failed to see two side by side buttons" + common.getStrError());
	}

	@When("^I see 5 default accounts with show more button$")
	public void seeshowmorebuttonwithdefaultaccounts() {
		boolean blnResult = newHouseholdPage.verifydefaultaccountswithshowmorebutton();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expands account chevron in combined statement section",
				"User should able to see five defualt accounts with show more button",
				"User is able to see five defualt accounts with show more button successfully",
				"Failed to see five defualt accounts with show more button" + common.getStrError());
	}

	@Then("^I click on show more button in combined statement section$")
	public void clickshowmorebuttonincombinedstatementsection() {
		boolean blnResult = newHouseholdPage.clickonCSshowmorebutton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User see accounts with show more button in combined statement section",
				"I click on show more button in combined statement section",
				"User is able to click on show more button in combined statement section successfully",
				"Failed to click on show more button in combined statement section" + common.getStrError());
	}

	@And("^I see the remaining accounts with no show more button in combined statement section$")
	public void notseeshowmorebuttonwithremainingaccounts() {
		boolean blnResult = newHouseholdPage.verifyremainingaccountswithnoshowmorebutton();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User expands account chevron in combined statement section",
				"User should not able to see show more button with remaining accounts",
				"User is not able to see show more button with remaining accounts successfully",
				"Failed on seeing show more button with remaining accounts" + common.getStrError());
	}

	@Then("^Verify household name in the summary panel$")
	public void verify_household_name_in_the_summary_panel() {
		boolean blnResult = newHouseholdPage.verifyHouseholsNameSummaryPanel();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household confirmation page", "User should be able to see summary panel",
				"User is able to see Household name in the summary panel successfully",
				"Failed to see Household name in the summary panel" + common.getStrError());
	}

	@Then("^verify Rep ID details$")
	public void verify_Rep_ID_details() {
		boolean blnResult = newHouseholdPage.verifyRepIDSummaryPanel();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household confirmation page", "User should be able to see summary panel",
				"User is able to see Rep ID information in the summary panel successfully",
				"Failed to see RepID information in the summary panel" + common.getStrError());
	}

	@Then("^verify Active indicator$")
	public void verify_Active_indicator() {
		boolean blnResult = newHouseholdPage.verifyRepIDSummaryPanel();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household confirmation page", "User should be able to see summary panel",
				"User is able to see Active status in green colour in the summary panel successfully",
				"Failed to see Active status in green colour in the summary panel" + common.getStrError());
	}

	@Then("^verify CONTENTS label$")
	public void verify_CONTENTS_label() {
		boolean blnResult = newHouseholdPage.verifyActiveStatusLabelSummaryPanel();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household confirmation page", "User should be able to see summary panel",
				"User is able to see CONTENTS label in the summary panel successfully",
				"Failed to see CONTENTS label in the summary panel" + common.getStrError());

	}

	@Then("^Verify Household Combined Statement Optional text in confirmation page$")
	public void verify_Household_Combined_Statement_Optional_text_in_confirmation_page() {
		common.waitForPageLoading(200);
		boolean blnResult = newHouseholdPage.verifyCSOptionalText();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household confirmation page", "User should be able to see Recommended section",
				"User is able to see Combined Statement optional displayed successfully",
				"Failed to see Combined statement optional in the summary panel" + common.getStrError());
	}

	@Then("^Verify Combined Statement link in confirmation page$")
	public void verify_Combined_Statement_link_in_confirmation_page() {
		boolean blnResult = newHouseholdPage.verifyCSLinkInConfPage();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household confirmation page", "User should be able to see Recommended section",
				"User is able to see Combined Statement button displayed successfully",
				"Failed to see Combined statement button in the confirmation page" + common.getStrError());
	}



	@And("^I click on PREPARE FORM FOR SIGNATURE button$")
	public void IClickOnButton() {
		common.waitForPageLoading();
		boolean blnResult = billingPage.clickOnButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Check if the user is able to click on PREPARE FORM FOR SIGNATURE button",
				"User should able to click on PREPARE FORM FOR SIGNATURE button",
				"User is able to click on PREPARE FORM FOR SIGNATURE button",
				"Failed to click on PREPARE FORM FOR SIGNATURE button. Error message: " + common.getStrError());
	}

	@Then("^I should see DocGrid page$")
	public void IShouldSeeDocGridPage() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.CheckElementDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Check if the user is able to see DocGrid page", "User should able to see DocGrid page",
				"User is able to see DocGrid page",
				"Failed to see DocGrid page. Error message: " + common.getStrError());
	}

	@When("^I see sub group combined  statement  section$")
	public void seesubgroupstatementsection() {
		boolean blnResult = newHouseholdPage.validatesubgroupcombinedstatementsection();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household capabilities section of the dashboard page",
				"User should be able to see subgroup combined statement section",
				"User is able to see subgroup combined statement section successfully",
				"Failed to see subgroup combined statement section" + common.getStrError());
	}

	@Then("^I see  sub group combined  statement  tiles in dashboard  Page$")
	public void seesubgroupcombinedstatementtilesindashboardPage() {

		boolean blnResult = newHouseholdPage.validatesubgroupcombinedstatementstiles();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in subgroup combined statement section of the dashboard page",
				"User should be able to see subgroup combined statement tiles",
				"User is able to see subgroup combined statement tiles successfully",
				"Failed to see subgroup combined statement tiles" + common.getStrError());
	}

	@When("^I see combined statement green banner with text$")
	public void seecombinedstatementgreenbannerwithtext() {
		boolean blnResult = newHouseholdPage.validatecombinedstatementgreenbannerwithtext();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in confirmation page",
				"User should be able to see combined statement green banner with text",
				"User is able to see combined statement green banner with text successfully",
				"Failed to see combined statement green banner with text" + common.getStrError());
	}

	@Then("^I see cross icon to close the combined statement green banner$")
	public void seecrossicontoclosecombinedstatementgreenbanner() {
		boolean blnResult = newHouseholdPage.validatecrossbuttoncombinedstatementbanner();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in confirmation page",
				"User should be able to see cross icon with combined statement banner",
				"User is able to see cross icon with combined statement banner successfully",
				"Failed to see cross icon with combined statement banner" + common.getStrError());
	}
	
	@When("^I click on Contents Chevron for billing section in Confirmation page$")
	public void i_click_on_Contents_Chevron_for_billing_section_in_Confirmation_page() throws Throwable {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickContentChevronBillingSecCongPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Check if the user is able to click on Contents chevron in Billing section from Confirmation page",
				"User should able to click on Contents chevron in Billing section from Confirmation page",
				"User is able to click on Contents chevron in Billing section from Confirmation page successfully",
				"Failed to click on Contents chevron in Billing section from Confirmation page" + common.getStrError());
	    
	}

	@Then("^I See the Content panel expanded for billing section in Confirmation page$")
	public void i_See_the_Content_panel_expanded_for_billing_section_in_Confirmation_page() {
		common.waitForPageLoading(200);
		boolean blnResult = newHouseholdPage.verifyContentsPanelExpandedForBillingSecInConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in confirmation page",
				"User should be able to see Content panel expanded for billing section in Confirmation page",
				"User is able to see Content panel expanded for billing section in Confirmation page successfully",
				"Failed to see Content panel expanded for billing section in Confirmation page" + common.getStrError());
	}

	@Then("^I see Accounts Chevron not expanded for billing section in Confirmation page$")
	public void i_see_Accounts_Chevron_not_expanded_for_billing_section_in_Confirmation_page() {
		common.waitForPageLoading(200);
		boolean blnResult = newHouseholdPage.verifyAccountsPanelNotExpandedBillingSectionConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in confirmation page",
				"User should be able to see Accounts panel not expanded for billing section in Confirmation page",
				"User is able to see Accounts panel not expanded for billing section in Confirmation page",
				"Failed to see Accounts panel not expanded for billing section in Confirmation page" + common.getStrError());
	}

	@When("^I click on Accounts Chevron for billing section in Confirmation page$")
	public void i_click_on_Accounts_Chevron_for_billing_section_in_Confirmation_page() {
		common.waitForPageLoading(200);
		boolean blnResult = newHouseholdPage.clickAccChevronBillingSecConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in confirmation page",
				"User should be able to click on Accounts chevron in billing section in Confirmation page",
				"User is able to click on Accounts chevron in billing section in Confirmation page",
				"Failed to click on Accounts chevron in billing section in Confirmation page" + common.getStrError());
	}

	@Then("^I see Accounts Chevron expanded for billing section in Confirmation page$")
	public void i_see_Accounts_Chevron_expanded_for_billing_section_in_Confirmation_page() throws Throwable {
		common.waitForPageLoading(200);
		boolean blnResult = newHouseholdPage.verifyAccountsPanelExpandedBillingSectionConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in confirmation page",
				"User should be able to see Accounts panel expanded for billing section in Confirmation page",
				"User is able to see Accounts panel expanded for billing section in Confirmation page",
				"Failed to see Accounts panel expanded for billing section in Confirmation page" + common.getStrError());
	}

	@Then("^I see the Content panel collapsed for billing section in Confirmation page$")
	public void i_see_the_Content_panel_collapsed_for_billing_section_in_Confirmation_page() throws Throwable {
		common.waitForPageLoading(200);
		boolean blnResult = newHouseholdPage.verifyContentChevronCollapseBillingSectionConfPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in confirmation page",
				"User should be able to see Contents panel collapsed for billing section in Confirmation page",
				"User is able to see Contents panel collapsed for billing section in Confirmation page",
				"Failed to see Contents panel collapsed for billing section in Confirmation page" + common.getStrError());
	}
	
	@And("I click on client Accounts chevron$")
	public void clickclientaccountchevron()
	{
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.clickclientaccountchevron();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User expands content chevron",
				"User should able to click on client account chevron",
				"User is able to click on client account chevron",
				"Failed to click on client account chevron" + common.getStrError());
	}
	
	
	
	@And("^I see client Accountname under combined statement section$")
	public void seeaccountnameundercombinedstatementsection()
	{
		common.waitForPageLoading(200);
		boolean blnResult = combinedStatementPage.verifyCSAccountname();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in combined  statement section of confirmation page",
				"User should be able to see account name under client name involved in combined statement capability",
				"User is able to see account name under client name involved in combined statement capability",
				"Failed to see account name under client name involved in combined statement capability" + common.getStrError());
	}
    @And("^I see Account class under combined statement section$")
    public void seeprognameundercombinedstatementsection()
    {
    	common.waitForPageLoading(200);
		boolean blnResult = combinedStatementPage.verifyCSAccountclass();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in combined  statement section of confirmation page",
				"User should be able to see account class under client name involved in combined statement capability",
				"User is able to see account class under client name involved in combined statement capability",
				"Failed to see account class under client name involved in combined statement capability" + common.getStrError());
    }
    
    @And("^I see client Account Number under combined statement section$")
    public void seeclientAccountNumberundercombinedstatementsection()
    {
    	common.waitForPageLoading(200);
		boolean blnResult = combinedStatementPage.verifyCSAccountnumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in combined  statement section of confirmation page",
				"User should be able to see account number under client name involved in combined statement capability",
				"User is able to see account number under client name involved in combined statement capability",
				"Failed to see account number under client name involved in combined statement capability" + common.getStrError());
    }
    @And("^I see Total account value in dollar under combined statement section$")
    public void seeTotalaccountvalueindollarundercombinedstatementsection()
    {
    	common.waitForPageLoading(200);
		boolean blnResult = combinedStatementPage.verifyCStotalaccountvalue();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in combined  statement section of confirmation page",
				"User should be able to see total account value in dollars under client name involved in combined statement capability",
				"User is able to see total account value in dollars under client name involved in combined statement capability",
				"Failed to see total account value in dollars under client name involved in combined statement capability" + common.getStrError());
    	
    }

	
	@When("^I click on a CashAccount Household Group name$")
	public void iclickoncashaccounthouseholdgroupname() {
		boolean blnResult = newHouseholdPage.clickCashAccountGroupName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hyperlinked Cash Account Household Group name",
				"User should click successfully on Hyperlinked Cash Account Household Group name",
				"User is able to click on Hyperlinked Cash Account Household Group name successfully",
				"Failed to click Hyperlinked Cash Account Household Group name." + common.getStrError());

	}
	
	@Then("^I see Balances and Investments section$")
	public void iseebalancesandinvestmentssection() {
		boolean blnResult = newHouseholdPage.verifyBalancesAndInvestments();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User land on summmary page of Cash Account Household Group name",
				"User should see Balances and Investments section rate for Household Group",
				"User is able to view Balances and Investments section on Household Group summary page successfully",
				"Failed to view Balances and Investments section on summary page of Household Group ."
						+ common.getStrError());

	}

	@Then("^I click on Show Full details Link$")
	public void iclickonshowfulldetailslink() {
		boolean blnResult = newHouseholdPage.clickShowFullDetailsLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Show Full details Link", "User should click successfully on Show Full details",
				"User is able to click on Show Full details successfully",
				"Failed to click Show Full details" + common.getStrError());

	}

	@And("^I should verify the Cash Accounts details Household accounts fields$")
	public void ishouldverifythecashaccountsdetailshouseholdaccountsfields(DataTable field) {
		common.waitForPageLoading();
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = newHouseholdPage.cashaccountsfieldsVisible(data.get("Cashaccountsfields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("Cashaccountsfields") + " available",
					"User should able to see the  " + data.get("Cashaccountsfields") + "fields",
					" listed field values is " + data.get("Cashaccountsfields") + " visible",
					"Failed : listed field values " + data.get("Cashaccountsfields") + "are NOT visible");

		}
	}
	
	@Then("^User Selects Yes Delete Combined Statement capability option$")
	public void iClickDeleteCSCapabilityOption() {
		boolean blnResult = combinedStatementPage.clickDeleteCSCapability();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on Delete capability option",
				"User is able to click on Yes delete capability option successfully",
				"Failed to click on delete combined statement capability option" + common.getStrError());
	}
	
	@Then("^I should not see Combined Statement capability on Streamline page$")
	public void verifyCStileNotPresent() {
		boolean blnResult = combinedStatementPage.verifyCStileNotPresent();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on Yes delete capability option",
				"User should not be able to see combined statement tile on streamline page successfully",
				"Failed to not see CS tile on streamline page" + common.getStrError());
	}
	
	@Then("^I should see page title read combined statement deleted$")
	public void verifyStreamlinePageTitle_DeleteCS() {
		boolean blnResult = combinedStatementPage.verifyStreamlinePageTitle_DeleteCS();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on Yes delete capability option",
				"User should see streamline page title reads as <Combined Statement Name> has been deleted successfully",
				"Failed to see streamline page title as <Combined Statement Name> has been deleted" + common.getStrError());
	}
	
	@When("^User Selects No do not Delete Combined Statement capability option$")
	public void iClickDoNoDeleteCSCapabilityOption() {
		boolean blnResult = combinedStatementPage.clickDoNoDeleteCSCapabilityOption();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on No, Do not delete combined statement option",
				"User is able to click on No, Do not delete combined statement option successfully",
				"Failed to click on No, Do not delete combined statement option" + common.getStrError());
	}

	@When("^The pop-up closes and still see option to Delete or Edit Combined Statement$")
	public void verifyPopUpCloses() {
		boolean blnResult = combinedStatementPage.verifyDeleteCSpopUpCloses();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement capability", "User clicks on No, Do not delete combined statement option",
				"User is able to see pop-up closes successfully",
				"Failed to see pop-up closes" + common.getStrError());
	}
	
	
	@And("^I create New Household$")
	public void icreatenewhousehold() {
		common.waitForPageLoading();
		String clientName = testData.get("strClientName");
		System.out.println("Step1");
		boolean blnResult = newHouseholdPage.createNewHousehold(clientName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on any one of the client name",
				"Client name should be clicked", "Client nameis clicked",
				"Failed to click the client name." + common.getStrError());

	}


	@When("^I should able to click on client account expand arrow$")
	public void ishouldabletoclickonclientaccountexpandarrow() {
		boolean blnResult = newHouseholdPage.clickClientAccountExpandArrow();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on client account chevron",
				"User should able to click on client account chevron successfully on new Household confirmation page",
				"User is able to click on client account chevron successfully ",
				"Failed to click on client account chevron on Household confirmation page." + common.getStrError());

	}



	@And("^I deleted already created Household$")
	public void ideletedalreadycreatedhousehold() {
		common.waitForPageLoading();
		String strGroupName = testData.get("groupName");
		System.out.println( testData.get("groupName"));
		boolean blnresultAmrit = newHouseholdPage.deleteHousehold(strGroupName);
	}
	
	@Then("^I See two decimal place for household value in summary banner$")
	public void i_See_two_decimal_place_for_household_value_in_summary_banner() {
		boolean blnResult = newHouseholdPage.iSeeTwoDecimalplaceForHouseholdValueCreateHouseholdPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Create household page",
				"User should able to see summary banner",
				"User is able to see two decimal places for household value in summary banner in Create household page successfully ",
				"Failed to see two decimal places for household value in summary banner in Create household page." + common.getStrError());
	}

	@Then("^I see two decimal place for clinet value in primary client banner$")
	public void i_see_two_decimal_place_for_clinet_value_in_primary_client_banner() {
		boolean blnResult = newHouseholdPage.iSeeTwoDecimalplaceForClientValueInCreateHouseholdPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Create household page",
				"User should able to see summary banner",
				"User is able to see two decimal places for household value in summary banner in Create household page successfully ",
				"Failed to see two decimal places for household value in summary banner in Create household page." + common.getStrError());
	}

	
	
	
	@Then("^I should not see sub group combined statement tile in dashboard page$")
	public void notseesubgroupcombinedstatementtileindashboardpage() {
		
		boolean blnResult = newHouseholdPage.subgroupcombinedstatementtilenotdisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User removes a client from a sub group combined statement having single client",
				"User should not able to see sub group combined statement tile in dashboard page",
				"User is not able to see sub group combined statement tile in dashboard page successfully ",
				"Failed on seeing sub group combined statement tile in dashboard page" + common.getStrError());
		
	}
	  @When("^I remove primary client of sub group combined statement with multiple clients$")
	  public void removeprimaryclientofsubgroupcombinedstatementwithmultipleclients()
	  {
			boolean blnResult = combinedStatementPage.removeCombinedStatementSubGroupPrimaryClient();
		  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User is in edit household Page",
					"User should clicks on cross button for the primary client of the combined statement subgroup having multiple clients",
					"User is able to click on cross button for the primary client of the combined statement subgroup having multiple clients successfully ",
					"Failed to click on cross button for the primary client of the combined statement subgroup having multiple clients" + common.getStrError());
	  }
	  
	  @Then("^I should see modal  message$")
	  public void seemodalmessage()
	  {
		  boolean blnResult = combinedStatementPage.seemodalmessagewithtext();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User clicks on cross button for the primary client of the combined statement subgroup having multiple clients",
					"User should able to see modal message with text",
					"User is able to see modal message with text successfully ",
					"Failed to see modal message with text" + common.getStrError());
	  }
	  @When("^I click on ok button of modal message$")
	  public void clickonokbutton()
	  {
		  boolean blnResult = combinedStatementPage.clickokbutton();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User sees modal message",
					"User should able to click on ok button",
					"User is able to click on ok button successfully ",
					"Failed to click on ok button" + common.getStrError());
	  }
	  
	  @Then("^I should see selected client for removal in household group$")
	  public void seeselectedclientforremovalinhouseholdgroup()
	  {
		  boolean blnResult = newHouseholdPage.seeselectedremovalclientinhhgroup();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User clicks on ok button from modal  message",
					"User should able to see selected client for removal in household group",
					"User is able to see selected client for removal in household group successfully ",
					"Failed to see selected client for removal in household group" + common.getStrError());
	  }


	
	@Then("^I See household name is not blank above summary banner in create household page$")
	public void i_See_household_name_is_not_blank_above_summary_banner_in_create_household_page() {
		boolean blnResult = newHouseholdPage.isHouseholdNameNotBlankCreateHouseholdPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Create household page",
				"User should able to create household page",
				"User is able to see household name field successfully and household field is not empty",
				"Failed to see household name in Create household page." + common.getStrError());
	}
	
	@When("^I click on Edit option from Dashboard for multiple combined statement$")
	public void i_click_on_Edit_option_from_Dashboard() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.clickEditOptionCombinedStatementDashboardPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household dashboard",
				"User should be able to click on Edit link for combined statement",
				"User is able to click on Edit button successfully ",
				"Failed to click on Edit button" + common.getStrError());
	}
	
	@When("^I click on Edit option from Dashboard for single combined statement$")
	public void i_click_on_Edit_option_from_Dashboard_for_single_combined_statement() {
		boolean blnResult = combinedStatementPage.clickEditOptionCombinedStatementSingleDashboardPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in household dashboard",
				"User should be able to click on Edit Pencil for combined statement",
				"User is able to click on Edit pencil icon successfully ",
				"Failed to click on Edit pencil icon" + common.getStrError());
	}
	
	@When("^I see New combined statement tile on Review HH page$")
	public void iSeeNewCStile_ReviewHHPage() {
		boolean blnResult = combinedStatementPage.validateNewCStile_ReviewHHPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User has added a client to New CS on Edit Details page",
				"User is on Review HH page",
				"User should be able to see New CS tile successfully ",
				"Failed to see New CS tile on Review HH page" + common.getStrError());
	}
	
	@When("^I see mailing address of client$")
	public void iSeeNewCSmailingAddress_ReviewHHPage() {
		boolean blnResult = combinedStatementPage.validateNewCSmailingAddress_ReviewHHPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User has added a client to New CS on Edit Details page",
				"User is on Review HH page",
				"User should be able to see New CS mailing address successfully ",
				"Failed to see New CS mailing address on Review HH page" + common.getStrError());
	}
	
	@When("^I see status label as active upon submission$")
	public void iSeeNewCSstatusLabel_ReviewHHPage() {
		boolean blnResult = combinedStatementPage.validateNewCSstatusLabel_ReviewHHPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User has added a client to New CS on Edit Details page",
				"User is on Review HH page",
				"User should be able to see New CS status label successfully ",
				"Failed to see New CS status label on Review HH page" + common.getStrError());
	}
	
	@When("^I Select Create a New Combined Statement for Client on CS overlay page$")
	public void iCreateNewCS_OverlayModal() {
		boolean blnResult = combinedStatementPage.clickCreateNewCS_OverlayModal();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on CS overlay moday",
				"User selects Create a New Combined Statement option",
				"User should be able to click on Create a New Combined Statement option successfully ",
				"Failed to click Create a New Combined Statement option" + common.getStrError());
	}
	
	@When("^I click on delete CS subgroups button$")
	public void iClickDeleteCSsubgroupsButton() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.clickDeleteCSsubgroupsButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement subgroups page",
				"User clicks on Delete button",
				"User should be able to click on Delete button successfully ",
				"Failed to click on Delete Button" + common.getStrError());
	}
	
	@When("^I click on Yes Delete combined statements option$")
	public void iClickYesDeletebutton_CSsubgroup() {
		boolean blnResult = combinedStatementPage.clickYesDeletebutton_CSsubgroup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement subgroups page",
				"User clicks on Delete button",
				"User should be able to click on Yes Delete this Combined Statement button successfully ",
				"Failed to click click on Yes Delete this Combined Statement button" + common.getStrError());
	}
	
	@When("^I click on No do not Delete Combined Statements option$")
	public void iClickNoDeletebutton_CSsubgroup() {
		common.waitForPageLoading();
		boolean blnResult = combinedStatementPage.clickDoNotDeletebutton_CSsubgroup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement subgroups page",
				"User clicks on Delete button",
				"User should be able to click on No, Do not Delete this Combined Statement button successfully ",
				"Failed to click click on No, do not Delete this Combined Statement button" + common.getStrError());
	}
	
	@When("^I should not see combined statement capability$")
	public void iDoNotSeeCombinedStatementTile() {
		boolean blnResult = combinedStatementPage.validateCombinedStatementTileNotPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Edit Combined Statement subgroups page",
				"User clicks on Delete button",
				"User should be able to click on No, Do not Delete this Combined Statement button successfully ",
				"Failed to click click on No, do not Delete this Combined Statement button" + common.getStrError());
	}
	
	@And("^I see collapsible account panel with X account number$")
	public  void seeCollapsePanelWithXaccountnumber()
	{
		boolean blnResult = newHouseholdPage.seeClientAccountsNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on review household page",
				"User has expanded account chevron for clients in review household Page",
				"User should be able to see collapsible account panel with X account number successfully ",
				"Failed to see collapsible account panel with X account number" + common.getStrError());
	}	

	@And("^I see total account value in dollars under show full details$")
	public void seeTotalAccountValueindollarsundershowfulldetails()
	
	{
		boolean blnResult = householdDashBoardPage.seeTotalAccountValueInDollars();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is on Dashboard page",
				"User clicks on show full details hyperlink",
				"User should be able to see Total account value in dollars successfully ",
				"Failed to see Total account value in dollars" + common.getStrError());
	}
	
	 @When("^I see total account value in dollars under combined statement sub section$")
	 public void  TotalAccountValueInDollarsUnderCombinedStatementSubSection()
	 {
		 boolean blnResult =combinedStatementPage.seeTotalAccountValueUnderCombinedStatementSection();
	   LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
							"When User is on household dashboard page",
							"User has navigated to combined statement sub section",
							"User should able to see total account value in dollars under combined statement sub section successfully",
							"Failed to see total account value in dollars under combined statement sub section" + common.getStrError());
	 }
	   @Then("^I see X accounts under combined statement sub section$")
	   public void seeXAccountsUnderCombinedStatementSubSection()
	   {
		   boolean blnResult = combinedStatementPage.seeTotalNumberOfAccountsUnderCombinedStatementSection();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
							"When User is on household dashboard page",
							"User has navigated to combined statement sub section",
							"User should able to see X accounts under combined statement sub section successfully ",
							"Failed to see X accounts under combined statement sub section" + common.getStrError());
	   }
	   
	   @When("^I see contents panel for combined statements$")
		public void iSeeContentsPanel_OverlayModal() {
			boolean blnResult = combinedStatementPage.validateContentsPanel_OverlayModal();
			common.waitForPageLoading();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User is on combined statement edit modal",
					"User should be able to see contents panel displayed on each combined statement tile for the group",
					"User is able to see contents panel displayed on each combined statement tile for the group successfully",
					"Failed to see contents panel displayed on each combined statement tile for the group" + common.getStrError());
		}
	   
	   @Then("^I should see message saying accounts not eligible for combined statement$")
	   public void i_should_see_message_saying_accounts_not_eligible_for_combined_statement(){
		   boolean blnResult = combinedStatementPage.errorMsgOutsideAccountCombinedStatement();
			common.waitForPageLoading();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"When User is on combined statement edit modal",
					"User should be able to see contents panel displayed on each combined statement tile for the group",
					"User is able to see contents panel displayed on each combined statement tile for the group successfully",
					"Failed to see contents panel displayed on each combined statement tile for the group" + common.getStrError());
	   }
	   
	   @When("^I clear the household name$")
	   public void i_clear_the_household_name() {
		   boolean blnResult = newHouseholdPage.clearHouseholdName();
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate user able to clear  group name field of the edit household Page",
					"user should able to clear group name successfully",
					"Group name cleared ",
					"Failed to clear agroup name" + common.getStrError());
	   }
		@When("^I click  on delete note hyperlink$")
		public void iclickondeletenotehyperlink()
		{
			 boolean blnResult = householdDashBoardPage.clickDeleteNoteHyperlink();
		 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the delete note hyperlink",
		 				"delete note hyperlink should be click successfully",
		 				"delete note hyperlink is clicked successfully",
		 				"Failed To click on delete note hyperlink" + common.getStrError());
}

		@Then("^I should see delete popup with options$")
		public void ishouldseedeletepopupwithoptions()
		{
			boolean blnResult = householdDashBoardPage.deleteNotePopupDisplayed();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks on delete note hyperlink",
	 				"User is able to see delete note popup with options",
	 				"User is able to able to see delete note popup with options sucessfully",
	 				"Failed to able to see delete note popup with options" + common.getStrError());
	     
}
		
		@When("^I click on No button$")
		public void iclickonNobutton()
		{
			boolean blnResult = householdDashBoardPage.clickNoButtonDeletePopup();
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the No button",
	 				"No button present in delete note popup should be click successfully",
	 				"No button present in delete note popup is clicked successfully",
	 				"Failed To click on No button present in delete note popup" + common.getStrError());
}
		@Then("^I click  on yes  button$")
		public void iclickonyesbuttonindeletenotepopup() {
			boolean blnResult = householdDashBoardPage.clickYesButtonDeletePopup();
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Yes button",
	 				"Yes button present in delete note popup should be click successfully",
	 				"Yes button present in delete note popup is clicked successfully",
	 				"Failed To click on Yes button present in delete note popup" + common.getStrError());
}
		@And("^I should not see deleted note in notes section$")
		public void ishouldnotseedeletednoteinnotessection()
		{
			boolean blnResult = householdDashBoardPage.deleteNoteNotPresent();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User deletes created note",
	 				"User is not able to see deleted note in note section",
	 				"User is not able to able to see deleted note in note section sucessfully",
	 				"Failed to able to see deleted note in note section" + common.getStrError());
	     
			
}
		
		@When("^I click on upgrade household to 2.0 button$")
		public void iclickonupgradehouseholdbutton()
		{
			boolean blnResult = householdDashBoardPage.clickUpgradeHouseholdButton();
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Upgrade household 2.0 button",
	 				"Upgrade household 2.0 button should be click successfully",
	 				"Upgrade household 2.0 button is clicked successfully",
	 				"Failed To click on Upgrade household 2.0 button" + common.getStrError());
		}
		
		@Then("^I select primary client of household$")
		public void iselectprimaryclientofhousehold()
		{
			boolean blnResult = householdDashBoardPage.clickPrimaryClientRadioButton();
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Primary Client radio button",
	 				"Primary client radio button should be click successfully",
	 				"Primary client radio button is clicked successfully",
	 				"Failed To click on primary client radio button" + common.getStrError());
		}

		@When("^I click on cancel upgrade link$")
		public void iclickoncancelupgradelink()
		{
			boolean blnResult = householdDashBoardPage.clickCancelUpgradeHyperlink();
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the cancel upgrade button",
	 				"cancel upgrade button should be click successfully",
	 				"cancel upgrade button is clicked successfully",
	 				"Failed To click on cancel upgrade button" + common.getStrError());
		}
		
		@When("^I click on continue to upgrade button$")
		public void iclickoncontinuetoupgradebutton()
		{
			boolean blnResult = householdDashBoardPage.clickContinueToUpgradeButton();
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the continue to upgrade button",
	 				"continue to upgrade button should be click successfully",
	 				"continue to upgrade button is clicked successfully",
	 				"Failed To click on continue to upgrade button" + common.getStrError());
		}
		@Then("^I should see review household upgrade page$")
		public void ishouldseereviewhouseholdupgradepage()
		{
		
			boolean blnResult = householdDashBoardPage.reviewUpgradePageDisplayed();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks on continue to upgrade button",
	 				"User is able to see review household upgrade page",
	 				"User is able to able to see review household upgrade page sucessfully",
	 				"Failed to able to see review household upgrade page" + common.getStrError());
			
		}
		@When("^I click on complete upgrade button$")
		public void iclickoncompleteupgradebutton()
		{
			
			boolean blnResult = householdDashBoardPage.clickCompleteUpgradeButton();
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click the Complete Upgrade button",
	 				"complete upgrade buttonshould be click successfully",
	 				" complete upgrade button is clicked successfully",
	 				"Failed To click on complete upgrade button" + common.getStrError());
		}
		
		
		@When("^I see capability tile with text$")
		public void seecapabilitytilewithtext()
		{
			boolean blnResult = householdDashBoardPage.capabilitytileWithTextDisplayed();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks on continue to upgrade button",
	 				"User is able to see capability tile with text in review household upgrade page",
	 				"User is able to able to see capability tile with text in review household upgrade page sucessfully",
	 				"Failed to able to see capability tile with text in review household upgrade page" + common.getStrError());
		}
		
		@Then("^I see Active upon upgrade status$")
		public void seeActiveuponupgradestatus()
		{
			boolean blnResult = householdDashBoardPage.activeUponUpgradeStatusDisplayed();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks on continue to upgrade button",
	 				"User is able to see Active upon upgrade status in the capability tile of the review household upgrade page",
	 				"User is able to able to see Active upon upgrade status in the capability tile sucessfully",
	 				"Failed to able to see Active upon upgrade status in the capability tile" + common.getStrError());
		}
		@And("^I see Automatically Streamlined verbiage in capability tile$")
		public void seeAutomaticallyStreamlinedverbiageincapabilitytile()
		{
			boolean blnResult = householdDashBoardPage.automaticallyStreamlinedDisplayed();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks on continue to upgrade button",
	 				"User is able to see Automatically Streamlined verbiage in capability tile of the review household upgrade page",
	 				"User is able to able to see Automatically Streamlined verbiage in capability tile sucessfully",
	 				"Failed to able to see Automatically Streamlined verbiage in capability tile" + common.getStrError());
		}
		@And("^I see static verbiage outside capability tile$")
		public void seestaticverbiageoutsidecapabilitytile()
		{
			boolean blnResult = householdDashBoardPage.outsideCapabilityTileTextDisplayed();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks on continue to upgrade button",
	 				"User is able to see static verbiage outside capability tile of the review household upgrade page",
	 				"User is able to able to see static verbiage outside capability tile sucessfully",
	 				"Failed to able to see static verbiage outside capability tile" + common.getStrError());
		}
		
		@Then("^I click on Move Accounts option$")
		public void i_click_on_Move_Accounts_option() {
			boolean blnResult = newHouseholdPage.clickOnMoveAccountOption();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User is on Clinets tab",
	 				"User is able to see client name and context menu",
	 				"User is able to able to click on Move Account option sucessfully",
	 				"Failed to click on Move Account option" + common.getStrError());
		}

		@Then("^I ensure Select Accounts to Move page is displayed$")
		public void i_ensure_Select_Accounts_to_Move_page_is_displayed() {
			boolean blnResult = newHouseholdPage.seeSelectAccountsToMovePage();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks Move Account option from Clinets tab",
	 				"User is able to see click on Move Accounts option",
	 				"User is able to able to see Select Accounts to Move page sucessfully",
	 				"Failed to Select Accounts to Move page" + common.getStrError());
		}
		
		
		@Then("^I see 1.0 Combined Statement Accounts To Be Removed modal$")
		public void seeCombinedStatementAccountsToBeRemovedmodal()
		{
			boolean blnResult = combinedStatementPage.verifyCombinedStatementAccountsToBeRemovedModal();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks on 1.0 combined statement hyperlink",
	 				"User is able to see 1.0 Combined Statement Accounts To Be Removed modal",
	 				"User is able to able to see 1.0 Combined Statement Accounts To Be Removed modal sucessfully",
	 				"Failed to see 1.0 Combined Statement Accounts To Be Removed modal" + common.getStrError());
			
		}
	@When("^I see 1.0 Combined Statement Accounts To Be Removed Modal Header$")
		public void seeCombinedStatementAccountsToBeRemovedModalHeader()
		{
			boolean blnResult = combinedStatementPage.verifyCombinedStatementAccountsToBeRemovedModalHeader();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User clicks on 1.0 combined statement hyperlink",
	 				"User is able to see 1.0 Combined Statement Accounts To Be Removed Modal Header",
	 				"User is able to able to see 1.0 Combined Statement Accounts To Be Removed Modal Header sucessfully",
	 				"Failed to see 1.0 Combined Statement Accounts To Be Removed Modal Header" + common.getStrError());
		}

@Then("^I see 1.0 Combined Statement Accounts To Be Removed Sub-header$")
		public void seeCombinedStatementAccountsToBeRemovedSubheader()
		{
			{
				boolean blnResult = combinedStatementPage.verifyCombinedStatementAccountsToBeRemovedModalSubHeader();
		 		common.waitForPageLoading(200);
		 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
		 				"When User clicks on 1.0 combined statement hyperlink",
		 				"User is able to see 1.0 Combined Statement Accounts To Be Removed Sub-header",
		 				"User is able to able to see 1.0 Combined Statement Accounts To Be Removed Sub-header sucessfully",
		 				"Failed to see 1.0 Combined Statement Accounts To Be Removed Sub-header" + common.getStrError());
			}
		}

@When("^I see account details for each 1.0 combined statement group$")
		public void seeaccountdetailsforeachcombinedstatementgroup(){
			{
				boolean blnResult = combinedStatementPage.verifyAccountDetailsInRemoveModal();
		 		common.waitForPageLoading(200);
		 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
		 				"When User clicks on 1.0 combined statement hyperlink",
		 				"User is able to see account details for each 1.0 combined statement group",
		 				"User is able to able to see account details for each 1.0 combined statement group sucessfully",
		 				"Failed to see account details for each 1.0 combined statement group" + common.getStrError());
			}
		}

	@Then("^I see section header 1.0 Combined Statement Group$")
		public void seesectionheaderCombinedStatementGroup()
		{
			{
				boolean blnResult = combinedStatementPage.verifySectionHeaderCombinedStatementGroup();
		 		common.waitForPageLoading(200);
		 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
		 				"When User clicks on 1.0 combined statement hyperlink",
		 				"User is able to see section header 1.0 Combined Statement Group",
		 				"User is able to able to see section header 1.0 Combined Statement Group sucessfully",
		 				"Failed to see section header 1.0 Combined Statement Group" + common.getStrError());
			}

}

@When("^I see cancel hyperlink at footer$")
		public void seecancelhyperlinkatfooter()
		{
			{
				boolean blnResult = combinedStatementPage.verifyCancelHyperlinkAtFooter();
		 		common.waitForPageLoading(200);
		 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
		 				"When User clicks on 1.0 combined statement hyperlink",
		 				"User is able to see cancel hyperlink at footer in remove modal",
		 				"User is able to able to see cancel hyperlink at footer in remove modal sucessfully",
		 				"Failed to see cancel hyperlink at footer in remove modal" + common.getStrError());
			}
		}

@Then("^I see REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button$")
		public void seeREMOVEACCOUNTSANDSETUPCOMBINEDSTATEMENTbutton()
		{
			{
				boolean blnResult = combinedStatementPage.verifyRemoveAccountsAndSetUpCombinedStatementButton();
		 		common.waitForPageLoading(200);
		 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
		 				"When User clicks on 1.0 combined statement hyperlink",
		 				"User is able to see REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button ",
		 				"User is able to able to see REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button sucessfully",
		 				"Failed to see REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button" + common.getStrError());
			}
		}

@When("^I click on REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button$")
		public void clickREMOVEACCOUNTSANDSETUPCOMBINEDSTATEMENTButton() {
			boolean blnResult = combinedStatementPage.clickRemoveAccountsAndSetUpCombinedStatementButton();
	 		common.waitForPageLoading(200);
	 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	 				"When User is on remove combined statement modal",
	 				"User is able to see REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button",
	 				"User is able to able to click on REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button sucessfully",
	 				"Failed to click on REMOVE ACCOUNTS AND SET UP 2.0 COMBINED STATEMENT button" + common.getStrError());
			
		}


@When("^I see Recent activity header$")
public void seeRecentActivityHeader()

	{
		boolean blnResult = householdDashBoardPage.recentActivityDisplayed();
 		common.waitForPageLoading(200);
 		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
 				"When User navigates to Dashboard Page",
 				"User is able to see Recent activity header",
 				"User is able to able to see Recent activity header sucessfully",
 				"Failed to able to see Recent activity header" + common.getStrError());
	}

@Then("^I see two recent activities$")
public void seeTwoRecentActivities()
{
	boolean blnResult = householdDashBoardPage.twoRecentActivitiesDisplayed();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User navigates to Recent Activity Section",
				"User is able to see two recent activities",
				"User is able to able to see two recent activities sucessfully",
				"Failed to able to see two recent activities" + common.getStrError());
}
@When("^I click on see for all this group hyperlink$")
public void clickSeeForAllThisGroupHyperlink()
{
	boolean blnResult = householdDashBoardPage.clickSeeForAllThisGroupHyperlink();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is seeing recent activities",
				"User is able to click on see for all this group hyperlink",
				"User is able to able to click on see for all this group hyperlink sucessfully",
				"Failed to click on see for all this group hyperlink" + common.getStrError());
}
@Then("^I should see new Activity tab$")
public void seeNewActivityTab()
{
	boolean blnResult = householdDashBoardPage.activityTabDisplayed();
		common.waitForPageLoading(200);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on see for all this group hyperlink",
				"User is able to see new Activity tab",
				"User is able to able to see new Activity tab sucessfully",
				"Failed to able to see new Activity tab" + common.getStrError());
}

@Then("I click on Edit CS subgroup")
public void i_click_on_edit_cs_subgroup() {
	boolean blnResult = combinedStatementPage.clickEditCSSubgroup();
	common.waitForPageLoading(200);
	LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
			"When User sees Edit Combined Statement option",
			"User is able to click on Edit Combined Statement option",
			"User is able to able to click on Edit Combined Statement option",
			"Failed to see click on Edit Combined Statement option" + common.getStrError());
}

@When("I click on Delete Capability for billing")
public void i_click_on_delete_capability_for_billing() {
	boolean blnResult = billingPage.clickDeleteCapability();
	common.waitForPageLoading(200);
	LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
			"When User is in Edit Billing page",
			"User is able to click on Delete Capability",
			"User is able to able to click on Delete Capability",
			"Failed to click on Delete Capability" + common.getStrError());
}

@When("^I click on Investment Management hyperlink$")
public void clickInvestmentManagementHyperlink()
{
       
       boolean blnResult = investmentManagementPage.clickInvestmentManagementHyperlink();
       common.waitForPageLoading(200);
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User is seeing Investment Management hyperlink in the active state",
                     "User is able to click on Investment Management hyperlink",
                     "User is able to able to click on Investment Management hyperlink sucessfully",
                     "Failed to click on Investment Management hyperlink" + common.getStrError());
}
@Then("^I should see Edit Investment management Page$")
public void seeEditInvestmentmanagementPage()
{
       boolean blnResult = investmentManagementPage.seeEditInvestmentManagementPage();
       common.waitForPageLoading(200);
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User clicks on investment management link",
                     "User is able to see Edit Investment management Page",
                     "User is able to able to see Edit Investment management Page sucessfully",
                     "Failed to able to see Edit Investment management Page" + common.getStrError());
}

@When("^I click on cancel and return to Dashboard hyperlink$")
public void clickcancelandreturntoDashboardHyperlink() {
       boolean blnResult = combinedStatementPage.clickCancelReturntoDashboardHyperlink();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User click on Edit Combined Statement Button in Dashboard",
                     "User should successfully click on Cancel & Return to Dashboard hyperlink",
                     "User is able to click on Cancel & Return to Dashboard hyperlink successfully",
                     "Failed to click on Cancel & Return to Dashboard hyperlink" + common.getStrError());  
}

              
@When("^I see five investment objectives$")
public void seeFiveInvestmentObjectives()
{
	
       boolean blnResult = investmentManagementPage.seeFiveInvestmentObjectives();
       common.waitForPageLoading(200);
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User is seeing Edit Investment Management Page",
                     "User is able to see five investment objectives",
                     "User is able to able to see five investment objectives sucessfully",
                     "Failed to able to see five investment objectives" + common.getStrError());
}
@Then("^I select one of the investment objective$")
public void selectOneOfTheInvestmentObjective()
{
	common.waitForPageLoading(200);
       boolean blnResult = investmentManagementPage.clickInvestmentObjectiveOption();
       
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User is seeing Edit Investment Management Page",
                     "User is able to click on one of the investment objective",
                     "User is able to able to click on one of the investment objective sucessfully",
                     "Failed to click on one of the investment objective" + common.getStrError());
}

@When("^I click on Edit investment objective button$")
public void clickOnEditInvestmentObjectiveButton(){
	common.waitForPageLoading(200);
       boolean blnResult = investmentManagementPage.clickEditInvestmentObjectiveButton();
       
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User is seeing confirmation Page",
                     "User is able to click on Edit investment objective button",
                     "User is able to able to click on Edit investment objective button sucessfully",
                     "Failed to click on Edit investment objective button" + common.getStrError());   
}

@When("^I click on Blue attest button$")
public void clickOnBlueAttestButton()
{
	common.waitForPageLoading(200);
       boolean blnResult = investmentManagementPage.clickOnBlueAttestButton();
       
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User is seeing Edit Investment Management Page",
                     "User is able to click on Blue attest button",
                     "User is able to able to click on Blue attest button sucessfully",
                     "Failed to click on Blue attest button" + common.getStrError());
}
@Then("^I should see Review Household Investment management details Page$")
public void seeReviewHouseholdInvestmentManagementDetailsPage()
{
	common.waitForPageLoading(200);
       boolean blnResult = investmentManagementPage.reviewInvestmentManagementPageDisplayed();
       
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User clicks on blue attestion button",
                     "User is able to see Review Household Investment management details Page",
                     "User is able to able to see Review Household Investment management details Page sucessfully",
                     "Failed to able to see Review Household Investment management details Page" + common.getStrError());
}

//@When("^I click on Delete Capability button$")
//public void clickOnDeleteCapabilityButton()
//{
//     boolean blnResult = billingPage.clickOnDeleteCapabilityButton();
//     common.waitForPageLoading(200);
//     LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
//                   "When User is seeing Edit Investment Management Page",
//                   "User is able to click on Delete Capability button",
//                   "User is able to able to click on Delete Capability button sucessfully",
//                   "Failed to click on Delete Capability button" + common.getStrError());
//       
//}
@Then("^I should see delete investment management overlay modal$")
public void seeDeleteInvestmentManagementOverlayModal()
{
	common.waitForPageLoading(200);
       boolean blnResult = investmentManagementPage.seeDeleteInvestmentMangementModal();
     
     LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                   "When User clicks on Delete Capability button",
                   "User is able to see delete investment management overlay modal",
                   "User is able to able to see delete investment management overlay modal sucessfully",
                   "Failed to able to see delete investment management overlay modal" + common.getStrError());  
}

@When("^I click on create investment objective button$")
public void clickCreateInvestmentObjectiveButton()
{
	common.waitForPageLoading(200);
       boolean blnResult = investmentManagementPage.clickCreateInvestmentObjectiveButton();
  
  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User is seeing review Investment Management Page",
                "User is able to click on create investment objective button",
                "User is able to able to click on create investment objective button sucessfully",
                "Failed to click on create investment objective button" + common.getStrError());
}

@Then("^I should see Delete Household Billing Modal$")
public void seeDeleteHouseholdBillingModal()
{
       common.waitForPageLoading(200);
    boolean blnResult = billingPage.seeDeleteBillingModal();
  
  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User clicks on Delete Capability button in the Edit Billing Page",
                "User is able to see Delete Household Billing modal",
                "User is able to able to see Delete Household Billing modal sucessfully",
                "Failed to able to see Delete Household Billing modal" + common.getStrError());  
}
@When("^I should see Investment Management Details Information$")
public void seeInvestmentManagementDetailsInformation()
{
       common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeInvestmentManagementDetailInformation();
  
  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User clicks on Delete Capability button",
                "User is able to see Investment Management Details Information",
                "User is able to able to see Investment Management Details Information sucessfully",
                "Failed to able to see Investment Management Details Information" + common.getStrError());  
}
@Then("^I should see Current Household IO$")
public void seeCurrentHouseholdIO()
{
       common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeCurrentHouseholdIO();
  
  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User clicks on Delete Capability button",
                "User is able to see Current Household IO",
                "User is able to able to see Current Household IO sucessfully",
                "Failed to able to see Current Household IO" + common.getStrError());  
}
@And("^I see Portfolio Allocation$")
public void seePortfolioAllocation()
{
       common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seePortfolioAllocation();
  
  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User clicks on Delete Capability button",
                "User is able to see Portfolio Allocation",
                "User is able to able to see Portfolio Allocation sucessfully",
                "Failed to able to see Portfolio Allocation" + common.getStrError());  
}

@When("^I click on review button in the overlay modal$")
public void clickReviewButtonOverlayModal()
{
       common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickReviewButtonOverlayModal();

LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Delete Overlay modal",
             "User is able to click on review button in the overlay modal",
             "User is able to able to click on review button in the overlay modal sucessfully",
             "Failed to click on review button in the overlay modal" + common.getStrError());
}
@Then("^I should see Delete Household billing and Investment Management modal$")
public void seeDeleteBillingAndInvestmentManagementModal()
{
       common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeDeleteBillingAndInvestmentModal();
  
  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User clicks on the review button of the Delete Investment Management overlay modal",
                "User is able to see Delete Household billing and Investment Management modal",
                "User is able to able to see Delete Household billing and Investment Management modal sucessfully",
                "Failed to able to see Delete Household billing and Investment Management modal" + common.getStrError());  
       
}

@When("^I click on Back button in the overlay modal$")
public void clickOnBackButtoInTheOverlayModal()
{
       common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickBackButtonOverlayModal();

LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Delete Overlay modal",
             "User is able to click on back button in the overlay modal",
             "User is able to able to click on back button in the overlay modal sucessfully",
             "Failed to click on back button in the overlay modal" + common.getStrError());
}

@Then("^I should see Deleting Investment Management overlay modal$")
public void seeDeletingInvestmentManagementOverlayModal() {
	 common.waitForPageLoading(200);
	    boolean blnResult = investmentManagementPage.seeDeletingInvestmentManagementModal();
	  
	  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	                "When User clicks on the Review button present in the Delete Investment Management overlay modal",
	                "User is able to see Deleting Investment Management overlay modal",
	                "User is able to able to see Deleting Investment Management overlay modal sucessfully",
	                "Failed to able to see Deleting Investment Management overlay modal" + common.getStrError());
}
@When("^I click on Delete Investment Management capability button$")
public void clickDeleteInvestmentManagementCapabilityButton() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickDeleteInvestmentManagementButton();

LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Investment Management overlay modal",
             "User is able to click on Delete Investment Management capability button",
             "User is able to able to click on Delete Investment Management capability button sucessfully",
             "Failed to click on Delete Investment Management capability button" + common.getStrError());
}

@And("^I should see Billing and Investment static Verbiage$")
public void seeBillingAndInvestmentStaticVerbiage()
{
	 common.waitForPageLoading(200);
	    boolean blnResult = investmentManagementPage.seeStaticVerbiagesDeleteBillingAndInvestmentModal();
	  
	  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	                "When User clicks on the Review button present in the Delete Investment Management overlay modal",
	                "User is able to see Deleting Billing and Investment Management Verbiages",
	                "User is able to able to see Deleting Billing and Investment Management Verbiages  sucessfully",
	                "Failed to able to see Deleting Billing and Investment Management Verbiages" + common.getStrError());	
}
@When("^I click on Delete two household capabilities button$")
public void clickDeleteTwoHouseholdCapabilitiesButton()
{
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickDeleteTwoCapabilitiesButton();

LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Billing and Investment Management overlay modal",
             "User is able to click on Delete two household capabilities button",
             "User is able to able to click on Delete two household capabilities button sucessfully",
             "Failed to click on Delete two household capabilities button" + common.getStrError());
	
}

@When("^I click on Investment objective dropdown button$")
public void clickInvestmentObjectiveDropdownButton()
{
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickInvestmentManagementDropdownButton();

LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Investment Management overlay modal",
             "User is able to click on Investment objective dropdown button",
             "User is able to able to click on Investment objective dropdown button sucessfully",
             "Failed to click on Investment objective dropdown button" + common.getStrError());
}

@Then("^I select Investment Management objective from dropdown$")
public void selectInvestmentManagementObjectiveFromDropdown()
{
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickInvestmentManagementFromDropdown();
LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Investment Management overlay modal",
             "User is able to select Investment Management objective from dropdown",
             "User is able to able to select Investment Management objective from dropdown sucessfully",
             "Failed to click select Investment Management objective from dropdown" + common.getStrError());
}
@And("I see delete Investment Management green banner with message")
public void seeDeleteInvestmentManagementGreenBannerWithMessage()
{
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeDeleteInvestmentManagementGreenBanner();
  
  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User clicks on the Delete Investment Management Button",
                "User is able to see delete Investment Management green banner with message",
                "User is able to able to see delete Investment Management green banner with message sucessfully",
                "Failed to able to see delete Investment Management green banner with message" + common.getStrError());	
}

@When("I select SHOW link from delete IMG overlay page")
public void i_select_show_link_from_delete_img_overlay_page() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickShowOnDeleteIMGOverlayPage();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Investment Management overlay modal",
             "User is able to select SHOW button on IMG overlay page",
             "User is able to able to click on SHOW button sucessfully",
             "Failed to click on the SHOW button in delete IMG overlay page" + common.getStrError());
}

@Then("I should see Portfolio Alocation section")
public void i_should_see_Portfolio_Alocation_section() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seePortfolioAllocationSection();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Investment Management overlay modal",
             "User is able to select SHOW button on IMG overlay page",
             "User is able to able to see portfolio allcation section sucessfully",
             "Failed to see portfilio allocation section" + common.getStrError());
}

@When("I click on HIDE link from delete IMG overlay page")
public void i_click_on_HIDE_link_from_delete_IMG_overlay_page() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickHideOnDeleteIMGOverlayPage();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Investment Management overlay modal",
             "User is able to select HIDE button on IMG overlay page",
             "User is able to click on HIDE sucessfully",
             "Failed to click on HIDE in delete IMG overlay page" + common.getStrError());
}

@Then("I should see Portfolio Alocation section is hidden")
public void i_should_see_Portfolio_Alocation_section_is_hidden() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.hiddenPortfolioAllocationSection();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Investment Management overlay modal",
             "User is able to select HIDE button on IMG overlay page",
             "User is able to see the portfolio allocation section hidden sucessfully",
             "Failed to see the portfolio allocation section hidden" + common.getStrError());
}

@And("I should verify the text below Investment Management title")
public void i_should_verify_the_text_below_Investment_Management_title() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.verifyTextBelowIMGTitle();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User see Deleting Investment Management overlay modal",
             "User is able to select HIDE button on IMG overlay page",
             "User is able to see the portfolio allocation section hidden sucessfully",
             "Failed to see the portfolio allocation section hidden" + common.getStrError());
}

@Then("Verify Target Allocation section")
public void verify_target_allocation_section() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.verifyTargetAllocationSection();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in New Investment Management Details",
             "User is able to select Investment Objective",
             "User is able to see the Target Allocation section sucessfully",
             "Failed to see the Target Allocation section" + common.getStrError());
}

@And("Verify Portfolio Allocation section")
public void verify_portfolio_allocation_section() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.verifyPortfolioAllocationSection();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in New Investment Management Details",
             "User is able to select Investment Objective",
             "User is able to see the Portfolio Allocation section sucessfully",
             "Failed to see the Portfolio Allocation section" + common.getStrError());
}

@Then("Verify Eligible account heading and text")
public void verify_eligible_account_heading_and_text() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.verifyEligibleAccountHeadingAndText();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in New Investment Management Details",
             "User is able to select Investment Objective",
             "User is able to see the Eligible account heading and text sucessfully",
             "Failed to see the Eligible account heading and text" + common.getStrError());
}

@And("Verify Address text")
public void verify_address_text() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.verifyIMGAddressText();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in New Investment Management Details",
             "User is able to select Investment Objective",
             "User is able to see the Address text sucessfully",
             "Failed to see the Address text" + common.getStrError());
}

@Then("I should see Edit combined statement Page for single statement")
public void i_should_see_edit_combined_statement_page_for_single_statement() {
	boolean blnResult = combinedStatementPage.EditcombinedstatementPageDisplayedForSingleStmt();
	LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
			"When User click on Edit combined statement Button,Edit combined statement page displayed",
			"User should able to see edit combined statement page",
			"User is able to see edit combined statement Page",
			"Failed to see edit combined statement page." + common.getStrError());
}

@When("I deselect to remove account")
public void i_deselect_to_remove_account() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.deselectAccountFromIMG();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User is able to See IMG page",
             "User is able to deselect account successfully",
             "Failed to deselect accounts for IMG" + common.getStrError());
}

@Then("Verify the static message displayed")
public void verify_the_static_message_displayed() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.verifyRemoveAcccountIMGStaticMsg();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User is deselecting account to remove from IMG",
             "User is able to see a static warning message successfully",
             "Failed to see a static warning message for IMG" + common.getStrError());
}

@Then("I should see Remove accounts overlay page")
public void i_should_see_remove_accounts_overlay_page() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeRemoveAccountsOverlayPage();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User is deselecting account to remove from IMG and click on Attestation button",
             "User is able to see Remove account from IMG page successfully",
             "Failed to see Remove account from IMG page" + common.getStrError());
}

@Then("I should verify text in Remove accounts overlay page")
public void i_should_verify_text_in_remove_accounts_overlay_page() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.verifyTextInRemoveAccountsOverlayPage();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User is deselecting account to remove from IMG and click on Attestation button",
             "User is able to see Remove account from IMG page successfully",
             "Failed to see Remove account from IMG page" + common.getStrError());
}

@Then("I should see Removing accounts from IMG overlay page")
public void i_should_see_removing_accounts_from_img_overlay_page() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeRemovingAccountsOverlayPage();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User clicks on Review button in Remove accounts from IMG page",
             "User is able to see Removing Accounts From Household Investment Management page successfully",
             "Failed to see Removing Accounts From Household Investment Management" + common.getStrError());
}

@When("I click on Final Review button")
public void i_click_on_final_review_button() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickFinalReviewButtonIMG();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User is navigating and proceeding to click Final Review button",
             "User is able to click Final Review button successfully",
             "Failed to click Final Review button" + common.getStrError());
}

@Then("I should see Excluded contents panel expanded")
public void i_should_see_excluded_contents_panel_expanded() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeExcludedContentsPanelIMG();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User is navigating and proceeding to click Final Review button",
             "User is able to click Final Review button successfully",
             "Failed to click Final Review button" + common.getStrError());
}

@When("I click on PROCEED button present in Pop-up message")
public void i_click_on_proceed_button_present_in_pop_up_message() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickProceedToCloseIMGOVerlay();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User clicks on Back button in the IMG overlay page",
             "User is able to see Edit IMG page successfully",
             "Failed to see Edit IMG page" + common.getStrError());
}

@Then("Removed accounts are displayed and highlighted in yellow.")
public void removed_accounts_are_displayed_and_highlighted_in_yellow() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeExcludedContentsTile();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User clicks on Final Review button",
             "User is able to see Excluded Contents tile successfully",
             "Failed to see Excluded Contents tile" + common.getStrError());
}

@When("I select to add account")
public void i_select_to_add_account() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.deselectAccountFromIMG();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User is able to See IMG page",
             "User is able to select account successfully",
             "Failed to se accounts for IMG" + common.getStrError());
}

@Then("I should see static alert message displayed")
public void i_should_see_static_alert_message_displayed() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.verifyAddAcccountIMGStaticMsg();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Edit Investment Management Details",
             "User is selecting account to remove from IMG",
             "User is able to see a static warning message successfully",
             "Failed to see a static warning message for IMG" + common.getStrError());
}

@Then("I should see IMG form Section in the confirmation page")
public void i_should_see_img_form_section_in_the_confirmation_page() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeIMGFormTile();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Household Confirmation page",
             "User is navigating to the end section of the apge",
             "User is able to see IMG form tile successfully",
             "Failed to see a IMG form tile" + common.getStrError());
}

@When("I click on Prepare Form for Signature button for IMG")
public void i_click_on_prepare_form_for_signature_button_for_img() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.clickOnSignatureFormForIMG();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Household Confirmation page",
             "User is navigating to the end section of the apge",
             "User is able to click on PREPARE FORM FOR SIGNATURE successfully",
             "Failed to see click on PREPARE FORM FOR SIGNATURE for IMG" + common.getStrError());
}

@Then("^I should see DocGrid page for IMG$")
public void IShouldSeeDocGridPageForIMG() {
	common.waitForPageLoading();
	boolean blnResult = investmentManagementPage.CheckElementDisplayed();
	LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
			"Check if the user is able to see DocGrid page", "User should able to see DocGrid page",
			"User is able to see DocGrid page",
			"Failed to see DocGrid page. Error message: " + common.getStrError());
}

@Then("I should see Activation requires static text")
public void i_should_see_activation_requires_static_text() {
	common.waitForPageLoading(200);
    boolean blnResult = investmentManagementPage.seeActivationRequiredFormMsg();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
             "When User is in Household Confirmation page",
             "User is navigating to the end section of the apge",
             "User is able to see ! ACTIVATION REQUIRES 1 FORM successfully",
             "Failed to see ! ACTIVATION REQUIRES 1 FORM" + common.getStrError());
}

@When("^I click on FAQs link in FAQs widget$")
public void clickInvestmentManagementFAQsHyperlinkInFAQsWidget()
{
	common.waitForPageLoading();
       boolean blnResult = investmentManagementPage.clickInvestmentManagementFAQsHyperlinkInFAQsWidget();
       common.waitForPageLoading(200);
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User is seeing Investment Management FAQs hyperlink in the active state",
                     "User is able to click on Investment Management FAQs hyperlink",
                     "User is able to able to click on Investment Management FAQs hyperlink sucessfully",
                     "Failed to click on Investment Management FAQs hyperlink" + common.getStrError());
}@When("^I click on FAQs pdf hyperlink in FAQs widget$")
public void clickInvestmentManagementFAQsPDFlinkInFAQsWidget()
{
	common.waitForPageLoading();
       boolean blnResult = investmentManagementPage.clickInvestmentManagementFAQsPDFlinkInFAQsWidget();
       common.waitForPageLoading(200);
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                     "When User is seeing Investment Management FAQs PDF link in the active state",
                     "User is able to click on Investment Management FAQs PDF link",
                     "User is able to able to click on Investment Management FAQs PDF link sucessfully",
                     "Failed to click on Investment Management FAQs PDF link" + common.getStrError());
}

@Then("^I click Break Point Option$")
public void ishouldabletoclickBreakPointFeeButton() {
	common.waitForPageLoading();
       boolean blnResult = billingPage.clickBreakPointFeeTypeButton();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click on Fee Type as Break Point",
                    "User should click successfully Break Point",
                    "User is able to click on Break Point type successfully",
                    "Failed to click Break Point Fee Type." + common.getStrError());
}
@Then("^I should see following fields in Break Point summary banner$")
public void isSeeBreakPointBillingRate_BillingPage(DataTable field) {
	common.waitForPageLoading();
       LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
       List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
       for (Map<String, String> data : userGuidesFields) {
              boolean blnResult = billingPage.displayBillRateTileValuesInBillingPage(data.get("fields"));
              LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                           "Validate that listed fields " + data.get("fields") + " available",
                           "User should able to see the  " + data.get("fields") + "fields",
                           " listed field values is " + data.get("fields") + " visible",
                           "Failed : listed field values " + data.get("fields") + "are NOT visible");
       }             
}
@When("^I select BP Additional Schedule from dropdown$")
public void iselectBPAdditionalScheduleFromDropdown() {
	common.waitForPageLoading();
       String additionalScheduleName = testData.get("additionalschedulenameForBP");
       boolean blnResult = newHouseholdPage.selectAdditionalSchedule(additionalScheduleName);
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User select BP additional Schedule",
                    "User should select successfully BP additional Schedule from Drop down",
                    "User is able to select the BP additional Schedule value successfully",
                    "Failed to select BP additional Schedule value." + common.getStrError());
}
@Then("^verify Tier value in the summary banner$")
public void ishouldabletoverifyTierValue_EditBillingDetailsPage() {
	common.waitForPageLoading();
       boolean blnResult = billingPage.tierValueIsEqualToHighlightedvalueInBPdetails();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User select on BP additional schedule value",
                    "User should see the Tier value equals to BP highlighted value",
                    "User should see the Tier value equals to BP highlighted value successfully",
                    "Failed to see the Tier value equals to BP highlighted value." + common.getStrError());
}
@Then("^I should able to see Review Household Billing Details page$")
public void ishouldabletoseeReviewHouseholdDetailspage() {
	common.waitForPageLoading();
       boolean blnResult = billingPage.verifyReviewHouseholdBillingDetailsPage();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click on Done Editing for Billing",
                    "User should able to see successfully Billing changes updated",
                    "User is able to see successfully review household billing details page page",
                    "Failed to view Review Household Billing Details page." + common.getStrError());
}
@Then("^I should see following fields in Review Household Billing Details page$")
public void isSeeBreakPointBillingRate_ReviewHouseholdBillingPage(DataTable field) {
	common.waitForPageLoading();
       LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
       List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
       for (Map<String, String> data : userGuidesFields) {
              boolean blnResult = billingPage.displayBillRateTileValuesInReviewHouseholdBillingDetailsPage(data.get("fields"));
              LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                           "Validate that listed fields " + data.get("fields") + " available",
                           "User should able to see the  " + data.get("fields") + "fields",
                           " listed field values is " + data.get("fields") + " visible",
                           "Failed : listed field values " + data.get("fields") + "are NOT visible");
       }             
}
@Then("^I should click Edit Details Button in reveiw hosehold Billing details page$")
public void ishouldabletoclickEditDetailsButton_ReviewHouseholdBillingDetailsPage() {
	common.waitForPageLoading();
       boolean blnResult = billingPage.clickEditDetailsButtonInReviewHBDpage();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click on Edit Details button in Review Household Billing Details Page",
                    "User should click successfully Edit Details button in Review Household Billing Details Page",
                    "User is able to click on Edit Details button in Review Household Billing Details Page successfully",
                    "Failed to click Edit Details button in Review Household Billing Details Page." + common.getStrError());
}
@Then("^I verify Breakpoint billing tile and column names in confimration page$")
public void i_verify_breakpoint_billing_tile_and_column_names_in_confirmation_page(DataTable field) {
	common.waitForPageLoading();
       LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
       List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
       for (Map<String, String> data : userGuidesFields) {
              boolean blnResult = billingPage.verifyBreakpointBillingTileInConfPage(data.get("fields"));
              LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                           "Validate that listed fields " + data.get("fields") + " available",
                           "User should able to see the  " + data.get("fields") + "fields",
                           " listed field values is " + data.get("fields") + " visible",
                           "Failed : listed field values " + data.get("fields") + "are NOT visible");
       }             
}

@When("I click on View Payout Schedule link")
public void i_click_on_view_payout_schedule_link() {
	common.waitForPageLoading();
	boolean blnResult = billingPage.clickViewPayoutSchedule();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                 "When User in household confirmation Page",
                 "User see View Payout Schedule link in the billing tile",
                 "User is able to click on View Payout Schedule link in the billing successfully",
                 "Failed to click View Payout Schedule link." + common.getStrError());
}

@Then("I select again the BP Additional Schedule from dropdown")
public void i_select_again_the_bp_additional_schedule_from_dropdown() {
	common.waitForPageLoading();
	 String additionalScheduleName = testData.get("additionalscheduleName1ForBP");
     boolean blnResult = newHouseholdPage.selectAdditionalSchedule(additionalScheduleName);
     LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User select BP additional Schedule",
                  "User should select successfully BP additional Schedule from Drop down",
                  "User is able to select the BP additional Schedule value successfully",
                  "Failed to select BP additional Schedule value." + common.getStrError());
}

@Then("I should land in Clientworks Resource Center")
public void i_should_land_in_clientworks_resource_center() {
	common.waitForPageLoading();
	boolean blnResult = billingPage.seeClientworksResouseCenter();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                 "When User in household Dashboard Page",
                 "User click on View Payout Schedule link in the billing tile",
                 "User is able to see ClientworksResourse Center page successfully",
                 "Failed to  see ClientworksResourse Center page" + common.getStrError());
}

@Then("I click on undo button")
public void i_click_on_undo_button() {
	common.waitForPageLoading();
	boolean blnResult = newHouseholdPage.clickOnUndoButton();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                 "When User in Edit household Page",
                 "User see the tracker",
                 "User is able to undo button successfully",
                 "Failed to click on the undo button" + common.getStrError());
}

@Then("Removed client is added back to Household")
public void removed_client_is_added_back_to_household() {
	common.waitForPageLoading();
	boolean blnResult = newHouseholdPage.seeRemovedAccountAddedBack();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                 "When User in Edit household Page",
                 "User see the tracker",
                 "User is able to see the client added back successfully",
                 "Failed to  see the client added back" + common.getStrError());
}

@Then("I should see scroll bar for clients in dashboard")
public void i_should_see_scroll_bar_for_clients_in_dashboard() {
	common.waitForPageLoading();
	boolean blnResult = newHouseholdPage.verifyClientsScrollBarDashboardPage();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                 "When User in Edit household Page",
                 "User see the tracker",
                 "User is able to see the client added back successfully",
                 "Failed to  see the client added back" + common.getStrError());
}

@Then("Verify Client Name and Mailing Address")
public void verify_client_name_and_mailing_address() {
	common.waitForPageLoading();
	boolean blnResult = combinedStatementPage.verifyClientAddressCSReviewPage();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                 "When User in Edit household Page",
                 "User see the tracker",
                 "User is able to see the client added back successfully",
                 "Failed to  see the client added back" + common.getStrError());
}

@And("^verify the account full address shown in Edit combined statement page$")
public void verify_the_account_full_address_shown_in_Edit_combined_statement_page()
{
       common.waitForPageLoading();
    boolean blnResult = combinedStatementPage.verifyCSAccountAddress();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is in combined  statement section of confirmation page",
                    "User should be able to see account address in combined statement capability",
                    "User is able to see account address in combined statement capability",
                    "Failed to see account address in combined statement capability" + common.getStrError());
}

@Then("^I verify Breakpoint billing tile and column names in dashboard page$")
public void i_verify_breakpoint_billing_tile_and_column_names_in_dashboard_page(DataTable field) {
       common.waitForPageLoading();
       LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
       List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
       for (Map<String, String> data : userGuidesFields) {
              boolean blnResult = billingPage.verifyBreakpointBillingTileInDashboardPage(data.get("fields"));
              LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                           "Validate that listed fields " + data.get("fields") + " available",
                           "User should able to see the  " + data.get("fields") + "fields",
                           " listed field values is " + data.get("fields") + " visible",
                           "Failed : listed field values " + data.get("fields") + "are NOT visible");
       }             
}

@When("^I click on FAQs link in Edit IMG page$")
public void clickFAQslinkText() {
       boolean blnResult = investmentManagementPage.clickOnFAQlinkText();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click on FAQs link text", "User should click FAQs link text successfully ",
                    "User is able to click on FAQs link text successfully",
                    "Failed to click on FAQs link text in edit IMG page." + common.getStrError());

}
@When("^I should see eligible accounts billing grid header name$")
public void verifyEligibleAccountsGridHeaderName() {
       boolean blnResult = billingPage.EligibleAccountsHeaderDisplayed();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click on Streamline billing ",
                    "User should see eligible accounts grid header name successfully ",
                    "User is able to see eligible accounts grid header name successfully",
                    "Failed to see eligible accounts grid header name." + common.getStrError());
}
@When("^I should see eligible accounts billing grid sub header name$")
public void verifyEligibleAccountsGridSubHeaderName() {
       boolean blnResult = billingPage.EligibleAccountsSubHeaderDisplayed();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click on Streamline billing",
                    "User should see eligible accounts grid sub header name successfully",
                    "User is able to see eligible accounts grid sub header name successfully",
                    "Failed to see eligible accounts grid sub header name." + common.getStrError());
}
@When("^Verify the Billing Type grid not displayed$")
public void verifyBillingTypeNotDisplayed() {
       boolean blnResult = billingPage.verifyBillingTypeNotDisplayed();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User click on Streamline billing",
               "User should not see Billing Type successfully",
               "User not able see Billing Type successfully",
               "Failed to Billing Type not displayed." + common.getStrError());
}
@When("^Verify the Done editing button disabled$")
public void verifyDoneEditingButtonDisabled() {
       boolean blnResult = billingPage.verifyDoneEditingButtonDisabled();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User click on Streamline billing",
               "User verify the Done editing button disabled successfully",
               "User verify the Done editing button disabled successfully",
               "Failed to verify the Done editing button disabled." + common.getStrError());
}
@When("^I remove account in Eligible accounts billing grid$")
public void clickAlreadySelectedAccountCheckbox() {
       boolean blnResult = billingPage.clickAlreadySelectedAccountCheckbox();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User click on Streamline billing",
               "User should click one of account checkbox for already selected account successfully",
               "User should able to click one of account checkbox for already selected account successfully",
               "Failed to click one of account checkbox for already selected account." + common.getStrError());
}
@When("^I should see Remove Account warning message$")
public void verifyRemovedAccountWarningMessage() {
       boolean blnResult = billingPage.verifyRemoveAcctWarningMsgDisplayed();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click on account checkbox for already selected account",
                    "User should see the remove account warning message successfully ",
                    "User is able to see the remove account warning message successfully",
                    "Failed to see the remove account warning message." + common.getStrError());
}
@When("^I add account in Eligible accounts billing grid$")
public void clickUnselectedAccountCheckbox() {
       boolean blnResult = billingPage.clickUnselectedAccountCheckbox();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User click on Streamline billing",
               "User should click one of account checkbox for unselected account successfully",
               "User should able to click one of account checkbox for unselected account successfully",
               "Failed to click one of account checkbox for unselected account." + common.getStrError());
}
@When("^I should see add Account warning message$")
public void verifyAddedAccountWarningMessage() {
       boolean blnResult = billingPage.verifyAddedAccountWarningMessage();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User click on account checkbox for unselected account",
               "User should see the add account warning message successfully ",
               "User is able to see the add account warning message successfully",
               "Failed to see the add account warning message." + common.getStrError());
}
@When("^I click the Approve button at group level$")
public void clickApproveButtonAtGroupLevel() {
       boolean blnResult = billingPage.clickApproveButtonAtGroupLevel();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User select/unselect Account checkbox",
                    "User should click Approve button at group level successfully ",
                    "User is able to click on Approve button at group level successfully",
                    "Failed to click on Approve button at group levelt in billing details page." + common.getStrError());
}
@When("^Verify the Billing Type grid displayed$")
public void verifyBillingTypeGrid() {
       boolean blnResult = billingPage.verifyBillingTypeGridDisplayed();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click on Approve button at group level in billing details page",
                    "User should see Billing Type successfully ",
                    "User is able to see Billing Type successfully",
                    "Failed to see Billing Type in billing details page." + common.getStrError());

}
@When("^I add the same account in Eligible accounts billing grid$")
public void clickSameAcctofRemovedCheckbox() {
       boolean blnResult = billingPage.clickAlreadySelectedAccountCheckbox();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User click the same account of removed account",
               "User should click the same account of removed account successfully",
               "User should able to click the same account of removed account successfully",
               "Failed to click the same account of removed account." + common.getStrError());
}
@When("^I should not see Remove Account warning message$")
public void verifyRemovedAccountWarningMsgNotDisplayed() {
       boolean blnResult = billingPage.verifyRemoveAcctWarningMsgNotDisplayed();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User click the same account of removed account",
                    "User should not see the remove account warning message successfully ",
                    "User is not able to see the remove account warning message successfully",
                    "Failed to not able to see the remove account warning message." + common.getStrError());
}
@When("^I remove the same account in Eligible accounts billing grid$")
public void clickSameAccountofAddAccountCheckbox() {
       boolean blnResult = billingPage.clickUnselectedAccountCheckbox();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User click the same account of added account checkbox",
               "User should click the same account of added account successfully",
               "User should able to click the same account of added account successfully",
               "Failed to click the same account of added account." + common.getStrError());
}
@When("^I should not see add Account warning message$")
public void verifyAddedAccountWarningMsgNotDisplayed() {
       boolean blnResult = billingPage.verifyAddedAcctWarningMsgNotDisplayed();
       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                "When User click the same account of added account checkbox",
               "User should not see the add account warning message successfully ",
               "User is not able to see the add account warning message successfully",
               "Failed to not able to see the add account warning message." + common.getStrError());
}

}
