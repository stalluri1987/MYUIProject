package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

/**
 * <p>
 * <br>
 * <b> Title: </b> NonBillableScheduleStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for NonBillableSchedule</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * NonBillableScheduleStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class NonBillableScheduleStepDef extends CommonStepDef {

	@Then("^I should see search box with default placeholder text$")
	public void searchBoxWithDefaultPlaceholderTextDisplayed() {
		boolean blnResult = nonBillableSchedule.searchBoxWithDefaultPlaceholderTextDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify search box with default placeholder text",
				"User should be able to see search box with default placeholder text",
				"Successfully able to see search box with default placeholder text",
				"Failed to see search box with default placeholder text: " + Common.strError);
	}

	@And("^I verify the availability of EDM Data grid header fields$")
	public void iVerifyTheAvailabilityOfEdmDataHeaderFields(DataTable headerFields) {
		boolean blnResult = nonBillableSchedule.iVerifyTheAvailabilityOfEdmDataHeaderFields(headerFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of EDM Data grid header fields",
				"User should be able to see all EDM Data grid header fields",
				"Successfully able to see all EDM Data grid header fields",
				"Failed to see all EDM Data grid header fields : " + Common.strError);
	}

	@And("^I verify the availability of Override EDM Data grid header fields$")
	public void iVerifyTheAvailabilityOfOvverideEdmDataHeaderFields(DataTable headerFields) {
		boolean blnResult = nonBillableSchedule.iVerifyTheAvailabilityOfOvverideEdmDataHeaderFields(headerFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Override EDM Data grid header fields",
				"User should be able to see all Override EDM Data grid header fields",
				"Successfully able to see all Override EDM Data grid header fields",
				"Failed to see all Override EDM Data grid header fields : " + Common.strError);
	}

	@And("^I enter Security No in search box$")
	public void iEnterSecurityNoInSearchBox() {
		boolean blnResult = nonBillableSchedule.iEnterDataInSearchBox(testData.get("strSecurityNo"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user enter the Security No in Search box",
				"User should be able to enter the Security No in Seach Box",
				"Successfully able to enter the Security No in Seach Box ",
				"Failed to enter the Security No in Seach Box : " + Common.strError);
	}

	@And("^I enter aggregated fund id in search box$")
	public void iEnterAggregatedFundIdInSearchBox() {
		boolean blnResult = nonBillableSchedule.iEnterDataInSearchBox(testData.get("strAggregatedFundId"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user enter the Aggregated Fund ID in Search box",
				"User should be able to enter the Aggregated Fund ID in Seach Box",
				"Successfully able to enter the Aggregated Fund ID in Seach Box ",
				"Failed to enter the Aggregated Fund ID in Seach Box : " + Common.strError);
	}

	@And("^I enter Symbol in search box$")
	public void iEnterSymbolInSearchBox() {
		boolean blnResult = nonBillableSchedule.iEnterDataInSearchBox(testData.get("strSymbol"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user enter the Symbol in Search box", "User should be able to enter the Symbol in Seach Box",
				"Successfully able to enter the Symbol in Seach Box ",
				"Failed to enter the Symbol in Seach Box : " + Common.strError);
	}

	@And("^I enter FBVA Security in search box$")
	public void iEnterFbvaSecurityInSearchBox() {
		boolean blnResult = nonBillableSchedule.iEnterDataInSearchBox(testData.get("strFbvaSecurity"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user enter the FBVA Security in Search box",
				"User should be able to enter the FBVA Security in Seach Box",
				"Successfully able to enter the FBVA Security in Seach Box ",
				"Failed to enter the FBVA Security in Seach Box : " + Common.strError);
	}

	@And("^I enter CUSIP in search box$")
	public void iEnterCusipInSearchBox() {
		boolean blnResult = nonBillableSchedule.iEnterDataInSearchBox(testData.get("strCusip"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user enter the CUSIP in Search box", "User should be able to enter the CUSIP in Seach Box",
				"Successfully able to enter the CUSIP in Seach Box ",
				"Failed to enter the CUSIP in Seach Box : " + Common.strError);
	}

	@And("^I select the populated data$")
	public void iSelectThePopulatedData() {
		boolean blnResult = nonBillableSchedule.iClickOnPopulatedData();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that user clicked on populated data", "User should be able to click on populated data",
				"Successfully able to click on populated data",
				"Failed to click on populated data : " + Common.strError);
	}

	@And("^I Verify EDM Data should be displayed when searched by CUSIP/FBVA Security/Symbol$")
	public void iVerifyEDMDataShouldBeDisplayedWhenSearchedByCusip() {
		boolean blnResult = nonBillableSchedule.iVerifyEDMData(testData.get("strCusip"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the EDM data is displayed",
				"User should be able to see the EDM data", "Successfully able to see the EDM data",
				"Failed to see the EDM data : " + Common.strError);
	}

	@And("^I Verify EDM Data should be displayed when searched by aggregated fund id$")
	public void iVerifyEDMDataShouldBeDisplayedWhenSearchedByAggregatedFundId() {
		boolean blnResult = nonBillableSchedule.iVerifyEDMData(testData.get("strAggregatedFundId"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the EDM data is displayed",
				"User should be able to see the EDM data", "Successfully able to see the EDM data",
				"Failed to see the EDM data : " + Common.strError);
	}

	@And("^I Verify EDM Data should be displayed when searched by Security No$")
	public void iVerifyEDMDataShouldBeDisplayedWhenSearchedBySecurityNo() {
		boolean blnResult = nonBillableSchedule.iVerifyEDMData(testData.get("strSecurityNo"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the EDM data is displayed",
				"User should be able to see the EDM data", "Successfully able to see the EDM data",
				"Failed to see the EDM data : " + Common.strError);
	}
	@Then("^I click on Add New button$")
	public void iClickonAddNewButton() {
		boolean blnResult = nonBillableSchedule.clickonAddNewButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Add New Button clicked",
				"User should be able to Click Add New button",
				"Successfully able to Click Add New button",
				"Failed to Click Add New button : " + Common.strError);
	}
	@Then("^I verify that Security No is displayed$")
	public void iVerifySecurityNoDisplay() {
		boolean blnResult = nonBillableSchedule.verifySecurityNoDisplay();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Security No is Displayed",
				"User should be able to see Security No",
				"Successfully able to see Security No",
				"Failed to see Security No : " + Common.strError);
	}
	@Then("^I enter Start Date Field$")
	public void iEnterStartDate() {
		boolean blnResult = nonBillableSchedule.enterStartDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Start Date is entered",
				"User should be able to enter Start Date",
				"Successfully able to enter Start Date",
				"Failed to enter Start Date : " + Common.strError);
	}
	@Then("^I enter End Date Field$")
	public void iEnterEndDate() {
		boolean blnResult = nonBillableSchedule.enterEndDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify End Date is entered",
				"User should be able to enter End Date",
				"Successfully able to enter End Date",
				"Failed to enter End Date : " + Common.strError);
	}
	@Then("^I enter Billing Category Field$")
	public void iEnterBillingCategory() {
		boolean blnResult = nonBillableSchedule.enterBillingCategory("Fully Billable");
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify BillingCategory Date is entered",
				"User should be able to enter BillingCategory Date",
				"Successfully able to enter BillingCategory Date",
				"Failed to enter BillingCategory Date : " + Common.strError);
	}
	@Then("^I click Save button$")
	public void iClickSaveButton() {
		boolean blnResult = nonBillableSchedule.clickSaveButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Save button is clicked",
				"User should be able to click Save Button",
				"Successfully able to click Save Button",
				"Failed to click Save Button : " + Common.strError);
	}
	@Then("^I verify Data Saved successfully$")
	public void iVerifyDataSaved() {
		boolean blnResult = nonBillableSchedule.verifyDataSaved();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Data is saved",
				"User should be able to see Data is saved",
				"Successfully able to see Data is saved",
				"Failed to see Data is saved : " + Common.strError);
	}
	@Then("^I click on Close button$")
	public void iClickCloseButton() {
		boolean blnResult = nonBillableSchedule.clickCloseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Close button is clicked",
				"User should be able to click Close Button",
				"Successfully able to click Close Button",
				"Failed to click Close Button : " + Common.strError);
	}
	
	
	@Then("^I click On Edit Link of the schedule")
	public void iClickEditLinkButton() {
		boolean blnResult = nonBillableSchedule.clickEditLinkButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Edit Link button is clicked",
				"User should be able to click Edit Link Button",
				"Successfully able to click Edit Link Button",
				"Failed to click Edit Link Button : " + Common.strError);
	}
	
	@Then("^I provide new Billing Category")
	public void iProvideBillingCategory() {
		boolean blnResult = nonBillableSchedule.enterBillingCategory("Non Billable");
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Billing Category is provided",
				"User should be able to provide Billing Category",
				"Successfully able to provide Billing Category",
				"Failed to provide Billing Category : " + Common.strError);
	}
	
	
	@Then("^I click on Delete Button in NB")
	public void iClickDeleteButton() {
		boolean blnResult = nonBillableSchedule.clickDeleteButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Delete Button is clicked",
				"User should be able to click Delete Button",
				"Successfully able to click Delete Button",
				"Failed to click Delete Button : " + Common.strError);
	}
	@Then("^I click on Yes button on pop up")
	public void iClickYesButton() {
		boolean blnResult = nonBillableSchedule.clickYesButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Delete Button is clicked",
				"User should be able to click Delete Button",
				"Successfully able to click Delete Button",
				"Failed to click Delete Button : " + Common.strError);
	}



	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
