package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * <br>
 * <b> Title: </b> ILocatorInitialize.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for ILocatorInitialize</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * checkForLocatorTypeAndInitialize : This method is used for check for locator
 * type and initialize them with value from FARM</br>
 * <br>
 * getLocatorDetails : This method is used for retrieving the locator
 * details(xpath, Id, Css etc) from FARM for given locator variables</br>
 * <br>
 * initializeLocatorValue : This method is used for initializing the locator
 * variable with value retrieved from FARM database based on locator type. Eg.
 * Variable headerXpath will be initialized with value stored under object name
 * 'headerXpath' and object xpath</br>
 *
 * @author aswain
 * @since 09/27/2019
 *        </p>
 */

public interface ILocatorInitialize {

	/**
	 * This method is used for check for locator type and initialize them with value
	 * from FARM
	 *
	 * @param pageObject - map object containing all the locator information from
	 *                   FARM for a given page
	 * @param field      - variable name of the locable in the page class
	 * @return void
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	default void checkForLocatorTypeAndInitialize(Map<String, HashMap<String, String>> pageObject, Field field,
			int pageId) {

		// modifying the pageiobject map if any extra scapce is there
		pageObject = pageObject.entrySet().stream()
				.collect(Collectors.toMap(e -> e.getKey().trim(), e -> e.getValue()));
		// checking for locator type and initializing them
		String[] locatorTypes = { LPLCoreConstents.XPATH, LPLCoreConstents.ID, LPLCoreConstents.CSS };
		for (String locatorType : locatorTypes) {
			// Retrieving the field/variable name
			String fieldName = field.getName();
			// Checking if the variable name represents a locator variables('xpath', 'css',
			// and 'id' suffix)
			if ((fieldName.toUpperCase().endsWith(locatorType))
					&& (getLocatorDetails(pageObject, fieldName, pageId).get(locatorType) != null)) {
				// Initialize the field/variable to a value read from FARM
				initializeLocatorValue(pageObject, field, fieldName, locatorType);
			}
		}
	}

	/**
	 * This method is used for retrieving the locator details(xpath, Id, Css etc)
	 * from FARM for given locator variables
	 *
	 * @param fieldName - name of the field/variable declared in this class
	 * @return Map<String, String>
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	default Map<String, String> getLocatorDetails(Map<String, HashMap<String, String>> pageObject, String fieldName,
			int pageId) {
		// Retrieving the locator details(Xpath, Css, ID etc) from FARM for given
		// locator variable
		Map<String, String> locatorDetails = pageObject.get(fieldName);
		if (locatorDetails == null)
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the locator details for " + fieldName + " for page ID " + pageId,
					"Locator details should be retrieved", "Locator details are successfully retrieved",
					"Failed to retrieve the locator details for " + fieldName
							+ ". Please check and add this locator in FARM. Variable names ending with 'Xpath', 'Id', and 'Css' are considered as locator variables. If "
							+ fieldName + " is not a locator variable, please rename it.",
					false);
		return locatorDetails;
	}

	/**
	 * This method is used for initializing the locator variable with value
	 * retrieved from FARM database based on locator type. Eg. Variable headerXpath
	 * will be initialized with value stored under object name 'headerXpath' and
	 * object xpath
	 *
	 * @param field       - refers to the field/variable declared in this class
	 * @param fieldName   - name of the field/variable declared in this class
	 * @param locatorType - type of the locator eg. Xpath, Css, Id
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	public default void initializeLocatorValue(Map<String, HashMap<String, String>> pageObject, Field field,
			String fieldName, String locatorType) {
		// Initializing the locator variable with value from FARM
		try {
			// Setting the field accessibility to true
			field.setAccessible(true);
			// Setting the locator variable to a value read from FARM
			field.set(this, pageObject.get(fieldName).get(locatorType));
		} catch (IllegalAccessException | IllegalArgumentException e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Initialization of page object variables for Dashboard page",
					"Page Objects should be successfully created for Dashboard class",
					"Page Objects successfully created for Dashboard class",
					"Failed to initialize the page objects of Dashboard from Farm for locator["
							+ field.getType().getName() + "]. Error:" + e.toString(),
					false);
		}
	}
}
