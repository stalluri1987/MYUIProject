package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> ProgramFeeManagementStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for ProgramFeeManagement</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * ProgramFeeManagementStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class ProgramFeeManagementStepDef extends CommonStepDef {
	public static final String OPTION = " option";
	public static final String PLATFORMDROPDOWNAVAILABLITY = "Verify the availability of Platform dropdown field options";

	@Then("^I verify the availability of Pricing Model dropdown field options$")
	public void iverifytheavailabilityofPricingModeldropdownfieldOptions(DataTable pricingModelTypes) {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofPricingModelDropdownFieldOptions(pricingModelTypes);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Pricing Model dropdown options",
				"User should be able to see all Pricing Model dropdown options",
				"Successfully able to see all Pricing Model dropdown options as expected",
				"Failed to see all Pricing Model dropdown options as expected : " + Common.strError);
	}

	@When("^I select REP AUM in the Pricing Model dropdown list$")
	public void iselectREPAUMinthePricingModeldropdownlist() {
		programFeeManagement.selectREPAUMinthePricingModelDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select REP AUM in the Pricing Model dropdown list", "User should able to select REP AUM",
				"Successfully able to select REP AUM", "Failed to select REP AUM :" + Common.strError);
	}

	@Then("^I verify the availability of Fee Component dropdown field options$")
	public void iverifytheavailabilityofFeeComponentdropdownfieldOptions(DataTable feeComponentTypes) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofFeeComponentDropDownFieldOptions(feeComponentTypes);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Fee Component dropdown field options",
				"User should be able to see all Fee Component dropdown options as expected",
				"Successfully able to see all Fee Component dropdown options as expected",
				"Failed to see all Fee Component dropdown options as expected : " + Common.strError);
	}

	@Then("^I verify the availability of MMC link$")
	public void iverifytheavailabilityofMMClink() {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofMMClink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availability of MMC link",
				"User should be able to see MMC link", "Successfully able to see MMC link",
				"Failed to see MMC link : " + Common.strError);
	}

	@Then("^I should see Next button is disable before selecting Fee Component Dropdown field$")
	public void ishouldseeNextbuttonisdisablebeforeselectingFeeComponentDropdownfield() {
		boolean blnResult = programFeeManagement.checkIfNextButtonisDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Next button is disable before selecting Fee Component Dropdown field",
				"User should be able to see Next button is disable Without Fee component selection",
				"Successfully able to see Next button is disable Without Fee component selection",
				"Failed to see Next button is disable Without Fee component selection : " + Common.strError);
	}

	@When("^I select Admin Fee$")
	public void iselectAdminFee() {
		programFeeManagement.iSelectAdminFee();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE, "Select Admin Fee",
				"User should able to select Admin Fee", "Successfully able to select Admin Fee",
				"Failed to select Admin Fee :" + Common.strError);
	}

	@Then("^I should see Next button get enable$")
	public void ishouldseeNextbuttongetenable() {
		boolean blnResult = programFeeManagement.iShouldSeeNextButtonGetEnable();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Next button get enable",
				"User should be able to see Next button get enable", "Successfully able to see Next button get enable",
				"Failed to see Next button get enable : " + Common.strError);
	}

	@Then("^I click on Next button$")
	public void iclickonNextbutton() {
		boolean blnResult = programFeeManagement.iClickonNextButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Next button",
				"User should be able to click Next Button", "Successfully able to click Next Button",
				"Failed to click Next Button :" + Common.strError);
	}

	@When("^I click on Export button under Schedule Management tab$")
	public void iclickonExportButton() {
		boolean blnResult = programFeeManagement.iclickonExportButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Export button",
				"User should be able to click Export Button", "Successfully able to click Export Button",
				"Failed to click Export Button :" + Common.strError);
	}

	@Then("^I should land on REP AUM - Manage Schedule page$")
	public void ishouldlandonManageSchedulepage() {
		boolean blnResult = programFeeManagement.iShouldLandOnREPAUMManageSchedulePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Manage Schedule page load",
				"User should be able to see Manage Schedule page", "Successfully able to see Manage Schedule page",
				"Failed to see Manage Schedule page : " + Common.strError);
	}

	@Then("^I verify ScheduleManagement tab is selected by default$")
	public void iverifyScheduleManagementtabisselectedbydefault() {
		boolean blnResult = programFeeManagement.iVerifyScheduleManagementTabIsSelectedbyDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify ScheduleManagement tab is selected by default",
				"User should be able to see Schedule Management tab is selected by default",
				"Successfully able to see Schedule Management tab is selected by default",
				"Failed to see Schedule Management tab is selected by default : " + Common.strError);
	}

	@When("^I select LPL SWS in the Pricing Model dropdown list$")
	public void iselectPremiumRIAinthePricingModeldropdownlist() {
		programFeeManagement.selectLPLSWSinthePricingModelDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select LPL SWS in the Pricing Model dropdown list", "User should able to select LPL SWS",
				"Successfully able to select LPL SWS", "Failed to select LPL SWS :" + Common.strError);
	}

	@When("^I select SWS Service Fee in the Fee Component dropdown list$")
	public void iselectPremiumServiceFeeintheFeeComponentdropdownlist() {
		programFeeManagement.iSelectPremiumServiceFee();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE, "Select SWS Service Fee",
				"User should able to select SWS Service Fee", "Successfully able to select SWS Service Fee",
				"Failed to select SWS Service Fee :" + Common.strError);
	}

	@Then("^I click on Rep/Firm Assignment Tracking tab$")
	public void iclickonRepAssignmentTrackingtab() {
		programFeeManagement.iclickonRepAssignmentTrackingTab();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Click on Rep Assignment Traking tab", "User should able to click on Rep/Firm Assignment Tracking tab",
				"Successfully able to click on Rep/Firm Assignment Tracking tab",
				"Failed to click on Rep/Firm Assignment Tracking tab :" + Common.strError);
	}

	@Then("^I click on Switch to Active Standard Assignments hyperlink$")
	public void iclickonSwitchtoActiveStandardAssignmentshyperlink() {
		programFeeManagement.iclickonSwitchtoActiveStandardhyperlink();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Click on Switch to Active Standard Assignments hyperlink",
				"User should able to click Switch to Active Standard Assignments hyperlink",
				"Successfully able to click on Switch to Active Standard Assignments hyperlink",
				"Failed to click on Switch to Active Standard Assignments hyperlink :" + Common.strError);
	}

	@Then("^I enter Rep ID/Name in Active Standard Assignments Filter criteria$")
	public void ienterRepIDNameinActiveStandardAssignmentsFiltercriteria() {
		boolean blnResult = programFeeManagement.enterRepIDorName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Rep ID/Name in filter criteria",
				"User should be able to enter Rep ID/Name", "Successfully able to enter enter Rep ID/Name",
				"Failed to enter enter Rep ID/Name : " + Common.strError);
	}

	@Then("^I click on Search button in Active Standard Assignments page$")
	public void iclickonSearchbuttoninActiveStandardAssignmentspage() {
		boolean blnResult = programFeeManagement.iClickOnSearchButtoninActiveStandardAssignmentspage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Search button under Active Standard Assignments page",
				"User should able to click on Search button under Active Standard Assignments page",
				"Successfully able to click on Search button under Active Standard Assignments page",
				"Failed to click on Search button under Active Standard Assignments page :" + Common.strError);
	}

	@Then("^I verify the display of fields in search results in Active Standard Assignments page$")
	public void iverifythedisplayoffieldsinsearchresultsinActiveStandardAssignmentspage(DataTable searchResultOptions) {
		boolean blnResult = programFeeManagement
				.verifyDisplayOfFieldsInSearchResultInactiveStandardAssignments(searchResultOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that display of fields for the searched Rep ID", "User should be able to see all search result",
				"Successfully able to see search results", "Failed to see search results : " + Common.strError);
	}

	@Then("^I click on Reset button$")
	public void iclickonResetbutton() {
		boolean blnResult = programFeeManagement.iClickOnResetButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Reset button",
				"User should able to click Reset button", "Successfully able to click Reset button",
				"Failed to click Reset button :" + Common.strError);
	}

	@Then("^I verify the availability of Fee Component dropdown field options for LPL SWS$")
	public void iverifytheavailabilityofFeeComponentdropdownfieldoptionsforLPLSWS(DataTable feeComponentTypes) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofFeeComponentDropDownFieldOptionsforLPLSWS(feeComponentTypes);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Fee Component dropdown field options for LPL SWS",
				"User should be able to see all Fee Component dropdown options for LPL SWS as expected",
				"Successfully able to see all Fee Component dropdown options for LPL SWS as expected",
				"Failed to see all Fee Component dropdown options for LPL SWS as expected : " + Common.strError);
	}

	@Then("^I should land on LPL SWS - Manage Schedule page$")
	public void ishouldlandonLPLSWSManageSchedulepage() {
		boolean blnResult = programFeeManagement.iShouldLandOnLPLSWSManageSchedulePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify LPL SWS - Manage Schedule page load",
				"User should be able to see LPL SWS - Manage Schedule page",
				"Successfully able to see LPL SWS - Manage Schedule page",
				"Failed to see LPL SWS - Manage Schedule page : " + Common.strError);
	}

	@Then("^I verify the default value selected for Select Platform dropdown$")
	public void iverifythedefaultvalueselectedforSelectPlatformdropdown() {
		boolean blnResult = programFeeManagement.verifyDefaultValueInSelectPlatformDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the default value selected for Platfor dropdown",
				"User should be able to see the default value selected for Platfor dropdown",
				"Successfully able to the default value selected for Platfor dropdown",
				"Failed to see the default value selected for Platfor dropdown : " + Common.strError);
	}

	@Then("^I verify the availability of Select Platform dropdown field options$")
	public void iverifytheavailabilityofSelectPlatformdropdownfieldoptions(DataTable selectPlatformList) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofSelectPlatformDropDownFieldOptions(selectPlatformList);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, PLATFORMDROPDOWNAVAILABLITY,
				"User should be able to see all Platform dropdown options as expected",
				"Successfully able to see all Platform dropdown options as expected",
				"Failed to see all Platform dropdown options as expected : " + Common.strError);
	}

	@Then("^I select MS in Select Platform dropdown list$")
	public void iselectMSinSelectPlatformdropdownlist() {
		programFeeManagement.selectMSinSelectPlatformDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MS in the Pricing Model dropdown list", "User should able to select MS",
				"Successfully able to select MS", "Failed to select MS :" + Common.strError);
	}

	@Then("^I select MWP in Select Platform dropdown list$")
	public void iselectMWPinSelectPlatformdropdownlist() {
		programFeeManagement.selectMWPinSelectPlatformDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MWP in the Pricing Model dropdown list", "User should able to select MWP",
				"Successfully able to select MWP", "Failed to select MWP :" + Common.strError);
	}

	@Then("^I select SAM in Select Platform dropdown list$")
	public void iselectSAMinSelectPlatformdropdownlist() {
		programFeeManagement.selectSAMinSelectPlatformDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select SAM in the Pricing Model dropdown list", "User should able to select SAM",
				"Successfully able to select SAM", "Failed to select SAM :" + Common.strError);
	}

	@Then("^I verify the availability of columns under Standard Schedule$")
	public void iverifytheavailabilityofcolumnsunderStandardSchedule(DataTable standardScheduleColumns) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofcolumnsunderStansardSchedule(standardScheduleColumns);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of columns under Standard Schedule and Other Schedule",
				"User should be able to see columns under Standard Schedule and Other Schedule",
				"Successfully able to see columns under Standard Schedule and Other Schedule",
				"Failed to see columns under Standard Schedule and Other Schedule : " + Common.strError);
	}

	@Then("^I verify the availability of columns under Other Schedules$")
	public void iverifytheavailabilityofcolumnsunderOtherSchedules(DataTable otherSchedulesColumns) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofcolumnsunderOtherSchedules(otherSchedulesColumns);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of columns under Standard Schedule and Other Schedule",
				"User should be able to see columns under Standard Schedule and Other Schedule",
				"Successfully able to see columns under Standard Schedule and Other Schedule",
				"Failed to see columns under Standard Schedule and Other Schedule : " + Common.strError);
	}

	@Then("^I verify the availability of data under Standard Schedule$")
	public void iverifytheavailabilityofdataunderStandardSchedule(DataTable standardScheduleData) {
		boolean blnResult = programFeeManagement.verifytheAvailabilityofdataunderStandardSchedule(standardScheduleData);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of data under Standard Schedule",
				"User should be able to see data under Standard Schedule as expected",
				"Successfully able to see data under Standard Schedule as expected",
				"Failed to see data under Standard Schedule as expected : " + Common.strError);
	}

	@Then("^I verify the availability of MS Standard 23bps under Schedule Name column$")
	public void iverifytheavailabilityofMSStandard23bpsunderScheduleNamecolumn() {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofMSStandard23bpsLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of MS Standard 23bps link",
				"User should be able to see MS Standard 23bps link", "Successfully able to see MS Standard 23bps link",
				"Failed to see MS Standard 23bps link : " + Common.strError);
	}

	@Then("^I verify the availability of MWP Standard 23bps under Schedule Name column$")
	public void iverifytheavailabilityofMWPStandard23bpsunderScheduleNamecolumn() {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofMWPStandard23bpsLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of MWP Standard 23bps link",
				"User should be able to see MWP Standard 23bps link",
				"Successfully able to see MWP Standard 23bps link",
				"Failed to see MWP Standard 23bps link : " + Common.strError);
	}

	@Then("^I verify the availability of SAMII Standard 18bps under Schedule Name column$")
	public void iverifytheavailabilityofSAMIIStandard18bpsunderScheduleNamecolumn() {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofSAMIIStandard18bpsLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of SAMII Standard 18bps link",
				"User should be able to see SAMII Standard 18bps link",
				"Successfully able to see SAMII Standard 18bps link",
				"Failed to see SAMII Standard 18bps link : " + Common.strError);
	}

	@Then("^I verify home button icon displayed$")
	public void iverifyhomebuttonicondisplayed() {
		boolean blnResult = programFeeManagement.verifyThehomeButtonicondisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the display of home button icon",
				"User should be able to see home button icon", "Successfully able to see home button icon",
				"Failed to see home button icon : " + Common.strError);
	}

	@When("^I click on Home button$")
	public void iclickonHomebutton() {
		boolean blnResult = programFeeManagement.iclickonHomeButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Home button",
				"User should able to click Home button", "Successfully able to click Home button",
				"Failed to click Home button :" + Common.strError);
	}

	@Then("^I verify the availability of Select Schedule dropdown field options$")
	public void iverifytheavailabilityofSelectScheduledropdownfieldoptions(DataTable selectScheduleList) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofSelectScheduleDropDownFieldOptions(selectScheduleList);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, PLATFORMDROPDOWNAVAILABLITY,
				"User should be able to see all Platform dropdown options as expected",
				"Successfully able to see all Platform dropdown options as expected",
				"Failed to see all Platform dropdown options as expected : " + Common.strError);
	}

	@Then("^I select CUSTOM in Select Schedule dropdown list$")
	public void iselectCUSTOMinSelectScheduledropdownlist() {
		programFeeManagement.selectCUSTOMinSelectScheduleDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select CUSTOM in Select Schedule dropdown list", "User should able to select CUSTOM",
				"Successfully able to select CUSTOM", "Failed to select CUSTOM :" + Common.strError);
	}

	@Then("^I select ONBOARDING in Select Schedule dropdown list$")
	public void iselectONBOARDINGinSelectScheduledropdownlist() {
		programFeeManagement.selectONBOARDINGinSelectScheduleDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select ONBOARDING in Select Schedule dropdown list", "User should able to select ONBOARDING",
				"Successfully able to select ONBOARDING", "Failed to select ONBOARDING :" + Common.strError);
	}

	@Then("^I select MISCELLANEOUS in Select Schedule dropdown list$")
	public void iselectMISCELLANEOUSinSelectScheduledropdownlist() {
		programFeeManagement.selectMISCELLANEOUSinSelectScheduleDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MISCELLANEOUS in Select Schedule dropdown list", "User should able to select MISCELLANEOUS",
				"Successfully able to select MISCELLANEOUS", "Failed to select MISCELLANEOUS :" + Common.strError);
	}

	@Then("^I verify the availability of Create New Schedule button$")
	public void iverifytheavailabilityofCreateNewSchedulebutton() {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofCreateNewScheduleButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of Create New Schedule button",
				"User should be able to see Create New Schedule button",
				"Successfully able to see Create New Schedule button",
				"Failed to see Create New Schedule button : " + Common.strError);
	}

	@When("^I click on Create New Schedule button$")
	public void iclickonCreateNewSchedulebutton() {
		boolean blnResult = programFeeManagement.iclickonCreateNewScheduleButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Create New Schedule button",
				"User should able to click Create New Schedule button",
				"Successfully able to click Create New Schedule button",
				"Failed to click Create New Schedule button :" + Common.strError);
	}

	@Then("^I verify the display of New Schedule window$")
	public void iverifythedisplayofNewSchedulewindow() {
		boolean blnResult = programFeeManagement.verifyThedisplayofNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of New Schedule window", "User should be able to see New Schedule window",
				"Successfully able to see New Schedule window",
				"Failed to see New Schedule window : " + Common.strError);
	}

	@Then("^I verify the availability of columns under Tier Structure$")
	public void iverifytheavailabilityofcolumnsunderTierStructure(DataTable tierStructureColumn) {
		boolean blnResult = programFeeManagement.verifytheAvailabilityofcolumnsunderTierStructure(tierStructureColumn);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of columns under Tier Structure",
				"User should be able to see columns under Tier Structure",
				"Successfully able to see columns under Tier Structure",
				"Failed to see columns under Tier Structure : " + Common.strError);
	}

	@Then("^I verify the availability of PLATFORM dropdown options in New Schedule window$")
	public void iverifytheavailabilityofPLATFORMdropdownoptionsinNewSchedulewindow(DataTable selectPlatformList) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofPLATFORMdropdownoptionsinNewSchedulewindow(selectPlatformList);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of PLATFORM dropdown options in New Schedule window",
				"User should be able to see PLATFORM dropdown options in New Schedule window as expected",
				"Successfully able to see PLATFORM dropdown options in New Schedule window as expected",
				"Failed to see PLATFORM dropdown options in New Schedule window as expected : " + Common.strError);
	}

	@Then("^I select MS in PLATFORM dropdown options in New Schedule window$")
	public void iselectMSinPLATFORMdropdownoptionsinNewSchedulewindow() {
		programFeeManagement.selectMSinPLATFORMDropdownOptionsinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MS in PLATFORM dropdown options in New Schedule window", "User should able to select MS",
				"Successfully able to select MS", "Failed to select MS :" + Common.strError);
	}

	@Then("^I select MWP in PLATFORM dropdown options in New Schedule window$")
	public void iselectMWPinPLATFORMdropdownoptionsinNewSchedulewindow() {
		programFeeManagement.selectMWPinPLATFORMDropdownOptionsinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MWP in PLATFORM dropdown options in New Schedule window", "User should able to select MWP",
				"Successfully able to select MWP", "Failed to select MWP :" + Common.strError);
	}

	@Then("^I select SAM in PLATFORM dropdown options in New Schedule window$")
	public void iselectSAMinPLATFORMdropdownoptionsinNewSchedulewindow() {
		programFeeManagement.selectSAMinPLATFORMDropdownOptionsinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select SAM in PLATFORM dropdown options in New Schedule window", "User should able to select SAM",
				"Successfully able to select SAM", "Failed to select SAM :" + Common.strError);
	}

	@Then("^I should see the Platform Name radio button is disabled in New Schedule window$")
	public void ishouldseethePlatformNameradiobuttonisdisabledinNewSchedulewindow(DataTable platformNameList) {
		boolean blnResult = programFeeManagement.checkIfPlatformNameisDisabledafterSelectingPlatform(platformNameList);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Platform Name radio button is disabled in New Schedule window after selecting Platform",
				"User should be able to see Platform Name radio button is disabled in New Schedule window after selecting Platform",
				"Successfully able to see Platform Name radio button is disabled in New Schedule window after selecting Platform",
				"Failed to see Platform Name radio button is disabled in New Schedule window after selecting Platform : "
						+ Common.strError);
	}

	@Then("^I verify the availability of SCHEDULE TYPE dropdown options in New Schedule window$")
	public void iverifytheavailabilityofSCHEDULETYPEdropdownoptionsinNewSchedulewindow(DataTable scheduleTypeList) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofSCHEDULETYPEdropdownoptionsinNewSchedulewindow(scheduleTypeList);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of SCHEDULE TYPE dropdown options in New Schedule window",
				"User should be able to see SCHEDULE TYPE dropdown options in New Schedule window as expected",
				"Successfully able to see SCHEDULE TYPE dropdown options in New Schedule window as expected",
				"Failed to see SCHEDULE TYPE dropdown options in New Schedule window as expected : " + Common.strError);
	}

	@Then("^I select CUSTOM Schedule Type in New Schedule window$")
	public void iselectCUSTOMScheduleTypeinNewSchedulewindow() {
		programFeeManagement.selectCUSTOMScheduleTypeinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select CUSTOM Schedule Type in New Schedule window", "User should able to select CUSTOM Schedule Type",
				"Successfully able to select CUSTOM Schedule Type",
				"Failed to select CUSTOM Schedule Type :" + Common.strError);
	}

	@Then("^I select ONBOARDING Schedule Type in New Schedule window$")
	public void iselectONBOARDINGScheduleTypeinNewSchedulewindow() {
		programFeeManagement.selectONBOARDINGScheduleTypeinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select ONBOARDING Schedule Type in New Schedule window",
				"User should able to select ONBOARDING Schedule Type",
				"Successfully able to select ONBOARDING Schedule Type",
				"Failed to select ONBOARDING Schedule Type :" + Common.strError);
	}

	@Then("^I select MISCELLANEOUS Schedule Type in New Schedule window$")
	public void iselectMISCELLANEOUSScheduleTypeinNewSchedulewindow() {
		programFeeManagement.selectMISCELLANEOUSScheduleTypeinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MISCELLANEOUS Schedule Type in New Schedule window",
				"User should able to select MISCELLANEOUS Schedule Type",
				"Successfully able to select MISCELLANEOUS Schedule Type",
				"Failed to select MISCELLANEOUS Schedule Type :" + Common.strError);
	}

	@Then("^I enter SCHEDULE NAME in New Schedule window$")
	public void ienterSCHEDULENAMEinNewSchedulewindow() {
		boolean blnResult = programFeeManagement.enterSCHEDULENAME();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter SCHEDULE NAME in New Schedule window",
				"User should be able to enter SCHEDULE NAME in New Schedule window",
				"Successfully able to enter SCHEDULE NAME in New Schedule window",
				"Failed to enter SCHEDULE NAME in New Schedule window : " + Common.strError);
	}

	@Then("^I enter FEE PERCENTAGE in Tier1$")
	public void ienterFEEPERCENTAGEinTier1() {
		boolean blnResult = programFeeManagement.enterFEEPERCENTAGEinTier1();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter FEE PERCENTAGE in Tier1",
				"User should be able to enter FEE PERCENTAGE in Tier1",
				"Successfully able to enter FEE PERCENTAGE in Tier1",
				"Failed to enter FEE PERCENTAGE in Tier1 : " + Common.strError);
	}

	@Then("^I enter FEE PERCENTAGE$")
	public void ienterFEEPERCENTAGE() {
		boolean blnResult = programFeeManagement.enterFeePercentage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter FEE PERCENTAGE in Tier1",
				"User should be able to enter FEE PERCENTAGE in Tier1",
				"Successfully able to enter FEE PERCENTAGE in Tier1",
				"Failed to enter FEE PERCENTAGE in Tier1 : " + Common.strError);
	}

	@Then("^I enter MINIMUM AUM in Tier2$")
	public void ienterMINIMUMAUMinTier2() {
		boolean blnResult = programFeeManagement.enterMINIMUMAUMinTier2();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter MINIMUM AUM in Tier2",
				"User should be able to enter MINIMUM AUM in Tier2", "Successfully able to enter MINIMUM AUM in Tier2",
				"Failed to enter MINIMUM AUM in Tier2 : " + Common.strError);
	}

	@Then("^I enter FEE PERCENTAGE in Tier2$")
	public void ienterFEEPERCENTAGEinTier2() {
		boolean blnResult = programFeeManagement.enterFEEPERCENTAGEinTier2();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter FEE PERCENTAGE in Tier2",
				"User should be able to enter FEE PERCENTAGE in Tier2",
				"Successfully able to enter FEE PERCENTAGE in Tier2",
				"Failed to enter FEE PERCENTAGE in Tier2 : " + Common.strError);
	}

	@When("^I click on Add Tier button$")
	public void iclickonAddTierbutton() {
		boolean blnResult = programFeeManagement.iclickonAddTierbutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on +Add Tier button",
				"User should able to click +Add Tier button", "Successfully able to click +Add Tier button",
				"Failed to click +Add Tier button :" + Common.strError);
	}

	@Then("^I enter MINIMUM AUM in Tier3$")
	public void ienterMINIMUMAUMinTier3() {
		boolean blnResult = programFeeManagement.enterMINIMUMAUMinTier3();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter MINIMUM AUM in Tier3",
				"User should be able to enter MINIMUM AUM in Tier3", "Successfully able to enter MINIMUM AUM in Tier3",
				"Failed to enter MINIMUM AUM in Tier3 : " + Common.strError);
	}

	@Then("^I enter FEE PERCENTAGE in Tier3$")
	public void ienterFEEPERCENTAGEinTier3() {
		boolean blnResult = programFeeManagement.enterFEEPERCENTAGEinTier3();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter FEE PERCENTAGE in Tier3",
				"User should be able to enter FEE PERCENTAGE in Tier3",
				"Successfully able to enter FEE PERCENTAGE in Tier3",
				"Failed to enter FEE PERCENTAGE in Tier3 : " + Common.strError);
	}

	@When("^I click on Save button$")
	public void iclickonSavebutton() {
		boolean blnResult = programFeeManagement.iclickonSavebutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Save button Button",
				"User should able to click Save button", "Successfully able to click Save button",
				"Failed to click Save button :" + Common.strError);
	}

	@When("^I click on Delete Action icon under Other Schedules$")
	public void iclickonDelteiconActionunderOtherSchedules() {
		boolean blnResult = programFeeManagement.iclickonDeleteiconforCreatedSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Delete Action icon under Other Schedules",
				"User should able to click Delete Action icon under Other Schedules",
				"Successfully able to click Delete Action icon under Other Schedules",
				"Failed to click Delete Action icon under Other Schedules :" + Common.strError);
	}

	@When("^I click on Radio Button to Select Created Schedule$")
	public void iclickonRadioButtontoSelectCreatedSchedule() {
		boolean blnResult = programFeeManagement.iclickonRadioButton1underOtherSchedules();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Save button",
				"User should able to click Radio Button to Select Created Schedule",
				"Successfully able to click Radio Button to Select Created Schedule",
				"Failed to click Radio Button to Select Created Schedule :" + Common.strError);
	}

	@When("^I click on Delete Button$")
	public void iclickonDelteButton() {
		boolean blnResult = programFeeManagement.iclickonDeleteButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete button",
				"User should able to click Delete button", "Successfully able to click Delete button",
				"Failed to click Delete button :" + Common.strError);
	}

	@Then("^I enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value$")
	public void ienterFEEPERCENTAGEinTier2gretaerthanTier1value() {
		boolean blnResult = programFeeManagement.enterFEEPERCENTAGEinTier2gretaerthanTier1value();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value",
				"User should be able to enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value",
				"Successfully able to enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value",
				"Failed to enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value : " + Common.strError);
	}

	@When("^I verify the display of error message alert$")
	public void iVerifytheDisplayoferrormessagealert() {
		boolean blnResult = programFeeManagement.iVerifytheDisplayoferrormessagealert();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Save button",
				"User should able to click Save button", "Successfully able to click Save button",
				"Failed to click Save button :" + Common.strError);
	}

	@When("^I click on Create New Assignment Button$")
	public void iclickonCreateNewAssignmentbutton() {
		boolean blnResult = programFeeManagement.iclickonCreateNewAssignmentButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Create New Assignment button",
				"User should able to click Create New Assignment button",
				"Successfully able to click Create New Assignment button",
				"Failed to click Create New Assignment button :" + Common.strError);
	}

	@When("^I verify the display of New Assignment window$")
	public void iVerifytheDisplayofNewAssignmentwindow() {
		boolean blnResult = programFeeManagement.iVerifytheDisplayofNewAssignmentwindow();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of New Assignment window", "User should able to see New Assignment window",
				"Successfully able to see New Assignment window",
				"Failed to click see New Assignment window :" + Common.strError);
	}

	@Then("^I verify the availability of search dropdown options in New Assignment window$")
	public void iverifythAvailabilityofSearchDropdownOptionsinNewAssignmentwindow(DataTable searchDropdownList) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofSearchDropdownOptionsinNewAssignmentwindow(searchDropdownList);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search dropdown options in New Assignment window",
				"User should be able to see search dropdown options in New Assignment window as expected",
				"Successfully able to see search dropdown options in New Assignment window as expected",
				"Failed to see search dropdown options in New Assignment window as expected : " + Common.strError);
	}

	@Then("^I enter RepID in Search REP Textbox$")
	public void iEnterRepIDinSearchREPTextbox() {
		boolean blnResult = programFeeManagement.enterRepIDinSearchREPTextbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value",
				"User should be able to enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value",
				"Successfully able to enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value",
				"Failed to enter FEE PERCENTAGE in Tier2 gretaer than Tier1 value : " + Common.strError);
	}

	@Then("^I enter Firm in Search FIRM Textbox$")
	public void iEnterFirminSearchFIRMTextbox() {
		boolean blnResult = programFeeManagement.iEnterFirminSearchFIRMTextbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Firm in Search FIRM Textbox",
				"User should be able to enter Firm in Search FIRM Textbox",
				"Successfully able to enter Firm in Search FIRM Textbox",
				"Failed to enter Firm in Search FIRM Textbox : " + Common.strError);
	}

	@When("^I click on Submit button in New Assignment window$")
	public void iclickonSubmitbuttoninNewAssignmentwindow() {
		boolean blnResult = programFeeManagement.iclickonSubmitButtoninNewAssignmentwindow();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Submit button in New Assignment window",
				"User should able to click Submit button in New Assignment window",
				"Successfully able to click Submit button in New Assignment window",
				"Failed to click Submit button in New Assignment window :" + Common.strError);
	}

	@Then("^I enter Rep ID/Name in Custom Assignments Filter criteria$")
	public void iEnterRepIDinCustomAssignmentFilterCriteria() {
		boolean blnResult = programFeeManagement.enterRepIDinCustomAssignmentFilterCriteria();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Rep ID/Name in Custom Assignments Filter criteria",
				"User should be able to enter Rep ID/Name in Custom Assignments Filter criteria",
				"Successfully able to enter Rep ID/Name in Custom Assignments Filter criteria",
				"Failed to enter Rep ID/Name in Custom Assignments Filter criteria : " + Common.strError);
	}

	@Then("^I click on Search button in Custom Assignments page$")
	public void iclickonSearchbuttoninCustomAssignmentspage() {
		boolean blnResult = programFeeManagement.iClickOnSearchButtoninCustomAssignmentspage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Search button",
				"User should able to click Search button", "Successfully able to click Search button",
				"Failed to click Search button :" + Common.strError);
	}

	@Then("^I verify the display of fields in search results in Custom Assignments page$")
	public void iverifythedisplayoffieldsinsearchResultsinCustomAssignmentspage(DataTable searchResultOptions) {
		boolean blnResult = programFeeManagement
				.verifyDisplayOfFieldsInSearchResultInCustomAssignments(searchResultOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that display of fields for the searched Rep ID", "User should be able to see all search result",
				"Successfully able to see search results", "Failed to see search results : " + Common.strError);
	}

	@Then("^I verify the availability of ScheduleName dropdown options in New Assignment window$")
	public void iverifythAvailabilityofScheduleNameDropdownOptionsinNewAssignmentwindow(
			DataTable scheduleNameDropdownList) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofScheduleNameDropdownOptionsinNewAssignmentwindow(scheduleNameDropdownList);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of ScheduleName dropdown options in New Assignment window",
				"User should be able to see ScheduleName dropdown options in New Assignment window as expected",
				"Successfully able to see ScheduleName dropdown options in New Assignment window as expected",
				"Failed to see ScheduleName dropdown options in New Assignment window as expected : "
						+ Common.strError);
	}

	@Then("^I click on Cancel button in New Assignment window$")
	public void iclickonCancelbuttoninNewAssignmentwindow() {
		boolean blnResult = programFeeManagement.iClickOnCancelbuttoninNewAssignmentwindow();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Search button",
				"User should able to click Search button", "Successfully able to click Search button",
				"Failed to click Search button :" + Common.strError);
	}

	@Given("^I click on Reports tab$")
	public void clickOnReportsTab() {
		boolean blnResult = programFeeManagement.clickOnReportsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Reports tab",
				"User should able to click Reports tab", "Successfully able to click Reports tab",
				"Failed to click Reports tab :" + Common.strError);
	}

	@Then("^I verify the availability of view report dropdown field options$")
	public void verifyTheAvailabilityofViewreportDropdownFieldoptions(DataTable reportTypes) {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofViewreportDropdownFieldoptions(reportTypes);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of view report dropdown field options",
				"User should be able to see all view report dropdown field options",
				"Successfully able to see all view report dropdown field options",
				"Failed to see all view report dropdown field options : " + Common.strError);
	}

	@Then("^I verify the availability of table column headers$")
	public void verifyTheAvailabilityofMasterAccountListTableColumns(DataTable culumnHeaders) {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofMasterAccountListTableColumns(culumnHeaders);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of MasterAccountList table column headers",
				"User should be able to see all MasterAccountList table column headers",
				"Successfully able to see all MasterAccountList table column headers",
				"Failed to see all MasterAccountList table column headers : " + Common.strError);
	}

	@Then("^I verify the availability of search field options$")
	public void verifyTheAvailabilityofHistoricalBillingDetailsSearchFieldOptions(DataTable serachFieldOptions) {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofHistoricalBillingDetailsSearchFieldOptions(serachFieldOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Historical Billing Details report search fields options",
				"User should be able to see all Historical Billing Details report search fields options",
				"Successfully able to see all Historical Billing Details report search fields options",
				"Failed to see all Historical Billing Details report search fields options : " + Common.strError);
	}

	@Then("^I verify the availability of Onboarding Period Termination Warnings Report Headers$")
	public void verifyOnboardingTerminationWarningsReportHeaders(DataTable reportHeaders) {
		boolean blnResult = programFeeManagement.verifyOnboardingTerminationWarningsReportHeaders(reportHeaders);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Historical Billing Details report search fields options",
				"User should be able to see all Historical Billing Details report search fields options",
				"Successfully able to see all Historical Billing Details report search fields options",
				"Failed to see all Historical Billing Details report search fields options : " + Common.strError);
	}

	@Then("^I should see Export button is disable$")
	public void exportButtonIsDisable() {
		boolean blnResult = programFeeManagement.exportButtonIsDisable();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Export button current state",
				"User should be able to see Export button is disable",
				"Successfully able to see Export button is disable",
				"Failed to see Export button is disable : " + Common.strError);
	}

	@Then("^I should see Master Account List for Models report opened in new tab$")
	public void masterAccountReportOpenedInNewTab() {
		boolean blnResult = programFeeManagement.masterAccountReportOpenedInNewTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Export button current state",
				"User should be able to see Master Account List for Models report opened in new tab",
				"Successfully able to see Master Account List for Models report opened in new tab",
				"Failed to see Master Account List for Models report opened in new tab : " + Common.strError);
	}

	@When("^I select (.+) option$")
	public void selectReportOption(String selectReportType) {
		boolean blnResult = programFeeManagement.selectReportOption(selectReportType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select " + selectReportType + OPTION,
				"User should able to select " + selectReportType + OPTION,
				"Successfully able to select " + selectReportType + OPTION,
				"Failed to click select " + selectReportType + " option:" + Common.strError);
	}

	@When("^I should see Export button got enabled$")
	public void exportButtonIsEnabled() {
		boolean blnResult = programFeeManagement.exportButtonIsEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the current state of Export button", "User should be able to see Export button got enabled",
				"Successfully able to see Export button got enabled",
				"Failed to see Export button got enabled : " + Common.strError);
	}

	@When("^I verify the availability of filter criteria fields under REP Assignment Report$")
	public void verifyFilterCriteriaFieldsunderREPAssignmentReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaFieldsunderREPAssignmentReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria fields under REP Assignment Report",
				"User should be able to see all filter criteria fields under REP Assignment Report",
				"Successfully able to see filter criteria fields under REP Assignment Report",
				"Failed to see all filter criteria fields under REP Assignment Report: " + Common.strError);
	}

	@When("^I verify the availability of filter criteria of date fields under REP Assignment Report$")
	public void verifyFilterCriteriaDateFieldsunderREPAssignmentReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaDateFieldsunderREPAssignmentReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria of date fields under REP Assignment Report",
				"User should be able to see all filter criteria of date fields under REP Assignment Report",
				"Successfully able to see filter criteria of date fields under REP Assignment Report",
				"Failed to see all filter criteria of date fields under REP Assignment Report: " + Common.strError);
	}

	@When("^I verify the availability of filter criteria of schedule type dropdown options under Rep Assignment report$")
	public void verifyFilterCriteriaOfScheduleTypeDropDownOptionsunderREPAssignmentReport(
			DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaOfScheduleTypeDropDownOptionsunderREPAssignmentReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria of schedule type dropdown options under REP Assignment Report",
				"User should be able to see all filter criteria of schedule type dropdown options under REP Assignment Report",
				"Successfully able to see filter criteria of schedule type dropdown options under REP Assignment Report",
				"Failed to see all filter criteria of schedule type dropdown options under REP Assignment Report: "
						+ Common.strError);
	}

	@When("^I verify the availability of filter criteria of select assignment status dropdown options under Rep Assignment report$")
	public void verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionsUnderREPAssignmentReport(
			DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionsUnderREPAssignmentReport(
						filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria of Assignment status options under REP Assignment Report",
				"User should be able to see all filter criteria of Assignment status options under REP Assignment Report",
				"Successfully able to see filter criteria of Assignment status options under REP Assignment Report",
				"Failed to see all filter criteria of Assignment status options under REP Assignment Report: "
						+ Common.strError);
	}

	@When("^I click on Export button under Reports tab$")
	public void clickOnExportButtonUnderReportstab() {
		boolean blnResult = programFeeManagement.clickOnExportButtonUnderReportstab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Export button",
				"User should able to click Export button", "Successfully able to click Export button",
				"Failed to click Export button :" + Common.strError);
	}

	@When("^I click on Export dropdown and select report$")
	public void clickOnExportDropDownAndSelectReportUnderReportstab() {
		boolean blnResult = programFeeManagement.clickOnExportDropDownAndSelectReportUnderReportstab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Export dropdown and select report",
				"User should able to click Export dropdown and select report",
				"Successfully able to click Export dropdown and select report",
				"Failed to click Export dropdown and select report :" + Common.strError);
	}

	@Then("^I verify file exported successfully$")
	public void checkIfReportExportedSuccessfully() {
		boolean blnResult = programFeeManagement.checkIfReportExportedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify if a file exported sucessfully",
				"User should be able to see file exported successfully",
				"Successfully able to see file exported successfully",
				"Failed to see  file exported successfully : " + Common.strError);
	}

	@Then("^I should see (.+) downloaded successfully$")
	public void checkIfReportDownloadedSuccessfully(String downloadedReportType) {
		boolean blnResult = programFeeManagement.checkIfReportDownloadedSuccessfully(downloadedReportType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file " + downloadedReportType + " downloaded sucessfully",
				"User should be able to see " + downloadedReportType + " file downloaded successfully",
				"Successfully able to see " + downloadedReportType + " file downloaded successfully",
				"Failed to see " + downloadedReportType + " file downloaded successfully : " + Common.strError);
	}

	@Then("^I verify the availability of filter criteria fields under Admin fee schedule report$")
	public void verifyFilterCriteriaFieldsunderAdminfeeschedulereport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaFieldsunderAdminfeeschedulereport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria fields under Admin fee schedule report",
				"User should be able to see all filter criteria fields under Admin fee schedule report",
				"Successfully able to see all filter criteria fields under Admin fee schedule report",
				"Failed to see all filter criteria fields under Admin fee schedule report : " + Common.strError);
	}

	@Then("^I verify the availability of filter criteria fields of different scedule type dropdown$")
	public void verifyFilterCriteriaFieldofDifferentSceduleTypeDropdown(DataTable scheduleTypes) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaFieldofDifferentSceduleTypesDropdown(scheduleTypes);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria fields of different scedule type dropdown",
				"User should be able to see all filter criteria fields of different scedule type dropdown",
				"Successfully able to see all filter criteria fields of different scedule type dropdown",
				"Failed to see all filter criteria fields of different scedule type dropdown : " + Common.strError);
	}

	@Then("^I should see Search button displayed$")
	public void searchButtonDisplayed() {
		boolean blnResult = programFeeManagement.searchButtonDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availablity of Search button",
				"User should be able to see Search button", "Successfully able to see Search button",
				"Failed to see Search button : " + Common.strError);
	}

	@Then("^I should see Reset button displayed$")
	public void resetButtonDisplayed() {
		boolean blnResult = programFeeManagement.resetButtonDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availablity of Reset button",
				"User should be able to see Reset button", "Successfully able to see Reset button",
				"Failed to see Reset button : " + Common.strError);
	}

	@Given("^I verify the availability of filter criteria fields under Admin fee report$")
	public void verifyFilterCriteriaFieldsunderAdminfeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement.verifyFilterCriteriaFieldsunderAdminfeeReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria fields under Admin fee report",
				"User should be able to see all filter criteria fields under Admin fee report",
				"Successfully able to see all filter criteria fields under Admin fee report",
				"Failed to see all filter criteria fields under Admin fee report as expected : " + Common.strError);
	}

	@Given("^I verify the availability of filter criteria date fields under Admin fee report$")
	public void verifyFilterCriteriaDateFieldsunderAdminfeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaDateFieldsunderAdminfeeReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria date fields under Admin fee report",
				"User should be able to see all filte criteria date fields under Admin fee report",
				"Successfully able to see all filter criteria date fields under Admin fee report",
				"Failed to see all filter criteria date fields under Admin fee report as expected : "
						+ Common.strError);
	}

	@Given("^I verify the table headers$")
	public void verifyThetableHeaders(DataTable tableHeaders) {
		boolean blnResult = programFeeManagement.verifyThetableHeaders(tableHeaders);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of all table headers", "User should be able to see all table headers",
				"Successfully able to see all table headers", "Failed to see all table headers : " + Common.strError);
	}

	@Given("^I verify the table headers of rep Aum Admin fee Report$")
	public void verifyThetableHeadersOfAdminFeeReport(DataTable tableHeaders) {
		boolean blnResult = programFeeManagement.verifyThetableHeadersOfAdminFeeReport(tableHeaders);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of all table headers of rep Aum Admin fee Report",
				"User should be able to see all table headers of rep Aum Admin fee Report",
				"Successfully able to see all table headers v",
				"Failed to see all table headers of rep Aum Admin fee Report: " + Common.strError);
	}

	@Given("^I verify the availability of filter criteria fields under AUM - by Program report$")
	public void verifyFilterCriteriaFieldsunderAumByProgramReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaFieldsunderAumByProgramReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria fields under AUM - by Program report",
				"User should be able to see all filter criteria fields under AUM - by Program report as expected",
				"Successfully able to see all filter criteria fields under AUM - by Program report as expected",
				"Failed to see all filter criteria fields under AUM - by Program report as expected : "
						+ Common.strError);
	}

	@Then("^I verify the availability of REP AUM Standard data under Standard Schedule$")
	public void iverifytheavailabilityofREPAUMStandarddataunderStandardSchedule(DataTable standardScheduleData) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofREPAUMStandardDataunderStandardSchedule(standardScheduleData);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of data under Standard Schedule",
				"User should be able to see data under Standard Schedule as expected",
				"Successfully able to see data under Standard Schedule as expected",
				"Failed to see data under Standard Schedule as expected : " + Common.strError);

	}

	@Then("^I verify the availability of Rep AUM Standard under Schedule Name column$")
	public void iverifytheavailabilityofRepAUMStandardunderScheduleNamecolumn() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofRepAUMStandardScheduleLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Rep AUM Standard link", "User should be able to see Rep AUM Standard link",
				"Successfully able to see Rep AUM Standard link",
				"Failed to see Rep AUM Standard link : " + Common.strError);
	}

	@Then("^I verify the availability of Standard Flat Feeschedule - Admin Fee data under Standard Schedule$")
	public void iverifytheavailabilityofStandardFlatFeescheduleAdminFeeDataUnderStandardSchedule(
			DataTable standardScheduleData) {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofStandardFlatFeescheduleAdminFeeData(standardScheduleData);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Standard Flat Feeschedule - Admin Fee data under Standard Schedule",
				"User should be able to Standard Flat Feeschedule - Admin Fee data under Standard Schedule",
				"Successfully able to see Standard Flat Feeschedule - Admin Fee data under Standard Schedule",
				"Failed to see Standard Flat Feeschedule - Admin Fee data under Standard Schedule : "
						+ Common.strError);
	}

	@Then("^I verify Minimum AUM for Tier1 is disabled$")
	public void iverifyMinimumAUMforTier1isdisabled() {
		boolean blnResult = programFeeManagement.verifyMinimumAUMforTier1isdisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Minimum AUM for Tier1 is disabled",
				"User should be able to see Minimum AUM for Tier1 is disabled",
				"Successfully able to see Minimum AUM for Tier1 is disabled",
				"Failed to see Minimum AUM for Tier1 is disabled : " + Common.strError);
	}

	@When("^I select Trade Admin Fee in the Fee Component dropdown list$")
	public void iselectTradeAdminFeeintheFeeComponentdropdownlist() {
		programFeeManagement.iSelectTradeAdminFee();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE, "Select Trade Admin Fee",
				"User should able to select Trade Admin Fee", "Successfully able to select Trade Admin Fee",
				"Failed to select Trade Admin Fee :" + Common.strError);
	}

	@Then("^I should land on REP AUM - Trade Admin Fee : Manage Schedule page$")
	public void ishouldlandonREPAUMTradeAdminFeeManageSchedulepage() {
		boolean blnResult = programFeeManagement.iShouldLandOnREPAUMTradeAdminFeeManageSchedulePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify LPL SWS - Manage Schedule page load",
				"User should be able to see LPL SWS - Manage Schedule page",
				"Successfully able to see LPL SWS - Manage Schedule page",
				"Failed to see LPL SWS - Manage Schedule page : " + Common.strError);
	}

	@Given("^I verify the availability of Platform dropdown field options$")
	public void verifyTheavailabilityFfPlatformDropdownfieldOptions(DataTable dropDownOptions) {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofPlatformDropdownOptions(dropDownOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, PLATFORMDROPDOWNAVAILABLITY,
				"User should be able to see all Platform dropdown field options",
				"Successfully able to see all Platform dropdown field options",
				"Failed to see all Platform dropdown field options : " + Common.strError);
	}

	@When("^I enter Start date$")
	public void enterStartdate() {
		programFeeManagement.enterStartdate();
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE, "Enter Start date",
				"User should be able to enter Start date", "Successfully able to enter Start date",
				"Failed to enter Start date : " + Common.strError);
	}

	@When("^I enter End date$")
	public void enterEnddate() {
		boolean blnResult = programFeeManagement.enterEnddate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter End date",
				"User should be able to enter End date", "Successfully able to enter End date",
				"Failed to enter End date : " + Common.strError);
	}

	@When("^I select Platform$")
	public void selectPlatform() {
		boolean blnResult = programFeeManagement.selectPlatform();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Platform",
				"User should be able to Select Platform", "Successfully able to Select Platforme",
				"Failed to Select Platform : " + Common.strError);
	}

	@When("^I select Schedule name$")
	public void selectSchedulename() {
		boolean blnResult = programFeeManagement.selectSchedulename();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Schedule",
				"User should be able to Select Schedule", "Successfully able to Select Schedule",
				"Failed to Select Schedule : " + Common.strError);
	}

	@When("^I enter Note$")
	public void enterNote() {
		boolean blnResult = programFeeManagement.enterNote();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Note",
				"User should be able to enter Note", "Successfully able to enter enter Note",
				"Failed to enter enter Note : " + Common.strError);
	}

	@When("^I click on Submit$")
	public void clickonSubmit() {
		boolean blnResult = programFeeManagement.clickonSubmit();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Submit button",
				"User should able to click Submit button", "Successfully able to click Submit button",
				"Failed to click Submit button :" + Common.strError);
	}

	@Then("^I should see Assignment created successfully$")
	public void assignmentCreatedSuccessfully() {
		boolean blnResult = programFeeManagement.assignmentCreatedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Assignment creation",
				"User should be able to see Assignment created successfully",
				"Successfully able to see Assignment created successfully",
				"Failed to see Assignment created successfully : " + Common.strError);
	}

	@When("^I select newly added Assignment$")
	public void selectNewlyAddedAssignment() {
		boolean blnResult = programFeeManagement.selectNewlyAddedAssignment();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Newly added Assignment",
				"User should be able to see newly added Assignment", "Successfully able to see newly added Assignment",
				"Failed to see newly added Assignment : " + Common.strError);
	}

	@When("^I select (.+) from Action dropdown$")
	public void selectCancelAssignmentOption(String actionType) {
		boolean blnResult = programFeeManagement.selectCancelAssignmentOption(actionType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select " + actionType + " Assignment",
				"User should be able to " + actionType + " Assignment",
				"Successfully able to " + actionType + " Assignment",
				"Failed to " + actionType + " Assignment : " + Common.strError);
	}

	@Then("^I should see Assignment cancelled successfully$")
	public void assignmentCancelledSuccessfully() {
		boolean blnResult = programFeeManagement.assignmentCancelledSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Assignment status",
				"User should be able to see Assignment cancelled successfully",
				"Successfully able to see Assignment cancelled successfully",
				"Failed to see Assignment cancellation : " + Common.strError);
	}

	@Given("^I verify the availability of Select Assignment dropdown field options$")
	public void verifyTheAvailabilityofSelectAssignmentdropdownFieldOptions(DataTable dropDownOptions) {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofSelectAssignmentdropdownFieldOptions(dropDownOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verifying Assignment dropdown field options",
				"User should be able to see all Assignment dropdown field options",
				"Successfully able to see all Assignment dropdown field options",
				"Failed to see all Assignment dropdown field options : " + Common.strError);
	}

	@When("^I select Custom Assignments option under Rep/Firm Assignment Tracking tab$")
	public void selectCustomAssignmentsOption() {
		programFeeManagement.selectCustomAssignmentsOption();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select Custom Assignments option under Rep/Firm Assignment Tracking tab",
				"User should able to select Custom Assignments option",
				"Successfully able to select Custom Assignments option",
				"Failed to select Custom Assignments option :" + Common.strError);
	}

	@When("^I should see only Custom Assignments records displayed$")
	public void customAssignmentsRecordsDisplayed() {
		boolean blnResult = programFeeManagement.customAssignmentsRecordsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Custom Assignments records",
				"User should be able to see Custom Assignments records successfully",
				"Successfully able to see Custom Assignments records successfully",
				"Failed to see Custom Assignments records : " + Common.strError);
	}

	@When("^I should see only Standard Assignments records displayed$")
	public void standardAssignmentsRecordsDisplayed() {
		boolean blnResult = programFeeManagement.standardAssignmentsRecordsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Standard Assignments records",
				"User should be able to see Standard Assignments records successfully",
				"Successfully able to see Standard Assignments records successfully",
				"Failed to see Standard Assignments records : " + Common.strError);
	}

	@When("^I select first Standard Assignment record$")
	public void selectFirstStandardAssignmentRecord() {
		programFeeManagement.selectFirstStandardAssignmentRecord();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select first Standard Assignments record under Searched result",
				"User should able to select first Standard Assignments recors",
				"Successfully able to select first Standard Assignments record",
				"Failed to select first Standard Assignments record :" + Common.strError);
	}

	@When("^I click on Action dropdown$")
	public void clickonActionDropdown() {
		boolean blnResult = programFeeManagement.clickonActionDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Action dropdown",
				"User should able to click Action dropdown", "Successfully able to click Action dropdown",
				"Failed to click Action dropdown :" + Common.strError);
	}

	@Then("^I should see all Action options are readonly$")
	public void allActionOptionsAreReadonly() {
		boolean blnResult = programFeeManagement.allActionOptionsAreReadonly();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Action options current state",
				"User should be able to see Action options are readonly",
				"Successfully able to see Action options are readonly",
				"Failed to see Action options are readonly : " + Common.strError);
	}

	@Then("^I verify the availability of Fee Type radio button options$")
	public void verifyTheAvailabilityOfFlatTypeRadioButtonOptions(DataTable feeTypeOptions) {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityOfFeeTypeRadioButtonOptions(feeTypeOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Fee Type radio button options",
				"User should be able to see Fee Type radio button options",
				"Successfully able to see Fee Type radio button options",
				"Failed to see Fee Type radio button options : " + Common.strError);
	}

	@When("^I select (.+) Feetype$")
	public void selectFlatFeetype(String feeType) {
		boolean blnResult = programFeeManagement.selectFeetype(feeType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select " + feeType + " Feetype",
				"User should able to select " + feeType, "Successfully able to select " + feeType + " Feetype",
				"Failed to select " + feeType + " Feetype :" + Common.strError);
	}

	@Then("^I should see (.+) label displayed above to the TIER grid$")
	public void progressiveTieredLabelDisplayed(String feeTypeLabel) {
		boolean blnResult = programFeeManagement.selectedFeeTypeLabelDisplayed(feeTypeLabel);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify " + feeTypeLabel + " label",
				"User should be able to see " + feeTypeLabel + " label displayed above to the TIER grid",
				"Successfully able to see " + feeTypeLabel + " label displayed above to the TIER grid",
				"Failed to see " + feeTypeLabel + " label displayed above to the TIER grid : " + Common.strError);
	}

	@Given("^I verify the availability of filter criteria fields under LPL SWS/SWS Fee report$")
	public void verifyFilterCriteriaFieldsunderLPLSWSorSWSFeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaFieldsunderLPLSWSorSWSFeeReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria fields under LPL SWS/SWS fee report",
				"User should be able to see all filter criteria fields under LPL SWS/SWS fee report",
				"Successfully able to see all filter criteria fields under LPL SWS/SWS fee report",
				"Failed to see all filter criteria fields under LPL SWS/SWS fee report as expected : "
						+ Common.strError);
	}

	@Given("^I verify the availability of filter criteria date fields under LPL SWS/SWS Fee report$")
	public void verifyFilterCriteriaDateFieldsunderLPLSWSorSWSFeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaDateFieldsunderLPLSWSorSWSfeeReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria date fields under LPL SWS/SWS fee report",
				"User should be able to see all filte criteria date fields under LPL SWS/SWS fee report",
				"Successfully able to see all filter criteria date fields under LPL SWS/SWS fee report",
				"Failed to see all filter criteria date fields under LPL SWS/SWS fee report as expected : "
						+ Common.strError);
	}

	@Given("^I verify the availability of result columns name under LPL SWS/SWS Fee report$")
	public void verifyAvailabilityofResultColumnNameunderLPLSWSorSWSFeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyAvailabilityofResultColumnNameunderLPLSWSorSWSFeeReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria date fields under LPL SWS/SWS fee report",
				"User should be able to see all filte criteria date fields under LPL SWS/SWS fee report",
				"Successfully able to see all filter criteria date fields under LPL SWS/SWS fee report",
				"Failed to see all filter criteria date fields under LPL SWS/SWS fee report as expected : "
						+ Common.strError);
	}

	@When("^I verify the availability of filter criteria fields under Firm Assignment Report$")
	public void verifyFilterCriteriaFieldsunderFirmAssignmentReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaFieldsunderFirmAssignmentReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria fields under Firm Assignment Report",
				"User should be able to see all filter criteria fields under Firm Assignment Report",
				"Successfully able to see filter criteria fields under Firm Assignment Report",
				"Failed to see all filter criteria fields under Firm Assignment Report: " + Common.strError);
	}

	@When("^I verify the availability of filter criteria of date fields under Firm Assignment Report$")
	public void verifyFilterCriteriaDateFieldsunderFirmAssignmentReport(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaDateFieldsunderFirmAssignmentReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria of date fields under Firm Assignment Report",
				"User should be able to see all filter criteria of date fields under Firm Assignment Report",
				"Successfully able to see filter criteria of date fields under Firm Assignment Report",
				"Failed to see all filter criteria of date fields under Firm Assignment Report: " + Common.strError);
	}

	@When("^I verify the availability of filter criteria of schedule type dropdown options under Firm Assignment report$")
	public void verifyFilterCriteriaOfScheduleTypeDropDownOptionsunderFirmAssignmentReport(
			DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaOfScheduleTypeDropDownOptionsunderFirmAssignmentReport(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria of schedule type dropdown options under Firm Assignment Report",
				"User should be able to see all filter criteria of schedule type dropdown options under Firm Assignment Report",
				"Successfully able to see filter criteria of schedule type dropdown options under Firm Assignment Report",
				"Failed to see all filter criteria of schedule type dropdown options under Firm Assignment Report: "
						+ Common.strError);
	}

	@When("^I verify the availability of filter criteria of select assignment status dropdown options under Firm Assignment report$")
	public void verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionsUnderFirmAssignmentReport(
			DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionsUnderREPAssignmentReport(
						filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria of Assignment status options under Firm Assignment Report",
				"User should be able to see all filter criteria of Assignment status options under Firm Assignment Report",
				"Successfully able to see filter criteria of Assignment status options under Firm Assignment Report",
				"Failed to see all filter criteria of Assignment status options under Firm Assignment Report: "
						+ Common.strError);
	}

	@Given("^I verify the availability of AUM by Program Report result column headers$")
	public void iverifyAvailabilityOfAUMByProgramResultColumnHeaders(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyAvailabilityOfAUMByProgramResultColumnHeaders(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of AUM by Program Report result column headers",
				"User should be able to see all AUM by Program Report result column headers",
				"Successfully able to see all AUM by Program Report result column headers",
				"Failed to see all AUM by Program Report result column headers : " + Common.strError);
	}

	@Then("^I click on tickbox for Period Begin Date$")
	public void iclicktickBoxofBeginDate() {
		boolean blnResult = programFeeManagement.clicktickBoxofBeginDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the tickbox is clicked",
				"User should be able to click the Period Begin Date tickbox",
				"Successfully able to click the Period Begin Date tickbox ",
				"Failed to click the Period Begin Date tickbox: " + Common.strError);
	}

	@Then("^I provide Period Begin Date for Open Historical$")
	public void iProvideBeginDate() {
		boolean blnResult = programFeeManagement.provideBeginDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify User provides Period Begin Date",
				"User should be able to provide Period Begin Date", "Successfully able to provide Period Begin Date ",
				"Failed to provide Period Begin Date : " + Common.strError);
	}

	@Then("^I provide Period End Date for Open Historical$")
	public void iProvideEndDate() {
		boolean blnResult = programFeeManagement.provideEndDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify User provides Period Begin Date",
				"User should be able to provide Period End Date", "Successfully able to provide Period End Date ",
				"Failed to provide Period End Date : " + Common.strError);
	}

	@Then("^I click on Generate Report Button$")
	public void iclickGenerateReportButtonOpenhist() {
		boolean blnResult = programFeeManagement.clickGenerateReportButtonOpen();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user is able to click Generate Report button",
				"User should be able to click Generate Report button ",
				"Successfully able to click Generate Report button ",
				"Failed to click Generate Report button: " + Common.strError);
	}

	@Then("^I click on ReportArrow button$")
	public void iclickReportArrowButtonOpenhist() {
		boolean blnResult = programFeeManagement.clickReportArrowButtonOpen();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user is able to click Report Arrow button", "User should be able to click Report Arrow button ",
				"Successfully able to click Report Arrow button ",
				"Failed to click  Report Arrowbutton: " + Common.strError);
	}

	@Then("^I validate SWS Fee Type field in Header$")
	public void ivalidateSWSFeeTypeinHeader() {
		boolean blnResult = programFeeManagement.validateSWSFeeTypeinHeader();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify SWS Fee Type is present in the header",
				"User should be able to see SWS Fee Type is present in the header ",
				"Successfully able to see SWS Fee Type is present in the header ",
				"Failed to see SWS Fee Type is present in the header: " + Common.strError);
	}

	@Then("^I validate Below Headers Present in the Report$")
	public void iValidateOpenHistoricalHeader(DataTable headerOptions) {
		boolean blnResult = programFeeManagement.validateOpenHistoricalHeader(headerOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, PLATFORMDROPDOWNAVAILABLITY,
				"User should be able to see all Header options", "Successfully able to see all Header options",
				"Failed to see all Header options : " + Common.strError);
	}

	@Then("^I verify the availability of Standard Flat Feeschedule - Trade Fee under Schedule Name column$")
	public void iverifyAvailabilityOfStandardFlatFeeSchedueTradeFee() {
		boolean blnResult = programFeeManagement.verifyAvailabilityOfStandardFlatFeeSchedueTradeFee();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Standard Flat Feeschedule - Trade Fee under Schedule Name column",
				"User should be able to see Standard Flat Feeschedule - Trade Fee under Schedule Name column",
				"Successfully able to see Standard Flat Feeschedule - Trade Fee under Schedule Name column",
				"Failed to see Standard Flat Feeschedule - Trade Fee under Schedule Name column : " + Common.strError);
	}

	@Then("^I click on Standard Flat Feeschedule - Trade Fee link under Schedule Name$")
	public void iclickonStandardFlatFeescheduleTradeFeeLinkUnderScheduleName() {
		boolean blnResult = programFeeManagement.clickonStandardFlatFeescheduleTradeFeeLinkUnderScheduleName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Standard Flat Feeschedule - Trade Fee link under Schedule Name",
				"User should be able to click Standard Flat Feeschedule - Trade Fee link under Schedule Name",
				"Successfully able to click Standard Flat Feeschedule - Trade Fee link under Schedule Name",
				"Failed to click Standard Flat Feeschedule - Trade Fee link under Schedule Name :" + Common.strError);
	}

	@Then("^I verify the Schedule popup name is displaying as Standard Flat Feeschedule - Trade Fee - Flat Fee$")
	public void iverifySchedulePopUpNameIsDisplayingAsStandardFlatFeeScheduleTradeFeeFlatFee() {
		boolean blnResult = programFeeManagement
				.verifySchedulePopUpNameIsDisplayingAsStandardFlatFeeScheduleTradeFeeFlatFee();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Schedule popup name is displaying as Standard Flat Feeschedule - Trade Fee - Flat Fee",
				"User should be able to see Schedule popup name is displaying as Standard Flat Feeschedule - Trade Fee - Flat Fee",
				"Successfully able to see Schedule popup name is displaying as Standard Flat Feeschedule - Trade Fee - Flat Fee",
				"Failed to see Schedule popup name is displaying as Standard Flat Feeschedule - Trade Fee - Flat Fee : "
						+ Common.strError);
	}

	@Then("^I click on Rep AUM Standard under Schedule Name column$")
	public void iclickonRepAUMStandardUnderScheduleNameColumn() {
		boolean blnResult = programFeeManagement.clickonRepAUMStandardUnderScheduleNameColumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Rep AUM Standard under Schedule Name column",
				"User should be able to click on Rep AUM Standard under Schedule Name column",
				"Successfully able to click on Rep AUM Standard under Schedule Name column",
				"Failed to click on Rep AUM Standard under Schedule Name column :" + Common.strError);
	}

	@Then("^I verify that schedule popup name is displaying as Rep AUM Standard - Tier Structure$")
	public void iverifytheSchedulePopUpNameIsDisplayingAsRepAUMStandardTierStructure() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofRepAUMStandardScheduleLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the schedule popup name is displaying as Rep AUM Standard - Tier Structure",
				"User should be able to see schedule popup name is displaying as Rep AUM Standard - Tier Structure",
				"Successfully able to see schedule popup name is displaying as Rep AUM Standard - Tier Structure",
				"Failed to see schedule popup name is displaying as Rep AUM Standard - Tier Structure : "
						+ Common.strError);
	}

	@Then("^I click on MS Standard 23bps link under Schedule Name$")
	public void iclickonMSStandard23bpsUnderScheduleNameColumn() {
		boolean blnResult = programFeeManagement.clickonMSStandard23bpsUnderScheduleNameColumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on MS Standard 23bps under Schedule Name column",
				"User should be able to click on MS Standard 23bps under Schedule Name column",
				"Successfully able to click on MS Standard 23bps under Schedule Name column",
				"Failed to click on MS Standard 23bps under Schedule Name column :" + Common.strError);
	}

	@Then("^I verify the Schedule popup name is displaying as MS Standard 23bps - Progressive Tier Structure$")
	public void iverifytheSchedulePopUpNameIsDisplayingAsMSStandard23bpsProgressiveTierStructure() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofMSStandard23bpsProgressiveScheduleLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the schedule popup name is displaying as MS Standard 23bps - Progressive Tier Structure",
				"User should be able to see schedule popup name is displaying as MS Standard 23bps - Progressive Tier Structure",
				"Successfully able to see schedule popup name is displaying as MS Standard 23bps - Progressive Tier Structure",
				"Failed to see schedule popup name is displaying as MS Standard 23bps - Progressive Tier Structure : "
						+ Common.strError);
	}

	@Then("^I click on MWP Standard 23bps link under Schedule Name$")
	public void iclickonMWPStandard23bpsUnderScheduleNameColumn() {
		boolean blnResult = programFeeManagement.clickonMWPStandard23bpsUnderScheduleNameColumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on MWP Standard 23bps under Schedule Name column",
				"User should be able to click on MWP Standard 23bps under Schedule Name column",
				"Successfully able to click on MWP Standard 23bps under Schedule Name column",
				"Failed to click on MWP Standard 23bps under Schedule Name column :" + Common.strError);
	}

	@Then("^I verify the Schedule popup name is displaying as MWP Standard 23bps - Progressive Tier Structure$")
	public void iverifytheSchedulePopUpNameIsDisplayingAsMWPStandard23bpsProgressiveTierStructure() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofMWPStandardSchedule23bpsProgressiveLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the schedule popup name is displaying as MWP Standard 23bps - Progressive Tier Structure",
				"User should be able to see schedule popup name is displaying as MWP Standard 23bps - Progressive Tier Structure",
				"Successfully able to see schedule popup name is displaying as MWP Standard 23bps - Progressive Tier Structure",
				"Failed to see schedule popup name is displaying as MWP Standard 23bps - Progressive Tier Structure : "
						+ Common.strError);
	}

	@Then("^I click on SAMII Standard 18bps link under Schedule Name$")
	public void iclickonSAMIIStandard18bpsUnderScheduleNameColumn() {
		boolean blnResult = programFeeManagement.clickonSAMIIStandard18bpsUnderScheduleNameColumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on SAMII Standard 18bps under Schedule Name column",
				"User should be able to click on SAMII Standard 18bps under Schedule Name column",
				"Successfully able to click on SAMII Standard 18bps under Schedule Name column",
				"Failed to click on SAMII Standard 18bps under Schedule Name column :" + Common.strError);
	}

	@Then("^I verify the Schedule popup name is displaying as SAMII Standard 18bps - Progressive Tier Structure$")
	public void iverifytheSchedulePopUpNameIsDisplayingAsSAMIIStandard18bpsProgressiveTierStructure() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofSAMIIStandard18bpsProgressiveScheduleLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the schedule popup name is displaying as SAMII Standard 18bps - Progressive Tier Structure",
				"User should be able to see schedule popup name is displaying as SAMII Standard 18bps - Progressive Tier Structure",
				"Successfully able to see schedule popup name is displaying as SAMII Standard 18bps - Progressive Tier Structure",
				"Failed to see schedule popup name is displaying as SAMII Standard 18bps - Progressive Tier Structure : "
						+ Common.strError);
	}

	@Then("^I verify the availability of SWS Fee Schedule Report column header$")
	public void iverifyAvailabilityOfSWSFeeScheduleReportColumnHeader(DataTable scheduleTypes) {
		boolean blnResult = programFeeManagement.verifyAvailabilityOfSWSFeeScheduleReportColumnHeader(scheduleTypes);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of filter criteria fields of different scedule type dropdown",
				"User should be able to see all filter criteria fields of different scedule type dropdown",
				"Successfully able to see all filter criteria fields of different scedule type dropdown",
				"Failed to see all filter criteria fields of different scedule type dropdown : " + Common.strError);
	}

	@Then("^I verify Submit button is (.+) without End date$")
	public void iVerifySubmitButtonIsDisabled(String buttonState) {
		boolean blnResult = programFeeManagement.iVerifySubmitButtonIsState(buttonState);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Submit button current state",
				"User should able to see Submit button is " + buttonState + " without End date",
				"Successfully able to see Submit button is " + buttonState + " without End date",
				"Failed to see Submit button is " + buttonState + " without End date :" + Common.strError);
	}

	@When("^I click on OK button in Assignment created pop up$")
	public void clickOnOKbutton() {
		boolean blnResult = programFeeManagement.clickOnOKbutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "click on OK button",
				"User should able to click OK button", "Successfully able to click OK button",
				"Failed to click OK button :" + Common.strError);
	}

	@When("^I click on Yes button in Assignment cancel pop up$")
	public void clickOnYesButtonInCancelPopUp() {
		boolean blnResult = programFeeManagement.clickOnYesButtonInCancelPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"click on Yes button in Assignment cancel pop up",
				"User should able to click on Yes button in Assignment cancel pop up",
				"Successfully able to click on Yes button in Assignment cancel pop up",
				"Failed to click on Yes button in Assignment cancel pop up :" + Common.strError);
	}

	@Then("^I verify availability of Standard Flat Feeschedule - Admin Fee data under Custom Schedule$")
	public void iverifyStandardFlatFeeScheduleAdminFeeDisplayed() {
		boolean blnResult = programFeeManagement.verifyStandardFlatFeeScheduleAdminFeeDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of Standard Flat Feeschedule - Admin Fee data under Custom Schedule",
				"User should be able to see Standard Flat Feeschedule - Admin Fee data under Custom Schedule",
				"Successfully able to see Standard Flat Feeschedule - Admin Fee data under Custom Schedule",
				"Failed to see Standard Flat Feeschedule - Admin Fee data under Custom Schedule : " + Common.strError);
	}

	@Then("^I should see Open Historical Billing Details report opened in new tab$")
	public void historicalBillingDetailsReportOpenedInNewTab() {
		boolean blnResult = programFeeManagement.historicalBillingDetailsReportOpenedInNewTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Open Historical Billing Details report",
				"User should be able to see Historical Billing Details report opened in new tab",
				"Successfully able to see Historical Billing Details report opened in new tab",
				"Failed to see Historical Billing Details report opened in new tab : " + Common.strError);
	}

	@Then("^I should see Onboarding Period Termination Warnings report opened in new tab$")
	public void onboardingPeriodTerminationWarningReportOpenedInNewTab() {
		boolean blnResult = programFeeManagement.onboardingPeriodTerminationWarningReportOpenedInNewTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Onboarding Period Termination Warnings report",
				"User should be able to see Onboarding Period Termination Warnings report opened in new tab",
				"Successfully able to see Onboarding Period Termination Warnings report opened in new tab",
				"Failed to see Onboarding Period Termination Warnings report opened in new tab : " + Common.strError);
	}

	@When("^I select Standard Assignments option under Rep/Firm Assignment Tracking tab$")
	public void selectStandardAssignmentsoption() {
		programFeeManagement.selectStandardAssignmentsoption();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select Standard Assignments option under Rep/Firm Assignment Tracking tab",
				"User should able to select Standard Assignments option",
				"Successfully able to select Standard Assignments option",
				"Failed to select Standard Assignments option :" + Common.strError);
	}

	@When("^I select (.+) in Schedule type drop down under Rep/Firm Assignment Tracking tab$")
	public void selectOnboardingScheduleTypeOption(String optionToSelect) {
		programFeeManagement.selectOnboardingScheduleTypeOption(optionToSelect);
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select " + optionToSelect + " in Schedule type drop down under Rep/Firm Assignment Tracking tab",
				"User should able to select " + optionToSelect
						+ " in Schedule type drop down under Rep/Firm Assignment Tracking tab",
				"Successfully able to select " + optionToSelect
						+ " in Schedule type drop down under Rep/Firm Assignment Tracking tab",
				"Failed to select " + optionToSelect
						+ " in Schedule type drop down under Rep/Firm Assignment Tracking tab :" + Common.strError);
	}

	@When("^I select (.+) in Request Status drop down under Rep/Firm Assignment Tracking tab$")
	public void selectApprovedRequestStatusOption(String optionToSelect) {
		programFeeManagement.selectApprovedRequestStatusOption(optionToSelect);
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select " + optionToSelect + " in Request Status drop down under Rep/Firm Assignment Tracking tab",
				"User should able to select " + optionToSelect
						+ " in Request Status drop down under Rep/Firm Assignment Tracking tab",
				"Successfully able to select " + optionToSelect
						+ " in Request Status drop down under Rep/Firm Assignment Tracking tab",
				"Failed to select " + optionToSelect
						+ " in Request Status drop down under Rep/Firm Assignment Tracking tab :" + Common.strError);
	}

	@When("^I clear end date in change assignment screen$")
	public void clearEnddateInChangeAssignmentScreen() {
		boolean blnResult = programFeeManagement.clearEnddateInChangeAssignmentScreen();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Clear end date in change assignment screen",
				"User should able to clear end date in change assignment screen",
				"Successfully able to clear end date in change assignment screen",
				"Failed to clear end date in change assignment screen :" + Common.strError);
	}

	@Then("^I should see Submit button (.+) in change assignment screen$")
	public void checkSubmitButtonCurrentState(String buttonCurrentState) {
		boolean blnResult = programFeeManagement.checkSubmitButtonCurrentState(buttonCurrentState);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Submit button current state in change assignment screen",
				"User should be able to see Submit button " + buttonCurrentState + " in change assignment screen",
				"Successfully able to see Submit button " + buttonCurrentState + " in change assignment screen",
				"Failed to see Submit button " + buttonCurrentState + " in change assignment screen : "
						+ Common.strError);
	}

	@Then("^I verify that Progressive Tier Structure is displaying in popup name$")
	public void iverifythatProgressiveTierStructureisdisplayinginPopupName() {
		boolean blnResult = programFeeManagement.verifythatProgressiveTierStructureisdisplayinginPopupName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Progressive Tier Structure is displaying in popup name",
				"User should be able to see Progressive Tier Structure is displaying in popup name",
				"Successfully able to see Progressive Tier Structure is displaying in popup name",
				"Failed to see Progressive Tier Structure is displaying in popup name : " + Common.strError);
	}

	@When("^I click on MS Standard Schedule Clone icon$")
	public void iclickonMSStandardScheduleCloneicon() {
		boolean blnResult = programFeeManagement.iclickonMSStandardScheduleCloneicon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on MS Standard Schedule Clone icon",
				"User should able to click MS Standard Schedule Clone iconn",
				"Successfully able to click MS Standard Schedule Clone icon",
				"Failed to click MS Standard Schedule Clone icon :" + Common.strError);
	}

	@Then("^I verify the display of MS Standard Schedule Clone popup$")
	public void iverifythedisplayofMSStandardScheduleClonePopup() {
		boolean blnResult = programFeeManagement.verifythedisplayofMSStandardScheduleClonePopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of Create New Schedule button",
				"User should be able to see Create New Schedule button",
				"Successfully able to see Create New Schedule button",
				"Failed to see Create New Schedule button : " + Common.strError);
	}

	@Then("^I click on newly added schedule name hyperlink$")
	public void clickonScheduleNameHyperLink() {
		boolean blnResult = programFeeManagement.clickonScheduleNameHyperLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on newly added schedule name hyperlink",
				"User should be able to click newly added schedule name hyperlink",
				"Successfully able to click newly added schedule name hyperlink",
				"Failed to click newly added schedule name hyperlink :" + Common.strError);
	}

	@Then("^I click on close button icon$")
	public void clickonCloseButtonIcon() {
		boolean blnResult = programFeeManagement.clickonCloseButtonIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on close button icon",
				"User should be able to click close button icon", "Successfully able to click close button icon",
				"Failed to click close button icon :" + Common.strError);
	}

	@Then("^I click on Copy schedule$")
	public void clickonCopyScheduleIcon() {
		boolean blnResult = programFeeManagement.clickonCopyScheduleIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Copy schedule icon",
				"User should be able to click Copy schedule icon", "Successfully able to click Copy schedule icon",
				"Failed to click Copy schedule icon :" + Common.strError);
	}

	@Then("^I click on Cancel in schedule pop up$")
	public void clickonCancel() {
		boolean blnResult = programFeeManagement.clickonCopyScheduleIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Cancel button",
				"User should be able to click Cancel button", "Successfully able to click Cancel button",
				"Failed to click Cancel button :" + Common.strError);
	}

	@Then("^I click on edit Schedule$")
	public void clickonEdit() {
		boolean blnResult = programFeeManagement.clickonEdit();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on edit icon",
				"User should be able to click edit icon", "Successfully able to click edit icon",
				"Failed to click edit icon :" + Common.strError);
	}

	@Then("^I should see Fee rate value is dislayed in BPS for (.+) in schedule name hyperlink$")
	public void percentageValueConvertedInPercentageInHyperLink(String feeType) {
		boolean blnResult = programFeeManagement.valueIsinBpsInScheduleNameHyperLink(feeType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Fee rate value is in BPS for " + feeType + " in schedule name hyperlink",
				"User should be able to see Fee rate value dislayed in BPS for " + feeType
						+ " in schedule name hyperlink",
				"Successfully able to see Fee rate value dislayed in BPS for " + feeType
						+ " in schedule name hyperlink",
				"Failed to see Fee rate value dislayed in BPS for " + feeType + " in schedule name hyperlink: "
						+ Common.strError);
	}

	@Then("^I should see value for (.+) feetype in BPS in Copy schedule popup$")
	public void percentagevalueIsinBpsInCopySchedulePopUp(String feeType) {
		boolean blnResult = programFeeManagement.valueIsinBpsInCopyAndEditSchedulePopUp(feeType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Fee rate value is in BPS for " + feeType + " in Copy schedule popup",
				"User should be able to see Fee rate value dislayed in BPS for " + feeType + " in Copy schedule popup",
				"Successfully able to see Fee rate value dislayed in BPS for " + feeType + " in Copy schedule popup",
				"Failed to see Fee rate value dislayed in BPS for " + feeType + " in Copy schedule popup: "
						+ Common.strError);
	}

	@Then("^I should see value for (.+) feetype in BPS in Edit schedule popup$")
	public void percentagevalueIsinBpsInEditSchedulePopUp(String feeType) {
		boolean blnResult = programFeeManagement.valueIsinBpsInCopyAndEditSchedulePopUp(feeType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Fee rate value is in BPS for " + feeType + " in Edit schedule popup",
				"User should be able to see Fee rate value dislayed in BPS for " + feeType + " in Edit schedule popup",
				"Successfully able to see Fee rate value dislayed in BPS for " + feeType + " in Edit schedule popup",
				"Failed to see Fee rate value dislayed in BPS for " + feeType + " in Edit schedule popup: "
						+ Common.strError);
	}

	@Then("^I select MAN in PLATFORM dropdown options in New Schedule window$")
	public void iselectMANinPLATFORMdropdownoptionsinNewSchedulewindow() {
		programFeeManagement.selectMANinPLATFORMDropdownOptionsinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MAN in PLATFORM dropdown options in New Schedule window", "User should able to select MAN",
				"Successfully able to select MAN", "Failed to select MAN :" + Common.strError);
	}

	@When("^I click on Delete Action icon$")
	public void iclickonDelteiconAction() {
		boolean blnResult = programFeeManagement.iclickonDeleteicon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Delete Action icon under Other Schedules",
				"User should able to click Delete Action icon under Other Schedules",
				"Successfully able to click Delete Action icon under Other Schedules",
				"Failed to click Delete Action icon under Other Schedules :" + Common.strError);
	}

	@Then("^I select MAS in PLATFORM dropdown options in New Schedule window$")
	public void iselectMASinPLATFORMdropdownoptionsinNewSchedulewindow() {
		programFeeManagement.selectMASinPLATFORMDropdownOptionsinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MAS in PLATFORM dropdown options in New Schedule window", "User should able to select MAS",
				"Successfully able to select MAS", "Failed to select MAS :" + Common.strError);
	}

	@Then("^I select SWM in PLATFORM dropdown options in New Schedule window$")
	public void iselectSWMinPLATFORMdropdownoptionsinNewSchedulewindow() {
		programFeeManagement.selectSWMinPLATFORMDropdownOptionsinNewScheduleWindow();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select SWM in PLATFORM dropdown options in New Schedule window", "User should able to select SWM",
				"Successfully able to select SWM", "Failed to select SWM :" + Common.strError);
	}

	@Then("^I verify the availability of Entity Type dropdown field options in (.+) Screen$")
	public void iverifytheavailabilityofEntityTypedropdownfieldoptions(String screenType, DataTable entityTypes) {
		boolean blnResult = programFeeManagement.verifytheAvailabilityofEntityTypeDropDownFieldOptions(entityTypes,
				screenType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Entity Type dropdown field options in " + screenType + " screen",
				"User should be able to see all Entity Type dropdown options in " + screenType + " screen",
				"Successfully able to see all Entity Type dropdown options in " + screenType + " screen",
				"Failed to see all Entity Type dropdown options in " + screenType + " screen , Error :"
						+ Common.strError);
	}

	@Then("^I select (.+) in Entity Type dropdown list in (.+) Screen$")
	public void iselectOptionFromEnityTypedropdownlist(String optionToSelect, String screentype) {
		programFeeManagement.selectOptionInEntityTypeDropdown(optionToSelect, screentype);
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select " + optionToSelect + " in the Pricing Model dropdown list in" + screentype + " Screen",
				"User should able to select " + optionToSelect + "in" + screentype + " Screen",
				"Successfully able to select " + optionToSelect + "in" + screentype + " Screen",
				"Failed to select " + optionToSelect + "in" + screentype + " Screen" + Common.strError);
	}

	@Then("^I select MAN in Select Platform dropdown list$")
	public void iselectMANinSelectPlatformdropdownlist() {
		programFeeManagement.selectMANinSelectPlatformDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MAN in the Pricing Model dropdown list", "User should able to select MAN",
				"Successfully able to select MAN", "Failed to select MAN :" + Common.strError);
	}

	@Then("^I select MAS in Select Platform dropdown list$")
	public void iselectMASinSelectPlatformdropdownlist() {
		programFeeManagement.selectMASinSelectPlatformDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select MAS in the Pricing Model dropdown list", "User should able to select MAS",
				"Successfully able to select MAS", "Failed to select MAS :" + Common.strError);
	}

	@Then("^I select SWM in Select Platform dropdown list$")
	public void iselectSWMinSelectPlatformdropdownlist() {
		programFeeManagement.selectSWMinSelectPlatformDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select SWM in the Pricing Model dropdown list", "User should able to select SWM",
				"Successfully able to select SWM", "Failed to select SWM :" + Common.strError);
	}

	@Then("^I verify the availability of SWS Hybrid Manager Access Network Standard 20bps under Schedule Name column$")
	public void iverifytheavailabilityofSWSHybridManagerAccessNetworkStandard20bpsunderScheduleNamecolumn() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofSWSHybridManagerAccessNetworkStandard20bpsLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of SWS Hybrid Manager Access Network Standard 20bps link",
				"User should be able to see SWS Hybrid Manager Access Network Standard 20bps link",
				"Successfully able to see SWS Hybrid Manager Access Network Standard 20bps link",
				"Failed to see SWS Hybrid Manager Access Network Standard 20bps link : " + Common.strError);
	}

	@Then("^I verify the availability of SWS Hybrid Manager Access Select Standard 20bps under Schedule Name column$")
	public void iverifytheavailabilityofSWSHybridManagerAccessSelectStandard20bpsunderScheduleNamecolumn() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofSWSHybridManagerAccessSelectStandard20bpsLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of SWS Hybrid Manager Access Select Standard 20bps link",
				"User should be able to see SWS Hybrid Manager Access Select Standard 20bps link",
				"Successfully able to see SWS Hybrid Manager Access Select Standard 20bps link",
				"Failed to see SWS Hybrid Manager Access Select Standard 20bps link : " + Common.strError);
	}

	@Then("^I verify the availability of SWS Hybrid SWM II Standard 15bps under Schedule Name column$")
	public void iverifytheavailabilityofSWSHybridSWMIIStandard15bpsLinkunderScheduleNamecolumn() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofSWSHybridSWSHybridSWMII15bpsLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of SWS Hybrid SWM II Standard 15bps link",
				"User should be able to see SWS Hybrid SWM II Standard 15bps link",
				"Successfully able to see SWS Hybrid SWM II Standard 15bps link",
				"Failed to see SWS Hybrid SWM II Standard 15bps link : " + Common.strError);
	}

	@Then("^I click on SWS Hybrid Manager Access Network Standard 20bps link under Schedule Name$")
	public void iclickonSWSHybridManagerAccessNetworkStandard20bpsUnderScheduleNameColumn() {
		boolean blnResult = programFeeManagement
				.clickonSWSHybridManagerAccessNetworkStandard20bpsLinkUnderScheduleNameColumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on SWS Hybrid Manager Access Network Standard 20bps under Schedule Name column",
				"User should be able to click on SWS Hybrid Manager Access Network Standard 20bps under Schedule Name column",
				"Successfully able to click on SWS Hybrid Manager Access Network Standard 20bps under Schedule Name column",
				"Failed to click on SWS Hybrid Manager Access Network Standard 20bps under Schedule Name column :"
						+ Common.strError);
	}

	@Then("^I click on SWS Hybrid Manager Access Select Standard 20bps link under Schedule Name$")
	public void iclickonSWSHybridManagerAccessSelectStandard20bpsUnderScheduleNameColumn() {
		boolean blnResult = programFeeManagement
				.clickonSWSHybridManagerAccessSelectStandard20bpsLinkUnderScheduleNameColumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on SWS Hybrid Manager Access Select Standard 20bps under Schedule Name column",
				"User should be able to click on SWS Hybrid Manager Access Select Standard 20bps under Schedule Name column",
				"Successfully able to click on SWS Hybrid Manager Access Select Standard 20bps under Schedule Name column",
				"Failed to click on SWS Hybrid Manager Access Select Standard 20bps under Schedule Name column :"
						+ Common.strError);
	}

	@Then("^I click on SWS Hybrid SWM II Standard 15bps link under Schedule Name$")
	public void iclickonSWSHybridSWMIIStandard15bpsUnderScheduleNameColumn() {
		boolean blnResult = programFeeManagement.clickonSWSHybridSWMIIStandard15bpsLinkUnderScheduleNameColumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on SWS Hybrid SWM II Standard 15bps under Schedule Name column",
				"User should be able to click on SWS Hybrid SWM II Standard 15bps under Schedule Name column",
				"Successfully able to click on SWS Hybrid SWM II Standard 15bps under Schedule Name column",
				"Failed to click on SWS Hybrid SWM II Standard 15bps under Schedule Name column :" + Common.strError);
	}

	@Then("^I verify the Schedule popup name is displaying as SWS Hybrid Manager Access Network Standard 20bps - Progressive Tier Structure$")
	public void iverifytheSchedulePopUpNameIsDisplayingAsSWSHybridManagerAccessNetworkStandard20bpsProgressiveTierStructure() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofSWSHybridManagerAccessNetworkStandard20bpsProgressiveScheduleLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the schedule popup name is displaying as SWS Hybrid Manager Access Network Standard 20bps - Progressive Tier Structure",
				"User should be able to see schedule popup name is displaying as SWS Hybrid Manager Access Network Standard 20bps - Progressive Tier Structure",
				"Successfully able to see schedule popup name is displaying as SWS Hybrid Manager Access Network Standard 20bps - Progressive Tier Structure",
				"Failed to see schedule popup name is displaying as SWS Hybrid Manager Access Network Standard 20bps - Progressive Tier Structure : "
						+ Common.strError);
	}

	@Then("^I verify the Schedule popup name is displaying as SWS Hybrid Manager Access Select Standard 20bps - Progressive Tier Structure$")
	public void iverifytheSchedulePopUpNameIsDisplayingAsSWSHybridManagerAccessSelectStandard20bpsProgressiveTierStructure() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofSWSHybridManagerAccessSelectStandard20bpsProgressiveScheduleLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the schedule popup name is displaying as SWS Hybrid Manager Access Select Standard 20bps - Progressive Tier Structure",
				"User should be able to see schedule popup name is displaying as SWS Hybrid Manager Access Select Standard 20bps - Progressive Tier Structure",
				"Successfully able to see schedule popup name is displaying as SWS Hybrid Manager Access Select Standard 20bps - Progressive Tier Structure",
				"Failed to see schedule popup name is displaying as SWS Hybrid Manager Access Select Standard 20bps - Progressive Tier Structure : "
						+ Common.strError);
	}

	@Then("^I verify the Schedule popup name is displaying as SWS Hybrid SWM II Standard 15bps - Progressive Tier Structure$")
	public void iverifytheSchedulePopUpNameIsDisplayingAsSWSHybridSWMIIStandard15bpsProgressiveTierStructure() {
		boolean blnResult = programFeeManagement
				.verifyTheAvailabilityofSWSHybridSWMIIStandard15bpsProgressiveScheduleLinkunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the schedule popup name is displaying as SWS Hybrid SWM II Standard 15bps - Progressive Tier Structure",
				"User should be able to see schedule popup name is displaying as SWS Hybrid SWM II Standard 15bps - Progressive Tier Structure",
				"Successfully able to see schedule popup name is displaying as SWS Hybrid SWM II Standard 15bps - Progressive Tier Structure",
				"Failed to see schedule popup name is displaying as SWS Hybrid SWM II Standard 15bps - Progressive Tier Structure : "
						+ Common.strError);
	}

	@Then("^I verify the availability of clone icon$")
	public void iverifytheavailabilityofCloneIcon() {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofCloneIconunderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availability of clone icon",
				"User should be able to see clone icon", "Successfully able to see clone icon",
				"Failed to see clone icon : " + Common.strError);
	}

	@Given("^I verify the availability of Firm Assignment Report result column headers$")
	public void iverifyAvailabilityOfFirmAssignmentReportColumnHeaders(DataTable filterCriteriaOptions) {
		boolean blnResult = programFeeManagement
				.verifyAvailabilityOfFirmAssignmentReportColumnHeaders(filterCriteriaOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Firm Assignment Report result column headers",
				"User should be able to see all Firm Assignment Report result column headers",
				"Successfully able to see all Firm Assignment Report result column headers",
				"Failed to see all Firm Assignment Report result column headers : " + Common.strError);
	}

	@Then("^I verify the availability of new Platform field under (.+) table in Modify Assignment screen$")
	public void verifyTheAvailabilityofPlatformFieldInModifyAssignmentScreen(String tableType) {
		boolean blnResult = programFeeManagement.verifyTheAvailabilityofPlatformField(tableType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of new Platform field in " + tableType + " screen",
				"User should be able to see new Platform field in " + tableType + " screen",
				"Successfully able to see new Platform field in " + tableType + " screen",
				"Failed to see new Platform field in " + tableType + " screen , Error :" + Common.strError);
	}

	@When("^I should see Schedule name displayed in hyperlink$")
	public void verifyScheduleNameHyperLink() {
		boolean blnResult = programFeeManagement.verifyScheduleNameHyperLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of Schedule name hyperlink", "User should able to see Schedule name hyperlink",
				"Successfully able to see Schedule name hyperlink",
				"Failed to see Schedule name hyperlink :" + Common.strError);
	}

	@When("^I select all assignments$")
	public void selectAllAssignmentCheckbox() {
		boolean blnResult = programFeeManagement.selectAllAssignmentCheckbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on select all assignments",
				"User should able to click select all assignments",
				"Successfully able to click on select all assignments",
				"Failed to click on select all assignments :" + Common.strError);
	}

	@Then("^I verify modify assignment option is disable in action drop down$")
	public void verifyModifyAssignmentOptionDisabled() {
		boolean blnResult = programFeeManagement.verifyModifyAssignmentOptionDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Assignment status",
				"User should be able to see modify assignment option is disable in action drop down",
				"Successfully able to modify assignment option is disable in action drop down",
				"Failed to modify assignment option is disable in action drop down : " + Common.strError);
	}

	@When("^I select In-active Assignments option under Rep/Firm Assignment Tracking tab$")
	public void selectInActiveAssignmentStatusOption() {
		programFeeManagement.selectInActiveAssignmentOption();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select In-active Assignments option under Rep/Firm Assignment Tracking tab",
				"User should able to select In-active Assignments option",
				"Successfully able to select In-active Assignments option",
				"Failed to select In-active Assignments option :" + Common.strError);
	}
	
	@When("^I select RIA CUSTODY PLATFORM in the Pricing Model dropdown list$")
	public void iselectRIACUSTODYPLATFORMinthePricingModeldropdownlist() {
		programFeeManagement.selectRIACUSTODYPLATFORMinthePricingModelDropdownList();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Select RIA CUSTODY PLATFORM in the Pricing Model dropdown list", 
				"User should able to select RIA CUSTODY PLATFORM",
				"Successfully able to select RIA CUSTODY PLATFORM", 
				"Failed to select RIA CUSTODY PLATFORM :" + Common.strError);
	}
	
	@Then("^I verify the availability of Fee Component dropdown field options for RIA Custody Platform$")
	public void iverifytheavailabilityofFeeComponentdropdownfieldoptionsforRIACustodyPlatform(DataTable feeComponentTypes) {
		boolean blnResult = programFeeManagement
				.verifytheAvailabilityofFeeComponentDropDownFieldOptionsforRIACustodyPlatform(feeComponentTypes);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Fee Component dropdown field options for RIA Custody Platform",
				"User should be able to see all Fee Component dropdown options for RIA Custody Platform as expected",
				"Successfully able to see all Fee Component dropdown options for RIA Custody Platform as expected",
				"Failed to see all Fee Component dropdown options for RIA Custody Platform as expected : " + Common.strError);
	}

	@When("^I select RIA Custody Platform Fee in the Fee Component dropdown list$")
	public void iselectRIACustodyPlatformFeeintheFeeComponentdropdownlist() {
		programFeeManagement.iSelectRIACustodyPlatformFee();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE, "Select RIA Custody Platform Fee",
				"User should able to select RIA Custody Platform Fee", "Successfully able to select RIA Custody Platform Fee",
				"Failed to select RIA Custody Platform Fee :" + Common.strError);
	}
	
	@Then("^I should land on RIA CUSTODY PLATFORM - RIA Custody Platform Fee : Manage Schedule page$")
	public void ishouldlandonRIACUSTODYPLATFORMRIACustodyPlatformFeeManageSchedulepage() {
		boolean blnResult = programFeeManagement.iShouldLandOnRIACUSTODYPLATFORMManageSchedulePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, 
				"Verify RIA CUSTODY PLATFORM - RIA Custody Platform Fee : Manage Schedule page load",
				"User should be able to see RIA CUSTODY PLATFORM - RIA Custody Platform Fee : Manage Schedule page", 
				"Successfully able to see RIA CUSTODY PLATFORM - RIA Custody Platform Fee : Manage Schedule page",
				"Failed to see RIA CUSTODY PLATFORM - RIA Custody Platform Fee : Manage Schedule page : " + Common.strError);
	}@Then("^I verify the availability of IFA/Hybrid SWM II Standard 5bps under Schedule Name column$")
	public void iverifytheavailabilityofIFAHybridSWMIIStandard5bpsunderScheduleNamecolumn() {
		boolean blnResult = programFeeManagement.verifytheavailabilityofIFAHybridSWMIIStandard5bpsunderScheduleNamecolumn();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of IFA/HybridSWMIIStandard5bps link",
				"User should be able to see IFA/HybridSWMIIStandard5bps link", "Successfully able to see IFA/HybridSWMIIStandard5bps link",
				"Failed to see IFA/HybridSWMIIStandard5bps link : " + Common.strError);
	}
	
	@Then("^I verify IFA/Hybrid RIA Entity Type under Standard Schedule$")
	public void iVerifyIFAorHybridRIAEntityTypeUnderStandardSchedule() {
		boolean blnResult = programFeeManagement.verifyIFAorHybridRIAEntityTypeUnderStandardSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of IFA/Hybrid RIA Entity Type under Standard Schedule",
				"User should be able to see IFA/Hybrid RIA Entity Type under Standard Schedule",
				"Successfully able to see IFA/Hybrid RIA Entity Type under Standard Schedule",
				"Failed to see IFA/Hybrid RIA Entity Type under Standard Schedule : " + Common.strError);
	}
	
	@Then("^I verify IFA/Hybrid RIA Entity Type under Other Schedule$")
	public void iVerifyIFAorHybridRIAEntityTypeUnderOtherSchedule() {
		boolean blnResult = programFeeManagement.verifyIFAorHybridRIAEntityTypeUnderOtherSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of IFA/Hybrid RIA Entity Type under Other Schedule",
				"User should be able to see IFA/Hybrid RIA Entity Type under Other Schedule",
				"Successfully able to see IFA/Hybrid RIA Entity Type under Other Schedule",
				"Failed to see IFA/Hybrid RIA Entity Type under Other Schedule : " + Common.strError);
	}
	
	@Then("^I verify Entity Type filter option is not present$")
	public void iVerifyEntityTypeFilterOptionIsNotPresent() {
		boolean blnResult = programFeeManagement.verifyEntityTypeFilterOptionIsNotPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Entity Type filter option is not present",
				"User should not be able to see Entity Type filter option",
				"Successfully not be able to see Entity Type filter option",
				"Failed to verify Entity Type filter option is not present : " + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}