package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.webservice.cucumber.pages;

import CWWebServicesCommon.CWSession;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import LPLWSSDK.LPLWSCookieInfo;
import com.google.gson.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import okhttp3.*;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.*;
import java.util.stream.Collectors;

import static io.restassured.RestAssured.given;


/**
 * <p>
 * <br><b> Title: </b> Common.java</br>
 * <br><b> Description: </b> Page Object Library for Common</br>
 * <br><b>Usage:</b></br>
 * <br>getXSRFToken                          : This method is used to get the XSRF Token value used as one of the header value in services called from ClientWorks application</br>
 * <br>setUpHeaders                          : This method is used to save the required headers values in a map</br>
 * <br>setUpQueryParams                      : This method is used to save the required query parameters values in a map</br>
 * <br>getRestResponse                       : This method is used to return the REST response object for the given method and type.</br>
 * <br>getDataJSONArray                      : This method takes response string(json) and return "data" property. Use this method when you expect the data property is of JSONArray type</br>
 * <br>getDataJSONObject                     : This method takes response string(json) and return "data" property. Use this method when you expect the data property is of JsonObject type</br>
 * <br>getElementNames                       : This method takes JsonObject and return names of all the elements(both objects and arrays)</br>
 * <br>getElementNamesForGivenElement        : This method takes JsonObject and return names of all the elements(both objects and arrays) inside the specified element name</br>
 * <br>setError                              : This method is used to append the error message to the strError variable</br>
 * <br>validateJsonElement                   : This method is used to validate the JSON data elements received in the response</br>
 * <br>isElementPresent                      : This method is used to check if the given elements is present in JSONElement object</br>
 * <br>getCurrentElement                     : This method is used to retrieve the JSONElement using the element name provided withing the given JsonElement</br>
 * <br>isGivenElementPresent                 : This method is used to check if the given element name of type elementType is present in the given JSONElement object</br>
 * <br>ElementType                           : This method is used to store the constants for different elements types in json</br>
 * <br>getElementType                        : This method is used to store the constants for different elements types in json</br>
 * <br>getJsonElement                        : This method is used to retrieve the JSONElement object from the given JSON string</br>
 * <br>getDataObject                         : This method is used to validate the JSON data elements received in the response</br>
 * <br>getJsonArray                          : This method is used to validate the JSON data elements received in the response</br>
 * <br>getListOfJsonObjectValueFromJsonArray : This method is used to validate the JSON data elements received in the response</br>
 * <br>validateDataElementInResponse         : This method is used to validate the JSON data elements received in the response</br>
 * <br>getElementType                        : This method is used to get the element type for the given element name</br>
 * <br>getElementName                        : This method is used to get the element name after removing the element type suffix([O],[N],[P],[A])</br>
 * <br>isJsonElementAnArray                  : This method is used to check if the JSONElement object is of type JSONArray</br>
 * <br>isJsonElementAnObject                 : This method is used to check if the JSONElement object is of type JSONObject</br>
 * <br>isJsonElementPrimitive                : This method is used to check if the JSONElement object is of type Primitive</br>
 * <br>isJsonElementNull                     : This method is used to check if the JSONElement object is of type Null</br>
 * <br>getList                               : This method is used to convert a set into a list</br>
 * <br>parseJson                             : This method is used to parse the JSON String into JSON Element</br>
 * <br>getRequestBody                        : Gets the request body.</br>
 * <br>isResponseElementsMatched             : Checks if is response elements matched.</br>
 * <br>getResponseArray                      : Gets the response array.</br>
 * <br>parseJsonElement                      : Parses the json element.</br>
 * <br>getKeySet                             : Gets the key set.</br>
 * <br>isJsonAtEndNode                       : Checks if is json at end node.</br>
 * <br>removePrimitiveElement                : Removes the primitive element.</br>
 * <br>getCWSessionCookiesWithoutBrowser     : This method is used to retrieve the transaction cookie without launching the browser.</br>
 * <br>String                                : This method is used to return the captured error message.</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 * </p>
 */

public class Common extends LPLCoreDriver {

    private static final String XSRF_TOKEN = "XSRF-TOKEN=";
    private static final String EMPTY_STRING = "";
    //Constants
    private static final String FORWORD_SLASH = "/";
    public static final String OBJECT_PREFIX = "[O]";
    public static final String ARRAY_PREFIX = "[A]";
    public static final String PRIMITIVE_PREFIX = "[P]";
    public static final String NULL_PREFIX = "[N]";
    static String strError = EMPTY_STRING;

    static RandomAccessFile stream = null;
    static FileChannel channel = null;
    static FileLock lock = null;
    static String fileLockMessage = "The process cannot access the file because another process has locked a portion of the file";

    static Set<Cookie> sessionCookie = null;
    static String xsrfToken = null;
    static String auth = null;
    static String zCookie = null;

    static String requestBody;

    //Map for storing headers
    static Map<String, String> headers = new HashMap<>();

    static Map<String, String> sessionCookiesCWWithoutBrowser;

    //Map for storing query parameters
    static Map<String, String> queryParams = new HashMap<>();
    protected static List<String> jsonElements = new LinkedList<>();

    /**
     * This method is used to get the XSRF Token value used as one of the header value in services called from ClientWorks application
     *
     * @return String
     * @author pmanohar
     * @since 11-13-2019
     */
    public static String getXSRFToken(String transactionCookie) {
        boolean blnResult = false;

        //splits transaction cookie in to parts array
        String[] parts = transactionCookie.replace(";", EMPTY_STRING).split(" ");

        //check if the parts array has 3 elements
        blnResult = (parts.length == 3);
        LPLCoreReporter.writeStepToReporter(blnResult,
                LPLCoreConstents.TRUE,
                "Retrieving the XSRF token",
                "XSRF token should successfully retrieved",
                "XSRF token should successfully retrieved",
                "Transaction cookie does not all the components[Auth, XSRF and Z values]",
                false);
        log.info(parts[1].replace(XSRF_TOKEN, EMPTY_STRING));
        return parts[1].replace(XSRF_TOKEN, EMPTY_STRING);
    }


    /**
     * This method is used to save the required headers values in a map
     *
     * @author pmanohar
     * @since 11-13-2019
     */
    public static void setUpHeaders() {

        LPLCoreDriver.StartSessionForWSTest();

        //Retrieving username
        String username = loginCredentials.get("Username");
        String password = loginCredentials.get("Password");
        String transactionCookie = getCWSessionCookiesWithoutBrowser(ocfg.getURL(), username, password);
        String auth = getCWSessionCookiesWithoutBrowser(ocfg.getURL(), username, password);
        List<String> headerList = new ArrayList<>();

        //Setting up headers
        headers.put("Cookie", transactionCookie);
        headers.put("X-XSRF-TOKEN", getXSRFToken(transactionCookie));
        headers.put("Origin", "https://clientworksqa.lpl.com");
        headers.put("securityToken",auth);
        

        //Storing the headers key and values in a list separated by semi-colon
        for (Map.Entry<String, String> entry : headers.entrySet())
            headerList.add(entry.getKey() + " : " + entry.getValue());
        //Reporter step for logging the header information
        LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE,
                LPLCoreConstents.TRUE,
                "Setting up request headers",
                "Request headers should be setup",
                "Following request headers are setup. " + String.join(", ", headerList),
                "Failed to setup the headers",
                false);
    }

    /**
     * This method is used to save the required query parameters values in a map
     *
     * @author pmanohar
     * @since 11-13-2019
     */
    public static void setUpQueryParams() {
        List<String> queryParamsList = new ArrayList<>();
        //Setting up query params
        Set<String> testDataKeys = testData.keySet();
        for (String testDataKey : testDataKeys) {
            if (testDataKey.startsWith("qp")) {//query params are stored as test data in FARM with prefix 'qp'
                String queryParamKey = testDataKey.substring(2);
                queryParams.put(queryParamKey, testData.get(testDataKey));
            }
        }

        //Storing the query parameters key and values in a list seperated by semi-colon
        for (Map.Entry<String, String> entry : queryParams.entrySet())
            queryParamsList.add(entry.getKey() + " : " + entry.getValue());

        if (!queryParamsList.isEmpty())
            //Reporter step for logging the Query Parameters information
            LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE,
                    LPLCoreConstents.TRUE,
                    "Setting up Query Parameters",
                    "Query Parameters should be setup",
                    "Following Query Parameters are setup. " + String.join(", ", queryParamsList),
                    "Failed to setup the Query Parameters",
                    false);
    }

    /**
     * This method is used to return the REST response object for the given method and type.
     *
     * @author pmanohar
     * @since 11-13-2019
     */
    public static Response getRestResponse(String methodType) {
        //set up the headers
        setUpHeaders();

        //set up the query parameters
        setUpQueryParams();

        //Setting the endpoint(retrieved from FARM)
        try {
            RestAssured.baseURI = testData.get("endpoint").trim();
        } catch (Exception e) {
            LPLCoreReporter.writeStepToReporter(false,
                    LPLCoreConstents.TRUE,
                    "Setting up API endpoint",
                    "API endpoint should be setup",
                    "Endpoint is set to " + RestAssured.baseURI,
                    "Failed to setup the endpoint",
                    false);
        }
        LPLCoreReporter.writeStepToReporter(RestAssured.baseURI != null,
                LPLCoreConstents.TRUE,
                "Setting up API endpoint",
                "API endpoint should be setup",
                "Endpoint is set to " + RestAssured.baseURI,
                "Failed to setup the endpoint",
                false);

        Response response = null;
        switch (methodType) {
            case "GET":
                //calling GET method after attaching the headers and query parameters to the request
                response = given().headers(headers).queryParams(queryParams).get();
                break;
            case "POST":
                //calling POST method
                response = given().headers(headers).contentType("application/json").body(getRequestBody()).post();
                break;
            default:
                return null;
        }
        //return response object
        return response;
    }

    /**
     * This method takes response string(json) and return "data" property. Use this method when you expect the data property is of JSONArray type
     *
     * @param jsonString
     * @return JSONArray
     * @author pmanohar
     * @since 11-13-2019
     */
    public static JsonArray getDataJSONArray(String jsonString) {
        //Parsing the json String to json element
        JsonElement jsonElement = new JsonParser().parse(jsonString);

        //getting the data array from the response string
        return jsonElement.getAsJsonObject().get("data").getAsJsonArray();
    }

    /**
     * This method takes response string(json) and return "data" property. Use this method when you expect the data property is of JsonObject type
     *
     * @param jsonString
     * @return JsonObject
     * @author pmanohar
     * @since 11-13-2019
     */
    public static JsonObject getDataJSONObject(String jsonString) {
        //parsing the json string to json element
        JsonElement jsonElement = new JsonParser().parse(jsonString);

        //getting the test data as json object from the response string
        return jsonElement.getAsJsonObject().get("data").getAsJsonObject();
    }

    /**
     * This method takes JsonObject and return names of all the elements(both objects and arrays)
     *
     * @param jsonObject
     * @return List<String>
     * @author pmanohar
     * @since 11-13-2019
     */
    public static List<String> getElementNames(JsonObject jsonObject) {
        //initialized the element list
        List<String> elementList = new ArrayList<>();

        //getting the entry set from the json object
        Set<Map.Entry<String, JsonElement>> entries = jsonObject.entrySet();

        //iterating the entry set
        for (Map.Entry<String, JsonElement> entry : entries) {
            elementList.add(entry.getKey());
        }
        return elementList;
    }

    /**
     * This method takes JsonObject and return names of all the elements(both objects and arrays) inside the specified element name
     *
     * @param jsonObject
     * @return List<String>
     * @author pmanohar
     * @since 11-13-2019
     */
    public static List<String> getElementNamesForGivenElement(JsonObject jsonObject, String elementName) {
        //initialized the element list
        List<String> elementList = new ArrayList<>();
        //getting the entry set from the json object
        Set<Map.Entry<String, JsonElement>> entries = jsonObject.entrySet();

        //iterating the entry set
        for (Map.Entry<String, JsonElement> entry : entries) {
            String key = entry.getKey();
            if (key.equals(elementName)) {
                JsonObject object = entry.getValue().getAsJsonObject();
                return getElementNames(object);
            }
            elementList.add(entry.getKey());
        }
        return elementList;
    }

    /**
     * This method is used to append the error message to the strError variable
     *
     * @param errorMessage
     * @author pmanohar
     * @since 11-15-2019
     */
    public static void setError(String errorMessage) {
        strError += errorMessage;
    }

    /**
     * This method is used to validate the JSON data elements received in the response
     *
     * @param objJsonElement - response JSONElement object received from JSON response
     * @param elementName    - name of the element(along with absolute path) to be checked
     * @return boolean
     * @author pmanohar
     * @since 11-15-2019
     */
    public static boolean validateJsonElement(JsonElement objJsonElement, String elementName) {
        boolean blnResult = false;
        JsonElement currentJsonElement = null;
        String testElement = elementName;
        JsonElement jsonElement = objJsonElement;
        if (!testElement.equals(OBJECT_PREFIX)) {
            testElement = testElement.substring(4);
        } else if (OBJECT_PREFIX.equals(testElement)) {
            return true;
        }

        String[] parts = testElement.split(FORWORD_SLASH);
        currentJsonElement = jsonElement;
        for (String part : parts) {
            if (part.endsWith(OBJECT_PREFIX) || part.endsWith(ARRAY_PREFIX)) {
                blnResult = isElementPresent(currentJsonElement, part);
                currentJsonElement = getCurrentElement(currentJsonElement, getElementName(part));
            } else if (part.endsWith(NULL_PREFIX) || part.endsWith(PRIMITIVE_PREFIX)) {
                blnResult = isElementPresent(currentJsonElement, part);
            }
            if (!blnResult)
                return false;
        }
        return blnResult;
    }

    /**
     * This method is used to check if the given elements is present in JSONElement object
     *
     * @param jsonElement - response JSONElement object received from JSON response
     * @param elementName - name of the element(along with absolute path) to be checked
     * @return boolean
     * @author pmanohar
     * @since 11-15-2019
     */
    public static boolean isElementPresent(JsonElement jsonElement, String elementName) {
        return isGivenElementPresent(jsonElement, getElementName(elementName), getElementType(elementName));
    }

    /**
     * This method is used to retrieve the JSONElement using the element name provided withing the given JsonElement
     *
     * @param jsonElement - response JSONElement object received from JSON response
     * @param elementName - name of the element(along with absolute path) to be checked
     * @return JsonElement
     * @author pmanohar
     * @since 11-15-2019
     */
    public static JsonElement getCurrentElement(JsonElement jsonElement, String elementName) {
        if (isJsonElementAnObject(jsonElement))
            return jsonElement.getAsJsonObject().get(elementName);
        if (isJsonElementAnArray(jsonElement))
            return jsonElement.getAsJsonArray().get(0).getAsJsonObject().get(elementName);
        return null;
    }

    /**
     * This method is used to check if the given element name of type elementType is present in the given JSONElement object
     *
     * @param jsonElement - response JSONElement object received from JSON response
     * @param elementName - name of the element(along with absolute path) to be checked
     * @param elementType - expected type of the element(Primitive, Object, Null or Array)
     * @return boolean
     * @author pmanohar
     * @since 11-15-2019
     */
    public static boolean isGivenElementPresent(JsonElement jsonElement, String elementName, String elementType) {
        boolean blnResult = false;
        JsonElement expectedJsonElement = null;

        //Retrieving the JSON object from JSONElement
        if (isJsonElementAnObject(jsonElement))
            expectedJsonElement = jsonElement.getAsJsonObject().get(elementName);
        else if (isJsonElementAnArray(jsonElement))
            expectedJsonElement = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get(elementName);

        if (expectedJsonElement != null) {
            //Checking for Primitive
            if (elementType.equals(ElementType.PRIMITIVE.getElementType()))
                blnResult = isJsonElementPrimitive(expectedJsonElement) || isJsonElementNull(expectedJsonElement);
                //Checking for Null
            else if (elementType.equals(ElementType.NULL.getElementType()))
                blnResult = isJsonElementNull(expectedJsonElement);
                //Checking for Object
            else if (elementType.equals(ElementType.OBJECT.getElementType()))
                blnResult = isJsonElementAnObject(expectedJsonElement);
                //Checking for Array
            else if (elementType.equals(ElementType.ARRAY.getElementType()))
                blnResult = isJsonElementAnArray(expectedJsonElement);
        } else {
            return false;
        }

        return blnResult;
    }

    /**
     * This method is used to store the constants for different elements types in json
     *
     * @author pmanohar
     * @since 11-15-2019
     */
    enum ElementType {
        PRIMITIVE("Primitive"), NULL("Null"), OBJECT("Object"), ARRAY("Array");

        private String type;

        private ElementType(String elementType) {
            this.type = elementType;
        }

        public String getElementType() {
            return type;
        }
    }

    /**
     * This method is used to retrieve the JSONElement object from the given JSON string
     *
     * @param jsonString - JSON String received from the GET/POST request call
     * @return JsonElement
     * @author pmanohar
     * @since 11-15-2019
     */
    public static JsonElement getJsonElement(String jsonString) {
        try {
            return new JsonParser().parse(jsonString);
        } catch (Exception e) {
            LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE,
                    LPLCoreConstents.TRUE,
                    "Convert json string into Json element",
                    "Json string should be converted unto JsonElement object",
                    "Json string is converted into JsonElement object",
                    "Failed to convert Json String to JsonElement object.Error: " + e.getMessage());
        }
        return null;
    }

    /**
     * This method is used to validate the JSON data elements received in the response
     *
     * @param jsonString - Represents the Json String received from the response
     * @return JsonObject
     * @author pmanohar
     * @since 11-19-2019
     */
    public static JsonObject getDataObject(String jsonString) {
        JsonObject jsonObject = new JsonObject();
        try {
            jsonObject = getJsonElement(jsonString).getAsJsonObject().get("data").getAsJsonObject();
        } catch (Exception e) {
            LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE,
                    LPLCoreConstents.TRUE,
                    "Retrieving the data object from the given json string",
                    "Data object should be successfully retrieved",
                    "Data object is retrieved",
                    "Failed to retrieve the data object.Error: " + e.getMessage());
        }
        return jsonObject;
    }

    /**
     * This method is used to validate the JSON data elements received in the response
     *
     * @param jsonObject       - Represents the Json Object
     * @param arrayElementName - Element name of the array to be retrieved
     * @return JsonArray
     * @author pmanohar
     * @since 11-19-2019
     */
    public static JsonArray getJsonArray(JsonObject jsonObject, String arrayElementName) {
        JsonArray jsonArray = null;
        try {
            jsonArray = jsonObject.getAsJsonArray(arrayElementName);
        } catch (Exception e) {
            LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE,
                    LPLCoreConstents.TRUE,
                    "Retrieving the " + arrayElementName + " Json array from the given json object",
                    arrayElementName + " Json array should be retrieved from the given json object",
                    arrayElementName + " Json array is retrieved from the given json object",
                    "Failed to retrieve the " + arrayElementName + " Json array.Error: " + e.getMessage());
        }
        return jsonArray;
    }

    public static List<String> getListOfJsonObjectValueFromJsonArray(JsonArray jsonArray, String jsonObjectName) {
        List<String> values = new ArrayList<>();
        int size = jsonArray.size();
        try {
            for (int i = 0; i < size; i++) {
                values.add(jsonArray.get(i).getAsJsonObject().get(jsonObjectName).getAsString());
            }
        } catch (Exception e) {
            LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE,
                    LPLCoreConstents.TRUE,
                    "Retrieving the " + jsonObjectName + " json object value from the given json array",
                    jsonObjectName + " json object value should be retrieved from the given json array",
                    jsonObjectName + " json object value is retrieved from the given json array",
                    "Exception occurred while retrieving the values for " + jsonObjectName + " json object. Error " + e.getMessage());
        }
        return values;
    }

    /**
     * This method is used to validate the JSON data elements received in the response
     *
     * @param jsonString       - JSON response received from the GET/POST request call
     * @param expectedElements - Expected list of elements along with absolute path stored in an array
     * @return boolean
     * @author pmanohar
     * @since 11-15-2019
     */
    public static boolean validateDataElementInResponse(String jsonString, String[] expectedElements) {
        //failing the test(by returning false) if the array containing the list of expected elements is empty
        if (expectedElements.length == 0) {
            strError += "Expected element list is empty.";
            return false;
        }
        //Map for storing results of element check
        Map<String, Boolean> result = new HashMap<>();

        //List for storing the missing elements
        List<String> missingElements = new ArrayList<>();

        //Converting the json storing into JSONElement object
        JsonElement jsonElement = getJsonElement(jsonString);

        //Checking if each expected element is present in the JSON response
        for (String expectedElement : expectedElements) {
            boolean blnResult = validateJsonElement(jsonElement, expectedElement);

            //Adding element name and result(if element present or not) to the map
            result.put(expectedElement, blnResult);
        }

        //Checking if the result map contains atleast one missing element
        if (result.containsValue(Boolean.FALSE)) {
            for (Map.Entry<String, Boolean> entry : result.entrySet()) {
                if (entry.getValue().toString().equals("false"))
                    //Adding missing element to the list
                    missingElements.add(entry.getKey());
            }
            //Setting error message for missing elements
            setError("The following elements are missing in the response json - " + String.join(", ", missingElements));
            return false;
        }
        return true;
    }

    /**
     * This method is used to get the element type for the given element name
     *
     * @param elementName - name of the element along with its type([O],[N],[P],[A])
     * @return String
     * @author pmanohar
     * @since 11-15-2019
     */
    public static String getElementType(String elementName) {
        if (elementName.contains("[O]"))
            return ElementType.OBJECT.getElementType();
        else if (elementName.contains("[A]"))
            return ElementType.ARRAY.getElementType();
        else if (elementName.contains("[P]"))
            return ElementType.PRIMITIVE.getElementType();
        else if (elementName.contains("[N]"))
            return ElementType.NULL.getElementType();
        return EMPTY_STRING;
    }

    /**
     * This method is used to get the element name after removing the element type suffix([O],[N],[P],[A])
     *
     * @param elementName - name of the element along with its type([O],[N],[P],[A])
     * @return String
     * @author pmanohar
     * @since 11-15-2019
     */
    public static String getElementName(String elementName) {
        return elementName.replace("[O]", EMPTY_STRING).replace("[A]", EMPTY_STRING).replace("[P]", EMPTY_STRING).replace("[N]", EMPTY_STRING);
    }

    /**
     * This method is used to check if the JSONElement object is of type JSONArray
     *
     * @param jsonElement - represent JSONElement object from the JSON response
     * @return boolean
     * @author pmanohar
     * @since 11-15-2019
     */
    public static boolean isJsonElementAnArray(JsonElement jsonElement) {
        boolean blnResult = false;
        try {
            blnResult = jsonElement.isJsonArray();
        } catch (Exception e) {
            return blnResult;
        }
        return blnResult;
    }

    /**
     * This method is used to check if the JSONElement object is of type JSONObject
     *
     * @param jsonElement - represent JSONElement object from the JSON response
     * @return boolean
     * @author pmanohar
     * @since 11-15-2019
     */
    public static boolean isJsonElementAnObject(JsonElement jsonElement) {
        boolean blnResult = false;
        try {
            blnResult = jsonElement.isJsonObject();
        } catch (Exception e) {
            return blnResult;
        }
        return blnResult;
    }

    /**
     * This method is used to check if the JSONElement object is of type Primitive
     *
     * @param jsonElement - represent JSONElement object from the JSON response
     * @return boolean
     * @author pmanohar
     * @since 11-15-2019
     */
    public static boolean isJsonElementPrimitive(JsonElement jsonElement) {
        boolean blnResult = false;
        try {
            blnResult = jsonElement.isJsonPrimitive();
        } catch (NullPointerException e) {
            return blnResult;
        }
        return blnResult;
    }

    /**
     * This method is used to check if the JSONElement object is of type Null
     *
     * @param jsonElement - represent JSONElement object from the JSON response
     * @return boolean
     * @author pmanohar
     * @since 11-15-2019
     */
    public static boolean isJsonElementNull(JsonElement jsonElement) {
        boolean blnResult = false;
        try {
            blnResult = jsonElement.isJsonNull();
        } catch (Exception e) {
            return blnResult;
        }
        return blnResult;
    }

    /**
     * This method is used to convert a set into a list
     *
     * @param set - respresents a set of type T
     * @return List<T>
     * @author pmanohar
     * @since 11-21-2019
     */
    public static <T> List<T> getList(Set<T> set) {
        // create an empty list
        List<T> list = new ArrayList<>();

        // push each element in the set into the list
        for (T t : set)
            list.add(t);

        // return the list
        return list;
    }

    /**
     * This method is used to parse the JSON String into JSON Element
     *
     * @param jsonString - represent JSONElement object from the JSON response
     * @return boolean
     * @author aswain
     * @since 11-21-2019
     */
    public static JsonElement parseJson(String jsonString) {
        //initialize jspon parser object
        JsonParser parser = new JsonParser();
        //parse the json string
        return parser.parse(jsonString);
    }

    /**
     * Gets the request body.
     *
     * @return the request body
     * @author aswain
     * @since 11-21-2019
     */
    private static JsonElement getRequestBody() {
        JsonElement requestBody = null;
        Gson gson = new Gson();
        try {
            String str = testData.get("requestBody");
            LPLCoreReporter.writeStepToReporter(str != null,
                    LPLCoreConstents.TRUE,
                    "Setting up Request body",
                    "Response body should be setup successfully",
                    "Response body is set to - " + str,
                    "Failed to get the Request body from FARM.",
                    false);
            requestBody = gson.fromJson(testData.get("requestBody"), JsonElement.class);
        } catch (JsonIOException | JsonSyntaxException e) {
            LPLCoreReporter.writeStepToReporter(false,
                    LPLCoreConstents.TRUE,
                    "Get Request body",
                    "User should get the request body from the json file",
                    "User got the request body successfully ",
                    "Failed to get the Requestbody. Error Message:- Syntax is wrong in requestbody" + e.getMessage(),
                    false);
        }
        return requestBody;

    }

    /**
     * Checks if is response elements matched.
     *
     * @param actualResponse   the actual response
     * @param expectedElements the expected elements
     * @return true, if is response elements matched
     * @author aswain
     * @since 12-11-2019
     */
    public static boolean isResponseElementsMatched(String actualResponse, String[] expectedElements) {
        boolean bStatus = true;
        String[] actualData = getResponseArray(actualResponse);
        List<String> extraElementonResponse = Arrays.asList(actualData).stream().filter(obj -> !Arrays.asList(expectedElements).contains(obj)).collect(Collectors.toList());

        if (!extraElementonResponse.isEmpty()) {
            strError += "Extra Elements added to the response : \n" + String.join("\n", extraElementonResponse);
            bStatus = false;
        }
        return bStatus;
    }

    /**
     * Gets the response array.
     *
     * @param response the response
     * @return the response array
     * @author aswain
     * @since 12-11-2019
     */
    public static String[] getResponseArray(String response) {
        String currentPath = EMPTY_STRING;
        JsonElement jsonElement = new JsonParser().parse(response);
        if (isJsonElementAnObject(jsonElement)) {
            jsonElements.add(OBJECT_PREFIX);
            currentPath += OBJECT_PREFIX + FORWORD_SLASH;
        }
        parseJsonElement(jsonElement, currentPath);
        return jsonElements.toArray(new String[0]);
    }

    /**
     * Parses the json element.
     *
     * @param jsonElement the json element
     * @param currentPath the current path
     * @author aswain
     * @since 12-11-2019
     */
    public static void parseJsonElement(JsonElement jsonElement, String currentPath) {
        JsonObject jsonObject = null;
        Set<String> keys = null;
        if (jsonElement.isJsonObject()) {
            jsonObject = jsonElement.getAsJsonObject();

        } else if (jsonElement.isJsonArray()) {
            jsonObject = jsonElement.getAsJsonArray().get(0).getAsJsonObject();

        } else {
            jsonObject = new JsonObject();
        }
        keys = getKeySet(jsonObject);
        StringBuilder path = new StringBuilder(currentPath);
        for (String elementName : keys) {
            JsonElement jsonElement1 = jsonObject.get(elementName);
            if (jsonElement1.isJsonObject()) {
                path.append(elementName + OBJECT_PREFIX + FORWORD_SLASH);
                parseJsonElement(jsonElement1, path.toString());
            } else if (jsonElement1.isJsonArray()) {
                path.append(elementName + ARRAY_PREFIX + FORWORD_SLASH);
                parseJsonElement(jsonElement1, path.toString());
            } else if (jsonElement1.isJsonPrimitive()) {
                path.append(elementName + PRIMITIVE_PREFIX + FORWORD_SLASH);
            } else if (jsonElement1.isJsonNull()) {
                path.append(elementName + NULL_PREFIX + FORWORD_SLASH);
            }
            jsonElements.add(path.substring(0, path.length() - 1));
            path = new StringBuilder(removePrimitiveElement(path.toString()) + FORWORD_SLASH);
        }
    }

    /**
     * Gets the key set.
     *
     * @param jsonElement the json element
     * @return the key set
     * @author aswain
     * @since 12-11-2019
     */
    public static Set<String> getKeySet(JsonElement jsonElement) {
        if (jsonElement.isJsonObject() && !jsonElement.isJsonNull())
            return jsonElement.getAsJsonObject().keySet();
        else if (jsonElement.isJsonArray() && !jsonElement.isJsonNull()) {
            return jsonElement.getAsJsonArray().get(0).getAsJsonObject().keySet();
        }
        return new HashSet<>();
    }

    /**
     * Checks if is json at end node.
     *
     * @param jsonElement the json element
     * @return true, if is json at end node
     * @author aswain
     * @since 12-11-2019
     */
    public static boolean isJsonAtEndNode(JsonElement jsonElement) {
        Set<String> keys = getKeySet(jsonElement);
        for (String key : keys) {
            if (isJsonElementAnObject(jsonElement)) {
                if (isJsonElementAnArray(jsonElement.getAsJsonObject().get(key)) || isJsonElementAnObject(jsonElement.getAsJsonObject().get(key)))
                    return false;
            } else if (isJsonElementAnArray(jsonElement)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Removes the primitive element.
     *
     * @param str the str
     * @return the string
     * @author aswain
     * @since 12-11-2019
     */
    public static String removePrimitiveElement(String str) {
        boolean primitiveOrNullElementFound = false;
        String fs = str.substring(0, str.length() - 1);
        String[] parts = fs.split(FORWORD_SLASH);
        String lastElementName = parts[parts.length - 1];
        String element;
        if (lastElementName.contains(PRIMITIVE_PREFIX) || lastElementName.contains(NULL_PREFIX)) {
            primitiveOrNullElementFound = true;
            parts[parts.length - 1] = EMPTY_STRING;
            element = String.join(FORWORD_SLASH, parts);
        } else {
            element = String.join(FORWORD_SLASH, Arrays.copyOfRange(parts, 0, parts.length - 1));
        }

        if (primitiveOrNullElementFound)
            return element.substring(0, element.length() - 1);
        else
            return element;
    }

    /**
     * This method is used to retrieve the transaction cookie without launching the browser.
     *
     * @param url
     * @param userName
     * @param password
     * @return the string
     * @author pmurugesan
     * @since 02-11-2020
     */
    private static String getCWSessionCookiesWithoutBrowser(String url, String userName, String password) {
        boolean blnResult = CWSession.createCWSession(url, userName, password);
        if (!blnResult)
            // Failed to create CW session
            LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, " User creates the CW session. ", " User should be able to create CW session. ", " User created the CW session. ",
                    " User unable to create CW session. ");

        try {
            sessionCookiesCWWithoutBrowser = CWSession.getCWSessionCookies();

            String xsrftoken1 = sessionCookiesCWWithoutBrowser.get("XSRF-TOKEN");
            String auth = sessionCookiesCWWithoutBrowser.get("Auth");
            String zCookie = sessionCookiesCWWithoutBrowser.get("z");
            if (xsrftoken1 == null || auth == null || zCookie == null)
                LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "User retrieves the auth/XSRF-TOKEN/z Cookies", " User should be able to rerieve auth/XSRF-TOKEN/z Cookies. ", " User retrieved the auth/XSRF-TOKEN/z Cookies. ", " User unable to retrieve auth/SRF-TOKEN/z Cookies. ");
            return "auth=" + auth + "; XSRF-TOKEN=" + xsrftoken1 + "; z=" + zCookie + ";";
        } catch (NullPointerException e) {
                LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "User retrieves the CW Session Cookies. ", "User should be able to get CW Session Cookies. ",
                        "User able to get CW Session Cookies. ", "User able to get CW Session Cookies. ");
        }
        return "";
    }

    /**
     * This method is used to return the captured error message.
     *
     * @return string
     * @author pmanohar
     * @since 02-11-2020
     */
    public static String getStrError(){
        return strError;
    }
}
