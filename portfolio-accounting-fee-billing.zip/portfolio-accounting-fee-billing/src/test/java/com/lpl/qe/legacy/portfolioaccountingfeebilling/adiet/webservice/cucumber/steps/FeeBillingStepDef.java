package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.FeeBilling;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> FeeBillingStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for FeeBilling</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * FeeBillingStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class FeeBillingStepDef extends CommonStepDef {
	int passCounter = 0;
	int failCounter = 0;
	int totalScenarioCount = 0;

	@Then("^I completed the process if any user blocked fee billing$")
	public void completeTheProcessIfAnyUserBlockedFeeBilling() {
		boolean blnResult = feeBilling.completeTheProcessIfAnyUserBlockedFeeBilling();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Completed the process if any user blocked fee billing",
				"User should able to complete the process if any user blocked fee billing",
				"Successfully able to complete the process if any user blocked fee billing",
				"Feebilling: Quarterly/Adhoc run is currently in progress:" + Common.strError);
	}

	@When("^I click on Adhoc button$")
	public void iClickonAdhocbutton() {
		boolean blnResult = feeBilling.iClickOnAdhocButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Adhoc button",
				"User should able to click Adhoc button", "Successfully able to click Adhoc button",
				"Failed to click Adhoc button :" + Common.strError);
	}

	@Then("^I should land on to Select Billing Processing Options screen$")
	public void iShouldlandontoSelectBillingProcessingOptionsscreen() {
		boolean blnResult = feeBilling.iShouldLandOnSelectBillingScreen();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Select Billing Processing screen",
				"User should be able to see Select Billing Processing screen",
				"Successfully able to see Select Billing Processing screen",
				"Failed to see Select Billing Processing screen : " + Common.strError);
	}

	@When("^I enter Quarter end date$")
	public void iEnterQuarterenddate() {
		boolean blnResult = feeBilling.iEnterQuarterEndDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Quarter end date",
				"User should be able to enter Quarter end date", "Successfully able to enter Quarter end date",
				"Failed to enter Quarter end date : " + Common.strError);
	}

	@When("^I enter Account List in Billing Processing Options screen$")
	public void iEnterAccountListinBillingProcessingOptionsscreen() {
		boolean blnResult = feeBilling.iEnterAccountList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Account List",
				"User should be able to enter Account List", "Successfully able to enter Account List",
				"Failed to enter Account List : " + Common.strError);
	}

	@When("^I select Generate file option$")
	public void iSelectGeneratefileoption() {
		boolean blnResult = feeBilling.iSelectGenerateFileoption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Generate file option checkbox",
				"User should able to select Generate file option checkbox",
				"Successfully able to select Generate file option checkbox",
				"Failed to select Generate file option checkbox :" + Common.strError);
	}

	@When("^I click on Next button in Billing Processing Options screen$")
	public void iClickonNextbuttoninBillingProcessingOptionsscreen() {
		boolean blnResult = feeBilling.iClickonNextbutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Next button",
				"User should able to click Next button", "Successfully able to click Next button",
				"Failed to click Next button :" + Common.strError);
	}

	@When("^I click on Confirm & Process$")
	public void iClickonConfirmProcess() {
		boolean blnResult = feeBilling.iClickonConfirmProcess();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Confirm & Process button",
				"User should able to click Confirm & Process button",
				"Successfully able to click Confirm & Process buton",
				"Failed to click Confirm & Process button :" + Common.strError);
	}

	@Then("^I should see OK button displayed$")
	public void iShouldseestatusasGenerateFeesSuccess() {
		boolean blnResult = feeBilling.iShouldseeOkButtonDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availability of Ok Button",
				"User should be able to see Ok Button", "Successfully able to see Ok Button",
				"Failed to see Ok Button : " + Common.strError);
	}

	@When("^I click on Ok button$")
	public void iClickonOkbutton() {
		boolean blnResult = feeBilling.iclickonOkButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Ok button",
				"User should able to click OK button", "Successfully able to click OK buton",
				"Failed to click OK button :" + Common.strError);
	}

	@When("^I click on Account Details report$")
	public void iClickOnAccountDetailsReport() {
		boolean blnResult = feeBilling.clickOnAccountDetailsReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Account Details report link",
				"User should able to click on Account Details report link",
				"Successfully able to click on Account Details report link",
				"Failed to click on Account Details report link :" + Common.strError);
	}

	@Then("^I see Account Detail Report Options$")
	public void iSeeAccountDetailsReportOptions() {
		boolean blnResult = feeBilling.seeAccountDetailsReportOptions();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"I verify the existense of Account Detail Report Options",
				"User should able to see Account Detail Report Options",
				"Successfully able to Account Detail Report Options",
				"Failed to Account Detail Report Options :" + Common.strError);
	}

	@When("^I enter Account Number in Account Detail Report Options$")
	public void iEnterAccountNumberInAccountDetailReportOptions() {
		boolean blnResult = feeBilling.enterAccountNumberInAccountDetailReportOptions();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"I enter Account Number in Account Detail Report Options",
				"User should able to enter Account Number in Account Detail Report Options",
				"Successfully able to enter Account Number in Account Detail Report Options",
				"Failed to enter Account Number in Account Detail Report Options :" + Common.strError);
	}

	@When("^I click on Run Report$")
	public void iClickOnRunReport() {
		boolean blnResult = feeBilling.clickOnRunReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Run report",
				"User should able to click on Run report", "Successfully able to click on Run report",
				"Failed to click o nRun report :" + Common.strError);
	}

	@When("^I login on the report tab$")
	public void iLogInOnReportTab() {
		accountUpdatesAndInfoPage.logInToAdietApplication();
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE, "Log in on the Report tab",
				"User should be able to Log in to Report tab", "Successfully able to Log in to Report tab",
				"Failed to Log in to Report tab: " + Common.strError);
	}

	@Then("^I verify that I see Account Details report$")
	public void iVerifyThatISeeAccountDetailsReport() {
		boolean blnResult = feeBilling.verifyTheAccountDetailsReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Account Details report is visible", "User should be able to see Account Details report",
				"Successfully able to see Account Details report",
				"Failed to see Account Details report: " + Common.strError);
	}

	@Then("^I validate the Account Details report data$")
	public void validateAccountDetailsReportData() {
		boolean blnResult = feeBilling.validateAccountDetailsReportData();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"validate the Account Details report data",
				"User should be able to validate the Account Details report data",
				"Successfully able to validate the Account Details report data",
				"Failed to validate the Account Details report data: " + Common.strError);
	}

	@When("^I click on Cancel in Review Menu Screen$")
	public void iClickonCancelinReviewMenuScreen() {
		boolean blnResult = feeBilling.iclickonCancel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Cancel button",
				"User should able to click Cancel button", "Successfully able to click Cancel buton",
				"Failed to click Cancel button :" + Common.strError);
	}

	@When("^I connect to BODS SQL Server$")
	public void connectToBodsSqlServer() {
		try {
			FeeBilling.connectToBodsSqlServer();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE, "Connect to BODS SQL Server",
				"User should be able to Connect to BODS SQL Server", "Successfully able to Connect to BODS SQL Server",
				"Failed to see Connect to BODS SQL Server : " + Common.strError);
	}

	@When("^I run the SQL query to validate if (.+) Account exist in the data$")
	public void runTheSQLQueryToValidateIfAccountExistInData(String accountType) {
		feeBilling.runTheSQLQueryToValidateIfSpecificAccountExistInData(accountType);
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to validate if " + accountType + " Account exist in the data",
				"User should be able to run the SQL query to validate if " + accountType + " Account exist in the data",
				"Successfully able to Run the SQL query to validate if " + accountType + " Account exist in the data",
				"Failed to Run the SQL query to validate if " + accountType + " Account exist in the data :"
						+ Common.strError);
	}

	@Then("^I verify that results prove that (.+) Account exist in the data - (.+)$")
	public void verifyResultsProveThatSpecificAccountExistInData(String accountType, String scenarioNumber) {
		boolean blnResult = feeBilling.verifyResultsProveThatAccountExistInData();
		// Count total passed and failed test cases
		if (blnResult)
			passCounter++;
		else
			failCounter++;

		// Count total scenarios
		totalScenarioCount++;
		// Print Test data existence with passed/failed result for the different account
		// types (Premium MS|Premium MWP|Premium SAM2|Non Premium)
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Verify " + accountType + " Account exist in the data",
				accountType + " Account should exist in the data",
				accountType + " Account exist in the data for " + scenarioNumber + " = " + blnResult,
				accountType + " Account do not should exist in the data :" + Common.strError);
	}

	@When("^I run the SQL query to validate that Premium fee rates & fees calculated accurately - scenario:5 validates data for 1,2,3,4$")
	public void runTheSQLQueryToValidatePremiumFeeRatesAndFees() {
		feeBilling.runTheSQLQueryToValidatePremiumFeeRatesAndFees();
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to validate the Premium fee rates & fees",
				"User should be able to Run the SQL query to validate Premium fee rates & fees",
				"Successfully able to Run the SQL query to validate that Premium fee rates & fees calculated accurately",
				"Failed to Run the SQL query to validate that Premium fee rates & fees calculated accurately:"
						+ Common.strError);
	}

	@Then("^I verify that results prove that Premium fee rates & fees calculated accurately$")
	public void verifyResultsProveThatPremiumFeeRatesFeesCalculatedAccurately() {
		boolean blnResult = feeBilling.verifyResultsProveThatPremiumFeeRatesFeesCalculatedAccurately();
		// Count total passed and failed test cases
		if (blnResult)
			passCounter++;
		else
			failCounter++;

		// Count total scenarios
		totalScenarioCount++;
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Verify Premium fee rates & fees calculated accurately",
				"Premium fee rates & fees should be calculated accurately",
				"Premium fee rates & fees got calculated accurately for scenario:5 validates data for 1,2,3,4 = "
						+ blnResult,
				"Premium fee rates & fees did not get calculated accurately :" + Common.strError);
	}

	@When("^I run the SQL query to validate that Employee Model Rebate calculated accurately - scenario:11 validates data for 6 to 10$")
	public void runTheSQLQueryToValidateEmployeeRebate() {
		feeBilling.runTheSQLQueryToValidateEmployeeRebate();
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to validate the Employee Rebate",
				"User should be able to Run the SQL query to validate Employee Rebate",
				"Successfully able to Run the SQL query to validate that Employee Rebate calculated accurately",
				"Failed to Run the SQL query to validate that Employee Rebate calculated accurately:"
						+ Common.strError);
	}

	@Then("^I verify that results prove that Employee Model Rebate calculated accurately$")
	public void verifyResultsProveThatEmployeeRebateCalculatedAccurately() {
		boolean blnResult = feeBilling.verifyResultsProveThatEmployeeRebateCalculatedAccurately();
		// Count total passed and failed test cases
		if (blnResult)
			passCounter++;
		else
			failCounter++;

		// Count total scenarios
		totalScenarioCount++;
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE, "Verify Employee Rebate calculated accurately",
				"Employee Rebate should be calculated accurately",
				"Employee Rebate got calculated accurately for scenario:5 validates data for 1,2,3,4 = " + blnResult,
				"Employee Rebate did not get calculated accurately :" + Common.strError);
	}

	@Then("^I print the passed and failed count with overall test case result status in the report$")
	public void printThePassedAndFailedCountResults() {
		boolean blnResult;
		String totalScenariosCount = Integer.toString(totalScenarioCount);
		String totalPassedCount = Integer.toString(passCounter);
		String totalFailedCount = Integer.toString(failCounter);
		if (failCounter > 0)
			blnResult = false;
		else
			blnResult = true;
		// Print over all passed/failed scenario count for different account types
		// (Premium MS|Premium MWP|Premium SAM2|Non Premium)
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Print total passed and failed test scenarios and final test result",
				"Total passed and failed test scenarios result needs to be print ",
				"Fee-billing Script passed and the Results are, Total Scenarios =" + totalScenariosCount
						+ ",Passed Scenarios= " + totalPassedCount + ",Failed Count=" + totalFailedCount,
				"Fee-billing Script failed and the Results are : Total Scenarios =" + totalScenariosCount
						+ ",Passed Scenarios= " + totalPassedCount + ",Failed Count=" + totalFailedCount + ","
						+ Common.strError);
	}

	@Then("^I run the SQL query to identify expected and actual Schedule A Program Rate using Account AUM$")
	public void runTheSQLQueryToIdentifyExpectedAndActualScheduleAProgramRateUsingAccountAUM() {
		feeBilling.runTheSQLQueryToIdentifyExpectedAndActualScheduleAProgramRateUsingAccountAUM();
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to identify the expected Program Rate using Account AUM",
				"User should be able to run the SQL query to identify the expected Program Rate using Account AUM",
				"Successfully able to Run the SQL query to identify the expected Program Rate using Account AUM",
				"Failed to Run the SQL query to identify the expected Program Rate using Account AUM :"
						+ Common.strError);
	}

	@Then("^I verify that results to prove that Schedule A Program Rate used in Fee Billing is derived from Account AUM$")
	public void verifyThatResultsToProveThatSheduleAProgramRateUsedInFeeBillingIsDerivedFromAccountAUM() {
		feeBilling.verifyThatResultsToProveThatScheduleAProgramRateUsedInFeeBillingIsDerivedFromAccountAUM();
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Compare the Actual Program Rate against expected Program Rate",
				"Actual Program Rate should match with expected Program Rate",
				"Actual Program Rate matches with expected Program Rate",
				"Actual Program Rate is not matching with the expected Program Rate :" + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
