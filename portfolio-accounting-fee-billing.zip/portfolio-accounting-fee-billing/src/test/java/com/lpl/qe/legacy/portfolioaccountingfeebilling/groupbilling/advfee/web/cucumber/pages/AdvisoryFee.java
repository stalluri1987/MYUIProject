package com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> AdvisoryFee.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for AdvisoryFee</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AdvisoryFee : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author Abdul Hadi
 * @since 07/14/2020
 *        </p>
 */

public class AdvisoryFee extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 951;
	Map<String, HashMap<String, String>> pageObjectMap;
	Common commonMethods = new Common(driver);

	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String HAMBURGER_MENU = "Hamburger Icon";
	public static final String TOOLS_TAB = "Tools Tab";
	public static final String FEE_SCHEDULING_SUB_TAB = "Fee Scheduling Sub Tab";
	public static final String TIERED_ADVISORY_FEE_TAB = "Tiered Advisory Fee Tab";
	public static final String MASTER_REPID_TEXTBOX = "Master RepId Textbox";
	public static final String MASTER_REP = "Master Rep";
	public static final String SAM_PLATFORM_CHECKBOX = "SAM Platform Checkbox";
	public static final String CANCEL_BUTTON = "Cancel Button";
	public static final String RATE_TEXTBOX = "Rate TextBox";
	public static final String SUCESS_HEADER = "Success Header";
	public static final String OK_BUTTON = "Ok Button";
	public static final String OK_BUTTON_IN_DELETE_CONFIRMATION_POPUP = "Ok Button in Delete confirmation Pop up";
	public static final String FLAT_FEE_DEFAULT_BANNER = "Falt Fee Default Banner";
	public static final String LOGOUT = "Log out";
	public static final String CREATE_YOUR_FIRST_FLAT_FEE_SECTION = "Create Your First Flat Fee Section";
	public static final String HINT_WHAT_ARE_DEFAULT = "What are default flat fees hint message";
	public static final String HINT_WHAT_IS_MY_DEFAULT = "What is my default hint message";
	public static final String HINT_HOW_WOULD_I_EDIT_SCHEDULE = "How would I edit a schedule hint message";
	public static final String HINT_WHAT_IS_MAX_AND_MIN_SCHEDULE = "What is the Minimum and Maximum rate hint message";
	public static final String CREATE_NEW_FLAT_FEE_BUTTON = "Create New Flat Fee Button";
	public static final String CREATE_FALT_FEE_DEFAULT_PAGE = "Create Flat Fee Default Page";
	public static final String CREATE_BUTTON_DISABLED = "Create Default button Is Disabled";
	public static final String CREATE_BUTTON_ENABLED = "Create Default button Is Enabled";
	public static final String CREATE_DEFAULT = "Create Default";
	public static final String FALT_FEE_DEFAULT_BANNER = "Flat Fee Default Banner";
	public static final String CONTEXT_MENU = "Context Menu";
	public static final String VIEW_EDIT_BUTTON = "View Edit Button";
	public static final String SELECT_VIEW_EDIT_OPTION = "Select View Edit Option";
	public static final String SAM = "SAM";
	public static final String SAM_DISABLED_CHECKBOX = "SAM Disabled Platform Checkbox";
	public static final String SWM = "SWM";
	public static final String SWM_DISABLED_CHECKBOX = "SWM Disabled Platform Checkbox";
	public static final String EDIT_DEFAULT_BUTTON_DISABLED = "Edit Default Button Disabled";
	public static final String EDIT_DEFAULT_BUTTON = "Edit Default Button";
	public static final String EDIT_DEFAULT = "Edit Flat Default";
	public static final String DELETE_OPTION = "Delete Option";
	public static final String DELTE_CONFIRMATION_POP_UP = "Delete Confirmation Pop Up";
	public static final String CREATE_NEW_BUTTON = "Create New Button";
	public static final String CREATE_NEW_SCHEDULE_PAGE = "Create New Schedule page";
	public static final String SAVE_BUTTON_DISABLED = "Save Button disabled";
	public static final String SCHEDULE_NAME = "Schedule Name";
	public static final String MAXIMUM_INVESTMENT_FIRST_TIER = "Maximum Investment First Tier";
	public static final String FEE_PERCENTAGE_FIRST_TIER = "Fee percentage First Tier";
	public static final String ADD_TIER_LINK = "Add Tier link";
	public static final String MAXIMUM_INVESTMENT_SECOND_TIER = "Maximum Investment Second Tier";
	public static final String FEE_PERCENTAGE_SECOND_TIER = "Fee percentage Second Tier";
	public static final String FEE_PERCENTAGE_THIRD_TIER = "Fee percentage Third Tier";
	public static final String SAVE_BUTTON_ENABLED = "Save Button Enabled";
	public static final String SAVE_BUTTON = "Save Button";
	public static final String CONFIRMATION_POPUP = "Confirmation Popup";
	public static final String NEW_SCHEDULE = "New Schedule";
	public static final String OPEN_MENU_ITEM = "Open Menu item";
	public static final String MENU_ITEM = "Menu item";
	public static final String SELECT_OR_MANAGE_PLATFORM = "Select Or Manage Platform";
	public static final String SELECT_OR_MANAGE_PLATFORM_PAGE = "Select Or Manage Platform page";
	public static final String SAM_PLATFORM = "SAM platform";
	public static final String SETTING_YOUR_DEFAULT_HINT_MESSAGE = "Setting your default hint message";
	public static final String SAM_CHECKBOX = "SAM Checkbox";
	public static final String SAVE_DEFAULTS = "Save Defaults";
	public static final String DELETE_MENU_OPTION = "Delete Menu option";
	public static final String NEW_SCHEDULE_DELETED = "New schedule deleted";
	public static final String SWM_PLATFORM = "SWM platform";
	public static final String SWM_CHECKBOX = "SWM checkbox";
	public static final String CREATE_NEW_BUTTON_DISABLED = "Create New Flat button is disabled";
	public static final String SWITCH_MASTER_REP = "Switch Master Rep";
	public static final String PLATFORM_HAMBURGER_LINK = "Platform Hamburger link";
	public static final String OPEN_OPTION_ENABLED = "Open Option is enabled";
	public static final String SCHEDULE_HAMBURGER_LINK = "Schedule Hamburger link";
	public static final String DEFAULT_PLATFORM = "Default Platform";
	public static final String SAM_MIN_MAX_RATE = "SAM Minimum and Maximum rate";
	public static final String SWM_MIN_MAX_RATE = "SWM Minimum and Maximum rate";
	public static final String CREATE_NEW_BUTTON_ENABLED = "Create New Flat button is enabled";
	public static final String SCHEDULE_SECTION = "Schedule Section";
	public static final String FLAT_FEE_SECTION = "Flat Fee Section";
	public static final String CREATE_YOUR_FIRST_SCHEDULE_SECTION = "Create Your First Schedule Section";
	public static final String ISDISABLED = "is disabled";
	public static final String FAILED_TO_SEE = " Failed to see";
	public static final String SUCCEESFULLY_BE_ABLE_TO_SEE = "Successfully be able to see ";

	String strLogOutXpath;
	String strHamburgerIconXpath;
	String strToolsTabXpath;
	String strFeeSchedulingSubTabXpath;
	String strTieredAdvisoryFeeTabXpath;
	String strMasterRepTextboxXpath;
	String strSelectMasterRepXpath;
	String strWhatAreDefaultFlatFeeHintXpath;
	String strWhatIsMyDefaultHintXpath;
	String strHowIeditScheduleHintXpath;
	String strCreateNewFlatFeeButtonXpath;
	String strSAMplatformCheckedXpath;
	String strPlatformDisabledXpath;
	String strCancelButtonXpath;
	String strRateTextBoxXpath;
	String strSuccessHeaderXpath;
	String strOkButtonXpath;
	String strFaltFeeDefaultBannerXpath;
	String strCreateWhatIsMaxAndMinRateHintXpath;
	String strCreateDefaultDisableBtnXpath;
	String strCreateDefaultEnableXpath;
	String strContextMenuXpath;
	String strOptionsBesidePlatFormXpath;
	String strEditDefaultDisableBtnXpath;
	String strEditDefaultEnableXpath;
	String strUpdatedRateCheckXpath;
	String strDeleteOptionXpath;
	String strDeleteSchedulePopUpXpath;
	String strOkButtonInDeletePopUpXpath;
	String strEditOptionXpath;
	String strDeleteOptionsXpath;
	String strEditDefaultPageXpath;
	String strCreateFlatFeeDefaultPageXpath;
	String strSWMplatformCheckedXpath;
	String strSWMplatformDisabledXpath;
	String strCreateNewScheduleButtonXpath;
	String strCreateNewSchedulePageXpath;
	String strSaveButtonDisabledXpath;
	String strScheduleNameTextboxXpath;
	String strMaximumInvestmentFirstTierXpath;
	String strFeePercentageFirstTierXpath;
	String strAddTierLinkXpath;
	String strMaximumInvestmentSecondTierXpath;
	String strFeePercentageSecondTierXpath;
	String strFeePercentageThirdTierXpath;
	String strSaveButtonEnabledXpath;
	String strOkbuttonInSuccessPopUpXpath;
	String strNewlyAddedScheduleNameXpath;
	String strContextMenuForScheduleTierXpath;
	String strMenuItemOpenXpath;
	String strMenuItemsBesideScheduleNameXpath;
	String strSelectOrManageXpath;
	String strManagePlatformDefaultPageXpath;
	String strSAMcheckBoxXpath;
	String strSettingYourDefaultScheduleHintXpath;
	String strSaveDefaultButtonXpath;
	String strDeleteMenuItemBesideScheduleNameXpath;
	String strDeleteScheduleTierPopUpXpath;
	String strDeleteOkButtonXpath;
	String strNewScheduleIsTaggedAsDefaultForSAMXpath;
	String strNewScheduleIsTaggedAsDefaultForSWMXpath;
	String strSWMcheckBoxXpath;
	String strOkbuttonInConfirmationDeletePopUpXpath;
	String strOkbuttonInManageSuccessPopUpXpath;
	String strManageScheduleSuccessHeaderXpath;
	String strOptionsBesidePlatFormDisabledXpath;
	String strCreateNewFlatFeeDisableBtnXpath;
	String strFlatCreateNewDisableBtnXpath;
	String strSwitchMasterRepXpath;
	String strFlatViewOrEditDisabledXpath;
	String strFlatDeleteDisabledXpath;
	String strFlatPlatformMenuItemsLinkXpath;
	String strTieredCreateNewDisableBtnXpath;
	String strOpenOptionXpath;
	String strTieredScheduleMenuItemsLinkXpath;
	String strDefaultPlatformColumnXpath;
	String strScheduleContextMenuForReadOnlyXpath;
	String strCreateYourFirstFlatFeeXpath;
	String strSelectOrManagePlatformDefaultXpath;
	String strMinimumAndMaximumRateForSAMplatformXpath;
	String strMinimumAndMaximumRateForSWMplatformXpath;
	String strOkButtonForDeleteXpath;
	String strCreateNewFlatFeeXpath;
	String strScheduleSectionXpath;
	String strCreateNewButtonXpath;
	String strCreateNewDisabledButtonXpath;
	String strCreateYourFirstScheduleSectionXpath;
	String strFlatFeeDefaultSectionXpath;
	String strSelectorManagePlatformOptionXpath;

	public AdvisoryFee(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This function is used to log out from the application
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean clickLogOut() {
		return clickElementUsingXpath(strLogOutXpath, LOGOUT);
	}

	/**
	 * This function is used to Menu Hamburger icon
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean clickonMenuHamburgericon() {
		return commonMethods.clickElementUsingXpath(strHamburgerIconXpath, HAMBURGER_MENU);
	}

	/**
	 * This function is used to choose Tools From list
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean chooseToolsFromlist() {
		waitTillVisibleUsingXpath(strToolsTabXpath, TOOLS_TAB);
		return commonMethods.clickElementUsingXpath(strToolsTabXpath, TOOLS_TAB);
	}

	/**
	 * This function is used to choose Fee Scheduling from list
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean chooseFeeSchedulingfromlist() {
		return commonMethods.clickElementUsingXpath(strFeeSchedulingSubTabXpath, FEE_SCHEDULING_SUB_TAB);
	}

	/**
	 * This function is used to check Advisory fee tab
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean iShouldLandonAdvisoryFeeTab() {
		return isElementPresentUsingXpath(strTieredAdvisoryFeeTabXpath, LPLCoreConstents.getInstance().HIGH,
				TIERED_ADVISORY_FEE_TAB);
	}

	/**
	 * This function is used to click on Master Rep textbox
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean clickonMasterRepTextbox() {
		waitTillVisibleUsingXpath(strMasterRepTextboxXpath, MASTER_REP);
		return commonMethods.clickElementUsingXpath(strMasterRepTextboxXpath, LPLCoreConstents.getInstance().HIGH,
				MASTER_REP);
	}

	/**
	 * This function is used to select Rep
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean selectRep() {
		return commonMethods.clickElementUsingXpath(
				commonMethods.getFormattedLocator(strSelectMasterRepXpath, testData.get("strMasterRep")),
				LPLCoreConstents.getInstance().HIGH, MASTER_REPID_TEXTBOX);
	}

	/**
	 * This function is used to check Create Your First Flat Fee Section
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean checkCreateYourFirstFlatFeeSection() {
		return isElementPresentUsingXpath(strCreateNewFlatFeeButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_YOUR_FIRST_FLAT_FEE_SECTION);
	}

	/**
	 * This function is used to check hint Message For What Are Default Flat Fee
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean hintMessageForWhatAreDefaultFlatFee() {
		return isElementPresentUsingXpath(strWhatAreDefaultFlatFeeHintXpath, LPLCoreConstents.getInstance().LOWEST,
				HINT_WHAT_ARE_DEFAULT);
	}

	/**
	 * This function is used to check hint Message For How Would I Edit a Schedule
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/17/2019
	 **/
	public boolean hintMessageForHowWouldiEditaSchedule() {
		return isElementPresentUsingXpath(strHowIeditScheduleHintXpath, LPLCoreConstents.getInstance().LOWEST,
				HINT_HOW_WOULD_I_EDIT_SCHEDULE);
	}

	/**
	 * This function is used to check hint Message For Maximum And Minimum Rate For
	 * Each Platform
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/17/2019
	 **/
	public boolean hintMessageForMaximumAndMinimumRateForEachPlatform() {
		return isElementPresentUsingXpath(strCreateWhatIsMaxAndMinRateHintXpath, LPLCoreConstents.getInstance().LOWEST,
				HINT_WHAT_IS_MAX_AND_MIN_SCHEDULE);
	}

	/**
	 * This function is used to check hint Message For What is my Default Flat Fee
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean hintMessageForWhatIsMyDefaultFlatFee() {
		return isElementPresentUsingXpath(strWhatIsMyDefaultHintXpath, LPLCoreConstents.getInstance().LOWEST,
				HINT_WHAT_IS_MY_DEFAULT);
	}

	/**
	 * This function is used to click on Create NewFlat Fee
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean strCreateNewFlatFeeButtonXpath() {
		return commonMethods.clickElementUsingXpath(strCreateNewFlatFeeButtonXpath, CREATE_NEW_FLAT_FEE_BUTTON);
	}

	/**
	 * This function is used to check Create Flat Fee Default page
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean landOnCreateFlatFeeDefaultpage() {
		return isElementPresentUsingXpath(strCreateFlatFeeDefaultPageXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_FALT_FEE_DEFAULT_PAGE);
	}

	/**
	 * This function is used to check whether SAM platform is selected or not
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifySAMplatformIsSelected() {
		return isElementPresentUsingXpath(strSAMplatformCheckedXpath, LPLCoreConstents.getInstance().LOWEST,
				SAM_PLATFORM_CHECKBOX);
	}

	/**
	 * This function is used to check whether SWM platform is selected or not
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/17/2019
	 **/
	public boolean verifySWMplatformIsSelected() {
		return isElementPresentUsingXpath(strSWMplatformCheckedXpath, LPLCoreConstents.getInstance().LOWEST,
				SAM_PLATFORM_CHECKBOX);
	}

	/**
	 * This function is used to check whether Cancel button is enable or not
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifyCancelButtonIsEnabled() {
		return isElementPresentUsingXpath(strCancelButtonXpath, LPLCoreConstents.getInstance().LOWEST, CANCEL_BUTTON);
	}

	/**
	 * This function is used to check whether Create Default button is Disabled or
	 * not
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifyCreateDefaultbuttonIsDisabled() {
		return isElementPresentUsingXpath(strCreateDefaultDisableBtnXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_BUTTON_DISABLED);
	}

	/**
	 * This function is used to enter valid date
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean enterValidRate() {
		return commonMethods.enterTextUsingXpath(strRateTextBoxXpath, testData.get("strValidRate"), RATE_TEXTBOX);
	}

	/**
	 * This function is used to check Create Default button is enabled or not
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifyThatCreateDefaultbuttonIsEnabled() {
		return isElementPresentUsingXpath(strCreateDefaultEnableXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_BUTTON_ENABLED);
	}

	/**
	 * This function is used to click on Create Default
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean clickOnCreateDefault() {
		return commonMethods.clickElementUsingXpath(strCreateDefaultEnableXpath, CREATE_DEFAULT);
	}

	/**
	 * This function is used to verify the Success Message
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifySuccessMessageIsShown() {
		return isElementPresentUsingXpath(strSuccessHeaderXpath, LPLCoreConstents.getInstance().MEDIUM, SUCESS_HEADER);
	}

	/**
	 * This function is used to click on OK button
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean clickOnOKbutton() {
		return commonMethods.clickElementUsingXpath(strOkButtonXpath, OK_BUTTON);
	}

	/**
	 * This function is used to click on OK button in SAM delete confirmation pop up
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/21/2019
	 **/
	public boolean clickOnOKbuttonInDeleteSAMandSWMconfirmPopUp() {
		return commonMethods.clickElementUsingXpath(strOkButtonInDeletePopUpXpath,
				OK_BUTTON_IN_DELETE_CONFIRMATION_POPUP);
	}

	/**
	 * This function is used to validate default list page
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean shouldLandonDefaultListPage() {
		return isElementPresentUsingXpath(strFaltFeeDefaultBannerXpath, LPLCoreConstents.getInstance().MEDIUM,
				FLAT_FEE_DEFAULT_BANNER);
	}

	/**
	 * This function is used to verify the Presence of Flat fee Default
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifythePresenceofFlatfeeDefault() {
		return isElementPresentUsingXpath(strFaltFeeDefaultBannerXpath, LPLCoreConstents.getInstance().LOWEST,
				FALT_FEE_DEFAULT_BANNER);
	}

	/**
	 * This method is used to check Menu Item Listed Besides Platform Name
	 * 
	 * @param string
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/17/2020
	 */
	public boolean verifyMenuItemListedBesidesPlatformName(String menuItem) {
		commonMethods.clickElementUsingXpath(strContextMenuXpath, CONTEXT_MENU);
		return commonMethods.isElementPresentUsingXpath(
				commonMethods.getFormattedLocator(strOptionsBesidePlatFormXpath, menuItem), menuItem);
	}

	/***
	 * This function is used to verify Menu Items Listed Besides Platform Name
	 *
	 * @param DataTable
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifyMenuItemsListedBesidesPlatformName(DataTable menuItems) {
		boolean blnResult = false;
		List<Map<String, String>> filters = menuItems.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get("options");
			blnResult = verifyMenuItemListedBesidesPlatformName(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCEESFULLY_BE_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + commonMethods.strError);
		}
		return blnResult;
	}

	/**
	 * This function is used to select View Edit option
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean selectViewEditoption() {
		return commonMethods.clickElementUsingXpath(strEditOptionXpath, VIEW_EDIT_BUTTON);
	}

	/**
	 * This function is used to verify select View Edit option page
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean ishouldLandonSelectViewEditoption() {
		return isElementPresentUsingXpath(strEditDefaultPageXpath, LPLCoreConstents.getInstance().LOWEST,
				SELECT_VIEW_EDIT_OPTION);
	}

	/**
	 * This function is used to verify that SAM platform checkbox disabled or not
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/21/2019
	 **/
	public boolean verifySAMplatformCheckboxisDisabled() {
		return isElementPresentUsingXpath(commonMethods.getFormattedLocator(strPlatformDisabledXpath, SAM),
				SAM_DISABLED_CHECKBOX);
	}

	/**
	 * This function is used to verify that SWM platform checkbox disabled or not
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/21/2019
	 **/
	public boolean verifySWMplatformCheckboxisDisabled() {
		return isElementPresentUsingXpath(commonMethods.getFormattedLocator(strPlatformDisabledXpath, SWM),
				SWM_DISABLED_CHECKBOX);
	}

	/**
	 * This function is used to
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifyEditDefaultButtonisDisabled() {
		return isElementPresentUsingXpath(strEditDefaultDisableBtnXpath, EDIT_DEFAULT_BUTTON_DISABLED);
	}

	/**
	 * This function is used to edit rate to Some other valid value
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean editRateToSomeOtherValidValue() {
		return commonMethods.enterTextUsingXpath(strRateTextBoxXpath, testData.get("strChangeValidRate"), RATE_TEXTBOX);
	}

	/**
	 * This function is used to verify Edit Default button is enabled or not
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifyEditDefaultButtonisEnabled() {
		return isElementPresentUsingXpath(strEditDefaultEnableXpath, LPLCoreConstents.getInstance().LOWEST,
				EDIT_DEFAULT_BUTTON);
	}

	/**
	 * This function is used to click on Edit Default
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean clickOnEditDefault() {
		return commonMethods.clickElementUsingXpath(strEditDefaultEnableXpath, EDIT_DEFAULT);
	}

	/**
	 * This function is used to select Delete option
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean selectDeleteOption() {
		return commonMethods.clickElementUsingXpath(strDeleteOptionsXpath, DELETE_OPTION);
	}

	/**
	 * This function is used to verify Confirmation Popup
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 **/
	public boolean verifyConfirmationPopup() {
		return isElementPresentUsingXpath(strDeleteScheduleTierPopUpXpath, LPLCoreConstents.getInstance().LOWEST,
				DELTE_CONFIRMATION_POP_UP);
	}

	/**
	 * This function is used to click on Create New button under tiered schedules
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean clickOnCreateNewButtonUnderTieredSchedules() {
		return commonMethods.clickElementUsingXpath(strCreateNewScheduleButtonXpath, CREATE_NEW_BUTTON);
	}

	/**
	 * This function is used to land on Create New Schedule page
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean landOnCreateNewSchedulePage() {
		return isElementPresentUsingXpath(strCreateNewSchedulePageXpath, LPLCoreConstents.getInstance().LOW,
				CREATE_NEW_SCHEDULE_PAGE);
	}

	/**
	 * This function is used to verify that Save Button is disabled
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyThatSaveButtonIsDisabled() {
		return isElementPresentUsingXpath(strSaveButtonDisabledXpath, LPLCoreConstents.getInstance().LOWEST,
				SAVE_BUTTON_DISABLED);
	}

	/**
	 * This function is used to enter Schedule Name
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean ienterScheduleName() {
		return commonMethods.enterTextUsingXpath(strScheduleNameTextboxXpath, testData.get("strScheduleNameTextbox"),
				SCHEDULE_NAME);
	}

	/**
	 * This function is used to enter Maximum Investment for first tier
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/30/2019
	 **/
	public boolean enterMaximumInvestmentForFirstTier() {
		return commonMethods.enterTextUsingXpath(strMaximumInvestmentFirstTierXpath,
				testData.get("strMaximumInvestmentFirstTier"), MAXIMUM_INVESTMENT_FIRST_TIER);
	}

	/**
	 * This function is used to enter Fee percentage for first tier
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean enterFeePercentageForFirstTier() {
		return commonMethods.enterTextUsingXpath(strFeePercentageFirstTierXpath,
				testData.get("strFeePercentageFirstTier"), FEE_PERCENTAGE_FIRST_TIER);
	}

	/**
	 * This function is used to click on Add Tier link
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean clickOnAddTierLink() {
		return commonMethods.clickElementUsingXpath(strAddTierLinkXpath, ADD_TIER_LINK);
	}

	/**
	 * This function is used to enter Maximum Investment for second tier
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean ienterMaximumInvestmentforSecondTier() {
		return commonMethods.enterTextUsingXpath(strMaximumInvestmentSecondTierXpath,
				testData.get("strMaximumInvestmentSecondTier"), MAXIMUM_INVESTMENT_SECOND_TIER);
	}

	/**
	 * This function is used to enter Fee Percentage for second tier
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean enterFeePercentageForSecondTier() {
		return commonMethods.enterTextUsingXpath(strFeePercentageSecondTierXpath,
				testData.get("strFeePercentageSecondTier"), FEE_PERCENTAGE_SECOND_TIER);
	}

	/**
	 * This function is used to enter Fee Percentage for third tier
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean enterFeePercentageForThirdTier() {
		return commonMethods.enterTextUsingXpath(strFeePercentageThirdTierXpath,
				testData.get("strFeePercentageThirdTier"), FEE_PERCENTAGE_THIRD_TIER);
	}

	/**
	 * This function is used to verify the Save Button is enabled
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyTheSaveButtonIsEnabled() {
		commonMethods.clickElementUsingXpath(strCreateNewSchedulePageXpath, CREATE_NEW_BUTTON);
		return isElementPresentUsingXpath(strSaveButtonEnabledXpath, SAVE_BUTTON_ENABLED);
	}

	/**
	 * This function is used to click on Save Button
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean clickOnSaveButton() {
		return commonMethods.clickElementUsingXpath(strSaveButtonEnabledXpath, SAVE_BUTTON);
	}

	/**
	 * This function is used to get Confirmation Popup to Save tiered schedules
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean getSuccessPopupToSaveTieredSchedules() {
		return isElementPresentUsingXpath(strSuccessHeaderXpath, LPLCoreConstents.getInstance().MEDIUM,
				CONFIRMATION_POPUP);
	}

	/**
	 * This function is used to click on Ok button in tiered schedules confirmation
	 * popup
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/03/2019
	 **/
	public boolean clickOnOkButtonInTieredManageSchedulesSuccessPopup() {
		return commonMethods.clickElementUsingXpath(strOkbuttonInManageSuccessPopUpXpath, OK_BUTTON);
	}

	/**
	 * This function is used to click on Ok button in tiered schedules confirmation
	 * popup
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean clickOnOkButtonInTieredSchedulesSuccessPopup() {
		return commonMethods.clickElementUsingXpath(strOkbuttonInSuccessPopUpXpath, OK_BUTTON);
	}

	/**
	 * This function is used to click on Ok button in tiered schedules delete
	 * confirmation popup
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean clickOnOkButtonInTieredSchedulesDeleteConfirmationPopup() {
		return commonMethods.clickElementUsingXpath(strOkbuttonInConfirmationDeletePopUpXpath, OK_BUTTON);
	}

	/**
	 * This function is used to verify the presence of new schedule
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyThePresenceOfNewSchedule() {
		return isElementPresentUsingXpath(commonMethods.getFormattedLocator(strNewlyAddedScheduleNameXpath,
				testData.get("strScheduleNameTextbox")), NEW_SCHEDULE);
	}

	/**
	 * This function is used to verify open menu item listed besides schedule name
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyOpenMenuItemListedBesidesScheduleName() {
		return isElementPresentUsingXpath(strMenuItemOpenXpath, LPLCoreConstents.getInstance().LOWEST, NEW_SCHEDULE);
	}

	/**
	 * This function is used to verify open menu item listed besides schedule name
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/4/2020
	 **/
	public boolean clickNewScheduleMenu() {
		return commonMethods.clickElementUsingXpath(commonMethods.getFormattedLocator(
				strContextMenuForScheduleTierXpath, testData.get("strScheduleNameTextbox")), CONTEXT_MENU);
	}

	/**
	 * This method is used to verify Menu items listed besides schedule name
	 * 
	 * @param menuItem
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/17/2020
	 */
	public boolean verifyMenuItemListedBesidesScheduleName(String menuItem) {
		return commonMethods.isElementPresentUsingXpath(
				commonMethods.getFormattedLocator(strMenuItemsBesideScheduleNameXpath, menuItem), menuItem);
	}

	/**
	 * This function is used to verify Menu items listed besides schedule name
	 *
	 * @param DataTable
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyMenuItemsListedBesidesScheduleName(DataTable menuItems) {
		boolean blnResult = false;
		List<Map<String, String>> filters = menuItems.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get("options");
			blnResult = verifyMenuItemListedBesidesScheduleName(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCEESFULLY_BE_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + commonMethods.strError);
		}
		return blnResult;
	}

	/**
	 * This function is used to select option SelectOrManage platform default
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean selectOptionSelectOrManagePlatformDefault() {
		return commonMethods.clickElementUsingXpath(strSelectOrManageXpath, SELECT_OR_MANAGE_PLATFORM);
	}

	/**
	 * This function is used to SelectOrManage platform default page navigation
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean selectOrManagePlatformDefaultPageNavigation() {
		return commonMethods.isElementPresentUsingXpath(strManagePlatformDefaultPageXpath,
				LPLCoreConstents.getInstance().FAIR, SELECT_OR_MANAGE_PLATFORM_PAGE);
	}

	/**
	 * This function is used to verify that SAM platform is available
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyThatSAMplatformIsAvailable() {
		return isElementPresentUsingXpath(strSAMcheckBoxXpath, LPLCoreConstents.getInstance().LOWEST, SAM_PLATFORM);
	}

	/**
	 * This function is used to hint Message setting your default schedules
	 * displayed
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean hintMessageSettingYourDefaultSchedulesDisplayed() {
		return isElementPresentUsingXpath(strSettingYourDefaultScheduleHintXpath, LPLCoreConstents.getInstance().LOWEST,
				SETTING_YOUR_DEFAULT_HINT_MESSAGE);
	}

	/**
	 * This function is used to select SAM checkbox
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean selectSAMcheckbox() {
		return commonMethods.clickElementUsingXpath(strSAMcheckBoxXpath, SAM_CHECKBOX);
	}

	/**
	 * This function is used to click on Save Defaults
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean clickonSaveDefaults() {
		return commonMethods.clickElementUsingXpath(strSaveDefaultButtonXpath, SAVE_DEFAULTS);
	}

	/**
	 * This function is used to verify that New Schedule is tagged as default for
	 * SAM platform
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyThatNewScheduleIsTaggedAsDefaultForSAMplatform() {
		return isElementPresentUsingXpath(strNewScheduleIsTaggedAsDefaultForSAMXpath,
				LPLCoreConstents.getInstance().FAIR, SAM);
	}

	/**
	 * This function is used to verify that New Schedule is tagged as default for
	 * SWM platform
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/31/2019
	 **/
	public boolean verifyThatNewScheduleIsTaggedAsDefaultForSWMplatform() {
		return isElementPresentUsingXpath(strNewScheduleIsTaggedAsDefaultForSWMXpath,
				LPLCoreConstents.getInstance().LOWEST, SWM);
	}

	/**
	 * This function is used to select delete option from listed Menu item
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean selectDeleteOptionFromListedMenuItem() {
		return commonMethods.clickElementUsingXpath(strDeleteMenuItemBesideScheduleNameXpath, DELETE_MENU_OPTION);
	}

	/**
	 * This function is used to get Delete confirmation popup
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean getDeleteConfirmationPopup() {
		return isElementPresentUsingXpath(strDeleteScheduleTierPopUpXpath, LPLCoreConstents.getInstance().LOWEST,
				CONFIRMATION_POPUP);
	}

	/**
	 * This function is used to get Confirmation popup
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean getConfirmationPopup() {
		return isElementPresentUsingXpath(strSuccessHeaderXpath, LPLCoreConstents.getInstance().MEDIUM,
				CONFIRMATION_POPUP);
	}

	/**
	 * This function is used to get Confirmation popup on manage schedule page
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/04/2019
	 **/
	public boolean getSuccessPopupOnManageSchedulePage() {
		return isElementPresentUsingXpath(strManageScheduleSuccessHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				CONFIRMATION_POPUP);
	}

	/**
	 * This function is used to verify the new schedule deleted from list
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyTheNewScheduleDeletedFromlist() {
		return commonMethods.isElementNotPresentUsingXpath(strNewlyAddedScheduleNameXpath);
	}

	/**
	 * This function is used to verify that SWM platform is available
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean verifyThatSWMplatformIsAvailable() {
		return isElementPresentUsingXpath(strSWMcheckBoxXpath, LPLCoreConstents.getInstance().LOWEST, SWM_PLATFORM);
	}

	/**
	 * This function is used to select SWM checkbox
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/29/2019
	 **/
	public boolean selectSWMcheckbox() {
		return commonMethods.clickElementUsingXpath(strSWMcheckBoxXpath, SWM_CHECKBOX);
	}

	/**
	 * This function is used to select Rep which already has default flat fee.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/05/2020
	 **/
	public boolean selectRepWhichHasFlatFeeDefault() {
		return commonMethods.clickElementUsingXpath(
				commonMethods.getFormattedLocator(strSelectMasterRepXpath,
						testData.get("strMasterRepWhichHasFlatDefault")),
				LPLCoreConstents.getInstance().HIGH, MASTER_REPID_TEXTBOX);
	}

	/**
	 * This function is used to verify Create New Flat Default button disabled or
	 * not.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/05/2020
	 **/
	public boolean verifyCreateNewFlatDefaultbuttonIsDisabled() {
		return isElementDisabled(strCreateNewFlatFeeDisableBtnXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_NEW_BUTTON_DISABLED);
	}

	/**
	 * This function is used to verify user able to click On Switch Master Rep
	 * Button or not.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/05/2020
	 **/
	public boolean clickOnSwitchMasterRepButton() {
		return commonMethods.clickElementUsingXpath(strSwitchMasterRepXpath, SWITCH_MASTER_REP);
	}

	/**
	 * This function is used to verify Create New button for flat disabled or not.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/05/2020
	 **/
	public boolean verifyFlatCreateNewbuttonIsDisabled() {
		return isElementDisabled(strFlatCreateNewDisableBtnXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_BUTTON_DISABLED);
	}

	/**
	 * This function is used to verify Menu options beside platform disabled or not.
	 *
	 * @param DataTable
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/05/2020
	 **/
	public boolean verifyMenuItemsListedBesidesPlatformNameDisabled(DataTable menuItems) {
		boolean blnResult = false;
		List<Map<String, String>> filters = menuItems.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get("options");
			blnResult = verifyMenuItemListedBesidesPlatformNameDisabled(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName + ISDISABLED,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName + ISDISABLED,
					SUCCEESFULLY_BE_ABLE_TO_SEE + filterName + ISDISABLED,
					FAILED_TO_SEE + filterName + ISDISABLED + " : " + commonMethods.strError);
		}
		return blnResult;
	}

	/**
	 * This function is used to click on Platform Menu Items Link
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/07/2020
	 **/
	public boolean clickOnPlatformMenuItemsLinkForFlatDefault() {
		return commonMethods.clickElementUsingXpath(strFlatPlatformMenuItemsLinkXpath, PLATFORM_HAMBURGER_LINK);
	}

	/**
	 * This function is used to verify Menu options beside platform disabled or not.
	 *
	 * @param String
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/05/2020
	 **/
	public boolean verifyMenuItemListedBesidesPlatformNameDisabled(String menuItem) {
		return commonMethods.isElementPresentUsingXpath(
				commonMethods.getFormattedLocator(strOptionsBesidePlatFormDisabledXpath, menuItem), menuItem);
	}

	/**
	 * This function is used to verifyTiered Schedule Create new button is disabled
	 * or not.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 **/
	public boolean verifyTieredScheduleCreateNewbuttonIsDisabled() {
		return isElementDisabled(strTieredCreateNewDisableBtnXpath, LPLCoreConstents.getInstance().LOW,
				CREATE_BUTTON_DISABLED);
	}

	/**
	 * This function is used to verify Open Option is enabled or not
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 **/
	public boolean verifyOpenOptionEnabled() {
		return isElementEnabled(strOpenOptionXpath, LPLCoreConstents.getInstance().LOWEST, OPEN_OPTION_ENABLED);
	}

	/**
	 * This function is used to click on Schedule Menu Items Link
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 **/
	public boolean clickOnScheduleMenuItemsLinkForTieredSchedule() {
		return commonMethods.clickElementUsingXpath(strTieredScheduleMenuItemsLinkXpath, SCHEDULE_HAMBURGER_LINK);
	}

	/**
	 * This function is used to verify Menu options beside Schedule disabled or not.
	 *
	 * @param String
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 **/
	public boolean verifyCopyAndDeleteAreDisabled(DataTable menuItems) {
		boolean blnResult = false;
		List<Map<String, String>> filters = menuItems.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get("options");
			blnResult = verifyCopyAndDeleteOptionsListedBesidesScheduleDisabled(filterName);
		}
		return blnResult;
	}

	/**
	 * This function is used to verify Menu options beside Schedule disabled or not.
	 *
	 * @param String
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 **/
	public boolean verifyCopyAndDeleteOptionsListedBesidesScheduleDisabled(String menuItem) {
		return commonMethods.isElementDisabled(
				commonMethods.getFormattedLocator(strScheduleContextMenuForReadOnlyXpath, menuItem),
				LPLCoreConstents.getInstance().LOWEST, menuItem);
	}

	/**
	 * This function is used to verify Select or manage platform default option is
	 * disabled or not.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/25/2020
	 **/
	public boolean verifySelectOrManageOptionIsDisabled() {
		return isElementPresentUsingXpath(strSelectorManagePlatformOptionXpath, LPLCoreConstents.getInstance().LOWEST,
				SELECT_OR_MANAGE_PLATFORM);
	}

	/**
	 * This function is used to verify Default Platform Column is present in the
	 * grid or not.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 **/
	public boolean verifythePresenceofDefaultPlatformColumnInGrid() {
		return isElementPresentUsingXpath(strDefaultPlatformColumnXpath, LPLCoreConstents.getInstance().LOWEST,
				DEFAULT_PLATFORM);
	}

	/**
	 * This function is used to verify font used for What Are Default Flat Fee
	 * message.
	 *
	 * @return boolean
	 * @author Pinki Sarkar
	 * @since 08/15/2020
	 **/
	public boolean robotFontUsedForWhatAreDefaultFlatFeeHint() {
		return fontRobotUsed(strWhatAreDefaultFlatFeeHintXpath, HINT_WHAT_ARE_DEFAULT);
	}

	/**
	 * This function is used to verify font used for What Is My Default message.
	 *
	 * @return boolean
	 * @author Pinki Sarkar
	 * @since 08/15/2020
	 **/
	public boolean robotFontUsedForWhatIsMyDefaultHint() {
		return fontRobotUsed(strWhatIsMyDefaultHintXpath, HINT_WHAT_IS_MY_DEFAULT);
	}

	/**
	 * This function is used to verify font used for How Would i Edit a Schedule
	 * message.
	 *
	 * @return boolean
	 * @author Pinki Sarkar
	 * @since 08/15/2020
	 **/
	public boolean robotFontUsedForHowWouldiEditaScheduleHint() {
		return fontRobotUsed(strHowIeditScheduleHintXpath, HINT_HOW_WOULD_I_EDIT_SCHEDULE);
	}

	/**
	 * This function is used to verify font used for Setting Your Default Schedules
	 * messages.
	 *
	 * @return boolean
	 * @author Pinki Sarkar
	 * @since 08/15/2020
	 **/
	public boolean robotFontUsedForSettingYourDefaultSchedulesHint() {
		return fontRobotUsed(strSettingYourDefaultScheduleHintXpath, SETTING_YOUR_DEFAULT_HINT_MESSAGE);
	}

	/**
	 * This function is used to verify font used for What is the Minimum and Maximum
	 * rate for each platform messages.
	 *
	 * @return boolean
	 * @author Pinki Sarkar
	 * @since 08/15/2020
	 **/
	public boolean robotFontUsedForMaximumAndMinimumRateForEachPlatformHint() {
		return fontRobotUsed(strCreateWhatIsMaxAndMinRateHintXpath, HINT_WHAT_IS_MAX_AND_MIN_SCHEDULE);
	}

	/**
	 * This function is used to verify What Are Default Flat Fee? message is not
	 * displayed.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/17/2020
	 **/
	public boolean hintMessageForWhatAreDefaultFlatFeeDisplayed() {
		return isElementNotDisplayed(strWhatAreDefaultFlatFeeHintXpath, LPLCoreConstents.getInstance().LOWEST,
				HINT_WHAT_ARE_DEFAULT);
	}

	/**
	 * This function is used to verify What Is My Default? message is not displayed.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/17/2020
	 **/
	public boolean hintMessageForWhatIsMyDefaultFlatFeeDisplayed() {
		return isElementNotDisplayed(strWhatIsMyDefaultHintXpath, LPLCoreConstents.getInstance().LOWEST,
				HINT_WHAT_IS_MY_DEFAULT);
	}

	/**
	 * This function is used to verify How Would I Edit A Schedule? message is not
	 * displayed.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/17/2020
	 **/
	public boolean hintMessageForHowWouldIEditAScheduleDisplayed() {
		return isElementNotDisplayed(strHowIeditScheduleHintXpath, LPLCoreConstents.getInstance().LOWEST,
				HINT_HOW_WOULD_I_EDIT_SCHEDULE);
	}

	/**
	 * This function is used to verify Create Your First Flat Fee section is not
	 * displayed.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/17/2020
	 **/
	public boolean createYourFirstFlatFeeScetionDisplayed() {
		return isElementNotDisplayed(strCreateYourFirstFlatFeeXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_YOUR_FIRST_FLAT_FEE_SECTION);
	}

	/**
	 * This function is used to verify Select Or Manage Platform Default Option is
	 * not displayed.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/20/2020
	 **/
	public boolean selectOrManagePlatformDefaultOptionDisplayed() {
		return isElementNotDisplayed(strSelectOrManagePlatformDefaultXpath, LPLCoreConstents.getInstance().LOWEST,
				SELECT_OR_MANAGE_PLATFORM);
	}

	/**
	 * This function is used to verify Minimum and Maximum rate for SAM platform in
	 * hint message
	 * 
	 * @return boolean
	 * @author Pinki Sarkar
	 * @since 08/17/2019
	 **/
	public boolean minimumAndMaximumRateForSAMplatformPresent() {
		return isElementPresentUsingXpath(strMinimumAndMaximumRateForSAMplatformXpath,
				LPLCoreConstents.getInstance().LOWEST, SAM_MIN_MAX_RATE);
	}

	/**
	 * This function is used to verify is Default Platform Column is not displayed.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/20/2020
	 **/
	public boolean defaultPlatformColumnDisplayed() {
		return isElementNotDisplayed(strDefaultPlatformColumnXpath, LPLCoreConstents.getInstance().LOWEST,
				DEFAULT_PLATFORM);
	}

	/**
	 * This function is used to verify Minimum and Maximum rate for SWM platform in
	 * hint message
	 * 
	 * @return boolean
	 * @author Pinki Sarkar
	 * @since 08/17/2019
	 **/
	public boolean minimumAndMaximumRateForSWMplatformPresent() {
		return isElementPresentUsingXpath(strMinimumAndMaximumRateForSWMplatformXpath,
				LPLCoreConstents.getInstance().LOWEST, SWM_MIN_MAX_RATE);
	}

	/**
	 * This function is used to click Ok button to delete schedule.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 09/14/2020
	 **/
	public boolean clickOkOnDeleteConfirmationPopup() {
		return commonMethods.clickElementUsingXpath(strOkButtonForDeleteXpath, OK_BUTTON);
	}

	/**
	 * This function is used to check whether Create New Flat fee button enabled or
	 * not
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/04/2020
	 **/
	public boolean verifyCreateNewFlatFeeButtonEnabled() {
		return isElementEnabled(strCreateNewFlatFeeXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_NEW_BUTTON_ENABLED);
	}

	/**
	 * This function is used to check whether Schedule section present or not
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/04/2020
	 **/
	public boolean verifyScheduleSectionPresent() {
		return isElementPresentUsingXpath(strScheduleSectionXpath, LPLCoreConstents.getInstance().LOWEST,
				SCHEDULE_SECTION);
	}

	/**
	 * This function is used to check whether Schedule section present or not
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/04/2020
	 **/
	public boolean verifyCreateNewButtonEnabled() {
		return isElementEnabled(strCreateNewButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_NEW_BUTTON_ENABLED);
	}

	/**
	 * This function is used to check whether Create Your FirstSchedule section
	 * present or not
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/05/2020
	 **/
	public boolean verifyCreateYourFirstScheduleSection() {
		return isElementPresentUsingXpath(strCreateYourFirstScheduleSectionXpath, LPLCoreConstents.getInstance().LOW,
				CREATE_YOUR_FIRST_SCHEDULE_SECTION);
	}

	/**
	 * This function is used to check whether Create New button disabled or not in
	 * flat default section
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/05/2020
	 **/
	public boolean verifyCreateNewDisabledInFlatSection() {
		return isElementDisabled(strCreateNewDisabledButtonXpath, LPLCoreConstents.getInstance().LOW,
				CREATE_NEW_BUTTON_ENABLED);
	}

	/**
	 * This function is used to check whether Flat Fee Default section present or
	 * not
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/05/2020
	 **/
	public boolean verifyFlatFeeDefaultSectionPresent() {
		return isElementPresentUsingXpath(strFlatFeeDefaultSectionXpath, LPLCoreConstents.getInstance().LOW,
				FLAT_FEE_SECTION);
	}
}
