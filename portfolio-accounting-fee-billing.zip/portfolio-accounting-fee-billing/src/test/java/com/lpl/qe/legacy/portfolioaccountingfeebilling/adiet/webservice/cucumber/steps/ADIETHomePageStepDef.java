package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> ADIETHomePageStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for ADIETHomePage</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * ADIETHomePageStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class ADIETHomePageStepDef extends CommonStepDef {
	@When("^I verify FBVA File Status header text displayed$")
	public void isIverifyFBVAFileStatusheadertextdisplayed() {
		boolean blnResult = homepagesfbva.verifFBVAFileStausgrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify FBVA Grid displays in Home page",
				"FBVA Grid has to display", "FBVA grid diplyed", "FBVA Grid  was not diplaying:" + Common.strError);
	}

	@When("I verify the availability of FBVA File Status Grid Headers$")
	public void iverifytheavailabilityofFBVAFileStatusGridHeaders(DataTable searchFieldsOptions) {
		boolean blnResult = homepagesfbva.iverifyFBVAFileStatusGridHeader(searchFieldsOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify FBVA files are displayed",
				"FBVA files should be display", "FBVA file status diplyaed",
				"FBVA file status was not displyed :" + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
