package com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TAFSReadOnlyGroupEnabledUserStepDef extends CommonStepDef {
	Common commonMethods = new Common(driver);

	@When("^I select a Rep which does not have flat fee default$")
	public void selectRepWhichDoesNotHaveFlatFeeDefault() {
		boolean blnResult = tafsAdminGroupPage.selectRep();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Rep from Search results",
				"User should able to Select Rep from Search results ",
				"Successfully able to Select Rep from Search results ",
				"Failed to Select Rep from Search results  :" + commonMethods.strError);
	}

	@Then("^I verify that Create New Flat Fee button is disabled$")
	public void verifyCreateNewFlatDefaultbuttonIsDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifyCreateNewFlatDefaultbuttonIsDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of disabled Create New Flat Fee button",
				"User should be able to see disabled Create New Flat Fee button",
				"Successfully able to see disabled Create New Flat Fee button",
				"Failed to see disabled Create New Flat Fee button : " + commonMethods.strError);
	}

	@When("^I click on Switch Master Rep$")
	public void clickOnSwitchMasterRepButton() {
		boolean blnResult = tafsAdminGroupPage.clickOnSwitchMasterRepButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "User clicks on Switch Master Rep button",
				"User should be able to click on Switch Master Rep button",
				"User is able to click on Switch Master Rep button",
				"User is not able to click on Switch Master Rep button " + commonMethods.strError);
	}

	@When("^I select another Rep which already has flat fee default$")
	public void selectRepWhichHasFlatFeeDefault() {
		boolean blnResult = tafsAdminGroupPage.selectRepWhichHasFlatFeeDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select Rep which doesn't have flat fee default from Search results",
				"User should able to Select Rep from Search results ",
				"Successfully able to Select Rep from Search results ",
				"Failed to Select Rep from Search results  :" + commonMethods.strError);
	}

	@Then("^I verify the presence of flat default for SAM$")
	public void verifythePresenceofFlatfeeDefaultForSAM() {
		boolean blnResult = tafsAdminGroupPage.verifythePresenceofFlatfeeDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of presence of flat fee default ",
				"User should be able to see presence of flat fee default",
				"Successfully able to see presence of flat fee default",
				"Failed to see presence of flat fee default : " + commonMethods.strError);
	}

	@Then("^I verify the presence of flat default for SWM$")
	public void verifythePresenceofFlatfeeDefaultForSWM() {
		boolean blnResult = tafsAdminGroupPage.verifythePresenceofFlatfeeDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of presence of flat fee default ",
				"User should be able to see presence of flat fee default",
				"Successfully able to see presence of flat fee default",
				"Failed to see presence of flat fee default : " + commonMethods.strError);
	}

	@Then("^I verify that Create New button under flat fee is disabled$")
	public void verifyFlatCreateNewbuttonIsDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifyFlatCreateNewbuttonIsDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of disabled Create Default button",
				"User should be able to see disabled Create Default button",
				"Successfully able to see disabled Create Default button",
				"Failed to see disabled Create Default button : " + commonMethods.strError);
	}

	@Then("^I click on Platform Menu Items hamburger link for flat default$")
	public void clickOnPlatformMenuItemsLinkForFlatDefault() {
		boolean blnResult = tafsAdminGroupPage.clickOnPlatformMenuItemsLinkForFlatDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to click on Platform Menu Items hamburger link for flat default ",
				"User should be able to click on Platform Menu Items hamburger link for flat default",
				"User able to click on Platform Menu Items hamburger link for flat default",
				"User not able to click on Platform Menu Items hamburger link for flat default:  "
						+ commonMethods.strError);
	}

	@Then("^I verify that the menu items listed besides platform name are all disabled$")
	public void verifyMenuItemsListedBesidesPlatformNameAreDisabled(DataTable menuItems) {
		boolean blnResult = tafsAdminGroupPage.verifyMenuItemsListedBesidesPlatformNameDisabled(menuItems);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of menu items listed besides platform are disabled",
				"Menu items listed besides platform should be disabled",
				"Menu items listed besides platform are disabled",
				"Menu items listed besides platform are not disabled:  " + commonMethods.strError);
	}

	@When("^I select a Rep which already has some tiered schedule defaulted for SAM$")
	public void selectRepWhichDoesNotHaveSAMTieredDefault() {
		boolean blnResult = tafsAdminGroupPage.selectRep();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Rep from Search results",
				"User should able to Select Rep from Search results ",
				"Successfully able to Select Rep from Search results ",
				"Failed to Select Rep from Search results  :" + commonMethods.strError);
	}

	@Then("^I verify that Create New button under Tiered Schedules is disabled$")
	public void verifyTieredScheduleCreateNewbuttonIsDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifyTieredScheduleCreateNewbuttonIsDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of disabled Create New button",
				"User should be able to see disabled Create New button",
				"Successfully able to see disabled Create New button",
				"Failed to see disabled Create New button : " + commonMethods.strError);
	}

	@Then("^I click on Schedule Menu Items hamburger link for Tiered Schedule$")
	public void clickOnScheduleMenuItemsLinkForTieredSchedule() {
		boolean blnResult = tafsAdminGroupPage.clickOnScheduleMenuItemsLinkForTieredSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to click on Schedule Menu Items hamburger link for Tiered Schedule ",
				"User should be able to click on Schedule Menu Items hamburger link for Tiered Schedule",
				"User able to click on Schedule Menu Items hamburger link for Tiered Schedule",
				"User not able to click on Schedule Menu Items hamburger link for Tiered Schedule:  "
						+ commonMethods.strError);
	}

	@Then("^I verify that Open option is enabled$")
	public void verifyOpenOptionEnabled() {
		boolean blnResult = tafsAdminGroupPage.verifyOpenOptionEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Open option is enabled or not",
				"User should see Open option as enabled", "User is able to see Open option as enabled",
				"User is not able to see Open option as enabled : " + commonMethods.strError);
	}

	@Then("^I verify that copy and delete options are disabled$")
	public void verifyCopyAndDeleteAreDisabled(DataTable menuItems) {
		boolean blnResult = tafsAdminGroupPage.verifyCopyAndDeleteAreDisabled(menuItems);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of copy and delete options listed besides schedule are disabled",
				"Copy and delete options listed besides schedule should be disabled",
				"Copy and delete options listed besides schedule are disabled",
				"Copy and delete options listed besides schedule are not disabled:  " + commonMethods.strError);
	}

	@Then("^I verify that Select or Manage Platform Default option is disabled$")
	public void verifySelectOrManageOptionIsDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifySelectOrManageOptionIsDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Select or Manage Platform Default option listed besides schedule is disabled",
				"Select or Manage Platform Default option listed besides schedule should be disabled",
				"Select or Manage Platform Default option schedule is disabled",
				"Select or Manage Platform Default option schedule is not disabled:  " + commonMethods.strError);
	}

	@Then("^I verify that following column is listed in grid - Default Platform$")
	public void verifythePresenceofDefaultPlatformColumnInGrid() {
		boolean blnResult = tafsAdminGroupPage.verifythePresenceofDefaultPlatformColumnInGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of presence of Default Platform ",
				"User should be able to see presence of Default Platform",
				"Successfully able to see presence of Default Platform",
				"Failed to see presence of Default Platform : " + commonMethods.strError);
	}

	@When("^I select a Rep which already has some tiered schedule defaulted for SWM$")
	public void selectRepWhichDoesNotHaveSWMTieredDefault() {
		boolean blnResult = tafsAdminGroupPage.selectRep();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Rep from Search results",
				"User should able to Select Rep from Search results ",
				"Successfully able to Select Rep from Search results ",
				"Failed to Select Rep from Search results  :" + commonMethods.strError);
	}
}
