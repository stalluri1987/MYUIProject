package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> Reporting.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for Reporting</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class Reporting extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 821;
	Map<String, HashMap<String, String>> pageObjectMap;

	public static final String REPORTING_PAGE_HEADER = "Reporting Page Header";
	public static final String OPS_REPORTING_TAB = "Ops Reporting Tab";
	public static final String REPORT_LINK = "Report Link";
	public static final String REPORT_HEADER = "MWP Strategist Payment Report";
	public static final String TERMED_REPORT_LINK = "MWP Termed Report Link";
	public static final String TERMED_REPORT_HEADER = "MWP Termed Accts Active Sleeves";
	public static final String ACTIVE_REPORT_LINK = "MWP Termed Report Link";
	public static final String ACTIVE_REPORT_HEADER = "MWP Termed Accts Active Sleeves";
	public static final String SPLIT_ID_LINK = "Split ID report link";
	public static final String SPLIT_ID_REPORT_OPEN = "Split ID Report open in new tab";
	public static final String FIRM_DROPDOWN = "Firm Dropdown";
	public static final String SPLIT_ID_HEADER = "Split ID Header";
	public static final String BILLING_QC_REPORTING_TAB = "Billing QC Reporting Tab";
	public static final String BILLING_SUMMARY_REPORT = "Billing Summary Report";
	public static final String OPTIONS = "options";
	public static final String SUCCESSFULLY_ABLE_TO_SEE = "Successfully be able to see ";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String PROP_MF_FEEREBATING_REPORTING_TAB = "Prop MF FeeRebating Reporting Tab";
	public static final String PROP_MF_FEEREBATING_REPORTING_LINK = "Prop MF FeeRebating Reporting Link";
	public static final String PROP_MF_REBATE_DAILY_MKT_VALUE_REPORT = "Prop MF Rebate Daily Mkt Value Report";
	public static final String PROP_MF_REBATE_DAILY_MKT_VALUE_REPORT_LINK = "Prop MF Rebate Daily Mkt Value Report Link";
	public static final String START_DATE_TEXTBOX = "Start Date TextBox";
	public static final String END_DATE_TEXTBOX = "End Date TextBox";
	public static final String ENTITY_DROPDOWN = "Entity Dropdown";
	public static final String CUSIPS_DROPDOWN = "CUSIPs Dropdown";
	public static final String CUSIPS_CHECKBOX = "CUSIPs CheckBox";
	public static final String VIEW_REPORT_BUTTON = "View Report Button";
	public static final String PROP_MF_REPORT_HEADER = "Prop MF Rebate Daily Mkt Value Report Header";
	public static final String DATE_RANGE = "Date Range in Report";
	public static final String ENTITY_ID_NAME = "Entity ID Name in Report";
	public static final String OPTIONS_DAILY_REPORT = "Options";
	public static final String VERIFY_START_DATE = "Verify Start Date";
	public static final String VERIFY_END_DATE = "Verify End Date";
	public static final String VERIFY_ENTITY = "Verify Entity";
	public static final String ATTRIBUTE_NAME = "value";
	public static final String PROP_MF_REBATE_MONTHLY_REPORT = "Prop MF Rebate Monthly Account Level Detail Report";
	public static final String PROP_MF_REBATE_MONTHLY_REPORT_LINK = "Prop MF Rebate Monthly Account Level Detail Report Link";
	public static final String PROP_MF_REBATE_MONTHLY_REPORT_TITLE = "Prop MF Rebate Monthly Account Level Detail Report Title";
	public static final String ENTITY_DROPDOWN_MONTHLY = "Entity Dropdown Monthly Report";
	public static final String ENTITY_CHECKBOX = "Entity Checkbox Monthly Report";
	public static final String CUSIPS_TEXTBOX = "CUSIPs TextBox Monthly Report";
	public static final String CUSIPS_DROPDOWN_MONTHLY_REPORT = "CUSIPs Dropdown Monthly Report";
	public static final String CUSIPS_CHECKBOX_MONTHLY_REPORT = "CUSIPs Checkbox Monthly Report";
	public static final String MONTH_END_DATE = "Month End Date in Monthly Report";
	public static final String MONTHLY_VIEW_REPORT_BUTTON = "Monthly View Report Button";
	public static final String PROP_MF_MONTHLY_REPORT_HEADER = "Prop MF Rebate Monthly Account Level Detail Report Header";
	public static final String VERIFY_MONTH_END_DATE = "Verify Month End Date";
	public static final String MONTH_END_DATE_LABEL = "Month End Date Label";
	public static final String VERIFY_ENTITY_LABEL = "Verify Entity Label Report";
	public static final String AVG_POS_VALUE = "Average Daily Position Value Report";
	public static final String AVG_POS_VALUE_LABEL = "Average Position Value";
	public static final String OPTIONS_MONTHLY_REPORT = "Options";
	public static final String PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT = "Prop MF Monthly Credit Total by CUSIP Report";
	public static final String MONTH_END_DATE_DROPDOWN = "Month End Date select from Dropdown";
	public static final String SUMMARY_VIEW_REPORT_BUTTON = "Prop MF Monthly Credit Total by CUSIP View Report Button";
	public static final String PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT_HEADER = "Prop MF Monthly Credit Total by CUSIP Report Header";
	public static final String CUSIP_FACTOR_FILE_VALUE = "CUSIP Factor File Received";
	public static final String TERMED_GWP_ACCOUNTS = "Termed GWP Accounts by Period";
    public static final String VIEW_REPORT = "VIEW_REPORT";
    public static final String TERMED_GWP_PERIOD_BY_PERIOD_REPORT_TITLE = "TermedGWPAccounts -Report Viewer";
	
    String strReportingHeaderXpath;
	String strOpsReportingTabXpath;
	String strModelAccountListForModelsLinkXpath;
	String strMWPStrategistPaymentReportLinkXpath;
	String strMWPStrategistPaymentReportHeaderXpath;
	String strBillingQCReportingTabXpath;
	String strBillingSummaryLinkXpath;
	String strBillingSummaryHeaderXpath;
	String strBillingSummaryTableHeaderXpath;
	List<String> browserActiveTabs;
	String strMWPAccountAttributesReportLinkXpath;
	String strMWPAccountAttributesReportHeaderXpath;
	String strMWPTermedAcctsActiveSleevesLinkXpath;
	String strMWPTermedAcctsActiveSleevesHeaderXpath;
	String strMWPActiveAcctsNoActiveSleevesLinkXpath;
	String strMWPActiveAcctsNoActiveSleevesHeaderXpath;
	String strAccountLevelReconciliationReportLinkXpath;
	String strPropMFFeeRebatingReportingTabXpath;
	String strPropMFRebateDailyMktValueReportXpath;
	String strPropMFRebateDailyMktValueTitleXpath;
	String strSearchFieldLabelsXpath;
	String strStartDateTextBoxXpath;
	String strEndDateTextBoxXpath;
	String currentEndDate;
	String strEntityDropDownXpath;
	String strEntityTextBoxXpath;
	String strCUSIPsDropDownXpath;
	String strSelectCUSIPsDropDownXpath;
	String strViewReportXpath;
	String strPropMFRebateDailyMktValueReportHeaderXpath;
	String strDateRangeXpath;
	String strEntityIDNameXpath;
	String strSearchFieldLabelsReportXpath;
	String strPropMFRebateMonthlyReportXpath;
	String strPropMFRebateMonthlyReportTitleXpath;
	String strClickEntityDropDownMonthlyReportXpath;
	String strSelectEntityDropDownMonthlyReportXpath;
	String strClickCUSIPsDropDownMonthlyReportXpath;
	String strSelectCUSIPsDropDownMonthlyReportXpath;
	String strMonthEndDateTextBoxXpath;
	String strMonthlyViewReportXpath;
	String strCUSIPsTextBoxMonthlyReportXpath;
	String strMonthlyReportHeaderXpath;
	String strMonthEndDateLabelXpath;
	String getPreviousMonthEndDate;
	String strEntityTextBoxMonthlyXpath;
	String strAvgPosValueXpath;
	String strSearchMonthlyAccountLabelsXpath;
	String strSearchMonthlyReportLabelsXpath;
	String strPropMFCUSIPReportXpath;
	String strPropMFCUSIPReportTitleXpath;
	String strMonthEndDateCUSIPReportXpath;
	String strCUSIPReportHeaderXpath;
	String strCUSIPFactorXpath;
	String strCUSIPLabelXpath;
	String strFundNameLabelXpath;
	String strCreditFactorLabelXpath;
	String strTotalCreditAmountLabelXpath;
	String strMissingFirmIDReportLinkXpath;
	String strTermedGWPAccountsByPeriodHeaderXpath;
	String strTermedGWPAccountsByPeriodLinkXPath;
    String strViewReportButtonXpath;
    String strBrokerAccountLinkXPath;
    String strTermedGWPAccountsByPeriodTitleXpath;
    String strAccountlevelReconciliationTitleXpath;
    String strAccountlevelReconciliationViewReportXpath;
    String strMissingFirmIDTitleXpath;
    String strMWPAccountAttributesTitleXpath;
    String strMWPAccountAtrributesHeaderXpath;
    String strAvgPosValXpath;
    String currentMonthFirstDate;

        
	public Reporting(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strReportingHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				REPORTING_PAGE_HEADER);
	}

	/**
	 * This method is used to verify Ops Reporting Tab should be displayed
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 09/03/2020
	 */
	public boolean iVerifytheAvailabilityofOpsReportingTab() {
		return isElementPresentUsingXpath(strOpsReportingTabXpath, LPLCoreConstents.getInstance().LOWEST,
				OPS_REPORTING_TAB);
	}

	/**
	 * This method is used to verify availability of Master Account List For Models
	 * report link
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 09/03/2020
	 */
	public boolean iVerifytheAvailabilityofMasterAccountListForModelsreportlink() {
		return isElementPresentUsingXpath(strModelAccountListForModelsLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				REPORT_LINK);
	}

	/**
	 * This method is used to click on Master Account List For Models report link
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 09/03/2020
	 */
	public boolean iClickOnMasterAccountListForModels() {
		return clickElementUsingXpath(strModelAccountListForModelsLinkXpath, REPORT_LINK);
	}

	/**
	 * This method is used to verify availability of MWP Strategist Payment Report
	 * report link
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 10/30/2020
	 */
	public boolean iVerifytheAvailabilityofMWPStrategistPaymentReportlink() {
		return isElementPresentUsingXpath(strMWPStrategistPaymentReportLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				REPORT_LINK);
	}

	/**
	 * This method is used to click on MWP Strategist Payment Report report link
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 10/30/2020
	 */
	public boolean iClickOnMWPStrategistPaymentReport() {
		return clickElementUsingXpath(strMWPStrategistPaymentReportLinkXpath, REPORT_LINK);
	}

	/**
	 * This method is used to check the header of MWP Strategist Payment Report
	 * report
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 11/9/2020
	 */
	public boolean verifytheHeaderofMWPStrategistPaymentReport() {
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		return isElementPresentUsingXpath(strMWPStrategistPaymentReportHeaderXpath, REPORT_HEADER);
	}

	/**
	 * This method is used to verify Billing QQC Reporting Tab should be displayed
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/02/2020
	 */
	public boolean iVerifytheAvailabilityofBillingQCReportingTab() {
		return isElementPresentUsingXpath(strBillingQCReportingTabXpath, LPLCoreConstents.getInstance().LOWEST,
				BILLING_QC_REPORTING_TAB);
	}

	/**
	 * This method is used to click on Billing QC Reporting tab
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/02/2020
	 */
	public boolean iclickOnBillingQCReportingTab() {
		return clickElementUsingXpath(strBillingQCReportingTabXpath, REPORT_LINK);
	}

	/**
	 * This method is used to verify availability of Billing Summary report link
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/02/2020
	 */
	public boolean iverifytheAvailabilityofBillingSummaryreportlink() {
		return isElementPresentUsingXpath(strBillingSummaryLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				REPORT_LINK);
	}

	/**
	 * This method is used to click on Billing Summary report link
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/02/2020
	 */
	public boolean iClickOnBillingSummary() {
		return clickElementUsingXpath(strBillingSummaryLinkXpath, REPORT_LINK);
	}

	/**
	 * This method is used to verify Billing Summary report is opened in new tab
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-02-2020
	 */
	public boolean billingSummaryReportOpenedinNewTab() {
		boolean blnResult;
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		blnResult = isElementPresentUsingXpath(strBillingSummaryHeaderXpath, LPLCoreConstents.getInstance().HIGHEST,
				BILLING_SUMMARY_REPORT);
		return blnResult;
	}

	/**
	 * This method is used to verify the display of header columns in Billing
	 * Summary Report
	 * 
	 * @param searchResultOptions
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/02/2020
	 */
	public boolean verifythedisplayofheadercolumnsinBillingSummaryReport(DataTable searchResultOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchResultOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/02/2020
	 */

	public boolean checkIfElementExistUsingTableHeaderText(String tableHeaderTextText) {
		return isElementPresentUsingXpath(getFormattedLocator(strBillingSummaryTableHeaderXpath, tableHeaderTextText),
				tableHeaderTextText);
	}

	/**
	 * This method is used to verify Prop MF FeeRebating Reporting Tab should be
	 * displayed
	 * 
	 * @return boolean
	 *
	 * @Author Siddharth Gupta
	 * @Since 11/26/2020
	 */
	public boolean iVerifyTheAvailabilityOfPropMFFeeRebatingReportingTab() {
		return isElementPresentUsingXpath(strPropMFFeeRebatingReportingTabXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_FEEREBATING_REPORTING_TAB);
	}

	/**
	 * This method is used to click on Prop MF FeeRebating Reporting Tab
	 * 
	 * @return boolean
	 *
	 * @Author Siddharth Gupta
	 * @Since 11/26/2020
	 */
	public boolean iClickOnPropMFFeeRebatingReportingTab() {
		return clickElementUsingXpath(strPropMFFeeRebatingReportingTabXpath, PROP_MF_FEEREBATING_REPORTING_LINK);
	}

	/**
	 * This method is used to verify Prop MF Rebate Daily Mkt Value report link
	 * should be displayed
	 * 
	 * @return boolean
	 *
	 * @Author Siddharth Gupta
	 * @Since 11/26/2020
	 */
	public boolean iVerifyTheAvailabilityOfPropMFRebateDailyMktValuerReportLink() {
		return isElementPresentUsingXpath(strPropMFRebateDailyMktValueReportXpath,
				LPLCoreConstents.getInstance().LOWEST, PROP_MF_REBATE_DAILY_MKT_VALUE_REPORT);
	}

	/**
	 * This method is used to click on Prop MF Rebate Daily Market Value report link
	 * 
	 * @return boolean
	 *
	 * @Author Siddharth Gupta
	 * @Since 11/26/2020
	 */
	public boolean iClickOnPropMFRebateDailyMktValueReportLink() {
		return clickElementUsingXpath(strPropMFRebateDailyMktValueReportXpath,
				PROP_MF_REBATE_DAILY_MKT_VALUE_REPORT_LINK);
	}

	/**
	 * This method is used to Verify the Page Title of the Prop MF Rebate Daily
	 * Market Value report opened in new tab
	 * 
	 * @return boolean
	 *
	 * @Author Siddharth Gupta
	 * @Since 11/26/2020
	 */
	public boolean propMFRebateDailyMktValueReportOpenedInNewTab() {
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		waitTillVisibleUsingXpath(strPropMFRebateDailyMktValueTitleXpath, LPLCoreConstents.getInstance().HIGHEST,
				PROP_MF_REBATE_DAILY_MKT_VALUE_REPORT);
		return isElementPresentUsingXpath(strPropMFRebateDailyMktValueTitleXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_REBATE_DAILY_MKT_VALUE_REPORT);
	}

	/**
	 * This method is used to check The Availability of Search Field Option Labels
	 * 
	 * @param dailyReportLabels
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/14/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldOptionLabels(DataTable dailyReportLabels) {
		boolean blnResult = false;
		List<Map<String, String>> filters = dailyReportLabels.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS_DAILY_REPORT);
			blnResult = verifyTheAvailablityOfSearchFieldTypes(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the Availability of Search Field Type
	 * 
	 * @param dailyReportLabels
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12-14-2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldTypes(String dailyReportLabels) {
		return isElementPresentUsingXpath(getFormattedLocator(strSearchFieldLabelsXpath, dailyReportLabels),
				dailyReportLabels);
	}

	/**
	 * This method is used to enter Start Date
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/01/2020
	 */
	public boolean enterStartDate() {
		currentMonthFirstDate = getFirstDateOfTheCurrentMonth(Calendar.getInstance());
	    
	    return enterTextUsingXpath(strStartDateTextBoxXpath, currentMonthFirstDate, START_DATE_TEXTBOX);
	}

	/**
	 * This method is used to enter End Date
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/01/2020
	 */
	public boolean enterEndDate() {
		waitTillVisibleUsingXpath(strEndDateTextBoxXpath, LPLCoreConstents.getInstance().HIGHEST,
				END_DATE_TEXTBOX);
		clickElementUsingXpath(strEndDateTextBoxXpath, END_DATE_TEXTBOX);
		currentEndDate = getDateFormat(Calendar.getInstance());
		waitTillVisibleUsingXpath(strEndDateTextBoxXpath, LPLCoreConstents.getInstance().HIGHEST,
				END_DATE_TEXTBOX);
		return enterTextUsingXpath(strEndDateTextBoxXpath, currentEndDate, END_DATE_TEXTBOX);
	}

	/**
	 * This method is used to select the Entity from dropdown list
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/02/2020
	 */
	public boolean selectEntityFromDropdownList() {
		waitTillVisibleUsingXpath(strEntityDropDownXpath, LPLCoreConstents.getInstance().HIGHEST,
				ENTITY_DROPDOWN);
		clickElementUsingXpath(strEntityDropDownXpath, ENTITY_DROPDOWN);
		waitTillVisibleUsingXpath(strEntityDropDownXpath, LPLCoreConstents.getInstance().HIGHEST,
				ENTITY_DROPDOWN);
		return selectValueFromDropdownUsingXpath(strEntityDropDownXpath, testData.get("strEntity"), ENTITY_DROPDOWN);
	}

	/**
	 * This method is used to select the CUSIPs from dropdown list
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/02/2020
	 */
	public boolean selectCUSIPsFromDropdownList() {
		waitTillVisibleUsingXpath(strCUSIPsDropDownXpath, LPLCoreConstents.getInstance().HIGHEST, CUSIPS_DROPDOWN);
		waitTillVisibleUsingXpath(strCUSIPsDropDownXpath, LPLCoreConstents.getInstance().HIGHEST, CUSIPS_DROPDOWN);
		
		return clickElementUsingXpath(strCUSIPsDropDownXpath, CUSIPS_DROPDOWN)
				&& clickElementUsingXpath(strSelectCUSIPsDropDownXpath, CUSIPS_CHECKBOX);
	}

	/**
	 * DESC : This method is used to click on the View Report button
	 * 
	 * @return boolean
	 *
	 * @Author : Siddharth Gupta
	 * @Since : 12/02/2020
	 */
	public boolean iClickOnViewReportButton() {
		return clickElementUsingXpath(strViewReportXpath, VIEW_REPORT_BUTTON);
	}

	/**
	 * This method is used to check the header of Prop MF Rebate Daily Mkt Value
	 * Report
	 * 
	 * @return boolean
	 * 
	 * @author Siddharth Gupta
	 * @since 12/02/2020
	 */
	public boolean iVerifyTheHeaderOfPropMFRebateDailyMktValueReport() {
		return isElementPresentUsingXpath(strPropMFRebateDailyMktValueReportHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, PROP_MF_REPORT_HEADER);
	}

	/**
	 * This method is used to check Date Range is present or not in Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/02/2020
	 */
	public boolean iVerifyDateRangeIsPresentInReport() {
		String strGetStartDate = getAttributeUsingXpath(strStartDateTextBoxXpath, ATTRIBUTE_NAME, VERIFY_START_DATE);
		String strGetEndDate = getAttributeUsingXpath(strEndDateTextBoxXpath, ATTRIBUTE_NAME, VERIFY_END_DATE);
		if (strGetStartDate.equals(currentMonthFirstDate) && strGetEndDate.equals(currentEndDate))
			return isElementPresentUsingXpath(strDateRangeXpath, LPLCoreConstents.getInstance().LOWEST, DATE_RANGE);
		else
			return false;

	}

	/**
	 * This method is used to check Entity is present or not in Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/02/2020
	 */
	public boolean iVerifyEntityIsPresentInReport() {
		String strGetEntity = getAttributeUsingXpath(strEntityTextBoxXpath, ATTRIBUTE_NAME, VERIFY_ENTITY);
		if (testData.get("strEntity").contains(strGetEntity))
			return isElementPresentUsingXpath(strEntityIDNameXpath, LPLCoreConstents.getInstance().LOWEST,
					ENTITY_ID_NAME);
		else
			return false;
	}

	/**
	 * This method is used to check The Availability of Search Field Option Labels
	 * in Daily Report
	 * 
	 * @param dailyReportLabels
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldOptionLabelsInReport(DataTable dailyReportLabels) {
		boolean blnResult = false;
		List<Map<String, String>> filters = dailyReportLabels.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS_DAILY_REPORT);
			blnResult = verifyTheAvailablityOfSearchFieldTypesForDailyReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the Availability of Search Field Type For Daily
	 * Report
	 * 
	 * @param dailyReportLabels
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldTypesForDailyReport(String dailyReportLabels) {
		return isElementPresentUsingXpath(getFormattedLocator(strSearchFieldLabelsReportXpath, dailyReportLabels),
				dailyReportLabels);
	}

	/**
	 * This method is used to verify Prop MF Rebate Monthly Account Level Detail
	 * Report link should be displayed
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheAvailabilityOfPropMFRebateMonthlyAccountLevelDetailReportLink() {
		return isElementPresentUsingXpath(strPropMFRebateMonthlyReportXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_REBATE_MONTHLY_REPORT);
	}
	
	/**
	 * This method is used to check the statement for Average Position Value Label
	 * 
	 * @return boolean
	 *
	 * @author Keven McBarnes
	 * @since 06/07/2021
	 */
	public boolean verifyTheStatementOfAveragePositionValueLabel() {
		return isElementPresentUsingXpath(strAvgPosValXpath, LPLCoreConstents.getInstance().LOWEST, AVG_POS_VALUE_LABEL);
	}

	/**
	 * This method is used to click on Prop MF Rebate Monthly Account Level Detail
	 * Report link
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean clickOnPropMFRebateMonthlyAccountLevelDetailReportLink() {
		return clickElementUsingXpath(strPropMFRebateMonthlyReportXpath, PROP_MF_REBATE_MONTHLY_REPORT_LINK);
	}

	/**
	 * This method is used to Verify the Page Title of the Prop MF Rebate Monthly
	 * Account Level Detail Report opened in new tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean propMFRebateMonthlyAccountLevelDetailReportOpenedInNewTab() {
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		waitTillVisibleUsingXpath(strPropMFRebateMonthlyReportTitleXpath, LPLCoreConstents.getInstance().HIGHEST,
				PROP_MF_REBATE_MONTHLY_REPORT_TITLE);
		return isElementPresentUsingXpath(strPropMFRebateMonthlyReportTitleXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_REBATE_MONTHLY_REPORT_TITLE);
	}

	/**
	 * This method is used to check The Availability of Search Field Option Labels
	 * for Monthly Report
	 * 
	 * @param monthlyReportLabels
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyAccountLevel(DataTable monthlyReportLabels) {
		boolean blnResult = false;
		List<Map<String, String>> filters = monthlyReportLabels.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS_MONTHLY_REPORT);
			blnResult = verifyTheAvailablityOfSearchFieldTypesForMonthlyAccountLevel(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the Availability of Search Field Type For
	 * Monthly Account Level
	 * 
	 * @param monthlyReportLabels
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldTypesForMonthlyAccountLevel(String monthlyReportLabels) {
		return isElementPresentUsingXpath(getFormattedLocator(strSearchMonthlyAccountLabelsXpath, monthlyReportLabels),
				monthlyReportLabels);
	}

	/**
	 * This method is used to select the Entity from dropdown list in Monthly Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean selectTheEntityFromDropdownListInMonthlyReport() {
		waitTillVisibleUsingXpath(strClickEntityDropDownMonthlyReportXpath, LPLCoreConstents.getInstance().HIGHEST,
				ENTITY_DROPDOWN_MONTHLY);
		return clickElementUsingXpath(strClickEntityDropDownMonthlyReportXpath, ENTITY_DROPDOWN_MONTHLY)
				&& clickElementUsingXpath(strSelectEntityDropDownMonthlyReportXpath, ENTITY_CHECKBOX);
	}

	/**
	 * This method is used to select the CUSIPs from dropdown list in Monthly Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean selectTheCUSIPsFromDropdownListInMonthlyReport() {
		clickElementUsingXpath(strCUSIPsTextBoxMonthlyReportXpath, CUSIPS_TEXTBOX);
		waitTillVisibleUsingXpath(strClickCUSIPsDropDownMonthlyReportXpath, LPLCoreConstents.getInstance().HIGHEST,
				CUSIPS_DROPDOWN_MONTHLY_REPORT);
		return clickElementUsingXpath(strClickCUSIPsDropDownMonthlyReportXpath, CUSIPS_DROPDOWN_MONTHLY_REPORT)
				&& clickElementUsingXpath(strSelectCUSIPsDropDownMonthlyReportXpath, CUSIPS_CHECKBOX_MONTHLY_REPORT);
	}

	/**
	 * This method is used to enter Month End Date
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean selectTheMonthEndDate() {
		waitTillVisibleUsingXpath(strMonthEndDateTextBoxXpath, LPLCoreConstents.getInstance().HIGHEST,
				MONTH_END_DATE);
		Calendar calendar = Calendar.getInstance();
		// add -1 month to current month
		calendar.add(Calendar.MONTH, -1);
		// set actual maximum date of previous month
		calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		getPreviousMonthEndDate = getDateFormat(calendar);
		return enterTextUsingXpath(strMonthEndDateTextBoxXpath, getPreviousMonthEndDate, MONTH_END_DATE);
	}

	/**
	 * DESC : This method is used to click on the View Report button in Monthly
	 * Report
	 * 
	 * @return boolean
	 *
	 * @Author : Siddharth Gupta
	 * @Since : 12/16/2020
	 */
	public boolean clickOnViewReportButtonInMonthlyReport() {
		return clickElementUsingXpath(strMonthlyViewReportXpath, MONTHLY_VIEW_REPORT_BUTTON);
	}

	/**
	 * This method is used to check the header of Prop MF Rebate Monthly Account
	 * Level Detail Report
	 * 
	 * @return boolean
	 * 
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheHeaderOfPropMFRebateMonthlyAccountLevelDetailReport() {
		return isElementPresentUsingXpath(strMonthlyReportHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_MONTHLY_REPORT_HEADER);
	}

	/**
	 * This method is used to check Month End Date is present or not in Monthly
	 * Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyMonthEndDateIsPresentInMonthlyReport() {
		String strGetMonthEndDate = getAttributeUsingXpath(strMonthEndDateTextBoxXpath, ATTRIBUTE_NAME,
				VERIFY_MONTH_END_DATE);
		return (strGetMonthEndDate.equals(getPreviousMonthEndDate))
				? isElementPresentUsingXpath(strMonthEndDateLabelXpath, LPLCoreConstents.getInstance().LOWEST,
						MONTH_END_DATE_LABEL)
				: LPLCoreConstents.FALSE;
	}

	/**
	 * This method is used to check Entity is present or not in Monthly Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyEntityIsPresentInMonthlyReport() {
		String strGetEntityLabel = getTextUsingXpath(strEntityTextBoxMonthlyXpath, VERIFY_ENTITY_LABEL);
		return (testData.get("strEntityMonthly").equals(strGetEntityLabel))
				? isElementPresentUsingXpath(strEntityTextBoxMonthlyXpath, LPLCoreConstents.getInstance().LOWEST,
						VERIFY_ENTITY_LABEL)
				: LPLCoreConstents.FALSE;
	}

	/**
	 * This method is used to check the statement of Average Daily Position Value
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheStatementOfAverageDailyPositionValue() {
		return isElementPresentUsingXpath(strAvgPosValueXpath, LPLCoreConstents.getInstance().LOWEST, AVG_POS_VALUE);
	}

	/**
	 * This method is used to check The Availability of Search Field Option Labels
	 * for Monthly Report
	 * 
	 * @param monthlyReportLabels
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyReport(DataTable monthlyReportLabels) {
		boolean blnResult = false;
		List<Map<String, String>> filters = monthlyReportLabels.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS_MONTHLY_REPORT);
			blnResult = verifyTheAvailablityOfSearchFieldTypesForMonthlyReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the Availability of Search Field Type For
	 * Monthly Report
	 * 
	 * @param monthlyReportLabels
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/16/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldTypesForMonthlyReport(String monthlyReportLabels) {
		return isElementPresentUsingXpath(getFormattedLocator(strSearchMonthlyReportLabelsXpath, monthlyReportLabels),
				monthlyReportLabels);
	}

	/**
	 * This method is used to verify availability of MWP Strategist Account
	 * Attributes Report report link
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 1/15/2021
	 */
	public boolean iVerifytheAvailabilityofMWPAccountAttributesReportlink() {
		return isElementPresentUsingXpath(strMWPAccountAttributesReportLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				REPORT_LINK);
	}

	/**
	 * This method is used to click on MWP Strategist Account Attributes report link
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 1/15/2021
	 */
	public boolean iClickOnMWPAccountAttributesReport() {
		return clickElementUsingXpath(strMWPAccountAttributesReportLinkXpath, REPORT_LINK);
	}

	/**
	 * This method is used to check the header of MWP Account Attributes Report
	 * report
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 1/15/2021
	 */
	public boolean verifytheHeaderofMWPAccountAttributesReport() {
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		return isElementPresentUsingXpath(strMWPAccountAttributesReportHeaderXpath, REPORT_HEADER);
	}

	/**
	 * This method is used to verify Prop MF Monthly Credit Total by CUSIP Report
	 * link should be displayed
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheAvailabilityOfPropMFMonthlyCreditTotalByCUSIPReportLink() {
		return isElementPresentUsingXpath(strPropMFCUSIPReportXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT);
	}

	/**
	 * This method is used to click on Prop MF Monthly Credit Total by CUSIP Report
	 * link
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean clickOnPropMFMonthlyCreditTotalByCUSIPReportLink() {
		return clickElementUsingXpath(strPropMFCUSIPReportXpath, PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT);
	}

	/**
	 * This method is used to Verify the Page Title of the Prop MF Monthly Credit
	 * Total by CUSIP Report opened in new tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean shouldSeePropMFMonthlyCreditTotalByCUSIPReportOpenedInNewTab() {
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		waitTillVisibleUsingXpath(strPropMFCUSIPReportTitleXpath, LPLCoreConstents.getInstance().HIGHEST,
				PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT);
		return isElementPresentUsingXpath(strPropMFCUSIPReportTitleXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT);
	}

	/**
	 * This method is used to check The Availability of Search Field Option Labels
	 * for Monthly Credit CUSIP Report
	 * 
	 * @param cusipReportLabels
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyCreditCUSIPReport(
			DataTable cusipReportLabels) {
		boolean blnResult = false;
		List<Map<String, String>> filters = cusipReportLabels.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS_MONTHLY_REPORT);
			blnResult = verifyTheAvailablityOfSearchFieldTypesForMonthlyCreditCUSIPReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the Availability of Search Field Type For
	 * Monthly Credit CUSIP Report
	 * 
	 * @param cusipReportLabels
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheAvailablityOfSearchFieldTypesForMonthlyCreditCUSIPReport(String cusipReportLabels) {
		return isElementPresentUsingXpath(getFormattedLocator(strSearchMonthlyAccountLabelsXpath, cusipReportLabels),
				cusipReportLabels);
	}

	/**
	 * This method is used to select the Entity from dropdown list for CUSIP Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean selectTheEntityFromDropdownListForCUSIPReport() {
		waitTillVisibleUsingXpath(strClickEntityDropDownMonthlyReportXpath, LPLCoreConstents.getInstance().HIGHEST,
				ENTITY_DROPDOWN_MONTHLY);

		return clickElementUsingXpath(strClickEntityDropDownMonthlyReportXpath, ENTITY_DROPDOWN_MONTHLY)
				&& clickElementUsingXpath(strSelectEntityDropDownMonthlyReportXpath, ENTITY_CHECKBOX);
	}

	/**
	 * This method is used to select the CUSIPs from dropdown list for CUSIP Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean selectTheCUSIPsFromDropdownListForCUSIPReport() {
		clickElementUsingXpath(strCUSIPsTextBoxMonthlyReportXpath, CUSIPS_TEXTBOX);		
		waitTillVisibleUsingXpath(strClickCUSIPsDropDownMonthlyReportXpath, LPLCoreConstents.getInstance().HIGHEST,
				CUSIPS_DROPDOWN_MONTHLY_REPORT);
		waitTillVisibleUsingXpath(strClickCUSIPsDropDownMonthlyReportXpath, LPLCoreConstents.getInstance().HIGHEST,
				CUSIPS_DROPDOWN_MONTHLY_REPORT);
		return clickElementUsingXpath(strClickCUSIPsDropDownMonthlyReportXpath, CUSIPS_DROPDOWN_MONTHLY_REPORT)
				&& clickElementUsingXpath(strSelectCUSIPsDropDownMonthlyReportXpath, CUSIPS_CHECKBOX_MONTHLY_REPORT);
	}

	/**
	 * This method is used to enter Month End Date for CUSIP Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean selectTheMonthEndDateFromDropdownList() {
		waitTillVisibleUsingXpath(strMonthEndDateCUSIPReportXpath, LPLCoreConstents.getInstance().HIGHEST,
				MONTH_END_DATE_DROPDOWN);
		Calendar calendar = Calendar.getInstance();
		// add -1 month to current month
		calendar.add(Calendar.MONTH, -1);
		// set actual maximum date of previous month
		calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		getPreviousMonthEndDate = dateFormat.format(calendar.getTime());
		return selectValueFromDropdownUsingXpath(strMonthEndDateCUSIPReportXpath, getPreviousMonthEndDate,
				MONTH_END_DATE_DROPDOWN);
	}

	/**
	 * DESC : This method is used to click on the View Report button in CUSIP Report
	 * 
	 * @return boolean
	 *
	 * @Author : Siddharth Gupta
	 * @Since : 01/13/2020
	 */
	public boolean clickOnViewReportButtonForCUSIPReport() {
		return clickElementUsingXpath(strMonthlyViewReportXpath, SUMMARY_VIEW_REPORT_BUTTON);
	}

	/**
	 * This method is used to check the header of Prop MF Monthly Credit Total by
	 * CUSIP Report
	 * 
	 * @return boolean
	 * 
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheHeaderOfPropMFMonthlyCreditTotalByCUSIPReport() {
		return isElementPresentUsingXpath(strCUSIPReportHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT_HEADER);
	}

	/**
	 * This method is used to check Month End Date is present or not in CUSIP Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyMonthEndDateIsPresentInCUSIPReport() {
		String strGetMonthEndDate = getAttributeUsingXpath(strMonthEndDateCUSIPReportXpath, ATTRIBUTE_NAME,
				VERIFY_MONTH_END_DATE);
		if (strGetMonthEndDate.equals(getPreviousMonthEndDate))
			return isElementPresentUsingXpath(strMonthEndDateLabelXpath, LPLCoreConstents.getInstance().LOWEST,
					MONTH_END_DATE_LABEL);
		else
			return false;
	}

	/**
	 * This method is used to check Entity is present or not in CUSIP Report
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyEntityIsPresentInCUSIPReport() {
		String strGetEntityLabel = getTextUsingXpath(strEntityTextBoxMonthlyXpath, VERIFY_ENTITY_LABEL);
		if (testData.get("strEntityMonthly").equals(strGetEntityLabel))
			return isElementPresentUsingXpath(strEntityTextBoxMonthlyXpath, LPLCoreConstents.getInstance().LOWEST,
					VERIFY_ENTITY_LABEL);
		else
			return false;
	}

	/**
	 * This method is used to check the statement of CUSIP Factor File
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheStatementOfCUSIPFactorFile() {
		return isElementPresentUsingXpath(strCUSIPFactorXpath, LPLCoreConstents.getInstance().LOWEST,
				CUSIP_FACTOR_FILE_VALUE);
	}

	/**
	 * This method is used to verify the Label of CUSIP
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheCUSIPLabel() {
		return isElementPresentUsingXpath(strCUSIPLabelXpath, LPLCoreConstents.getInstance().LOWEST,
				CUSIP_FACTOR_FILE_VALUE);
	}

	/**
	 * This method is used to verify the Label of Fund Name
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheFundNameLabel() {
		return isElementPresentUsingXpath(strFundNameLabelXpath, LPLCoreConstents.getInstance().LOWEST,
				CUSIP_FACTOR_FILE_VALUE);
	}

	/**
	 * This method is used to verify the Label of Credit Factor
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheCreditFactorLabel() {
		return isElementPresentUsingXpath(strCreditFactorLabelXpath, LPLCoreConstents.getInstance().LOWEST,
				CUSIP_FACTOR_FILE_VALUE);
	}

	/**
	 * This method is used to verify the Label of Total Credit Amount
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/13/2020
	 */
	public boolean verifyTheTotalCreditAmountLabel() {
		return isElementPresentUsingXpath(strTotalCreditAmountLabelXpath, LPLCoreConstents.getInstance().LOWEST,
				CUSIP_FACTOR_FILE_VALUE);
	}

	/**
	 * This method is used to verify availability of MWP Termed Accts Active Sleeves
	 * report link
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/24/2021
	 */
	public boolean iVerifyTheAvailabilityOfMWPTermedAcctsActiveSleevesLink() {
		return isElementPresentUsingXpath(strMWPTermedAcctsActiveSleevesLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, TERMED_REPORT_LINK);
	}

	/**
	 * This method is used to click on MMWP Termed Accts Active Sleeves link
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/24/2021
	 */
	public boolean iClickOnMWPTermedAcctsActiveSleeves() {
		return clickElementUsingXpath(strMWPTermedAcctsActiveSleevesLinkXpath, TERMED_REPORT_LINK);
	}

	/**
	 * This method is used to check the header of MWP Termed Accts Active Sleeves
	 * report
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/24/2021
	 */
	public boolean iVerifyTheHeaderOfMWPTermedAcctsActiveSleeves() {
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		return isElementPresentUsingXpath(strMWPTermedAcctsActiveSleevesHeaderXpath, TERMED_REPORT_HEADER);
	}

	/**
	 * This method is used to verify the display of header columns in Split ID
	 * Report
	 * 
	 * @param searchResultOptions
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/28/2021
	 */
	public boolean verifythedisplayofheadercolumnsinMWPTermedAcctsActiveSleeves(DataTable searchResultOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchResultOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify availability of MWP Active Accts No Active
	 * Sleeves report link
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/25/2021
	 */
	public boolean iVerifyTheAvailabilityOfMWPActiveAcctsNoActiveSleevesLink() {
		return isElementPresentUsingXpath(strMWPActiveAcctsNoActiveSleevesLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, ACTIVE_REPORT_LINK);
	}

	/**
	 * This method is used to click on MWP Active Accts No Active Sleeves link
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/25/2021
	 */
	public boolean iClickOnMWPActiveAcctsNoActiveSleeves() {
		return clickElementUsingXpath(strMWPActiveAcctsNoActiveSleevesLinkXpath, ACTIVE_REPORT_LINK);
	}

	/**
	 * This method is used to check the header of MWP Active Accts No Active Sleeves
	 * report
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/25/2021
	 */
	public boolean iVerifyTheHeaderOfMWPActiveAcctsNoActiveSleeves() {
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		return isElementPresentUsingXpath(strMWPActiveAcctsNoActiveSleevesHeaderXpath, ACTIVE_REPORT_HEADER);
	}

	/**
	 * This method is used to verify the display of header columns in Split ID
	 * Report
	 * 
	 * @param searchResultOptions
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/28/2021
	 */
	public boolean verifythedisplayofheadercolumnsinMWPActiveAcctsNoActiveSleeves(DataTable searchResultOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchResultOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify availability of Account Level Reconciliation
	 * Report report link
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 2/15/2021
	 */
	public boolean iVerifytheAvailabilityofAccountLevelReconciliationReportLink() {
		return isElementPresentUsingXpath(strAccountLevelReconciliationReportLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, REPORT_LINK);
	}

	/**
	 * This method is used to click on Account Level Reconciliation Report
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 2/15/2021
	 */
	public boolean iClickOnAccountLevelReconciliationReportLink() {
			return clickElementUsingXpath(strAccountLevelReconciliationReportLinkXpath, REPORT_LINK);
	
	}
	/**
	 * This method is used to verify availability of Missing Firm ID
	 * Report report link
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 3/2/2021
	 */
	public boolean iVerifytheAvailabilityofMissingFirmIDReportLink() {
		return isElementPresentUsingXpath(strMissingFirmIDReportLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, REPORT_LINK);
	}

	/**
	 * This method is used to click on Missing Firm ID
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 3/2/2021
	 */
	public boolean iClickOnMissingFirmIDReportLink() {
		return clickElementUsingXpath(strMissingFirmIDReportLinkXpath, REPORT_LINK);
	}
	
	/**
     * This method is availability of Termed GWP Accounts By Period report link
     * 
     * @return boolean
     *
     * @author saritha akkaraju
     * @since 4/8/2021
     */
       public boolean iVerifytheAvailabilityofTermedGWPAccountsByPeriodReportLink() {
           return isElementPresentUsingXpath(strTermedGWPAccountsByPeriodLinkXPath, LPLCoreConstents.getInstance().LOWEST,
                       REPORT_LINK);
     }
   
     /**
      * This method is used to click on Termed GWP Accounts By Period report link
      * 
      * @return boolean
      *
      * @author saritha akkaraju
      * @since 4/8/2021
      */
      public boolean iClickOnTermedGWPAccountsByPeriodReportLink() {
              return clickElementUsingXpath(strTermedGWPAccountsByPeriodLinkXPath, REPORT_LINK);

       }
       /**
       * This method is used to Verify the Page opens for Termed GWP accounts in new tab
       * Market Value report opened in new tab
       * 
       * @return boolean
       *
       * @Author saritha akkaraju
       * @Since 4/10/2021
       */
             public boolean termedGWPAccountsByPeriodReportOpenedInNewTab() {
                    browserActiveTabs = getActiveBrowserTabs();
                    switchToSecondTab(browserActiveTabs);
                    logInNewTabOpening();
                    waitTillVisibleUsingXpath(strTermedGWPAccountsByPeriodTitleXpath, LPLCoreConstents.getInstance().HIGHEST,
                   		 REPORT_LINK);
                    return isElementPresentUsingXpath(strTermedGWPAccountsByPeriodTitleXpath, LPLCoreConstents.getInstance().LOWEST,
                    		 REPORT_LINK);
             }
	     /**
	      * This method is used to Verify the Page opens for Account Reconiciliation report in new tab
	      * Market Value report opened in new tab
	      * 
	      * @return boolean
	      *
	      * @Author saritha akkaraju
	      * @Since 5/18/2021
	      */     
             public boolean accountLevelReconciliationReportOpenedInNewTab() {
                 browserActiveTabs = getActiveBrowserTabs();
                 switchToSecondTab(browserActiveTabs);
                 refreshTheWebpage();
                 logInNewTabOpening();
                 return isElementPresentUsingXpath(strAccountlevelReconciliationViewReportXpath, LPLCoreConstents.getInstance().LOWEST,
                		 REPORT_LINK);
          }
         /**
    	  * This method is used to Verify the Page opens for Missed FIrm ID in new tab
    	  * Market Value report opened in new tab
    	  * 
    	  * @return boolean
    	  *
    	  * @Author saritha akkaraju
    	  * @Since 5/18/2021
    	  */     
               public boolean missedFirmIDOpenedInNewTab() {
                  browserActiveTabs = getActiveBrowserTabs();
                  switchToSecondTab(browserActiveTabs);
                  logInNewTabOpening(); 
                  waitTillVisibleUsingXpath(strMissingFirmIDTitleXpath, LPLCoreConstents.getInstance().HIGHEST,
                    		 REPORT_LINK);
                  return isElementPresentUsingXpath(strMissingFirmIDTitleXpath, LPLCoreConstents.getInstance().LOWEST,
                    		 REPORT_LINK);
              }
               
          /**
          * This method is used to Verify the Page opens for Missed FIrm ID in new tab
          * Market Value report opened in new tab
          * 
          * @return boolean
          *
          * @Author saritha akkaraju
          * @Since 5/18/2021
          */     
               public boolean MWPAccountAttributesOpenedInNewTab() {
                     browserActiveTabs = getActiveBrowserTabs();
                     switchToSecondTab(browserActiveTabs);
                     logInNewTabOpening();
                     waitTillVisibleUsingXpath(strMWPAccountAtrributesHeaderXpath, LPLCoreConstents.getInstance().HIGHEST,
                    		 REPORT_LINK);
                             
                     return isElementPresentUsingXpath(strMWPAccountAtrributesHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
                          		 REPORT_LINK);
                    }      
        /**
        * This method is used to click on View Report
        * 
        * @return boolean
        *
        * @author saritha akkaraju
        * @since 4/8/2021
        */
         public boolean iClickOnViewReport() {
             return clickElementUsingXpath(strViewReportButtonXpath, VIEW_REPORT);
         }
         /**
         * This method is used to check the header of Termed GWP Accounts By Period
         * report
         * 
         * @return boolean
         *
         * @author saritha akkaraju
         * @since 4/8/2021
         */
          public boolean iVerifytheHeaderofTermedGWPAccountsByPeriod() {
               return isElementPresentUsingXpath(strTermedGWPAccountsByPeriodHeaderXpath, REPORT_LINK);
           } 
           /**
           * This method is used to verify the display of header columns in Termed GWP Accounts By Period
           * 
           * @param searchResultOptions
           * @return boolean
           *
           * @author saritha akkaraju
           * @since 4/8/2021
           */
           public boolean iverifythedisplayofheadercolumnsinTermedGWPAccountsByPeriod(DataTable ReportColumns) {
                 boolean blnResult = false;
                 List<Map<String, String>> filters = ReportColumns.asMaps(String.class, String.class);
                 for (Map<String, String> data : filters) {
                      String filterName = data.get(OPTIONS);
                      blnResult = checkIfElementExistUsingTableHeaderText(filterName);
                      LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                              USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
                              SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
                    }
                  return blnResult;
             }
             /**
             * This method is used to verify availability of Broker Account  Report
             * report link
             * 
              * @return boolean
             *
             * @author saritha akkaraju
             * @since 4/10/2021
             */
             public boolean iVerifytheAvailabilityofBrokerAccountReportlink() {
                    return isElementPresentUsingXpath(strBrokerAccountLinkXPath, LPLCoreConstents.getInstance().LOWEST,
                                 REPORT_LINK);
             }
             /**
             * This method is used to click on Broker Account report link
             * 
              * @return boolean
             *
             * @author saritha akkaraju
             * @since 4/10/2021
             */
             public boolean iClickOnBrokerAccountReportlink() {
                    return clickElementUsingXpath(strBrokerAccountLinkXPath, REPORT_LINK);
             }      

}
