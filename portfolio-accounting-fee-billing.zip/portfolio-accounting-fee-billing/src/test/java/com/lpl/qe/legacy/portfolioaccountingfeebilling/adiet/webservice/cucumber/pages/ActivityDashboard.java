package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> ActivityDashboard.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for ActivityDashboard</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class ActivityDashboard extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 815;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String ACTIVITY_DASHBOARD_PAGE_HEADER = "Activity Dashboard Page Header";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String SUCESSFULLY_ABLE_TO_SEE = "Successfully be able to see ";
	public static final String OPTION = "options";
	public static final String ACTIVITY_DATA = "Activity Data";
	public static final String DATE_RANGE_DRPDWN = "Date Range Dropdown";
	public static final String DATEFORMAT = "MM/dd/yyyy";
	public static final String SEARCHBUTTON = "Search Button";
	public static final String CHECKBOX_ALL = "Check box All";
	public static final String DATEVALUE = "Date Value";
	String strActivityDashboardHeaderXpath;
	String strCheckBoxXpath;
	String strCheckBoxAllXpath;
	String strColumnsInReportsXpath;
	String strActivityDataXpath;
	String strDateRangeDrpdwnXpath;
	String strDateValueXpath;
	String strSearchBtnXpath;

	public ActivityDashboard(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strActivityDashboardHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				ACTIVITY_DASHBOARD_PAGE_HEADER);
	}

	/**
	 * This method is used to check If Column Available In Report
	 * 
	 * @param columnInReport
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/24/2020
	 */
	public boolean checkIfColumnsAvailableInReport(String columnInReport) {
		return isElementPresentUsingXpath(getFormattedLocator(strColumnsInReportsXpath, columnInReport),
				columnInReport);
	}

	/**
	 * This method is used to check If Columns Available In Report
	 * 
	 * @boolean columnsInReport
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/24/2020
	 */
	// To verify the options available in the dropdown TrackingStatus
	public boolean verifyColumnsAvailableInactivityReport(DataTable columnsInReport) {
		boolean blnResult = false;
		List<Map<String, String>> filters = columnsInReport.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTION);
			blnResult = checkIfColumnsAvailableInReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If checkBox available on Activity Dashboard page
	 * 
	 * @param checkBox
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 01/21/2021
	 */
	public boolean checkIfCheckBoxAvailable(String checkBoxOnPage) {
		return isElementPresentUsingXpath(getFormattedLocator(strCheckBoxXpath, checkBoxOnPage), checkBoxOnPage);
	}

	/**
	 * This method is used to check If checkBox available on Activity Dashboard page
	 * 
	 * @boolean checkBox
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 01/21/2021
	 */
	// To verify the checkBox available on Activity Dashboard page
	public boolean verifyCheckBoxAvailable(DataTable checkboxOnPage) {
		boolean blnResult = false;
		List<Map<String, String>> filters = checkboxOnPage.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTION);
			blnResult = checkIfCheckBoxAvailable(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If checkBox All is selected on Activity
	 * Dashboard page
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 01/21/2021
	 */
	public boolean verifyAllCheckboxIsSelected() {
		WebElement checkBoxAll = getWebElementUsingXpath(strCheckBoxAllXpath, CHECKBOX_ALL);
		return checkBoxAll.isSelected();
	}

	/**
	 * This method is used to verify transaction data is displayed
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 01/21/2021
	 */
	public boolean verifyActivityDataIsDisplayed() {
		return isElementPresentUsingXpath(DISPLAYED, strActivityDataXpath, ACTIVITY_DATA);
	}

	/**
	 * This method is used to select value in Date Range Drop Down
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 12/18/2020
	 */
	public boolean selectValueInDateRangeDropdown(String drpdwnValue) {
		selectValueFromDropdownUsingXpath(strDateRangeDrpdwnXpath, drpdwnValue, DATE_RANGE_DRPDWN);
		return isDropDownValueSelected(strDateRangeDrpdwnXpath, drpdwnValue);
	}

	/**
	 * This method is used to select value in Date Range Drop Down
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 12/18/2020
	 */
	public boolean verifyDateFormat() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
		dateFormat.setLenient(false);
		String dateValue = getTextUsingXpath(strDateValueXpath, DATEVALUE).trim();
		try {
			dateFormat.parse(dateValue);
		} catch (ParseException e) {
			setErrorMessage(e.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * This method is used to Click On Search Button under Transaction tab
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 12/28/2020
	 */
	public boolean iClickOnSearchButtonUnderActivityDashboard() {
		return clickElementUsingXpath(strSearchBtnXpath, SEARCHBUTTON);
	}
}
