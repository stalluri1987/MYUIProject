package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;

/**
 * <p>
 * <br>
 * <b> Title: </b> FBVADashboard.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for FBVADashboard</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class FBVADashboard extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 816;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String FBVA_DASHBOARD_PAGE_HEADER = "FBVA Dashboard Page Header";
	String strFBVADashboardHeaderXpath;

	public FBVADashboard(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strFBVADashboardHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				FBVA_DASHBOARD_PAGE_HEADER);
	}
}
