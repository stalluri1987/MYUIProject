package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> ReportingNextGenStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for ReportingNextGen</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * ReportingNextGenStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class ReportingNextGenStepDef extends CommonStepDef {

	@And("^I verify the availability of Prop MF FeeRebating Reporting Tab on Reporting NextGen page$")
	public void iVerifyTheAvailabilityOfPropMFFeeRebatingReportingTabOnReportingNextGenPage() {
		boolean blnResult = reportingNextGen
				.verifyTheAvailabilityOfPropMFFeeRebatingReportingTabOnReportingNextGenPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Prop MF FeeRebating Reporting Tab on Reporting NextGen page",
				"User should be able to see Prop MF FeeRebating Reporting Tab on Reporting NextGen page",
				"Successfully able to see Prop MF FeeRebating Reporting Tab on Reporting NextGen page",
				"Failed to see Prop MF FeeRebating Reporting Tab on Reporting NextGen page : " + Common.strError);
	}

	@When("^I click on Prop MF FeeRebating Reporting Tab on Reporting NextGen page$")
	public void iClickOnPropMFFeeRebatingReportingTabOnReportingNextGenPage() {
		boolean blnResult = reportingNextGen.clickOnPropMFFeeRebatingReportingTabOnReportingNextGenPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the Prop MF FeeRebating Reporting Tab on Reporting NextGen page",
				"User should be able to to Click on the Prop MF FeeRebating Reporting Tab on Reporting NextGen page",
				"Successfully able to Click on the Prop MF FeeRebating Reporting Tab on Reporting NextGen page",
				"Failed to Click on the Prop MF FeeRebating Reporting Tab on Reporting NextGen page : "
						+ Common.strError);
	}

	@Then("^I verify the availability of Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page$")
	public void iVerifyTheAvailabilityOfPropMFRebateDailyMktValueReportLinkOnReportingNextGenPage() {
		boolean blnResult = reportingNextGen
				.verifyTheAvailabilityOfPropMFRebateDailyMktValueReportLinkOnReportingNextGenPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page",
				"User should be able to see Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page",
				"Successfully able to see Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page",
				"Failed to see Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page :  "
						+ Common.strError);
	}

	@When("^I click on Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page$")
	public void iClickOnPropMFMonthlyCreditTotalByCUSIPReportLinkOnReportingNextGenPage() {
		boolean blnResult = reportingNextGen.clickOnPropMFMonthlyCreditTotalByCUSIPReportLinkOnReportingNextGenPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page",
				"User should be able to Click on the Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page",
				"Successfully able to Click on the Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page",
				"Failed to Click on the Prop MF Monthly Credit Total by CUSIP Report link on Reporting NextGen page : "
						+ Common.strError);
	}

	@Then("^I should see Prop MF Monthly Credit Total by CUSIP Report opened in another tab$")
	public void iShouldSeePropMFMonthlyCreditTotalByCUSIPReportOpenedInAnotherTab() {
		boolean blnResult = reportingNextGen.shouldSeePropMFMonthlyCreditTotalByCUSIPReportOpenedInAnotherTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Page Title of the Prop MF Monthly Credit Total by CUSIP Report opened in third tab",
				"User should be able to see Prop MF Monthly Credit Total by CUSIP Report opened in third tab",
				"Successfully able to see Prop MF Monthly Credit Total by CUSIP Report opened in third tab",
				"Failed to see Prop MF Monthly Credit Total by CUSIP Report opened in third tab : " + Common.strError);
	}

	@And("^I go back to Adiet Home Page$")
	public void iGoBackToAdietHomePage() {
		boolean blnResult = reportingNextGen.goBackToAdietHomePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify to go back Adiet Home Page",
				"User should be able to see Adiet Home Page", "Successfully able to see Adiet Home Page",
				"Failed to see Adiet Home Page : " + Common.strError);
	}

	@And("^I verify the data with NextGen Report$")
	public void iVerifyTheDataWithNextGenReport() {
		boolean blnResult = reportingNextGen.verifyTheDataWithNextGenReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the data with NextGen Report",
				"User should be able to verify the data with NextGen Report",
				"Successfully able to verify the data with NextGen Report",
				"Failed to verify the data with NextGen Report : " + Common.strError);
	}

	@Then("^I verify the availability of Non RIA Accounts as RIA Report Link$")
	public void iVerifyTheAvailabilityOfNonRiaAccountsAsRiaReportLink() {
		boolean blnResult = reportingNextGen.verifyTheAvailabilityOfNonRiaAccountsAsRiaReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Non RIA Accounts as RIA Report Link",
				"User should be able to verify the availability of Non RIA Accounts as RIA Report Link",
				"Successfully able to verify the availability of Non RIA Accounts as RIA Report Link",
				"Failed to verify the availability of Non RIA Accounts as RIA Report Link : " + Common.strError);
	}

	@And("^I click on Non RIA Accounts as RIA Report Link$")
	public void iClickOnNonRiaAccountsAsRiaReportLink() {
		boolean blnResult = reportingNextGen.clickOnNonRiaAccountsAsRiaReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the user is able to click on Non RIA Accounts as RIA Report Link",
				"User should be able to click on Non RIA Accounts as RIA Report Link",
				"Successfully able to click on Non RIA Accounts as RIA Report Link",
				"Failed to click on Non RIA Accounts as RIA Report Link : " + Common.strError);
	}

	@Then("^I verify the Header of Non RIA Accounts as RIA Report$")
	public void iVerifyTheHeaderOfNonRiaAccountsAsRiaReport() {
		boolean blnResult = reportingNextGen.verifyTheHeaderOfNonRiaAccountsAsRiaReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Header of Non RIA Accounts as RIA Report",
				"User should be able to verify the Header of Non RIA Accounts as RIA Report",
				"Successfully able to verify the Header of Non RIA Accounts as RIA Report",
				"Failed to verify the Header of Non RIA Accounts as RIA Report : " + Common.strError);
	}

	@And("^I verify the availablity of search field option labels for Non RIA Accounts as RIA Report$")
	public void iVerifyTheAvailablityOfSearchFieldOptionLabelsForNonRiaAccountsAsRiaReport(
			DataTable nonRiaAccountsReport) {
		boolean blnResult = reportingNextGen
				.verifyTheAvailablityOfSearchFieldOptionLabelsForNonRiaAccountsAsRiaReport(nonRiaAccountsReport);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search field option labels for Non RIA Accounts as RIA Report",
				"User should be able to see all search field option labels",
				"Successfully able to see all search field option labels as expected",
				"Failed to see all search field option labels as expected : " + Common.strError);
	}

	@And("^I get the Non RIA Accounts data and go back to Adiet Home Page$")
	public void iGetTheNonRiaAccountsDataAndGoBackToAdietHomePage() {
		boolean blnResult = reportingNextGen.getTheNonRiaAccountsDataAndGoBackToAdietHomePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Get the Non RIA Accounts data and go back to Adiet Home Page",
				"User should be able to get the Non RIA Accounts data and go back to Adiet Home Page",
				"Successfully able to get the Non RIA Accounts data and go back to Adiet Home Page",
				"Failed to get the Non RIA Accounts data and go back to Adiet Home Page : " + Common.strError);
	}

	@And("^I verify the Non RIA Accounts Classic Data with NextGen Data$")
	public void iVerifyTheNonRiaAccountsClassicDataWithNextGenData() {
		boolean blnResult = reportingNextGen.verifyTheNonRiaAccountsClassicDataWithNextGenData();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Non RIA Accounts Classic Data with NextGen Data",
				"User should be able to verify the Non RIA Accounts Classic Data with NextGen Data",
				"Successfully able to verify the Non RIA Accounts Classic Data with NextGen Data",
				"Failed to verify the Non RIA Accounts Classic Data with NextGen Data : " + Common.strError);
	}

	@Then("^I click on Hamburger Icon")
	public void iClickOnHamburgerIcon() {
		boolean blnResult = reportingNextGen.clickOnHamburgerIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if user is able to click on Hamburger Icon ",
				"User should be able to able to click on Hamburger Icon",
				"Successfully able to click on Hamburger Icon",
				"Failed to click on Hamburger Icon : " + Common.strError);
	}

	@Then("^I choose Historical Correction")
	public void iChooseHistoricalCorrection() {
		boolean blnResult = reportingNextGen.clickOnHistoricalCorrection();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if user is able to click on Historical Correction ",
				"User should be able to able to click on Historical Correction",
				"Successfully able to click on Historical Correction",
				"Failed to click on Historical Correction : " + Common.strError);
	}

	@Then("^I click on Fee Correction")
	public void iClickOnFeeCorrection() {
		boolean blnResult = reportingNextGen.clickOnFeeCorrection();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if user is able to click on Fee Correction ",
				"User should be able to able to click on Fee Correction",
				"Successfully able to click on Fee Correction",
				"Failed to click on Fee Correction : " + Common.strError);
	}

	@Then("^I click on Process Tracking")
	public void iClickOnProcessTracking() {
		boolean blnResult = reportingNextGen.clickOnProcessTrackingTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if user is able to click on Process Tracking ",
				"User should be able to able to click on Process Tracking",
				"Successfully able to click on Process Tracking",
				"Failed to click on Process tracking : " + Common.strError);
	}

	@Then("^I choose Portfolio Accounting$")
	public void iChoosePortfolioAccounting() {
		boolean blnResult = reportingNextGen.clickOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if user is able to click on PortfolioAccounting ",
				"User should be able to able to click on PortfolioAccounting",
				"Successfully able to click on PortfolioAccounting",
				"Failed to click on PortfolioAccounting : " + Common.strError);
	}

	@Then("^I verify availability of below columns in HC$")
	public void iverifytheavailabilityofsearchfields(DataTable columnOptions) {
		boolean blnResult = reportingNextGen.verifyTheAvailabilityOfColumnsHC(columnOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availability of columns",
				"User should be able to see all columns", "Successfully able to see all columns",
				"Failed to see all columns : " + Common.strError);
	}

	@Then("^I verify availability of below columns on Process Tracking Tab$")
	public void iverifytheavailabilityonProceverifyTheAvailabilityOfColumnsOnPTssTracking(DataTable columnOptions) {
		boolean blnResult = reportingNextGen.verifyTheAvailabilityOfColumnsOnPT(columnOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availability of columns",
				"User should be able to see all columns", "Successfully able to see all columns",
				"Failed to see all columns : " + Common.strError);
	}

	@Then("^I click on Review and Approve Tab")
	public void iClickOnReviewAndApprove() {
		boolean blnResult = reportingNextGen.clickOnReviewAndApprove();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if user is able to click on Review and Approve Tab ",
				"User should be able to able to click on Review and Approve Tab",
				"Successfully able to click on Review and Approve Tab",
				"Failed to click on Review and Approve Tab : " + Common.strError);
	}

	@And("^I verify availability of below columns on ReviewAndApprove Tab")
	public void iVerifyTheAvailabilityOfColumns(DataTable reviewAndApprove) {
		boolean blnResult = reportingNextGen.verifyTheAvailabilityOfColumnsOnReviewAndApprove(reviewAndApprove);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of columns on ReviewAndApprove Tab",
				"User should be able to see all columns on ReviewAndApprove Tab",
				"Successfully able to see all columns on ReviewAndApprove Tab",
				"Failed to see all columns on ReviewAndApprove Tab : " + Common.strError);
	}

	@And("^I verify Approve button is present")
	public void iVerifyApproveButtonIsPresent() {
		boolean blnResult = reportingNextGen.verifyApproveButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Approve button", "User should be able to see Approve button",
				"Successfully able to see Approve button", "Failed to see Approve button : " + Common.strError);
	}

	@And("^I verify Clear List button is present")
	public void iVerifyProcessTrackingIsPresent() {
		boolean blnResult = reportingNextGen.verifyClearListIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Clear List button", "User should be able to see Clear List button",
				"Successfully able to see Clear List button", "Failed to see Clear List button : " + Common.strError);
	}

	@And("^I verify Hold button is present")
	public void iVerifyHoldButtonIsPresent() {
		boolean blnResult = reportingNextGen.verifyHoldButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availability of Hold button",
				"User should be able to see Hold button", "Successfully able to see Hold button",
				"Failed to see Hold button : " + Common.strError);
	}

	@And("^I verify Remove button is present")
	public void iVerifyRemoveButtonIsPresent() {
		boolean blnResult = reportingNextGen.verifyRemoveButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Remove button", "User should be able to see Remove button",
				"Successfully able to see Remove button", "Failed to see Remove button : " + Common.strError);
	}

	@And("^I verify Export button is present")
	public void iVerifyExportButtonIsPresent() {
		boolean blnResult = reportingNextGen.verifyExportButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Export button", "User should be able to see Export button",
				"Successfully able to see Export button", "Failed to see Export button : " + Common.strError);
	}

	@When("^I click on Export button on Review and Approve Tab")
	public void clickOnExportButtonOnReviewAndApprovePage() {
		boolean blnResult = reportingNextGen.iClickOnExportButtonOnReviewAndApprovePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Export button",
				"User should able to click Export button", "Successfully able to click Export button",
				"Failed to click Export button :" + Common.strError);
	}

	@Then("^I click on Export All Data from the list")
	public void clickOnExportAllData() {
		boolean blnResult = reportingNextGen.iClickOnExportAllData();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on ExportAllData from the list",
				"User should able to click ExportAllData from the list",
				"Successfully able to click ExportAllData from the list",
				"Failed to click ExportAllData from the list :" + Common.strError);
	}

	@And("^I verify file downloaded successfully on Review and Approve Tab")
	public void verifyFileDownloadedSuccessfully() {
		boolean blnResult = reportingNextGen.verifyDownloadedFile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully",
				"Successfully able to see file downloaded successfully",
				"Failed to see file downloaded successfully : " + Common.strError);
	}

	@And("^I verify that the Portfolio Accounting Page has below tabs")
	public void iVerifyPortfolioAccoutingTabs(DataTable portfoliotab) {
		boolean blnResult = reportingNextGen.verifyPortfolioAccountingTabs(portfoliotab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below tabs on Portfolio Accounting page",
				"User should be able to see the tabs on Portfolio Accounting page",
				"Successfully able to see the tabs on Portfolio Accounting page",
				"Failed to see the tabs on Portfolio Accounting page : " + Common.strError);
	}

	@And("^I enter LPL AcctNum1 in given field")
	public void iEnterLPLAcctNum1() {
		boolean blnResult = reportingNextGen.enterLPLAcctNum1();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if user is able to enter AcctNum1", "User should be able to enter AcctNum1",
				"Successfully able to enter AcctNum1", "Failed to enter AcctNum1 : " + Common.strError);
	}

	@And("^I click on Search button present on the page")
	public void iClickOnSearchButton() {
		boolean blnResult = reportingNextGen.clickOnSearchButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if user is able to click on Search Button", "User should be able to click on Search Button",
				"Successfully able to click on Search Button", "Failed to click on Search Button : " + Common.strError);
	}
	
	@And("^I click on BETA tab on Portfolio Accounting$")
	public void iClickOnBetaTabOnPortfolioAccounting() {
		boolean blnResult = reportingNextGen.clickOnBetaTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on BETA Tab on PortfolioAccounting page",
				"User should able to click on BETA Tab on PortfolioAccounting page",
				"Successfully able to click on BETA Tab on PortfolioAccounting page",
				"Failed to click on BETA Tab on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify that the Beta tab has below columns")
	public void iVerifyBetaTabPageElements(DataTable betatab) {
		boolean blnResult = reportingNextGen.verifyBetaTabPageElements(betatab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below columns on Beta Tab",
				"User should be able to see the columns on Beta Tab",
				"Successfully able to see the columns on Beta Tab",
				"Failed to see the columns on Beta Tab : " + Common.strError);
	}

	@And("^I verify Process button is present")
	public void iVerifyProcessButtonIsPresent() {
		boolean blnResult = reportingNextGen.verifyProcessButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Process button", "User should be able to see Process button",
				"Successfully able to see Process button", "Failed to see Process button : " + Common.strError);
	}

	@And("^I verify Reject button is present")
	public void iVerifyRejectButtonIsPresent() {
		boolean blnResult = reportingNextGen.verifyRejectButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Reject button", "User should be able to see Reject button",
				"Successfully able to see Reject button", "Failed to see Reject button : " + Common.strError);
	}

	@And("^I verify Remove button is present in FC")
	public void iVerifyRemoveButtonIsPresentFC() {
		boolean blnResult = reportingNextGen.verifyRemoveButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Remove button", "User should be able to see Remove button",
				"Successfully able to see Remove button", "Failed to see Remove button : " + Common.strError);
	}

	@And("^I select few accounts checkbox on Review and Approve Tab")
	public void iSelectFewAccountsCheckbox(DataTable acccheckbox) {
		boolean blnResult = reportingNextGen.selectFewAccountsCheckbox(acccheckbox);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select few account checkbox",
				"User should be able to Select few account checkbox",
				"Successfully able to Select few account checkbox",
				"Failed to see Select few account checkbox : " + Common.strError);
	}

	@Then("^I click on Export selected rows from the list")
	public void iClickOnExportSelectedRows() {
		boolean blnResult = reportingNextGen.clickOnExportSelectedRows();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on ExportSelectedRows from the list",
				"User should able to click ExportSelectedRows from the list",
				"Successfully able to click ExportSelectedRows from the list",
				"Failed to click ExportSelectedRows from the list :" + Common.strError);
	}

	@Then("^I verify PrevAccount button is present")
	public void iVerifyPrevAccountButtonIsPresent() {
		boolean blnResult = reportingNextGen.verifyPrevAccountButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of PrevAccount button", "User should be able to see PrevAccount button",
				"Successfully able to see PrevAccount button", "Failed to see PrevAccount button : " + Common.strError);
	}

	@Then("^I verify NextAccount button is present")
	public void iVerifyNextAccountButtonIsPresent() {
		boolean blnResult = reportingNextGen.verifyNextAccountButtonIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of NextAccount button", "User should be able to see NextAccount button",
				"Successfully able to see NextAccount button", "Failed to see NextAccount button : " + Common.strError);
	}

	@And("^I click on NextAccount button")
	public void iClickOnNextAccountButton() {
		boolean blnResult = reportingNextGen.clickOnNextAccountButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on NextAccount button",
				"User should able to click NextAccount button", "Successfully able to click NextAccount button",
				"Failed to click NextAccount button :" + Common.strError);
	}

	@And("^I click on PrevAccount button")
	public void iClickOnPrevAccountButton() {
		boolean blnResult = reportingNextGen.clickOnPrevAccountButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on PrevAccount button",
				"User should able to click PrevAccount button", "Successfully able to click PrevAccount button",
				"Failed to click PrevAccount button :" + Common.strError);
	}

	@And("^I check for Export button on Portfolio Accounting page$")
	public void iCheckExportButtonIsPresentOnPortfolioAccountingPage() {
		boolean blnResult = reportingNextGen.verifyExportButtonIsPresentOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Export button on PortfolioAccounting",
				"User should be able to see Export button on PortfolioAccounting",
				"Successfully able to see Export button on PortfolioAccounting",
				"Failed to see Export button on PortfolioAccounting: " + Common.strError);
	}

	@When("^I click on Export button on Portfolio Accounting$")
	public void iClickOnExportButtonOnPortfolioAccounting() {
		boolean blnResult = reportingNextGen.clickOnExportButtonOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click Export Button on PortfolioAccounting page",
				"User should able to click Export Button on PortfolioAccounting page",
				"Successfully able to click Export Button on PortfolioAccounting page",
				"Failed to click Export Button on PortfolioAccounting page :" + Common.strError);
	}

	@Then("^I click on Export All Data on Portfolio Accounting page$")
	public void iClickOnExportAllDataOnPortfolioAccountingPage() {
		boolean blnResult = reportingNextGen.clickOnExportAllDataOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click ExportAllData from list on PortfolioAccounting page",
				"User should able to click ExportAllData from list on PortfolioAccounting page",
				"Successfully able to click ExportAllData from list on PortfolioAccounting page",
				"Failed to click ExportAllData from list on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify file downloaded successfully for Beta tab")
	public void iVerifyFileDownloadedForBetaTab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForBetaTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for Beta Tab",
				"Successfully able to see file downloaded successfully for Beta Tab",
				"Failed to see file downloaded successfully for Beta Tab: " + Common.strError);
	}

	@Then("^I Click on Process Button on Fee Corrections Page")
	public void clickOnProcessButton() {
		boolean blnResult = reportingNextGen.clickOnProcessButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Process Button on Fee Corrections",
				"User should able to Click on Process Button on Fee Corrections",
				"Successfully able to Click on Process Button on Fee Corrections",
				"Failed to Click on Process Button on Fee Corrections :" + Common.strError);
	}

	@Then("^I Verify Process button is enabled")
	public void iVerifyProcessButtonIsEnabled() {
		boolean blnResult = reportingNextGen.iVerifyProcessButtonIsEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Process Button is enabled on Fee Corrections",
				"User should able to Verify Process Button is enabled on Fee Corrections",
				"Successfully able to Verify Process Button is enabled on Fee Corrections",
				"Failed to Verify Process Button is enabled on Fee Corrections :" + Common.strError);
	}

	@And("^I select some accounts checkbox on Beta Tab Portfolio Accounting page$")
	public void iSelectFewAccountsCheckboxOnBetaTab(DataTable acccheckboxbeta) {
		boolean blnResult = reportingNextGen.selectFewAccountsCheckboxOnBetaTab(acccheckboxbeta);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select few account checkbox on Beta tab",
				"User should be able to Select few account checkbox on Beta tab",
				"Successfully able to Select few account checkbox on Beta tab",
				"Failed to see Select few account checkbox on Beta tab: " + Common.strError);
	}

	@Then("^I click on Export selected rows on Portfolio Accounting page$")
	public void iClickOnExportSelectedRowsOnPortfolioAccountingPage() {
		boolean blnResult = reportingNextGen.clickOnExportSelectedRowsOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click ExportSelectedRows from list on PortfolioAccounting page",
				"User should able to click ExportSelectedRows from list on PortfolioAccounting page",
				"Successfully able to click ExportSelectedRows from list on PortfolioAccounting page",
				"Failed to click ExportSelectedRows from list on PortfolioAccounting page :" + Common.strError);
	}

	@When("^I click on FBVA Transactions tab$")
	public void iClickOnFBVATransactionsTab() {
		boolean blnResult = reportingNextGen.clickOnFBVATransactionsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on FBVATransactions Tab on PortfolioAccounting page",
				"User should able to click on FBVATransactions Tab on PortfolioAccounting page",
				"Successfully able to click on FBVATransactions Tab on PortfolioAccounting page",
				"Failed to click on FBVATransactions Tab on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify that the FBVA Transactions tab has below columns$")
	public void iVerifyPageElementsOnFBVATransactionsTab(DataTable fbvatranstab) {
		boolean blnResult = reportingNextGen.verifyFBVATransactionsTabPageElements(fbvatranstab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below columns on FBVA Transactions",
				"User should be able to see the columns on FBVA Transactions",
				"Successfully able to see the columns on FBVA Transactions",
				"Failed to see the columns on FBVA Transactions : " + Common.strError);
	}

	@And("^I verify file downloaded successfully for FBVATransactions tab$")
	public void iVerifyFileDownloadedForFBVATransactionsTab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForFBVATransactionsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for FBVATransactions Tab",
				"Successfully able to see file downloaded successfully for FBVATransactions Tab",
				"Failed to see file downloaded successfully for FBVATransactions Tab: " + Common.strError);
	}

	@And("^I select some accounts checkbox on FBVATransactions Tab Portfolio Accounting page$")
	public void iSelectFewAccountsCheckboxOnFBVATransactionsTab(DataTable acccheckboxfbvatrans) {
		boolean blnResult = reportingNextGen.selectFewAccountsCheckboxOnFBVATransactionsTab(acccheckboxfbvatrans);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select few account checkbox on FBVATransactions tab",
				"User should be able to Select few account checkbox on FBVATransactions tab",
				"Successfully able to Select few account checkbox on FBVATransactions tab",
				"Failed to see Select few account checkbox on FBVATransactions tab: " + Common.strError);
	}

	@When("^I click on FBVA Positions tab$")
	public void iClickOnFBVAPositionsTab() {
		boolean blnResult = reportingNextGen.clickOnFBVAPositionsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on FBVAPositions Tab on PortfolioAccounting page",
				"User should able to click on FBVAPositions Tab on PortfolioAccounting page",
				"Successfully able to click on FBVAPositions Tab on PortfolioAccounting page",
				"Failed to click on FBVAPositions Tab on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify that the FBVA Positions tab has below columns$")
	public void iVerifyPageElementsOnFBVAPositionsTab(DataTable fbvapostab) {
		boolean blnResult = reportingNextGen.verifyFBVATransactionsTabPageElements(fbvapostab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below columns on FBVA Positions",
				"User should be able to see the columns on FBVA Positions",
				"Successfully able to see the columns on FBVA Positions",
				"Failed to see the columns on FBVA Positions : " + Common.strError);
	}

	@And("^I verify file downloaded successfully for FBVAPositions tab$")
	public void iVerifyFileDownloadedForFBVAPositionsTab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForFBVAPositionsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for FBVAPositions Tab",
				"Successfully able to see file downloaded successfully for FBVAPositions Tab",
				"Failed to see file downloaded successfully for FBVAPositions Tab: " + Common.strError);
	}

	@And("^I select some accounts checkbox on FBVAPositions Tab Portfolio Accounting page$")
	public void iSelectFewAccountsCheckboxOnFBVAPositionsTab(DataTable acccheckboxfbvapos) {
		boolean blnResult = reportingNextGen.selectFewAccountsCheckboxOnFBVAPositionsTab(acccheckboxfbvapos);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select few account checkbox on FBVAPositions tab",
				"User should be able to Select few account checkbox on FBVAPositions tab",
				"Successfully able to Select few account checkbox on FBVAPositions tab",
				"Failed to see Select few account checkbox on FBVAPositions tab: " + Common.strError);
	}

	@When("^I click on Positions tab on Portfolio Accounting page$")
	public void iClickOnThePositionsTabOnPortfolioAccounting() {
		boolean blnResult = reportingNextGen.userClicksOnThePositionsTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Positions Tab on PortfolioAccounting page",
				"User should able to click on Positions Tab on PortfolioAccounting page",
				"Successfully able to click on Positions Tab on PortfolioAccounting page",
				"Failed to click on Positions Tab on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify that Positions tab has below columns present$")
	public void iVerifyPageElementsOnPositionsTab(DataTable postab) {
		boolean blnResult = reportingNextGen.verifyPositionsTabPageElements(postab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below columns on Positions Tab",
				"User should be able to see the columns on Positions Tab",
				"Successfully able to see the columns on Positions Tab",
				"Failed to see the columns on Positions Tab: " + Common.strError);
	}

	@And("^I verify file downloaded successfully for Positions tab on PortfolioAccounting page$")
	public void iVerifyFileDownloadedForPositionsTab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForPositionsTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for Positions Tab",
				"Successfully able to see file downloaded successfully for Positions Tab",
				"Failed to see file downloaded successfully for Positions Tab: " + Common.strError);
	}

	@And("^I select some accounts checkbox on Positions Tab Portfolio Accounting page$")
	public void iSelectFewAccountsCheckboxOnPositionsTab(DataTable acccheckboxpos) {
		boolean blnResult = reportingNextGen.selectFewAccountsCheckboxOnPositionsTab(acccheckboxpos);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select few account checkbox on Positions tab",
				"User should be able to Select few account checkbox on Positions tab",
				"Successfully able to Select few account checkbox on Positions tab",
				"Failed to see Select few account checkbox on Positions tab: " + Common.strError);
	}

	@When("^I click on Direct Business FBVA tab$")
	public void clickOnDirectBusinessFBVATab() {
		boolean blnResult = reportingNextGen.clickOnDirectBusinessFBVATab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Direct Business FBVA Tab on PortfolioAccounting page",
				"User should able to click on Direct Business FBVA Tab on PortfolioAccounting page",
				"Successfully able to click on Direct Business FBVA Tab on PortfolioAccounting page",
				"Failed to click on Direct Business FBVA Tab on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify file downloaded successfully for Direct Business FBVA tab on PortfolioAccounting page$")
	public void iVerifyFileDownloadedForDirectBusinessFBVATab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForPositionsTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for Direct Business FBVA Tab",
				"Successfully able to see file downloaded successfully for Direct Business FBVA Tab",
				"Failed to see file downloaded successfully for Direct Business FBVA Tab: " + Common.strError);
	}

	@And("^I verify that Direct Business FBVA tab has below columns present$")
	public void iVerifyPageElementsOnDirectBusinessFBVATab(DataTable postab) {
		boolean blnResult = reportingNextGen.iVerifyPageElementsOnDirectBusinessFBVATab(postab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below columns on Direct Business FBVA Tab",
				"User should be able to see the columns on Direct Business FBVA Tab",
				"Successfully able to see the columns on Direct Business FBVA Tab",
				"Failed to see the columns on Direct Business FBVA Tab: " + Common.strError);
	}

	@When("^I click on Transactions tab on Portfolio Accounting Page$")
	public void iClickOnTransactionsTabOnPortfolioAccounting() {
		boolean blnResult = reportingNextGen.userClicksOnTransactionsTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Transactions Tab on PortfolioAccounting page",
				"User should able to click on Transactions Tab on PortfolioAccounting page",
				"Successfully able to click on Transactions Tab on PortfolioAccounting page",
				"Failed to click on Transactions Tab on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify that Transactions tab has below columns present$")
	public void iVerifyPageElementsOnTransactionsTab(DataTable trantab) {
		boolean blnResult = reportingNextGen.iVerifyPageElementsOnTransactionsTab(trantab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below columns on Transactions Tab",
				"User should be able to see the columns on Transactions Tab",
				"Successfully able to see the columns on Transactions Tab",
				"Failed to see the columns on Transactions Tab: " + Common.strError);
	}

	@And("^I verify file downloaded successfully for Transactions tab on PortfolioAccounting page$")
	public void iVerifyFileDownloadedForTransactionsTab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForTransactionsTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for Transactions Tab",
				"Successfully able to see file downloaded successfully for Transactions Tab",
				"Failed to see file downloaded successfully for Transactions Tab: " + Common.strError);
	}

	@When("^I click on Audits tab on Portfolio Accounting Page$")
	public void iClickOnAuditsTabOnPortfolioAccounting() {
		boolean blnResult = reportingNextGen.userClicksOnAuditsTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Audits Tab on PortfolioAccounting page",
				"User should able to click on Audits Tab on PortfolioAccounting page",
				"Successfully able to click on Audits Tab on PortfolioAccounting page",
				"Failed to click on Audits Tab on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify that Audits tab has below columns present$")
	public void iVerifyPageElementsOnAuditsTab(DataTable auditTab) {
		boolean blnResult = reportingNextGen.iVerifyPageElementsOnAuditsTab(auditTab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below columns on Audits Tab",
				"User should be able to see the columns on Audits Tab",
				"Successfully able to see the columns on Audits Tab",
				"Failed to see the columns on Audits Tab: " + Common.strError);
	}

	@And("^I verify file downloaded successfully for Audits tab on PortfolioAccounting page$")
	public void iVerifyFileDownloadedForAuditsTab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForAuditsTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for Audits Tab",
				"Successfully able to see file downloaded successfully for Audits Tab",
				"Failed to see file downloaded successfully for Audits Tab: " + Common.strError);
	}

	@When("^I click on Performance tab on Portfolio Accounting Page$")
	public void iClickOnPerformanceTabOnPortfolioAccounting() {
		boolean blnResult = reportingNextGen.userClicksOnPerformanceTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Performance Tab on PortfolioAccounting page",
				"User should able to click on Performance Tab on PortfolioAccounting page",
				"Successfully able to click on Performance Tab on PortfolioAccounting page",
				"Failed to click on Performance Tab on PortfolioAccounting page :" + Common.strError);
	}

	@And("^I verify that Performance tab has below columns present$")
	public void iVerifyPageElementsOnPerformanceTab(DataTable perfTab) {
		boolean blnResult = reportingNextGen.iVerifyPageElementsOnPerformanceTab(perfTab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below columns on Performance Tab",
				"User should be able to see the columns on Performance Tab",
				"Successfully able to see the columns on Performance Tab",
				"Failed to see the columns on Performance Tab: " + Common.strError);
	}

	@And("^I verify file downloaded successfully for Performance tab on PortfolioAccounting page$")
	public void iVerifyFileDownloadedForPerformanceTab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForPerformanceTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for Performance Tab",
				"Successfully able to see file downloaded successfully for Performance Tab",
				"Failed to see file downloaded successfully for Performance Tab: " + Common.strError);
	}

	@And("^I verify file downloaded successfully for Sleeves tab on PortfolioAccounting page$")
	public void iVerifyFileDownloadedForSleevesTab() {
		boolean blnResult = reportingNextGen.verifyFileDownloadedForPerformanceTabOnPortfolioAccounting();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully for Sleeves Tab",
				"Successfully able to see file downloaded successfully for Sleeves Tab",
				"Failed to see file downloaded successfully for Sleeves Tab: " + Common.strError);
	}
	
	@And("^I click on Account Details tab on Portfolio Accounting Page$")
	public void iClickOnAccountDetailsTab() {
		boolean blnResult = reportingNextGen.clickOnAccountDetailsTabOnPortfolioAccountingPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on AccountDetails Tab on PortfolioAccounting page",
				"User should able to click on AccountDetails Tab on PortfolioAccounting page",
				"Successfully able to click on AccountDetails Tab on PortfolioAccounting page",
				"Failed to click on AccountDetails Tab on PortfolioAccounting page :" + Common.strError);
	}
	
	@And("^I verify InceptionDate$")
	public void iVerifyInceptionDate() {
		boolean blnResult = reportingNextGen.isInceptionDateDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Inception Date is given",
				"Inception Date should be given", "Inception Date is given", "Inception Date is not given"  + Common.strError);
	}
	
	@Then("^I input a new InceptionDate$")
	public void iInputANewInceptionDate() {
		boolean blnResult = reportingNextGen.enterInceptionDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if new Inception Date is Entered",
				"New Inception Date should be Entered", "New Inception Date is Entered", "New Inception Date is not Entered" + Common.strError );
	}	
	
	@And("^I click on cancel icon$")
	public void iClickOnCancelIcon() {
		boolean blnResult = reportingNextGen.isInceptionDateIconClicked();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Inception Date is cancelled ",
				"Inception Date should be cancelled", "Inception Date is cancelled", "Inception Date is not cancelled"  + Common.strError);
	}	

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
