package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice;

import static io.restassured.RestAssured.given;

import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;

import CWWebServicesCommon.CWSession;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class LPLAPICommon extends LPLCoreDriver {

	static Map<String, String> sessionCookiesCWWithoutBrowser;

	static final String XSRF_TOKEN = "XSRF-TOKEN=";
	static final String EMPTY_STRING = "";
	static HttpClientContext context = HttpClientContext.create();
	static HttpResponse response = null;
	static HttpClient client = HttpClientBuilder.create().build();

	/**
	 * This method is used to return the response string(json/html) for given API
	 * input details(restAPIInfo object)
	 *
	 * @param methodType
	 * @param methodName
	 * @param restAPIInfo - object contains all required inputs for API call
	 * @return String
	 * @author pmanohar
	 * @since 11-13-2019
	 */
	public static String getRestResponse(String methodType, String methodName, LPLRestAPIInfo restAPIInfo) {
		boolean ntlmAuthentication = getNtlmAuthenticationValue(restAPIInfo);
		if (ntlmAuthentication)
			return getResponse(methodType, getCredentialsProvider(restAPIInfo), restAPIInfo);
		try {
			RestAssured.baseURI = restAPIInfo.getEndpoint();
			// restAPIInfo.getEndpoint();
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Setting up API endpoint",
					"API endpoint should be setup", "Endpoint is set to " + RestAssured.baseURI,
					"Failed to setup the endpoint");
		}
		Response response = null;
		switch (methodType.toUpperCase()) {
		case "GET":
			response = getResponseForGetMethod(restAPIInfo);
			break;
		case "POST":
			response = getResponseForPostMethod(restAPIInfo);
			break;
		case "PUT":
			response = getResponseForPutMethod(restAPIInfo);
			break;
		case "DELETE":
			response = getResponseForDeleteMethod(restAPIInfo);
			break;
		default:
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Checking the method type",
					"API method type should be valid method like GET or POST", "Valid method type is passed",
					"Invalid method type is passed[" + methodType + "]");
		}
		if (response == null)
			// Reporter for response object check
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Validate if REST method call return a response", "Response object should not be null",
					"Response object is not null", "Response object is null.");
		restAPIInfo.setResponseDetails(response);
		String htmlRestDetails = LPLAPIReport.generateHTMLReport(restAPIInfo);
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"<a href='" + htmlRestDetails + "'>View " + methodName + " API Request and Response Details</a>", "",
				"", "");
		return getResponseJsonString(response);
	}

	/**
	 * This method is used to return true/false depending on whether API call
	 * require NTML authentication
	 *
	 * @param restAPIInfo
	 * @return boolean
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static boolean getNtlmAuthenticationValue(LPLRestAPIInfo restAPIInfo) {
		return restAPIInfo.getNtlmAuthentication();
	}

	/**
	 * This method is used to return the Response object for GET call using given
	 * API input details(restAPIInfo object)
	 *
	 * @param restAPIInfo - object contains all required inputs for API call
	 * @return Response
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static Response getResponseForGetMethod(LPLRestAPIInfo restAPIInfo) {
		Map<String, String> headers = restAPIInfo.getRequestHeaders();
		Map<String, String> queryParams = restAPIInfo.getQueryParams();

		if (!headers.isEmpty() && !queryParams.isEmpty())
			return given().relaxedHTTPSValidation().headers(headers).queryParams(queryParams).get();
		else if (!headers.isEmpty() && queryParams.isEmpty())
			return given().relaxedHTTPSValidation().headers(headers).get();
		else if (headers.isEmpty() && !queryParams.isEmpty())
			return given().relaxedHTTPSValidation().queryParams(queryParams).get();
		else if (headers.isEmpty() && queryParams.isEmpty())
			return given().relaxedHTTPSValidation().queryParams(queryParams).get();
		else
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Calling GET Rest API method",
					"GET method should be called successfully", "GET method is called successfully",
					"Failed to call the GET method");
		return null;
	}

	/**
	 * This method is used to return the Response object for Post call using given
	 * API input details(restAPIInfo object)
	 *
	 * @param restAPIInfo - object contains all required inputs for API call
	 * @return Response
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static Response getResponseForPostMethod(LPLRestAPIInfo restAPIInfo) {
		try {
			RequestSpecification requestSpecification = given().relaxedHTTPSValidation();
			addHeaders(requestSpecification, restAPIInfo);
			addQueryParams(requestSpecification, restAPIInfo);
			addBody(requestSpecification, restAPIInfo);
			return requestSpecification.post();
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Calling POST Rest API method",
					"POST method should be called successfully", "POST method is called successfully",
					"Failed to call the POST method. Error: " + e.getMessage());
		}
		return null;
	}

	/**
	 * This method is used to return the Response object for Put call using given
	 * API input details(restAPIInfo object)
	 *
	 * @param restAPIInfo - object contains all required inputs for API call
	 * @return Response
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static Response getResponseForPutMethod(LPLRestAPIInfo restAPIInfo) {
		try {
			RequestSpecification requestSpecification = given().relaxedHTTPSValidation();
			addHeaders(requestSpecification, restAPIInfo);
			addQueryParams(requestSpecification, restAPIInfo);
			addBody(requestSpecification, restAPIInfo);
			return requestSpecification.put();
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Calling POST Rest API method",
					"POST method should be called successfully", "POST method is called successfully",
					"Failed to call the POST method. Error: " + e.getMessage());
		}
		return null;
	}

	/**
	 * This method is used to return the Response object for Delete call using given
	 * API input details(restAPIInfo object)
	 *
	 * @param restAPIInfo - object contains all required inputs for API call
	 * @return Response
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static Response getResponseForDeleteMethod(LPLRestAPIInfo restAPIInfo) {
		try {
			RequestSpecification requestSpecification = given().relaxedHTTPSValidation();
			addHeaders(requestSpecification, restAPIInfo);
			addQueryParams(requestSpecification, restAPIInfo);
			return requestSpecification.delete();
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Calling POST Rest API method",
					"POST method should be called successfully", "POST method is called successfully",
					"Failed to call the POST method. Error: " + e.getMessage());
		}
		return null;
	}

	public static void addHeaders(RequestSpecification requestSpecification, LPLRestAPIInfo restAPIInfo) {
		Map<String, String> headers = restAPIInfo.getRequestHeaders();
		if (!headers.isEmpty())
			requestSpecification.headers(headers);
	}

	public static void addQueryParams(RequestSpecification requestSpecification, LPLRestAPIInfo restAPIInfo) {
		Map<String, String> queryParams = restAPIInfo.getQueryParams();
		if (!queryParams.isEmpty())
			requestSpecification.queryParams(queryParams);
	}

	public static void addBody(RequestSpecification requestSpecification, LPLRestAPIInfo restAPIInfo) {
		if (restAPIInfo.getPayloadType().equalsIgnoreCase("json"))
			requestSpecification.contentType("application/json").body(restAPIInfo.getRequestPayload());
		else if (restAPIInfo.getPayloadType().equalsIgnoreCase("x-www-form-urlencoded"))
			requestSpecification.formParams(restAPIInfo.getRequestFormParameters());
	}

	/**
	 * This method is used to retrieve the transaction cookie without launching the
	 * browser.
	 *
	 * @param url
	 * @param userName
	 * @param password
	 * @return String
	 * @author pmanohar
	 * @since 02-11-2020
	 */
	public static String getCWSessionCookiesWithoutBrowser(String url, String userName, String password) {
		boolean blnResult = CWSession.createCWSession(url, userName, password);
		if (!blnResult)
			// Failed to create CW session
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, " User creates the CW session. ",
					" User should be able to create CW session. ", " User created the CW session. ",
					" User unable to create CW session. ");

		try {
			sessionCookiesCWWithoutBrowser = CWSession.getCWSessionCookies();

			String xsrftoken1 = sessionCookiesCWWithoutBrowser.get("XSRF-TOKEN");
			String auth = sessionCookiesCWWithoutBrowser.get("Auth");
			String zCookie = sessionCookiesCWWithoutBrowser.get("z");
			if (xsrftoken1 == null || auth == null || zCookie == null)
				LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE,
						"User retrieves the auth/XSRF-TOKEN/z Cookies",
						" User should be able to rerieve auth/XSRF-TOKEN/z Cookies. ",
						"User retrieved the auth/XSRF-TOKEN/z Cookies. ",
						" User unable to retrieve auth/XSRF-TOKEN/z Cookies. ");
			return "auth=" + auth + "; XSRF-TOKEN=" + xsrftoken1 + "; z=" + zCookie + ";";
		} catch (NullPointerException e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "User retrieves the CW Session Cookies. ",
					"User should be able to get CW Session Cookies. ", "User able to get CW Session Cookies. ",
					"User able to get CW Session Cookies. ");
		}
		return "";
	}

	/**
	 * This method is used to get the XSRF Token value used as one of the header
	 * value in services called from ClientWorks application
	 *
	 * @return String
	 * @author pmanohar
	 * @since 11-13-2019
	 */
	public static String getXSRFToken(String transactionCookie) {
		boolean blnResult = false;

		// splits transaction cookie in to parts array
		String[] parts = transactionCookie.replace(";", EMPTY_STRING).split(" ");

		// check if the parts array has 3 elements
		blnResult = (parts.length == 3);
		if (!blnResult)
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Retrieving the XSRF token",
					"XSRF token should successfully retrieved", "XSRF token should successfully retrieved",
					"Transaction cookie does not all the components[Auth, XSRF and Z values]", false);
		log.info(parts[1].replace(XSRF_TOKEN, EMPTY_STRING));
		return parts[1].replace(XSRF_TOKEN, EMPTY_STRING);
	}

	/**
	 * This method is used to add query parameters as key-value pair to the given
	 * map
	 *
	 * @param queryParams
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static void addQueryParamFromFarm(Map<String, String> queryParams) {
		// Setting up query params
		Set<String> testDataKeys = testData.keySet();
		for (String testDataKey : testDataKeys) {
			if (testDataKey.startsWith("qp_")) {// query params are stored as test data in FARM with prefix 'qp'
				String queryParamKey = testDataKey.substring(3);
				queryParams.put(queryParamKey, testData.get(testDataKey));
			}
		}
	}

	/**
	 * This method is used to add query parameters as key-value pair to the given
	 * map
	 *
	 * @param queryParams
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static void addFormParameters(Map<String, String> queryParams) {
		// Setting up query params
		Set<String> testDataKeys = testData.keySet();
		for (String testDataKey : testDataKeys) {
			if (testDataKey.startsWith("qp_")) {// query params are stored as test data in FARM with prefix 'qp'
				String queryParamKey = testDataKey.substring(3);
				queryParams.put(queryParamKey, testData.get(testDataKey));
			}
		}
	}

	/**
	 * This method is used to add request header parameters as key-value pair to the
	 * given map
	 *
	 * @param headerParams
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static void addHeaderParametersFromFarm(Map<String, String> headerParams) {
		// Adding header parameters from FARM
		Set<String> testDataKeys = testData.keySet();
		for (String testDataKey : testDataKeys) {
			if (testDataKey.startsWith("hp_")) {// headers are stored as test data in FARM with prefix 'hp'
				String headerParamKey = testDataKey.substring(3);
				headerParams.put(headerParamKey, testData.get(testDataKey));
			}
		}
	}

	/**
	 * This method is used to check if NTML authentication is required for API call
	 * and return true/false
	 *
	 * @return boolean
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static boolean isNtlmAuthenticationRequired() {
		Set<String> testDataKeys = testData.keySet();
		if (testDataKeys.contains("ntlmAuthentication"))
			return testData.get("ntlmAuthentication").equalsIgnoreCase("true");
		return false;
	}

	public static boolean isClientWorksHeaderRequired() {
		Set<String> testDataKeys = testData.keySet();
		if (testDataKeys.contains("isClientWorksHeaderRequired"))
			return testData.get("isClientWorksHeaderRequired").equalsIgnoreCase("true");
		return false;
	}

	/**
	 * This method is used to add header parameters(Cookie and X-XSRF-TOKEN) as
	 * key-value pair to the given map
	 *
	 * @param headers
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static void addClientWorksHeaders(Map<String, String> headers) {
		String transactionCookie = getCWSessionCookiesWithoutBrowser(ocfg.getURL(), loginCredentials.get("Username"),
				loginCredentials.get("Password"));
		if (transactionCookie == null)
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the transaction Cookie for Clientworks session",
					"Transaction Cookie for Clientworks session should be generated",
					"Transaction Cookie for Clientworks session is generated",
					"Unable to generate the Transaction cookie for Clientworks session", false);
		headers.put("Cookie", transactionCookie);
		headers.put("X-XSRF-TOKEN", getXSRFToken(transactionCookie));
	}

	/**
	 * This method is used to return the endpoint value(testdata) from FARM
	 *
	 * @return String
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static String getEndPointFromFarm() {
		return getDataFromFarm("endpoint");
	}

	/**
	 * This method is used to return the request body from FARM
	 *
	 * @return String
	 * @author pmanohar
	 * @since 9.17.2019
	 */

	public static String getRequestBodyFromFarm() {
		Set<String> keys = testData.keySet();
		if (keys.contains("requestBodyFromFile"))
			return LPLJsonUtility.readTextFromFile(getDataFromFarm("requestBodyFromFile"));
		else
			return getDataFromFarm("requestBody");
	}

	public static String getPayloadType() {
		Set<String> keys = testData.keySet();
		if (keys.contains("requestBodyFromFile") || keys.contains("requestBody"))
			return "json";
		else if (doesSetContainsValueStartingWith(keys, "fp_"))
			return "x-www-form-urlencoded";
		return "";
	}

	public static boolean doesSetContainsValueStartingWith(Set<String> keys, String value) {
		for (String key : keys) {
			if (key.startsWith(value))
				return true;
		}
		return false;

	}

	/**
	 * This method is used to return the response json string from given Response
	 * object.
	 *
	 * @return String
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static String getResponseJsonString(Response response) {
		return response.getBody().asString();
	}

	/**
	 * This method is used to validate the response status code.
	 *
	 * @param methodName
	 * @param actualStatusCode
	 * @param expectedStatusCode
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static void validateStatusCode(String methodName, int actualStatusCode, int expectedStatusCode) {
		// validating the response status code
		boolean blnResult = (actualStatusCode == expectedStatusCode);

		// Reporter for response status code
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if " + methodName + " method call returns a status code of " + expectedStatusCode,
				"Status code " + expectedStatusCode + " should be returned",
				"Status code " + expectedStatusCode + " is returned", "Failed to return status code "
						+ expectedStatusCode + ". Expected: " + expectedStatusCode + " Actual: " + actualStatusCode);
	}

	/**
	 * This method is used to validate the response status line.
	 *
	 * @param methodName
	 * @param actualStatusLine
	 * @param expectedStatusLine
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static void validateStatusLine(String methodName, String actualStatusLine, String expectedStatusLine) {
		// validating the response status code
		boolean blnResult = actualStatusLine.contains(expectedStatusLine);

		// Reporter for response status line
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if " + methodName + " method call returns a status line of HTTP/1.1 " + expectedStatusLine,
				"Status line HTTP/1.1 " + expectedStatusLine + " should be returned",
				"Status line " + actualStatusLine + " is returned",
				"Failed to return correct status line. Expected: HTTP/1.1 " + expectedStatusLine + " Actual: "
						+ actualStatusLine);
	}

	/**
	 * This method is used to return LPLRestAPIInfo object containing all the
	 * information required for API call
	 *
	 * @param methodType
	 * @return LPLRestAPIInfo
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static LPLRestAPIInfo readAPIDetailsFromFarm(String methodType) {
		boolean ntlmAuthentication = isNtlmAuthenticationRequired();
		String payloadType = "";
		String requestPayload = "";
		Map<String, String> formParameters = new HashMap<>();
		// Setting endpoint
		String endpoint = getEndPointFromFarm();

		// Setting headers
		Map<String, String> headers = new HashMap<>();
		LPLAPICommon.addHeaderParametersFromFarm(headers);// Store static headers in FARM

		// Setting query Parameters
		Map<String, String> queryParams = new HashMap<>();
		LPLAPICommon.addQueryParamFromFarm(queryParams);
		if (isClientWorksHeaderRequired())
			addClientWorksHeaders(headers);

		// Setting request body
		if (methodType.equalsIgnoreCase("POST") || methodType.equalsIgnoreCase("PUT")) {
			payloadType = getPayloadType();
			if (payloadType.equalsIgnoreCase("json"))
				requestPayload = LPLAPICommon.getRequestBodyFromFarm();
			else if (payloadType.equalsIgnoreCase("x-www-form-urlencoded"))
				formParameters = getFormParameters();
		}

		// Setting ntml authentication details
		if (ntlmAuthentication) {
			String username = getDataFromFarm("ntlmUsername");
			String password = getNtlmPassword();
			return getRestAPIInfo(methodType, endpoint, headers, queryParams, payloadType, requestPayload, true,
					username, password, formParameters);
		} else
			return getRestAPIInfo(methodType, endpoint, headers, queryParams, payloadType, requestPayload,
					formParameters);
	}

	public static Map<String, String> getFormParameters() {
		Map<String, String> formParameters = new HashMap<>();
		// Setting up form params
		Set<String> testDataKeys = testData.keySet();
		for (String testDataKey : testDataKeys) {
			if (testDataKey.startsWith("fp_")) {// query params are stored as test data in FARM with prefix 'qp'
				String formParamKey = testDataKey.substring(3);
				formParameters.put(formParamKey, testData.get(testDataKey));
			}
		}
		return formParameters;
	}

	/**
	 * This method is used to return LPLRestAPIInfo object containing all the
	 * information required for API call
	 *
	 * @param methodType
	 * @param endpoint
	 * @param headers
	 * @param queryParams
	 * @param requestPayload
	 * @return LPLRestAPIInfo
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static LPLRestAPIInfo getRestAPIInfo(String methodType, String endpoint, Map<String, String> headers,
			Map<String, String> queryParams, String payloadType, String requestPayload,
			Map<String, String> formParameters) {
		if (methodType.equalsIgnoreCase("GET") || methodType.equalsIgnoreCase("DELETE"))
			return new LPLRestAPIInfo(methodType, endpoint, headers, queryParams);
		else if (methodType.equalsIgnoreCase("POST") || methodType.equalsIgnoreCase("PUT"))
			if (!formParameters.isEmpty())
				return new LPLRestAPIInfo(methodType, endpoint, headers, payloadType, formParameters);
			else
				return new LPLRestAPIInfo(methodType, endpoint, headers, queryParams, payloadType, requestPayload);
		return null;
	}

	/**
	 * This method is used to return LPLRestAPIInfo object containing all the
	 * information required for API call
	 *
	 * @param methodType
	 * @param endpoint
	 * @param headers
	 * @param queryParams
	 * @param requestPayload
	 * @param ntlmFlag
	 * @param ntlmUsername
	 * @param ntlmPassword
	 * @return LPLRestAPIInfo
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static LPLRestAPIInfo getRestAPIInfo(String methodType, String endpoint, Map<String, String> headers,
			Map<String, String> queryParams, String payloadType, String requestPayload, boolean ntlmFlag,
			String ntlmUsername, String ntlmPassword, Map<String, String> formParameters) {
		if (methodType.equalsIgnoreCase("GET") || (methodType.equalsIgnoreCase("DELETE")))
			return new LPLRestAPIInfo(methodType, endpoint, headers, queryParams, ntlmFlag, ntlmUsername, ntlmPassword);
		else if (methodType.equalsIgnoreCase("POST") || methodType.equalsIgnoreCase("PUT"))
			if (!formParameters.isEmpty())
				return new LPLRestAPIInfo(methodType, endpoint, headers, queryParams, payloadType, ntlmFlag,
						ntlmUsername, ntlmPassword, formParameters);
			else
				return new LPLRestAPIInfo(methodType, endpoint, headers, queryParams, payloadType, requestPayload,
						ntlmFlag, ntlmUsername, ntlmPassword);
		return null;
	}

	/**
	 * This method is used to return URI object for given endpoint(url) and other
	 * API details(restAPIInfo)
	 *
	 * @param url
	 * @param restAPIInfo
	 * @return URI
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static URI getUri(String url, LPLRestAPIInfo restAPIInfo) {
		URI uri = null;
		String[] parts = url.split("/");
		String schema = parts[0].replace(":", "");// removing colon from http: or https: string
		String host = parts[2];
		String path = "/";
		for (int i = 3; i < parts.length; i++) {
			if (parts.length - i != 1)
				path += parts[i] + "/";
			else
				path += parts[i];
		}
		try {
			URIBuilder uriBuilder = new URIBuilder().setScheme(schema).setHost(host).setPath(path);
			uri = addParameter(uriBuilder, restAPIInfo.getQueryParams()).build();
		} catch (URISyntaxException e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Creating an URI builder",
					"URI should be built successfully", "URI is built successfully",
					"Failed to build the URI. Error message" + e.getMessage(), false);
		}
		return uri;
	}

	/**
	 * This method is used to add query parameters to URIBuilder object
	 *
	 * @param uriBuilder
	 * @param queryParams
	 * @return URIBuilder
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static URIBuilder addParameter(URIBuilder uriBuilder, Map<String, String> queryParams) {
		Set<Map.Entry<String, String>> queryParamsEntries = queryParams.entrySet();
		for (Map.Entry<String, String> entry : queryParamsEntries) {
			uriBuilder.setParameter(entry.getKey(), entry.getValue());
		}
		return uriBuilder;
	}

	/**
	 * This method is used to return response string(json/html) for given API
	 * details
	 *
	 * @param methodType
	 * @param credsProvider
	 * @param restAPIInfo
	 * @return String
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static String getResponse(String methodType, CredentialsProvider credsProvider, LPLRestAPIInfo restAPIInfo) {
		context.setCredentialsProvider(credsProvider);
		StopWatch watch = new StopWatch();
		watch.start();
		try {
			switch (methodType.toUpperCase()) {
			case "GET":
				HttpUriRequest request = new HttpGet(getUri(restAPIInfo.getEndpoint(), restAPIInfo));
				addHeaders(request, restAPIInfo.getRequestHeaders());
				response = client.execute(request, context);
				break;
			case "POST":
				HttpPost postRequest = new HttpPost(getUri(restAPIInfo.getEndpoint(), restAPIInfo));
				StringEntity params = new StringEntity(restAPIInfo.getRequestPayload());
				postRequest.setEntity(params);
				response = client.execute(postRequest, context);
				break;
			case "PUT":
				HttpPut putRequest = new HttpPut(getUri(restAPIInfo.getEndpoint(), restAPIInfo));
				StringEntity putParams = new StringEntity(restAPIInfo.getRequestPayload());
				putRequest.setEntity(putParams);
				response = client.execute(putRequest, context);
				break;
			case "DELETE":
				HttpDelete deleteRequest = new HttpDelete(getUri(restAPIInfo.getEndpoint(), restAPIInfo));
				addHeaders(deleteRequest, restAPIInfo.getRequestHeaders());
				response = client.execute(deleteRequest, context);
				break;
			default:
				break;
			}
			watch.stop();
			restAPIInfo.setResponseDetails(response, watch.getTime(TimeUnit.MILLISECONDS));
			String htmlRestDetails = LPLAPIReport.generateHTMLReport(restAPIInfo);
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
					"<a href='" + htmlRestDetails + "'>View " + methodType + " API Request and Response Details</a>",
					"", "", "");
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Retrieve the response from the API",
					"API Response should be successfully retrieved", "API Response is successfully retrieved",
					"Exception occurred while retrieving the response. Error message: " + e.getMessage(), false);
		}
		return restAPIInfo.getResponseData();
	}

	/**
	 * This method is used to add header parameters for given HttpUriRequest
	 *
	 * @param request
	 * @param headerParams
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static void addHeaders(HttpUriRequest request, Map<String, String> headerParams) {
		Set<Map.Entry<String, String>> headerParameterEntries = headerParams.entrySet();
		for (Map.Entry<String, String> entry : headerParameterEntries) {
			request.addHeader(entry.getKey(), entry.getValue());
		}
	}

	/**
	 * This method is used to return CredentialsProvider(NTML authentication
	 * details) object using the given API details(restAPIInfo object)
	 *
	 * @param restAPIInfo
	 * @return CredentialsProvider
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static CredentialsProvider getCredentialsProvider(LPLRestAPIInfo restAPIInfo) {
		CredentialsProvider credsProvider = null;
		try {
			credsProvider = new BasicCredentialsProvider();
			credsProvider.setCredentials(AuthScope.ANY, new NTCredentials(restAPIInfo.getNtlmUserName(),
					restAPIInfo.getNtlmPassword(), getComputerName(), "corp"));
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE,
					"Retrieving the username and password from FARM",
					"Username and password should be successfully retrieved", "Username and password is retrieved",
					"Username and password could not be retrieved. Error message: " + e.getMessage(), false);
		}
		return credsProvider;
	}

	/**
	 * This method is used to return the computer name
	 *
	 * @return String
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static String getComputerName() {
		String hostname = "";
		try {
			InetAddress addr = java.net.InetAddress.getLocalHost();
			hostname = addr.getHostName();
		} catch (UnknownHostException e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Check the computer name",
					"Computer name should be retrieved", "Computer name is retrieved",
					"Exception occurred when trying to retrieve the computer name. Error message: " + e.getMessage(),
					false);
		}
		return hostname;
	}

	/**
	 * This method is used to retrieve the test data from FARM for given key
	 *
	 * @param key - test data key
	 * @return String
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static String getDataFromFarm(String key) {
		String value = "";
		try {
			value = testData.get(key);
		} catch (NullPointerException e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieve the test data from FARM",
					"Test data should be successfully from FARM for key[" + key + "]",
					"Test data is successfully retrieved", "Failed to retrieve the value from FARM for key[" + key
							+ "]. Please check in FARM if the test data is added for this key");
		}
		return value;
	}

	/**
	 * This method is used to retrieve the NTLM password from FARM
	 *
	 * @return String
	 * @author pmanohar
	 * @since 9.17.2019
	 */
	public static String getNtlmPassword() {
		boolean encrypted = false;
		Set<String> keys = testData.keySet();
		if (keys.contains("ntlmPasswordEncrypted"))
			encrypted = testData.get("ntlmPasswordEncrypted").equalsIgnoreCase("true");
		if (encrypted)
			return new String(Base64.getDecoder().decode(testData.get("ntlmPassword")));
		else
			return testData.get("ntlmPassword");
	}

}
