package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.lpl.qe.blackbird.reporter.BlackbirdReporter;

/**
 * <p>
 * <br>
 * <b> Title: </b> ILocatorInitialize.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for ILocatorInitialize</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * checkForLocatorTypeAndInitialize : This method is used for check for locator
 * type and initialize them with value from FARM</br>
 * <br>
 * getLocatorDetails : This method is used for retrieving the locator
 * details(xpath, Id, Css etc) from FARM for given locator variables</br>
 * <br>
 * initializeLocatorValue : This method is used for initializing the locator
 * variable with value retrieved from FARM database based on locator type. Eg.
 * Variable headerXpath will be initialized with value stored under object name
 * 'headerXpath' and object xpath</br>
 *
 * @author aswain
 * @since 09/27/2019
 *        </p>
 */

public interface ILocatorInitialize {

	/**
	 * This method is used for check for locator type and initialize them with value
	 * from FARM
	 *
	 * @param pageObject - map object containing all the locator information from
	 *                   FARM for a given page
	 * @param fields     - variable names of the locable in the page class
	 * @return void
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	default void checkForLocatorTypeAndInitializeFields(Map<String, HashMap<String, String>> pageObject, Field[] fields,
			int pageIdentifier) {
		List<String> missingFieldNames = new ArrayList<>();
		for (Field field : fields) {
			String fieldName = field.getName();
			if (doesFieldNameRepresentLocatorVariable(fieldName)) {
				Map<String, String> locatorDetails = pageObject.get(fieldName);
				if (locatorDetails == null)
					missingFieldNames.add(fieldName);
			}
		}
		if (!missingFieldNames.isEmpty()) {
			System.out.println("Failed to retrieve the locator details for following field names["
					+ String.join(", ", missingFieldNames)
					+ "]. Please check and add this locator in FARM. Variable names ending with 'Xpath', 'Id', and 'Css' are considered as locator variables. If variable declared is not a locator variable, please rename it."); 

			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the locator details for Page ID[" + pageIdentifier + "]",
					"Locator details should be retrieved", "Locator details are successfully retrieved",
					"Failed to retrieve the locator details for following field names["
							+ String.join(", ", missingFieldNames)
							+ "]. Please check and add this locator in FARM. Variable names ending with 'Xpath', 'Id', and 'Css' are considered as locator variables. If variable declared is not a locator variable, please rename it.",
					false);
		}
			
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObject, field, pageIdentifier);
		}
	}

	/**
	 * This method is used for check for locator type and initialize them with value
	 * from FARM
	 *
	 * @param pageObject - map object containing all the locator information from
	 *                   FARM for a given page
	 * @param field      - variable name of the locable in the page class
	 * @return void
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	default void checkForLocatorTypeAndInitialize(Map<String, HashMap<String, String>> pageObject, Field field,
			int pageIdentifier) {

		// modifying the page object map if any extra scapce is there
		pageObject = pageObject.entrySet().stream()
				.collect(Collectors.toMap(Map.Entry::getKey , Map.Entry::getValue));
		// checking for locator type and initializing them
		String[] locatorTypes = { LPLCoreConstents.XPATH, LPLCoreConstents.ID, LPLCoreConstents.CSS };
		for (String locatorType : locatorTypes) {
			// Retrieving the field/variable name
			String fieldName = field.getName();
			// Checking if the variable name represents a locator variables('xpath', 'css',
			// and 'id' suffix)
			if ((fieldName.toUpperCase().endsWith(locatorType))
					&& (getLocatorDetails(pageObject, fieldName, pageIdentifier).get(locatorType) != null)) {
				// Initialize the field/variable to a value read from FARM
				initializeLocatorValue(pageObject, field, fieldName, locatorType);
			}
		}
	}

	/**
	 * This method is used for variable name represents a locator(Ending with
	 * Xpath,Css orXpath
	 *
	 * @param fieldName - variable names of the locable in the page class
	 * @return void
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	default boolean doesFieldNameRepresentLocatorVariable(String fieldName) {
		String[] locatorTypes = { LPLCoreConstents.XPATH, LPLCoreConstents.ID, LPLCoreConstents.CSS };
		for (String locatorType : locatorTypes) {
			if (fieldName.toUpperCase().endsWith(locatorType))
				return true;
		}
		return false;
	}

	/**
	 * This method is used for retrieving the locator details(xpath, Id, Css etc)
	 * from FARM for given locator variables
	 *
	 * @param fieldName - name of the field/variable declared in this class
	 * @return Map<String, String>
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	default Map<String, String> getLocatorDetails(Map<String, HashMap<String, String>> pageObject, String fieldName,
			int pageId) {

		// Retrieving the locator details(Xpath, Css, ID etc) from FARM for given
		// locator variable
		Map<String, String> locatorDetails = pageObject.get(fieldName);
		if (locatorDetails == null) {
			BlackbirdReporter.log("Failed to retrieve the locator details for " + fieldName
							+ ". Please check and add this locator in FARM. Variable names ending with 'Xpath', 'Id', and 'Css' are considered as locator variables. If "
							+ fieldName + " is not a locator variable, please rename it."); 
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the locator details for " + fieldName + " from Page ID[" + pageId + "]",
					"Locator details should be retrieved", "Locator details are successfully retrieved",
					"Failed to retrieve the locator details for " + fieldName
							+ ". Please check and add this locator in FARM. Variable names ending with 'Xpath', 'Id', and 'Css' are considered as locator variables. If "
							+ fieldName + " is not a locator variable, please rename it.",
					false);
		}
		return locatorDetails;
	}

	/**
	 * This method is used for initializing the locator variable with value
	 * retrieved from FARM database based on locator type. Eg. Variable headerXpath
	 * will be initialized with value stored under object name 'headerXpath' and
	 * object xpath
	 *
	 * @param field       - refers to the field/variable declared in this class
	 * @param fieldName   - name of the field/variable declared in this class
	 * @param locatorType - type of the locator eg. Xpath, Css, Id
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	public default void initializeLocatorValue(Map<String, HashMap<String, String>> pageObject, Field field,
			String fieldName, String locatorType) {
		// Initializing the locator variable with value from FARM
		try {
			// Setting the field accessibility to true
			field.setAccessible(true);
			// Setting the locator variable to a value read from FARM
			field.set(this, pageObject.get(fieldName).get(locatorType));
		} catch (IllegalAccessException | IllegalArgumentException e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Initialization of page object variables for Dashboard page",
					"Page Objects should be successfully created for Dashboard class",
					"Page Objects successfully created for Dashboard class",
					"Failed to initialize the page objects of Dashboard from Farm for locator["
							+ field.getType().getName() + "]. Error:" + e.toString(),
					false);
		}
	}
}
