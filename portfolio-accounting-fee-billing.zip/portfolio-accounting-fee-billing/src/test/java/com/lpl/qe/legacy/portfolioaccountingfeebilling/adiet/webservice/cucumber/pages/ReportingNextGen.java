package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> ReportingNextGen.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for Reporting NextGen</br>
 * <br>
 * <b>Usage:</b></br>
 * </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author Siddharth Gupta (sidgupta)
 * @since 02/04/2021
 *        </p>
 */
public class ReportingNextGen extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 1098;
	boolean blnResult = false;
	Map<String, HashMap<String, String>> pageObjectMap;

	public static final String REPORTING_NEXTGEN_PAGE_HEADER = "Reporting NextGen Page Header";
	public static final String PROP_MF_FEEREBATING_REPORTING_TAB_NEXTGEN = "Prop MF FeeRebating Reporting Tab NextGen Page";
	public static final String PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT_NEXTGEN = "Prop MF Monthly Credit Total by CUSIP Report NextGen Page";
	public static final String PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT_TITLE_NEXTGEN = "Prop MF Monthly Credit Total by CUSIP Report Title NextGen Page";
	public static final String VERIFY_CUSIP = "CUSIP Text Value";
	public static final String VERIFY_TOTAL_CREDIT = "Total Credit Amount Value";
	public static final String HOME_PAGE = "Home Page Hub";
	public static final String NON_RIA_ACCOUNTS_AS_RIA_REPORT = "Non RIA Accounts as RIA Report";
	public static final String NON_RIA_ACCOUNTS_AS_RIA_REPORT_HEADER = "Non RIA Accounts as RIA Report Header";
	public static final String OPTIONS = "options";
	public static final String CHECKBOX = "checkboxes";
	public static final String SUCCESSFULLY_ABLE_TO_SEE = "Successfully able to see ";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String VERIFY_NON_RIA_LPL_ACCOUNT = "Non RIA LPL Account Number";
	public static final String VERIFY_NON_RIA_ACCOUNT_CLASS = "Non RIA LPL Account Number";
	public static final String HAMBURGER = "Hamburger Icon";
	public static final String HISTORICAL_CORRECTION_MENU = "Historical Correction Menu";
	public static final String FEE_CORRECTION = "Fee Correction";
	public static final String REVIEW_AND_APPROVE = "Review annd Approve";
	public static final String PROCESS_BUTTON_ON_FEECORRECTIONS_PAGE = "Process Button on FeeCorrection Page";
	public static final String APPROVE_BUTTON_ON_REVIEW_AND_APPROVE_PAGE = "Approve Button on Review And Approve Page";
	public static final String HOLD_BUTTON_ON_REVIEW_AND_APPROVE_PAGE = "Hold Button on Review And Approve Page";
	public static final String REMOVE_BUTTON_ON_REVIEW_AND_APPROVE_PAGE = "Remove Button on Review And Approve Page";
	public static final String EXPORT_BUTTON_ON_REVIEW_AND_APPROVE_PAGE = "Export Button on Review And Approve Page";
	public static final String EXPORT_ALL_DATA = "Export all data from list";
	public static final String PORTFOLIO_ACCOUNTING_MENU = "Portfolio Accounting Menu";
	public static final String ACCOUNT_NUMBER_TEXTBOX = "Account Number Textbox on Portfolio Accounting page";
	public static final String ACCOUNT_NUMBER1 = "Enter AcctNum1 on Portfolio Accounting page";
	public static final String SEARCH_BUTTON = "Search Button on Portfolio Accounting page";
	public static final String PROCESS_BUTTON_ON_REVIEW_AND_APPROVE_PAGE = "Process Button in fee correction tab";
	public static final String REJECT_BUTTON_ON_REVIEW_AND_APPROVE_PAGE = "Reject Button in fee correction tab";
	public static final String REMOVE_BUTTON_ON_REVIEW_AND_APPROVE_PAGE_FC = "Remove Button in fee correction tab";
	public static final String BETA_PAGE_ELEMENTS = "Beta Page Elements";
	public static final String EXPORT_SELECTED_ROWS = "Export Selected Rows";
	public static final String PREVACCOUNT_BUTTON = "PrevAccount Button";
	public static final String NEXTACCOUNT_BUTTON = "NextAccount Button";
	public static final String EXPORTBUTTON_PORTFOLIOACCOUNTING = "Export Button On Portfolio Accounting Page";
	public static final String EXPORTALLDATA_PORTFOLIOACCOUNTING = "Export All Data on Portfolio Accounting";
	public static final String EXPORTSELECTEDROWS_PORTFOLIOACCOUNTING = "Export Selected Rows on Portfolio Accounting";
	public static final String FBVATRANSACTIONS_TAB = "FBVA Transactions tab";
	public static final String FBVAPOSITIONS_TAB = "FBVA Positions Tab";
	public static final String POSITIONS_TAB = "Positions Tab";
	public static final String DIRECT_BUSINESS_FBVA_TAB = "Direct Business FBVA Tab";
	public static final String TRANSACTIONS_TAB = "Transactions Tab";
	public static final String AUDITS_TAB = "Audits Tab";
	public static final String PERFORMANCE_TAB = "Performance Tab";
	public static final String PROCESS_TRACKING_TAB = "Process Tracking Tab";
	public static final String CLEAR_LIST_ON_PROCESS_TRACKING_PAGE = "Clear List Button in Process Tracking tab";
	public static final String AVG_POS_VALUE_LABEL = "Average Position Value";
	public static final String BETA_TAB = "Beta Tab";
	public static final String ACCOUNT_DETAILS_TAB = "AccountDetails Tab";
	public static final String INCEPTION_DATE_VALUE = "Inception Date Value";
	public static final String INCEPTION_DATE_TEXTBOX = "Inception Date Text";
	public static final String INCEPTION_DATE_CANCEL_ICON = "Inception Date Cancel Icon";

	String strAvgPosValueXpath;
	String strReportingNextGenHeaderXpath;
	String strFeeRebatingTabXpath;
	String strCusipReportXpath;
	String strPropMFCUSIPReportTitleXpath;
	String strOriginalHandle;
	String strGetCusipTextNextGen;
	String strTotalCreditAmtNextGen;
	String strCusipTextXpath;
	String strTotalCreditAmtXpath;
	String strHomePageXpath;
	String strNonRiaAccountsXpath;
	String strNonRiaHeaderXpath;
	String strNonRiaLabelsXpath;
	String strNonRiaLplAccXpath;
	String strNonRiaAccClassXpath;
	String strGetNonRiaLplAccNoNextGen;
	String strGetNonRiaAccClassNextGen;
	String strHamburgerXpath;
	String strHistoricalCorrectionXpath;
	String strFeeCorrectionXpath;
	String strColumnHeadersXpath;
	String strReviewAndApproveXpath;
	String strReviewAndApproveColumnsXpath;
	String strApproveButtonOnReviewAndApprovePageXpath;
	String strHoldButtonOnReviewAndApprovePageXpath;
	String strRemoveButtonOnReviewAndApprovePageXpath;
	String strExportButtonOnReviewAndApprovePageXpath;
	String strExportAllDataXpath;
	String strMonthlyCreditCusipReportXpath;
	String strPortfolioAccountingXpath;
	String strAccountNoTextBoxXpath;
	String strSearchButtonXpath;
	String strBetaTabXpath;
	String strProcessButtonFCXpath;
	String strRejectButtonFCXpath;
	String strRemoveButtonFCXpath;
	String strAccountCheckboxXpath;
	String strExportSelectedRowsXpath;
	String strPortfolioAccountingTabXpath;
	String strPrevAccountButtonXpath;
	String strNextAccountButtonXpath;
	String strExportButtonPortfolioAccountingXpath;
	String strExportAllDataPortfolioAccountingXpath;
	String strExportSelectedRowsPortfolioAccountingXpath;
	String strFBVATransactionsTabXpath;
	String strFBVAPositionsTabXpath;
	String strPositionsTabXpath;
	String strDirectBusinessFBVATabXpath;
	String strDirectBusinessFBVATableHeaderXpath;
	String strTransactionsTabXpath;
	String strAuditsTabXpath;
	String strPerformanceTabXpath;
	String strProcessTrackingXPath;
	String strClearListButtonXPath;
	String strProcessTrackingColumnsXpath;
	String strAccountDetailsTabXpath;
	String strInceptionDateValueXpath;
	String strInceptionDateInputXpath;
	String strInceptionDateCancelIconXpath;
	

	public ReportingNextGen(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02-04-2021
	 */
	public boolean isPageLoaded() {
		strOriginalHandle = driver.getWindowHandle();
		List<String> browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		return isElementPresentUsingXpath(strReportingNextGenHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				REPORTING_NEXTGEN_PAGE_HEADER);
	}

	/**
	 * This method is used to verify Prop MF FeeRebating Reporting Tab should be
	 * displayed on Reporting NextGen Page
	 * 
	 * @return boolean
	 *
	 * @Author Siddharth Gupta
	 * @Since 02/11/2021
	 */
	public boolean verifyTheAvailabilityOfPropMFFeeRebatingReportingTabOnReportingNextGenPage() {
		return isElementPresentUsingXpath(strFeeRebatingTabXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_FEEREBATING_REPORTING_TAB_NEXTGEN);
	}

	/**
	 * This method is used to click on Prop MF FeeRebating Reporting Tab on
	 * Reporting NextGen Page
	 * 
	 * @return boolean
	 *
	 * @Author Siddharth Gupta
	 * @Since 02/11/2021
	 */
	public boolean clickOnPropMFFeeRebatingReportingTabOnReportingNextGenPage() {
		return clickElementUsingXpath(strFeeRebatingTabXpath, PROP_MF_FEEREBATING_REPORTING_TAB_NEXTGEN);
	}

	/**
	 * This method is used to verify Prop MF Monthly Credit Total by CUSIP Report
	 * link should be displayed on Reporting NextGen Page
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/11/2021
	 */
	public boolean verifyTheAvailabilityOfPropMFRebateDailyMktValueReportLinkOnReportingNextGenPage() {
		return isElementPresentUsingXpath(strMonthlyCreditCusipReportXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT_NEXTGEN);
	}

	/**
	 * This method is used to click on Prop MF Monthly Credit Total by CUSIP Report
	 * link on Reporting NextGen Page
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/11/2021
	 */
	public boolean clickOnPropMFMonthlyCreditTotalByCUSIPReportLinkOnReportingNextGenPage() {
		return clickElementUsingXpath(strMonthlyCreditCusipReportXpath,
				PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT_NEXTGEN);
	}

	/**
	 * This method is used to Verify the Page Title of the Prop MF Monthly Credit
	 * Total by CUSIP Report opened in another(third) tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/11/2021
	 */
	public boolean shouldSeePropMFMonthlyCreditTotalByCUSIPReportOpenedInAnotherTab() {
		List<String> browserActiveTabs = getActiveBrowserTabs();
		switchToThirdTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		waitTillVisibleUsingXpath(strPropMFCUSIPReportTitleXpath, LPLCoreConstents.getInstance().HIGHEST,
				PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT_TITLE_NEXTGEN);
		return isElementPresentUsingXpath(strPropMFCUSIPReportTitleXpath, LPLCoreConstents.getInstance().LOWEST,
				PROP_MF_REBATE_CUSIP_FACTOR_FILE_REPORT_TITLE_NEXTGEN);
	}

	/**
	 * This method is used to get the NextGen CUSIP Report Data and go back to ADIET
	 * Home Page
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/11/2021
	 */
	public boolean goBackToAdietHomePage() {
		strGetCusipTextNextGen = getTextUsingXpath(strCusipTextXpath, VERIFY_CUSIP);
		strTotalCreditAmtNextGen = getTextUsingXpath(strTotalCreditAmtXpath, VERIFY_TOTAL_CREDIT);
		switchToOriginalHandle(strOriginalHandle);
		return isElementPresentUsingXpath(strHomePageXpath, LPLCoreConstents.getInstance().LOWEST, HOME_PAGE);
	}

	/**
	 * This method is used to Verify the Classic CUSIP Report Data with NextGen
	 * CUSIP Report Data
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/11/2021
	 */
	public boolean verifyTheDataWithNextGenReport() {
		String strGetCusipTextReporting = getTextUsingXpath(strCusipTextXpath, VERIFY_CUSIP);
		String strTotalCreditAmtReporting = getTextUsingXpath(strTotalCreditAmtXpath, VERIFY_TOTAL_CREDIT);
		if (strGetCusipTextReporting.equals(strGetCusipTextNextGen)
				&& strTotalCreditAmtReporting.equals(strTotalCreditAmtNextGen))
			return isElementPresentUsingXpath(strTotalCreditAmtXpath, LPLCoreConstents.getInstance().LOWEST,
					VERIFY_TOTAL_CREDIT);
		else
			return false;
	}

	/**
	 * This method is used to verify the availability of Non RIA Accounts as RIA
	 * Report link should be displayed
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/26/2021
	 */
	public boolean verifyTheAvailabilityOfNonRiaAccountsAsRiaReportLink() {
		return isElementPresentUsingXpath(strNonRiaAccountsXpath, LPLCoreConstents.getInstance().LOWEST,
				NON_RIA_ACCOUNTS_AS_RIA_REPORT);
	}

	/**
	 * This method is used to click on Non RIA Accounts as RIA Report Link
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/26/2021
	 */
	public boolean clickOnNonRiaAccountsAsRiaReportLink() {
		return clickElementUsingXpath(strNonRiaAccountsXpath, NON_RIA_ACCOUNTS_AS_RIA_REPORT);
	}

	/**
	 * This method is used to verify the Header of Non RIA Accounts as RIA Report
	 * opened in new tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/26/2021
	 */
	public boolean verifyTheHeaderOfNonRiaAccountsAsRiaReport() {
		List<String> browserActiveTabs = getActiveBrowserTabs();
		switchToThirdTab(browserActiveTabs);
		return isElementPresentUsingXpath(strNonRiaHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				NON_RIA_ACCOUNTS_AS_RIA_REPORT_HEADER);
	}

	/**
	 * This method is used to verify the availability of search field option labels
	 * for Non RIA Accounts as RIA Report
	 * 
	 * @param nonRiaAccountsReport
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/26/2021
	 */
	public boolean verifyTheAvailablityOfSearchFieldOptionLabelsForNonRiaAccountsAsRiaReport(
			DataTable nonRiaAccountsReport) {

		List<Map<String, String>> filters = nonRiaAccountsReport.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyTheAvailablityOfLabelsForNonRiaAccountsAsRiaReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availablity of labels for Non RIA Accounts
	 * as RIA Report
	 * 
	 * @param nonRiaAccountsReport
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/26/2021
	 */
	public boolean verifyTheAvailablityOfLabelsForNonRiaAccountsAsRiaReport(String nonRiaAccountsReport) {
		return isElementPresentUsingXpath(getFormattedLocator(strNonRiaLabelsXpath, nonRiaAccountsReport),
				nonRiaAccountsReport);
	}

	/**
	 * This method is used to get the Non RIA Accounts data and go back to Adiet
	 * Home Page
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/26/2021
	 */
	public boolean getTheNonRiaAccountsDataAndGoBackToAdietHomePage() {
		strGetNonRiaLplAccNoNextGen = getTextUsingXpath(strNonRiaLplAccXpath, VERIFY_NON_RIA_LPL_ACCOUNT);
		strGetNonRiaAccClassNextGen = getTextUsingXpath(strNonRiaAccClassXpath, VERIFY_NON_RIA_ACCOUNT_CLASS);
		switchToOriginalHandle(strOriginalHandle);
		return isElementPresentUsingXpath(strHomePageXpath, LPLCoreConstents.getInstance().LOWEST, HOME_PAGE);
	}

	/**
	 * This method is used to verify the Non RIA Accounts Classic Data with NextGen
	 * Data
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 02/26/2021
	 */
	public boolean verifyTheNonRiaAccountsClassicDataWithNextGenData() {
		String strGetNonRiaLplAccNoReporting = getTextUsingXpath(strNonRiaLplAccXpath, VERIFY_NON_RIA_LPL_ACCOUNT);
		String strGetNonRiaAccClassReporting = getTextUsingXpath(strNonRiaAccClassXpath, VERIFY_NON_RIA_ACCOUNT_CLASS);
		if (strGetNonRiaLplAccNoReporting.equals(strGetNonRiaLplAccNoNextGen)
				&& strGetNonRiaAccClassReporting.equals(strGetNonRiaAccClassNextGen))
			return isElementPresentUsingXpath(strNonRiaAccClassXpath, LPLCoreConstents.getInstance().LOWEST,
					VERIFY_NON_RIA_ACCOUNT_CLASS);
		else
			return false;
	}

	public boolean clickOnHamburgerIcon() {
		return clickElementUsingXpath(strHamburgerXpath, LPLCoreConstents.getInstance().LOWEST, HAMBURGER);
	}

	public boolean clickOnHistoricalCorrection() {
		return clickElementUsingXpath(strHistoricalCorrectionXpath, LPLCoreConstents.getInstance().LOWEST,
				HISTORICAL_CORRECTION_MENU);
	}

	public boolean clickOnFeeCorrection() {
		return clickElementUsingXpath(strFeeCorrectionXpath, LPLCoreConstents.getInstance().LOWEST, FEE_CORRECTION);
	}

	public boolean verifyTheAvailabilityOfColumnsHC(DataTable columnOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = columnOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String columnHeader = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingPlaceholderTextHC(columnHeader);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + columnHeader, USER_SHOULD_BE_ABLE_TO_SEE + columnHeader,
					SUCESSFULLY_ABLE_SEE + columnHeader, FAILED_TO_SEE + columnHeader + strError);
		}
		return blnResult;
	}

	public boolean checkIfElementExistUsingPlaceholderTextHC(String columnHeadersText) {
		return isElementPresentUsingXpath(getFormattedLocator(strColumnHeadersXpath, columnHeadersText),
				LPLCoreConstents.getInstance().MEDIUM, columnHeadersText);
	}

	/**
	 * This method is used to Click on Review And Approve Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/02/2021
	 */

	public boolean clickOnReviewAndApprove() {

		return clickElementUsingXpath(strReviewAndApproveXpath, LPLCoreConstents.getInstance().LOWEST,
				REVIEW_AND_APPROVE);
	}

	/**
	 * This method is used to verify page elements on Review And Approve Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/07/2021
	 */

	public boolean verifyTheAvailabilityOfColumnsOnReviewAndApprove(DataTable reviewAndApprove) {

		boolean blnResult = false;
		List<Map<String, String>> filters = reviewAndApprove.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String reviewPageHeader = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingPlaceholderTextReviewAndApprove(reviewPageHeader);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + reviewPageHeader, USER_SHOULD_BE_ABLE_TO_SEE + reviewPageHeader,
					SUCESSFULLY_ABLE_SEE + reviewPageHeader, FAILED_TO_SEE + reviewPageHeader + strError);
		}
		return blnResult;
	}

	public boolean checkIfElementExistUsingPlaceholderTextReviewAndApprove(String reviewAndApproveColumnsText) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strReviewAndApproveColumnsXpath, reviewAndApproveColumnsText),
				LPLCoreConstents.getInstance().MEDIUM, reviewAndApproveColumnsText);
	}

	/**
	 * This method is used to verify Approve button on Review And Approve Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/09/2021
	 */

	public boolean verifyApproveButtonIsPresent() {
		return isElementPresentUsingXpath(strApproveButtonOnReviewAndApprovePageXpath,
				LPLCoreConstents.getInstance().LOWEST, APPROVE_BUTTON_ON_REVIEW_AND_APPROVE_PAGE);
	}

	/**
	 * This method is used to verify Hold button on Review And Approve Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/09/2021
	 */

	public boolean verifyHoldButtonIsPresent() {
		return isElementPresentUsingXpath(strHoldButtonOnReviewAndApprovePageXpath,
				LPLCoreConstents.getInstance().LOWEST, HOLD_BUTTON_ON_REVIEW_AND_APPROVE_PAGE);
	}

	/**
	 * This method is used to verify Remove button on Review And Approve Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/09/2021
	 */

	public boolean verifyRemoveButtonIsPresent() {
		return isElementPresentUsingXpath(strRemoveButtonOnReviewAndApprovePageXpath,
				LPLCoreConstents.getInstance().LOWEST, REMOVE_BUTTON_ON_REVIEW_AND_APPROVE_PAGE);
	}

	/**
	 * This method is used to verify Export button on Review And Approve Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/14/2021
	 */
	public boolean verifyExportButtonIsPresent() {
		return isElementPresentUsingXpath(strExportButtonOnReviewAndApprovePageXpath,
				LPLCoreConstents.getInstance().LOWEST, EXPORT_BUTTON_ON_REVIEW_AND_APPROVE_PAGE);
	}

	/**
	 * This method is used to click on Export button on Review And Approve Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/14/2021
	 */

	public boolean iClickOnExportButtonOnReviewAndApprovePage() {
		return clickElementUsingXpath(strExportButtonOnReviewAndApprovePageXpath, LPLCoreConstents.getInstance().LOWEST,
				EXPORT_BUTTON_ON_REVIEW_AND_APPROVE_PAGE);
	}

	/**
	 * This method is used to click on Export All Data from list *
	 * 
	 *
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/14/2021
	 */

	public boolean iClickOnExportAllData() {
		return clickElementUsingXpath(strExportAllDataXpath, LPLCoreConstents.getInstance().LOWEST, EXPORT_ALL_DATA);
	}

	/**
	 * This method is used verify whether the file is Downloaded
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/14/2020
	 */

	public boolean verifyDownloadedFile() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used click on Portfolio Accounting Menu
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/22/2020
	 */
	public boolean clickOnPortfolioAccounting() {
		return clickElementUsingXpath(strPortfolioAccountingXpath, LPLCoreConstents.getInstance().LOWEST,
				PORTFOLIO_ACCOUNTING_MENU);
	}

	/**
	 * This method is used enter AccotNum1 on Portfolio Accounting Menu
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/22/2020
	 */

	public boolean enterLPLAcctNum1() {

		return enterTextUsingXpath(strAccountNoTextBoxXpath, testData.get(ACCOUNT_NUMBER1), ACCOUNT_NUMBER_TEXTBOX);

	}

	/**
	 * This method is used to click on Search button on Portfolio Accounting Menu
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/22/2020
	 */
	public boolean clickOnSearchButton() {
		return clickElementUsingXpath(strSearchButtonXpath, LPLCoreConstents.getInstance().LOWEST, SEARCH_BUTTON);
	}

	/**
	 * This method is used to Verify the availablity of Beta Page elements
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/22/2021
	 */

	public boolean verifyBetaTabPageElements(DataTable betatab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = betatab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = clickElementUsingXpath(strBetaTabXpath, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;

	}

	/**
	 * This method is used verify Process Button in Fee Correction Tab
	 * 
	 * @return boolean
	 *
	 * @author Mrigna Malhotra
	 * @since 04/22/2020
	 */

	public boolean verifyProcessButtonIsPresent() {
		return isElementPresentUsingXpath(strProcessButtonFCXpath, LPLCoreConstents.getInstance().LOWEST,
				PROCESS_BUTTON_ON_REVIEW_AND_APPROVE_PAGE);
	}

	/**
	 * This method is used verify Reject Button in Fee Correction Tab
	 * 
	 * @return boolean
	 *
	 * @author Mrigna Malhotra
	 * @since 04/22/2020
	 */
	/**
	 * This method is used verify Process Button is enabled in Fee Correction Tab
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 04/27/2020
	 */

	public boolean iVerifyProcessButtonIsEnabled() {
		return isElementEnabled(strProcessButtonFCXpath, PROCESS_BUTTON_ON_FEECORRECTIONS_PAGE);
	}

	/**
	 * This method is used verify Process Button is clicked in Fee Correction Tab
	 * 
	 * @return boolean
	 *
	 * @author saritha akkaraju
	 * @since 04/27/2020
	 */

	public boolean clickOnProcessButton() {
		return clickElementUsingXpath(strProcessButtonFCXpath, LPLCoreConstents.getInstance().LOWEST,
				PROCESS_BUTTON_ON_FEECORRECTIONS_PAGE);
	}

	/**
	 * This method is used verify Reject Button in Fee Correction Tab
	 * 
	 * @return boolean
	 *
	 * @author Mrigna Malhotra
	 * @since 04/22/2020
	 */
	public boolean verifyRejectButtonIsPresent() {
		return isElementPresentUsingXpath(strRejectButtonFCXpath, LPLCoreConstents.getInstance().LOWEST,
				PROCESS_BUTTON_ON_REVIEW_AND_APPROVE_PAGE);
	}

	public boolean verifyRemoveButtonFCIsPresent() {
		return isElementPresentUsingXpath(strRemoveButtonFCXpath, LPLCoreConstents.getInstance().LOWEST,
				PROCESS_BUTTON_ON_REVIEW_AND_APPROVE_PAGE);
	}

	/**
	 * This method is used click multiple checkboxes to select accounts
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/23/2021
	 */
	public boolean selectFewAccountsCheckbox(DataTable acccheckbox) {
		boolean blnResult = false;
		List<Map<String, String>> filters = acccheckbox.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(CHECKBOX);
			blnResult = clickElementUsingXpath(getFormattedLocator(strAccountCheckboxXpath, filterName), filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;

	}

	public boolean clickOnExportSelectedRows() {
		return clickElementUsingXpath(strExportSelectedRowsXpath, LPLCoreConstents.getInstance().LOWEST,
				EXPORT_SELECTED_ROWS);

	}

	/**
	 * This method is used to verify tabs on Portfolio Accounting page
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/26/2021
	 */

	public boolean verifyPortfolioAccountingTabs(DataTable portfoliotab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = portfoliotab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = clickElementUsingXpath(getFormattedLocator(strPortfolioAccountingTabXpath, filterName),
					filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify Prev Account button
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyPrevAccountButtonIsPresent() {
		return isElementPresentUsingXpath(strPrevAccountButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				PREVACCOUNT_BUTTON);
	}

	/**
	 * This method is used to verify Next Account button
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyNextAccountButtonIsPresent() {
		return isElementPresentUsingXpath(strNextAccountButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				NEXTACCOUNT_BUTTON);
	}

	/**
	 * This method is used to click on Next Account button
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean clickOnNextAccountButton() {
		return clickElementUsingXpath(strNextAccountButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				NEXTACCOUNT_BUTTON);
	}

	/**
	 * This method is used to click on Prev Account button
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean clickOnPrevAccountButton() {
		return clickElementUsingXpath(strPrevAccountButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				PREVACCOUNT_BUTTON);
	}

	/**
	 * This method is verify export buttons on Portfolio Accounting page
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyExportButtonIsPresentOnPortfolioAccounting() {
		waitTillVisibleUsingXpath(strExportButtonPortfolioAccountingXpath, LPLCoreConstents.getInstance().HIGHEST,
				EXPORTBUTTON_PORTFOLIOACCOUNTING);
		return isElementPresentUsingXpath(strExportButtonPortfolioAccountingXpath,
				LPLCoreConstents.getInstance().LOWEST, EXPORTBUTTON_PORTFOLIOACCOUNTING);
	}

	/**
	 * This method is used to click on Export button
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean clickOnExportButtonOnPortfolioAccounting() {
		waitTillVisibleUsingXpath(strExportButtonPortfolioAccountingXpath, LPLCoreConstents.getInstance().HIGHEST,
				EXPORTBUTTON_PORTFOLIOACCOUNTING);
		return clickElementUsingXpath(strExportButtonPortfolioAccountingXpath, LPLCoreConstents.getInstance().LOWEST,
				EXPORTBUTTON_PORTFOLIOACCOUNTING);
	}

	/**
	 * This method is used to click on ExportAllData
	 * 
	 * @return boolean Hisotical
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean clickOnExportAllDataOnPortfolioAccounting() {
		return clickElementUsingXpath(strExportAllDataPortfolioAccountingXpath, LPLCoreConstents.getInstance().LOWEST,
				EXPORTALLDATA_PORTFOLIOACCOUNTING);
	}

	/**
	 * This method is used to verify file downloaded for beta tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyFileDownloadedForBetaTab() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));

	}

	/**
	 * This method is used to click on few accounts on Beta Tab for
	 * ExportSelectedRows functionality
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean selectFewAccountsCheckboxOnBetaTab(DataTable acccheckboxbeta) {
		boolean blnResult = false;
		List<Map<String, String>> filters = acccheckboxbeta.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(CHECKBOX);
			waitTillVisibleUsingXpath(getFormattedLocator(strAccountCheckboxXpath, filterName), filterName);
			blnResult = clickElementUsingXpath(getFormattedLocator(strAccountCheckboxXpath, filterName), filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;

	}

	/**
	 * This method is used to click on ExportSelected Rows
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean clickOnExportSelectedRowsOnPortfolioAccounting() {
		return clickElementUsingXpath(strExportSelectedRowsPortfolioAccountingXpath,
				LPLCoreConstents.getInstance().LOWEST, EXPORTSELECTEDROWS_PORTFOLIOACCOUNTING);
	}

	/**
	 * This method is used to click on FBVATrans
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean clickOnFBVATransactionsTab() {
		return clickElementUsingXpath(strFBVATransactionsTabXpath, LPLCoreConstents.getInstance().LOWEST,
				FBVATRANSACTIONS_TAB);
	}

	/**
	 * This method is used to verify page-elements of FBVATrans
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyFBVATransactionsTabPageElements(DataTable fbvatranstab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = fbvatranstab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = clickElementUsingXpath(strFBVATransactionsTabXpath, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;

	}

	/**
	 * This method is used tovrify File downloaded for FBVATRans
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyFileDownloadedForFBVATransactionsTab() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));

	}

	/**
	 * This method is used to check few accounts on FBVATrans Tab for
	 * ExportSelectedRows functionality
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean selectFewAccountsCheckboxOnFBVATransactionsTab(DataTable acccheckboxfbvatrans) {
		boolean blnResult = false;
		List<Map<String, String>> filters = acccheckboxfbvatrans.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(CHECKBOX);
			blnResult = clickElementUsingXpath(getFormattedLocator(strAccountCheckboxXpath, filterName), filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;

	}

	/**
	 * This method is used to click on FBVAPos
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean clickOnFBVAPositionsTab() {
		return clickElementUsingXpath(strFBVAPositionsTabXpath, LPLCoreConstents.getInstance().LOWEST,
				FBVAPOSITIONS_TAB);
	}

	/**
	 * This method is used to verify page elements on FBVAPos
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyFBVATransactionsTabPageElement(DataTable fbvapostab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = fbvapostab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = clickElementUsingXpath(strFBVAPositionsTabXpath, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;

	}

	/**
	 * This method is used to verify file downloaded on FBVAPos
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyFileDownloadedForFBVAPositionsTab() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used to check few accounts on FBVAPos
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean selectFewAccountsCheckboxOnFBVAPositionsTab(DataTable acccheckboxfbvapos) {
		boolean blnResult = false;
		List<Map<String, String>> filters = acccheckboxfbvapos.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(CHECKBOX);
			blnResult = clickElementUsingXpath(getFormattedLocator(strAccountCheckboxXpath, filterName), filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify page elements on Positions tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyPositionsTabPageElements(DataTable postab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = postab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = clickElementUsingXpath(strPositionsTabXpath, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click on Positions tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */

	public boolean userClicksOnThePositionsTabOnPortfolioAccounting() {
		return clickElementUsingXpath(strPositionsTabXpath, LPLCoreConstents.getInstance().HIGHEST, POSITIONS_TAB);
	}

	/**
	 * This method is used to verify file downloaded on Positions tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean verifyFileDownloadedForPositionsTabOnPortfolioAccounting() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used to check few accounts on Positions tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 04/27/2021
	 */
	public boolean selectFewAccountsCheckboxOnPositionsTab(DataTable acccheckboxpos) {
		boolean blnResult = false;
		List<Map<String, String>> filters = acccheckboxpos.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(CHECKBOX);
			waitTillVisibleUsingXpath(getFormattedLocator(strAccountCheckboxXpath, filterName), filterName);
			blnResult = clickElementUsingXpath(getFormattedLocator(strAccountCheckboxXpath, filterName), filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click on Direct Business FBVA tab
	 * 
	 * @return boolean
	 *
	 * @author H Abdul Hadi
	 * @since 05/21/2021
	 */

	public boolean clickOnDirectBusinessFBVATab() {
		return clickElementUsingXpath(strDirectBusinessFBVATabXpath, LPLCoreConstents.getInstance().LOWEST,
				DIRECT_BUSINESS_FBVA_TAB);
	}

	/**
	 * This method is used to verify file downloaded on Direct Business FBVA tab
	 * 
	 * @return boolean
	 *
	 * @author H Abdul Hadi
	 * @since 05/21/2021
	 */
	public boolean iVerifyFileDownloadedForDirectBusinessFBVATab() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used to validate individual header element
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean iVerifyPageElementOnDirectBusinessFBVATab(String tableHeaderTextText) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strDirectBusinessFBVATableHeaderXpath, tableHeaderTextText), tableHeaderTextText);
	}

	/**
	 * This method is used to verify page elements on Direct Business FBVA tab
	 * 
	 * @return boolean
	 *
	 * @author H Abdul Hadi
	 * @since 05/21/2021
	 */
	public boolean iVerifyPageElementsOnDirectBusinessFBVATab(DataTable postab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = postab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = iVerifyPageElementOnDirectBusinessFBVATab(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click on Transactions tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 05/26/2021
	 */

	public boolean userClicksOnTransactionsTabOnPortfolioAccounting() {
		return clickElementUsingXpath(strTransactionsTabXpath, LPLCoreConstents.getInstance().LOWEST, TRANSACTIONS_TAB);
	}

	/**
	 * This method is used to verify page elements on Transactions tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 05/26/2021
	 */
	public boolean iVerifyPageElementsOnTransactionsTab(DataTable trantab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = trantab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = clickElementUsingXpath(strTransactionsTabXpath, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify file downloaded for Transactions tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 05/26/2021
	 */

	public boolean verifyFileDownloadedForTransactionsTabOnPortfolioAccounting() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used to click on Audits tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 06/03/2021
	 */

	public boolean userClicksOnAuditsTabOnPortfolioAccounting() {
		return clickElementUsingXpath(strAuditsTabXpath, LPLCoreConstents.getInstance().LOWEST, AUDITS_TAB);
	}

	/**
	 * This method is used to verify page elements on Audits tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 06/03/2021
	 */
	public boolean iVerifyPageElementsOnAuditsTab(DataTable auditTab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = auditTab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = clickElementUsingXpath(strAuditsTabXpath, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify file downloaded for Audits tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 06/03/2021
	 */

	public boolean verifyFileDownloadedForAuditsTabOnPortfolioAccounting() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used to click on Performance tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 06/07/2021
	 */

	public boolean userClicksOnPerformanceTabOnPortfolioAccounting() {
		return clickElementUsingXpath(strPerformanceTabXpath, LPLCoreConstents.getInstance().LOWEST, PERFORMANCE_TAB);
	}

	/**
	 * This method is used to verify page elements on Performance tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 06/07/2021
	 */
	public boolean iVerifyPageElementsOnPerformanceTab(DataTable perfTab) {
		boolean blnResult = false;
		List<Map<String, String>> filters = perfTab.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = clickElementUsingXpath(strPerformanceTabXpath, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify file downloaded for Performance tab
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 06/07/2021
	 */

	public boolean verifyFileDownloadedForPerformanceTabOnPortfolioAccounting() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used to verify Headers under Process Tracking Tab
	 * 
	 * @return boolean
	 *
	 * @author Saritha Akkaraju
	 * @since 06/08/2021
	 */

	/**
	 * This method is used to Click on Process and Tracking Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Saritha Akkaraju
	 * @since 06/08/2021
	 */

	public boolean clickOnProcessTrackingTab() {

		return clickElementUsingXpath(strProcessTrackingXPath, LPLCoreConstents.getInstance().LOWEST,
				PROCESS_TRACKING_TAB);
	}

	/**
	 * This method is used to verify page elements on Process Tracking Tab
	 * 
	 * 
	 *
	 * @return boolean
	 *
	 * @author Saritha Akkaraju
	 * @since 06/08/2021
	 */
	public boolean verifyTheAvailabilityOfColumnsOnPT(DataTable processTracking) {
		boolean blnResult = false;
		List<Map<String, String>> filters = processTracking.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String processPageHeader = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingPlaceholderTextProcessTracking(processPageHeader);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + processPageHeader, USER_SHOULD_BE_ABLE_TO_SEE + processPageHeader,
					SUCESSFULLY_ABLE_SEE + processPageHeader, FAILED_TO_SEE + processPageHeader + strError);
		}
		return blnResult;
	}

	public boolean checkIfElementExistUsingPlaceholderTextProcessTracking(String processTrackingText) {
		return isElementPresentUsingXpath(getFormattedLocator(strProcessTrackingColumnsXpath, processTrackingText),
				LPLCoreConstents.getInstance().MEDIUM, processTrackingText);
	}

	/**
	 * This method is used to verify Clear List button on Review And Approve Tab
	 * 
	 * 
	 * F
	 * 
	 * @return boolean
	 *
	 * @author Saritha Akkaraju
	 * @since 06/08/2021
	 */

	public boolean verifyClearListIsPresent() {
		return isElementPresentUsingXpath(strClearListButtonXPath, LPLCoreConstents.getInstance().LOWEST,
				CLEAR_LIST_ON_PROCESS_TRACKING_PAGE);
	}

	/**
	 * This method is used to check the statement for Average Position Value Label
	 * 
	 * @return boolean
	 *
	 * @author Keven McBarnes
	 * @since 06/07/2021
	 */
	public boolean verifyTheStatementOfAveragePositionValueLabel() {
		return isElementPresentUsingXpath(strAvgPosValueXpath, LPLCoreConstents.getInstance().LOWEST,
				AVG_POS_VALUE_LABEL);
	}

	/**
	 * This method is used to verify file downloaded for Sleeves tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/28/2021
	 */

	public boolean verifyFileDownloadedForSleevesTabOnPortfolioAccounting() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used to verify click on BETA Tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 07/06/2021
	 */
	public boolean clickOnBetaTabOnPortfolioAccounting() {
		return clickElementUsingXpath(strBetaTabXpath, LPLCoreConstents.getInstance().LOWEST,
				BETA_TAB);
	}

	/**
	 * This method is used to verify click on Account Details Tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 07/19/2021
	 */
	public boolean clickOnAccountDetailsTabOnPortfolioAccountingPage() {
		return clickElementUsingXpath(strAccountDetailsTabXpath, LPLCoreConstents.getInstance().LOWEST,
				ACCOUNT_DETAILS_TAB);
	}

	public boolean isInceptionDateDisplayed() {
		 boolean blnResult;
			String inceptionDate= getTextUsingXpath(strInceptionDateValueXpath, INCEPTION_DATE_VALUE).trim();
			blnResult = inceptionDate.equals(testData.get("strExpectedInceptionDate"));
			return blnResult;
	}

	public boolean enterInceptionDate() {
		return enterTextUsingXpath(strInceptionDateInputXpath, testData.get("strInceptionDateInput"), INCEPTION_DATE_TEXTBOX);
	}

	public boolean isInceptionDateIconClicked() {
		 return clickElementUsingXpath(strInceptionDateCancelIconXpath, LPLCoreConstents.getInstance().LOWEST,
					INCEPTION_DATE_CANCEL_ICON);
	}

}
