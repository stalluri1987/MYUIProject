package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.webservice;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class LPLRestAPIInfo {

    private String methodType;
    private String endpoint;
    private Map<String, String> requestHeaders = new HashMap<>();
    private Map<String, String> responseHeaders = new HashMap<>();
    private Map<String, String> queryParams = new HashMap<>();
    private Map<String, String> formParams = new HashMap<>();
    private String requestPayload;
    private String responseTime;
    private String statusCode;
    private String statusLine;
    private String responseData;
    private boolean ntlmAuthentication = false;
    private String ntlmUsername;
    private String ntlmPassword;
    private String payloadType = "";

    /**
     * This is a constructor to initialize the endpoint and method type
     *
     * @param endpoint
     * @param methodType
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint) {
        setMethodType(methodType);
        setEndpoint(endpoint);
    }

    /**
     * This is a constructor to initialize the endpoint, method type and request headers
     *
     * @param methodType
     * @param endpoint
     * @param requestHeaders
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint, Map<String, String> requestHeaders) {
        setMethodType(methodType);
        setEndpoint(endpoint);
        setRequestHeaders(requestHeaders);
    }

    /**
     * This is a constructor to initialize the endpoint, method type, request headers and query parameters
     *
     * @param methodType
     * @param endpoint
     * @param requestHeaders
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint, Map<String, String> requestHeaders, Map<String, String> queryParams) {
        setMethodType(methodType);
        setEndpoint(endpoint);
        setRequestHeaders(requestHeaders);
        setQueryParams(queryParams);
    }

    /**
     * This is a constructor to initialize the endpoint, method type, request headers, query parameters and NTML authentication details
     *
     * @param methodType
     * @param endpoint
     * @param requestHeaders
     * @param queryParams
     * @param ntlmAuthentication
     * @param ntlmUsername
     * @param ntlmPassword
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint, Map<String, String> requestHeaders, Map<String, String> queryParams, boolean ntlmAuthentication, String ntlmUsername, String ntlmPassword) {
        setMethodType(methodType);
        setEndpoint(endpoint);
        setRequestHeaders(requestHeaders);
        setQueryParams(queryParams);
        setNtlmAuthenticationDetails(ntlmAuthentication, ntlmUsername, ntlmPassword);
    }

    /**
     * This is a constructor to initialize the endpoint, method type, request headers and requestPayload
     *
     * @param methodType
     * @param endpoint
     * @param requestHeaders
     * @param requestPayload
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint, Map<String, String> requestHeaders, String requestPayload) {
        setMethodType(methodType);
        setEndpoint(endpoint);
        setRequestHeaders(requestHeaders);
        setRequestPayload(requestPayload);
    }

    /**
     * This is a constructor to initialize the endpoint, method type, request headers, query parameters and requestPayload
     *
     * @param methodType
     * @param endpoint
     * @param requestHeaders
     * @param queryParams
     * @param requestPayload
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint, Map<String, String> requestHeaders, Map<String, String> queryParams, String requestPayloadType, String requestPayload) {
        setMethodType(methodType);
        setEndpoint(endpoint);
        setRequestHeaders(requestHeaders);
        setQueryParams(queryParams);
        setRequestPayload(requestPayload);
        setPayloadType(requestPayloadType);
    }

    /**
     * This is a constructor to initialize the endpoint, method type, request headers and requestPayload
     *
     * @param methodType
     * @param endpoint
     * @param requestHeaders
     * @param formParams
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint, Map<String, String> requestHeaders, String payloadType, Map<String, String> formParams) {
        setMethodType(methodType);
        setEndpoint(endpoint);
        setRequestHeaders(requestHeaders);
        setRequestFormParameters(formParams);
        setPayloadType(payloadType);
    }

    /**
     * This is a constructor to initialize the endpoint, method type, request headers, query parameters, request payload and NTML authentication details
     *
     * @param methodType
     * @param endpoint
     * @param requestHeaders
     * @param queryParams
     * @param ntlmAuthentication
     * @param ntlmUsername
     * @param ntlmPassword
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint, Map<String, String> requestHeaders, Map<String, String> queryParams, String payloadType, boolean ntlmAuthentication, String ntlmUsername, String ntlmPassword,Map<String, String> formParameters) {
        setMethodType(methodType);
        setEndpoint(endpoint);
        setRequestHeaders(requestHeaders);
        setQueryParams(queryParams);
        setNtlmAuthenticationDetails(ntlmAuthentication, ntlmUsername, ntlmPassword);
        setPayloadType(payloadType);
        setRequestFormParameters(formParameters);
    }

    /**
     * This is a constructor to initialize the endpoint, method type, request headers, query parameters, request payload and NTML authentication details
     *
     * @param methodType
     * @param endpoint
     * @param requestHeaders
     * @param queryParams
     * @param ntlmAuthentication
     * @param ntlmUsername
     * @param ntlmPassword
     * @author pmanohar
     * @since 9.19.2020
     */
    public LPLRestAPIInfo(String methodType, String endpoint, Map<String, String> requestHeaders, Map<String, String> queryParams, String payloadType, String requestPayload, boolean ntlmAuthentication, String ntlmUsername, String ntlmPassword) {
        setMethodType(methodType);
        setEndpoint(endpoint);
        setRequestHeaders(requestHeaders);
        setQueryParams(queryParams);
        setRequestPayload(requestPayload);
        setNtlmAuthenticationDetails(ntlmAuthentication, ntlmUsername, ntlmPassword);
        setPayloadType(payloadType);
    }

    /**
     * This method is used to initialize the NTML authentication details
     *
     * @param ntlmAuthentication
     * @param ntlmUsername
     * @param ntlmPassword
     * @author pmanohar
     * @since 9.19.2020
     */
    private void setNtlmAuthenticationDetails(boolean ntlmAuthentication, String ntlmUsername, String ntlmPassword) {
        this.ntlmAuthentication = ntlmAuthentication;
        this.ntlmUsername = ntlmUsername;
        this.ntlmPassword = ntlmPassword;
    }

    /**
     * This method is used to initialize the endpoint
     *
     * @param endpoint
     * @author pmanohar
     * @since 9.19.2020
     */
    private void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    /**
     * This method is used to initialize the method type(GET, POST etc)
     *
     * @param methodType
     * @author pmanohar
     * @since 9.19.2020
     */
    private void setMethodType(String methodType) {
        this.methodType = methodType;
    }

    /**
     * This method is used to initialize the request headers
     *
     * @param requestHeaders
     * @author pmanohar
     * @since 9.19.2020
     */
    private void setRequestHeaders(Map<String, String> requestHeaders) {
        this.requestHeaders = requestHeaders;
    }

    /**
     * This method is used to initialize the query parameters
     *
     * @param queryParams
     * @author pmanohar
     * @since 9.19.2020
     */
    private void setQueryParams(Map<String, String> queryParams) {
        this.queryParams = queryParams;
    }

    /**
     * This method is used to initialize the Request Payload
     *
     * @param requestPayload
     * @author pmanohar
     * @since 9.19.2020
     */
    private void setRequestPayload(String requestPayload) {
        this.requestPayload = requestPayload;
    }

    /**
     * This method is used to initialize the Request Payload(form parameters
     *
     * @param formParams
     * @author pmanohar
     * @since 9.19.2020
     */
    private void setRequestFormParameters(Map<String, String> formParams) {
        this.formParams = formParams;
    }

    /**
     * This method is used to initialize the status Code value from response object
     *
     * @param statusCode
     * @author pmanohar
     * @since 9.19.2020
     */
    public void setStatusCode(int statusCode) {
        this.statusCode = String.valueOf(statusCode);
    }

    /**
     * This method is used to initialize the status line value from response object
     *
     * @param statusLine
     * @author pmanohar
     * @since 9.19.2020
     */
    public void setStatusLine(String statusLine) {
        this.statusLine = statusLine;
    }

    /**
     * This method is used to initialize the payload type value from response object
     *
     * @param payloadType
     * @author pmanohar
     * @since 9.19.2020
     */
    public void setPayloadType(String payloadType) {
        this.payloadType = payloadType;
    }

    /**
     * This method is used to return the PayloadType value
     *
     * @return boolean
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getPayloadType() {
        return payloadType;
    }

    /**
     * This method is used to return the ntlm authentication flag value(true/false)
     *
     * @return boolean
     * @author pmanohar
     * @since 9.19.2020
     */
    public boolean getNtlmAuthentication() {
        return ntlmAuthentication;
    }

    /**
     * This method is used to return the Endpoint
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getEndpoint() {
        return endpoint;
    }

    /**
     * This method is used to return the Request Headers
     *
     * @return Map<String, String>
     * @author pmanohar
     * @since 9.19.2020
     */
    public Map<String, String> getRequestHeaders() {
        return requestHeaders;
    }

    /**
     * This method is used to return the Response Headers
     *
     * @return Map<String, String>
     * @author pmanohar
     * @since 9.19.2020
     */
    public Map<String, String> getResponseHeaders() {
        return responseHeaders;
    }

    /**
     * This method is used to return the Query Parameters
     *
     * @return Map<String, String>
     * @author pmanohar
     * @since 9.19.2020
     */
    public Map<String, String> getQueryParams() {
        return queryParams;
    }

    /**
     * This method is used to return the Request Payload
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getRequestPayload() {
        return requestPayload;
    }

    /**
     * This method is used to return the Request Payload(form parameters)
     *
     * @return Map<String, String>
     * @author pmanohar
     * @since 9.19.2020
     */
    public Map<String, String> getRequestFormParameters() {
        return formParams;
    }

    /**
     * This method is used to return the Response Time
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getResponseTime() {
        return responseTime;
    }

    /**
     * This method is used to return the Status Code
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * This method is used to return the Status line
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getStatusLine() {
        return statusLine;
    }

    /**
     * This method is used to return the Response Data
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getResponseData() {
        return responseData;
    }

    /**
     * This method is used to return the NTLM username
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getNtlmUserName() {
        return ntlmUsername;
    }

    /**
     * This method is used to return the ntlm password
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getNtlmPassword() {
        return ntlmPassword;
    }

    /**
     * This method is used to initialize the response headers, response data and response time using the response object
     *
     * @param response
     * @author pmanohar
     * @since 9.19.2020
     */
    public void setResponseDetails(Response response) {
        Headers headers = response.getHeaders();
        if (!response.getHeaders().asList().isEmpty())
            for (Header header : headers)
                responseHeaders.put(header.getName(), header.getValue());

        setStatusCode(response.statusCode());
        setStatusLine(response.statusLine());
        this.responseData = response.getBody().asString();
        this.responseTime = String.valueOf(response.getTime());
    }

    /**
     * This method is used to set the response details using the given HttpResponse object
     *
     * @param response
     * @param responseTime
     * @author pmanohar
     * @since 9.19.2020
     */
    public void setResponseDetails(HttpResponse response, long responseTime) {
        org.apache.http.Header[] headers = response.getAllHeaders();
        for (org.apache.http.Header header : headers)
            responseHeaders.put(header.getName(), header.getValue());
        setStatusCode(response.getStatusLine().getStatusCode());
        setStatusLine(response.getStatusLine().toString());
        this.responseData = getResponse(response);
        this.responseTime = String.valueOf(responseTime);
    }

    /**
     * This method is used to set the response string(json/html) using the given HttpResponse object
     *
     * @param response
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    private String getResponse(HttpResponse response) {
        HttpEntity entity = response.getEntity();
        try {
            return EntityUtils.toString(entity, "UTF-8");
        } catch (IOException | ParseException e) {
            LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Retrieve the response JSON from the HTTPResponse object",
                    "Response should be successfully retrieved",
                    "Response is successfully retrieved",
                    "Unable to retrieve the response from HTTPResponse object. Error message: " + e.getMessage(), false);
        }
        return "";
    }

    /**
     * This method is used to return method type
     *
     * @return String
     * @author pmanohar
     * @since 9.19.2020
     */
    public String getMethodType() {
        return methodType;
    }

    /**
     * This method is used to add additional query parameters(dynamic ones not stored as testdata in FARM)
     *
     * @param queryParameters
     * @author pmanohar
     * @since 9.19.2020
     */
    public void addQueryParams(Map<String, String> queryParameters) {
        for (Map.Entry<String, String> queryParameter : queryParameters.entrySet())
            queryParams.put(queryParameter.getKey(), queryParameter.getValue());
    }

    /**
     * This method is used to add additional header parameters(dynamic ones not stored as testdata in FARM)
     *
     * @param headerParameters
     * @author pmanohar
     * @since 9.19.2020
     */
    public void addHeaders(Map<String, String> headerParameters) {
        for (Map.Entry<String, String> headerParameter : headerParameters.entrySet())
            requestHeaders.put(headerParameter.getKey(), headerParameter.getValue());
    }

}
