package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.util.HashMap;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import LPLCoreDriver.LPLCoreUtil;

public class Navigation extends Common implements ILocatorInitialize {
	public static final int PAGE_IDENTIFIER = 792;

	public static final String TIERED_ADVISORY_FEE_SCHEDULES = "Tiered Advisory Fee Schedules";
	public static final String CLIENT_FEE_SCHEDULE = "Client Fee Schedule";
	public static final String MUTUAL_FUNDS = "Mutual Funds";
	public static final String EQUITIES = "Equities";
	public static final String OPTIONS = "Options";
	public static final String SUMMARY = "Summary";
	public static final String INVESTMENTS = "Investments";
	public static final String ORDERS = "Orders";
	public static final String ACTIVITY = "Activity";
	public static final String EDIT_HOUSEHOLD_GROUP = "Edit Household Group";
	public static final String EDIT_MWP_TAX_HARVESTING = "MWP Tax Harvesting";
	public static final String EDIT_MWP_REBALANCE_FREQ_CHANGE = "MWP Rebalancing Frequency Change";
	public static final String RUN_REPORT = "Run Report";
	public static final String ACH_TRANSFER = "ACH Transfer";
	public static final String ENROLL_CLIENT = "Enroll Client";
	public static final String ANNUAL_CLIENT_REVIEW = "Annual Client Review";
	public static final String PHONE_CALL = "Phone Call";
	public static final String ACCOUNT_SUMMARY = "Account Summary";
	public static final String FORMS = "Forms";
	public static final String COPY = "Copy";
	public static final String COPY_2_0 = "Copy 2.0";
	public static final String REQUESTS = "Requests";
	public static final String DOCUMENTS = "Documents";
	public static final String STATEMENTS = "Statements";
	public static final String CREATE_NEW_USER_DEFINED_GROUP = "Create New User Defined Group";
	public static final String ADD_TO_USER_DEFINED_GROUP = "Add to User Defined Group";
	public static final String CREATE_ACCOUNT = "Create Account";
	public static final String CREATE_ACCOUNT_2_0 = "Create Account 2.0";
	public static final String CREATE_ONLINE_REQUEST = "Create Online Request";
	public static final String SCHEDULE_REPORT = "Schedule Report";
	public static final String ASSIGN_BENCHMARK = "Assign Benchmark";
	public static final String PORTFOLIO_REVIEW = "Portfolio Review";
	public static final String PORTFOLIO_COMPARISON = "Portfolio Comparison";
	public static final String OUTGOING_ACCOUNT_TRANSFER = "Outgoing Account Transfer";
	public static final String SUBMENU = " submenu";
	public static final String FIXED_INCOME = "Fixed Income";
	public static final String EVENT = "Event";
	public static final String IMPERSONATE_CLIENT = "Impersonate Client";
	public static final String ACCOUNT_JOURNAL = "Account Journal";
	public static final String ACCOUNT_MULTI_JOURNAL = "Account Multi Journal";
	public static final String ACCOUNT_ADD_CHANGE_RECURRING = "Account Add/Change Recurring";
	public static final String ACCOUNT_PROFILE = "Account Profile";
	public static final String ACCOUNT_INVESTMENTS = "Account Investments";
	public static final String ACCOUNT_ORDERS = "Account Orders";
	public static final String ACCOUNT_ACTIVITY = "Account Activity";
	public static final String ACCOUNT_REQUESTS = "Account Requests";
	public static final String ACCOUNT_DOCUMENTS = "Account Documents";
	public static final String ACCOUNT_STATEMENTS = "Account Statements";
	public static final String ACCOUNT_CRM = "Account CRM";
	public static final String ACCOUNT_ADDRESS = "Account Address";
	public static final String ACCOUNT_ACCOUNT_OPTIONS = "Account Account Options";
	public static final String ACCOUNT_CONVERT_ACCOUNT = "Account Convert Account";
	public static final String ACCOUNT_CLOSE_ACCOUNT = "Account Close Account";
	public static final String ACCOUNT_LINK_ACCOUNT = "Account Link Account";
	public static final String ACCOUNT_TIERED_ADVISORY_FEE_SCHEDULES = "Account Tiered Advisory Fee Schedules";
	public static final String ACCOUNT_CLIENT_FEE_SCHEDULE = "Account Client Fee Schedule";
	public static final String ACCOUNT_COPY = "Copy Account";
	public static final String ACCOUNT_COPY_2_0 = "Account Copy 2.0";
	public static final String ACCOUNT_ACH = "Account ACH";
	public static final String ACCOUNT_CHECK = "Account Check";
	public static final String ACCOUNT_WIRE = "Account Wire";
	public static final String ACCOUNT_WRITEOFF = "Account Writeoff";
	public static final String ACCOUNT_COMPLEX_RETIREMENT = "Account Complex Retirement";
	public static final String ACCOUNT_ACH_TRANSFER = "Account ACH Transfer";
	public static final String ACCOUNT_ADD_INSTRUCTIONS = "Account Add Instructions";
	public static final String INVALID_PAGE_NAME = "Invalid page name[";
	public static final String IS_PASSED = "] is passed.";
	public static final String BLANK = "";
	HashMap<String, HashMap<String, String>> pageObjectMap;

	public static final String ENTERTRADEWINDOW = "Enter Trade Window";

	String strTabNameXpath;
	String strMoreMenuXpath;
	String strMoreMenuItemXpath;
	String strClientContextMenuXpath;
	String strAccountContextMenuXpath;
	String strClientGoalsXpath;
	String strClientInvestmentsXpath;
	String strClientOrdersXpath;
	String strClientActivityXpath;
	String strClientRequestsXpath;
	String strClientDocumentsXpath;
	String strClientStatementsXpath;
	String strClientCRMXpath;
	String strClientSummaryHeaderTextXpath;
	String strClientNameXpath;
	String strAccountNameXpath;
	String strEditClientModalWindowHeaderXpath;
	String strAccountSummaryHeaderXpath;
	String strAccountProfileHeaderXpath;
	String strAccountInvestmentHeaderXpath;
	String strAccountsOrderHeadersXpath;
	String strAccountActivitiesXpath;
	String strAccountRequestsXpath;
	String strAccountDocumentsXpath;
	String strAccountStatementsXpath;
	String strAccountCreateNewHouseholdGroupXpath;
	String strAccountBlueSkyPreOrderCheckXpath;
	String strAccountACHXpath;
	String strAccountWireXpath;
	String strAccountJournalXpath;
	String strAccountMultiJournalXpath;
	String strAccountAddChangeRecurringXpath;
	String strAccountWriteOffXpath;
	String strAccountAddtoHouseholdGroupXpath;
	String strAccountCreateNewUserDefinedGroupXpath;
	String strAccountAddtoUserDefinedGroupXpath;
	String strAccountCRMXpath;
	String strCloseAccountXpath;
	String strCopyXpath;
	String strCopy2Xpath;
	String strACHTransferXpath;
	String strAddInstructionsXpath;
	String strBuyAnnuityXpath;
	String strAccountTransferXpath;
	String strRunReportXpath;
	String strScheduleReportXpath;
	String strAssignBenchmarkXpath;
	String strPortfolioReviewXpath;
	String strPortfolioComparisonXpath;
	String strPortfolioRebalanceXpath;
	String strCreateOnlineRequestXpath;
	String strFormsXpath;
	String strAccountOptionsXpath;
	String strConvertAccountXpath;
	String strMWPTaxHoldingsTitleXpath;
	String strMWPRebalancingFreqChangeTitleXpath;

	public static final String QUITHOLDCANCELREQUEST = "Yes, Quit Hold Cancel Request";
	public static final String CANCELORDER = "Yes, Cancel Order";
	public static final String SYMBOLNAME = "AAPL";
	public static final String SEARCHBUTTON = "Search button";
	public static final String EMPTY_TEXT = "";
	public static final String BUY = "BUY";
	public static final String SELL = "SELL";
	public static final String SHORTSELL = "SHORT SELL";
	public static final String COMMISSIONCALCULATOR = "Calculate Commission";
	public static final String CHANGEDIVIDENDOPTIONS = "Instructions for";
	public static final String HOLD = "HOLD";
	public static final String ASSETCLASSOVERRIDE = "Asset Class Override";
	public static final String PRICEHISTORY = "Price History";
	public static final String MODALBUY = "Buy";
	public static final String MODALSELL = "Sell";
	public static final String MODALSHORTSELL = "Short Sell";
	public static final String MODALCOMMISSIONCALCULATOR = "Commission Calculator";
	public static final String MODALCHANGEDIVIDENDOPTIONS = "Change Dividend Options";
	public static final String MODALHOLD = "Hold";
	public static final String REMOVETEXT = "Symbol / CUSIP / ID:";
	public static final String EMPTYWHITESPACE = " ";
	public static final String CLOSEWINDOW = "Close Window";
	public static final String CONFIRMATIONMESSAGE = "Confirmation Messsage";
	public static final String INVESTMENTSPAGE = "Investments Page";
	public static final String VALUE = "Value";
	public static final String SEARCHACCOUNT = "Search Acconunt";
	public static final String ACCOUNTNOTEXTBOX = "Account Number TextBox";
	public static final String CROSSICON = "Cross Icon";
	public static final String CLOSEICON = "Close Icon";
	public static final String CLOSEBUTTON = "Close Button";
	public static final String IMPORTANTINFORMATIONLINK = "Important Information Link";
	public static final String IMPORTANTINFORMATIONWINDOW = "Important Information Window";
	public static final String CONTENT = "Content";
	public static final String CLICKHERELINK = "Click Here Link";
	public static final String VIEWALLOPENNOTIFICATIONLINK = "View All Open Notifications Link";
	public static final String COUNTOFNOTIFICATIONS = "Count Of Notifications";
	public static final String ALLTASKQUICKVIEW = "All Task Quick View Selected";
	public static final String CLIENTWORKSNOTIFICATIONPAGE = "ClientWorks Notification Page";
	public static final String SEARCHACCOUNTHOLDINGS = "Search Account holdings";
	public static final String SEARCHACCOUNTHOLDINGSSELECTED = "Search Account Holdings Selected";
	public static final String SYMBOLTEXTBOX = "Symbol Text Box";
	public static final String HOME_PAGE = "Home Page";
	public static final String REPORTPAGE = "Report Page";
	public static final String CLIENTLINK = "Client Link";
	public static final String ACCOUNTNUMBERLINK = "Account Number Link";

	public Navigation(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		checkForLocatorTypeAndInitializeFields(pageObjectMap, this.getClass().getDeclaredFields(), PAGE_IDENTIFIER);
	}

	/**
	 * This method is used for navigating to the specified page
	 *
	 * @param tabName - Name of the tab in the menu bar
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	public boolean navigateToPage(String tabName) {
		boolean blnResult;
		String elementName = tabName + " Tab";
		// check for the tabName
		if (isTabNameVisibleOnPage(tabName))
			// click on tab Name
			blnResult = clickElementUsingXpath(getFormattedLocator(strTabNameXpath, tabName), elementName);
		else {
			// click on more menu
			clickMoreMenu();
			// click on more menu items
			blnResult = clickElementUsingXpath(getFormattedLocator(strMoreMenuItemXpath, tabName), elementName);
		}
		// wait for the page load
		waitForPageLoading();
		return blnResult;
	}

	/**
	 * This method is used for retrieving the menu option for the give page name
	 *
	 * @param pageName - name of the page
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	public String getSubMenu(String pageName) {
		switch (pageName) {
		case FORMS:
		case COPY:
		case COPY_2_0:
		case CREATE_ONLINE_REQUEST:
			return "";
		default:
			return pageName;
		}
	}

	/**
	 * This method is used for navigating to a specified page from the client
	 * context menu
	 *
	 * @param pageName     - name of the page
	 * @param contextValue - Client Name
	 * @author pmanohar
	 * @since 09/09/2019
	 * 
	 *        public boolean navigateToPageFromClientContextMenu(String pageName,
	 *        String contextValue) { boolean blnResult = false; try { //get the
	 *        Client Context menu locator String contextMenuLocator =
	 *        getFormattedLocator(strClientContextMenuXpath, contextValue); //mouse
	 *        over on client name
	 *        LPLCoreUtil.mouseHoverJScript(driver.findElement(By.xpath(getFormattedLocator(strClientNameXpath,
	 *        contextValue, contextValue)))); //click on specified page from context
	 *        menu blnResult =
	 *        iasTradingCommon.performContextOrActionDropdown(getMainMenuForClientSubMenu(pageName),
	 *        pageName, getSubPageNameClient(pageName),
	 *        By.xpath(contextMenuLocator)); //wait for the page to load
	 *        waitForPageLoading(); } catch (Exception e) {
	 *        LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE,
	 *        "Navigating to " + pageName + " from Client context menu", pageName +
	 *        " page should be loaded", pageName + " page is loaded", pageName + "
	 *        page is not loaded"); } return blnResult; }
	 */

	/**
	 * This method is used for check if tab name is visible
	 *
	 * @param tabName - name of the tab
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	private boolean isTabNameVisibleOnPage(String tabName) {
		// check if tab name is visible
		return isElementPresentUsingXpath(DISPLAYED, getFormattedLocator(strTabNameXpath, tabName), tabName + " Tab");
	}

	/**
	 * This method is used for navigating to a specified page from the Account
	 * context menu
	 *
	 * @param pageName     - name of the page
	 * @param contextValue - Client Name
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	public boolean navigateToPageFromAccountContextMenu(String pageName, String contextValue) {
		boolean blnResult = false;
		try {
			// get the Account Context menu locator
			String contextMenuLocator = getFormattedLocator(strAccountContextMenuXpath, contextValue);
			LPLCoreSync.staticWait(lplCoreConstents.BaseInMiliSec);
			// mouse over on Account Number
			LPLCoreUtil.mouseHoverJScript(
					driver.findElement(By.xpath(getFormattedLocator(strAccountNameXpath, contextValue))));
			// click on specified page from context menu
			blnResult = iasTradingCommon.performContextOrActionDropdown(getMainMenuForAccountSubMenu(pageName),
					getSubMenu(pageName), getSubPageNameAccount(pageName), By.xpath(contextMenuLocator));
			// wait for the page to load
			waitForPageLoading();
			return blnResult;
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE,
					"Navigating to " + pageName + " from Account context menu", pageName + " page should be loaded",
					pageName + " page is loaded", pageName + " page is not loaded");
		}
		return blnResult;
	}

	/**
	 * This method is used for click on More Menu
	 *
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	private boolean clickMoreMenu() {
		// click on More Menu
		return clickElementUsingXpath(strMoreMenuXpath, "More Menu");
	}

	/**
	 * This method is used get the Sub page Name for Account Context Menu
	 *
	 * @param pageName - name of the Page
	 * @author Naga Praveen
	 * @since 09/09/2019
	 */
	public String getSubPageNameAccount(String pageName) {
		switch (pageName) {
		case TIERED_ADVISORY_FEE_SCHEDULES:
			return "A2A 2TGC";
		case CLIENT_FEE_SCHEDULE:
			return "FCF Schedule Settings";
		case "Check":
			return "Send";
		case MUTUAL_FUNDS:
		case EQUITIES:
		case FIXED_INCOME:
		case "UIT":
			return "Buy";
		case OPTIONS:
			return "Buy to Open";
		default:
			return "";
		}
	}

	/**
	 * This method is used get the Sub page Name for Client Context Menu
	 *
	 * @param pageName - name of the Page
	 * @author Naga Praveen
	 * @since 09/09/2019
	 */
	public String getSubPageNameClient(String pageName) {
		// To get the Sub page Name
		if (pageName.equalsIgnoreCase(TIERED_ADVISORY_FEE_SCHEDULES))
			return "TAFS Schedule Settings";
		else
			return "";
	}

	/**
	 * This method is used for check if the Page is loaded from Client Context Menu
	 *
	 * @param pageName - name of the Page
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	public boolean isPageLoadedForClient(String pageName) {
		switch (pageName) {
		case SUMMARY:
			return isElementPresentUsingXpath(strClientSummaryHeaderTextXpath, lplCoreConstents.VERYHIGH,
					"Client Summary");
		case "Goals":
			return isElementPresentUsingXpath(strClientGoalsXpath, lplCoreConstents.VERYHIGH, "Client Goals");
		case INVESTMENTS:
			return isElementPresentUsingXpath(strClientInvestmentsXpath, lplCoreConstents.VERYHIGH,
					"Client Investments");
		case ORDERS:
			return isElementPresentUsingXpath(strClientOrdersXpath, lplCoreConstents.VERYHIGH, "Client Orders");
		case ACTIVITY:
			return isElementPresentUsingXpath(strClientActivityXpath, lplCoreConstents.VERYHIGH, "Client Activity");
		case REQUESTS:
			return isElementPresentUsingXpath(strClientRequestsXpath, lplCoreConstents.VERYHIGH, "Client Requests");
		case DOCUMENTS:
			return isElementPresentUsingXpath(strClientDocumentsXpath, lplCoreConstents.VERYHIGH, "Client Documents");
		case STATEMENTS:
			return isElementPresentUsingXpath(strClientStatementsXpath, lplCoreConstents.VERYHIGH, "Client Statements");
		case "CRM":
			return isElementPresentUsingXpath(strClientCRMXpath, lplCoreConstents.VERYHIGH, "Client CRM");
		case "Send Check":
			return isElementPresentUsingXpath("", lplCoreConstents.VERYHIGH, "Send Check");
		case ENROLL_CLIENT:
			return isElementPresentUsingXpath("", lplCoreConstents.VERYHIGH, ENROLL_CLIENT);

		default:
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE,
					"Check if " + pageName + "page is displayed", pageName + " page should be displayed",
					pageName + " page is displayed", INVALID_PAGE_NAME + pageName + IS_PASSED);
		}
		return false;
	}

	/**
	 * This method is used for switch to a Frame
	 *
	 * @param strFrame1
	 * @param strFrame2
	 * @param strFrame3
	 * @author Taheer
	 * @since 09/09/2019
	 */

	public boolean switchTo(String strFrame1, String strFrame2, String strFrame3) {
		boolean blnResult = false;
		try {
			// switch to default content
			driver.switchTo().defaultContent();
			// store the string array in frames
			String[] frames = { strFrame1, strFrame2, strFrame3 };
			// Using for each loop store the Framename value
			for (String framename : frames) {
				// if it's not null or else null switch to frame
				if (framename != null && !framename.equals(BLANK)) {
					// switch to frame
					driver.switchTo().frame(framename);
					blnResult = true;
				}
			}
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			blnResult = false;
		}
		return blnResult;
	}

	/**
	 * This method is used for switch to a Frame
	 *
	 * @author Taheer
	 * @since 09/09/2019
	 */
	public void switchToFrame() {
		// switch to a Frame
		switchTo("iframe-modal-frame", "", "");
	}

	/**
	 * This method is used for switch to an window
	 *
	 * @author Taheer
	 * @since 09/09/2019
	 */
	public boolean switchWindow() {
		try {
			Set<String> strWindows = driver.getWindowHandles();
			// Using for each loop store the window value
			for (String eachWindow : strWindows) {
				// switch to window
				driver.switchTo().window(eachWindow);
			}
			return true;
		} catch (Exception ex) {
			setErrorMessage(ex.getMessage());
			return false;
		}
	}

	/**
	 * This method is used for check if the Page is loaded from Account Context Menu
	 *
	 * @param pageName - name of the Page
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	public boolean isPageLoadedForAccount(String pageName) {
		switch (pageName) {
		case ACCOUNT_SUMMARY:
			return isElementPresentUsingXpath(strAccountSummaryHeaderXpath, lplCoreConstents.VERYHIGH, ACCOUNT_SUMMARY);
		case ACCOUNT_PROFILE:
			return isElementPresentUsingXpath(strAccountProfileHeaderXpath, lplCoreConstents.VERYHIGH, ACCOUNT_PROFILE);
		case ACCOUNT_INVESTMENTS:
			return isElementPresentUsingXpath(strAccountInvestmentHeaderXpath, lplCoreConstents.VERYHIGH,
					ACCOUNT_INVESTMENTS);
		case ACCOUNT_ORDERS:
			return isElementPresentUsingXpath(strAccountsOrderHeadersXpath, lplCoreConstents.VERYHIGH, ACCOUNT_ORDERS);
		case ACCOUNT_ACTIVITY:
			return isElementPresentUsingXpath(strAccountActivitiesXpath, lplCoreConstents.VERYHIGH, ACCOUNT_ACTIVITY);
		case ACCOUNT_REQUESTS:
			return isElementPresentUsingXpath(strAccountRequestsXpath, lplCoreConstents.VERYHIGH, ACCOUNT_REQUESTS);
		case ACCOUNT_DOCUMENTS:
			return isElementPresentUsingXpath(strAccountDocumentsXpath, lplCoreConstents.VERYHIGH, ACCOUNT_DOCUMENTS);
		case ACCOUNT_STATEMENTS:
			return isElementPresentUsingXpath(strAccountStatementsXpath, lplCoreConstents.VERYHIGH, ACCOUNT_STATEMENTS);
		case ACCOUNT_CRM:
			return isElementPresentUsingXpath(strAccountCRMXpath, lplCoreConstents.VERYHIGH, ACCOUNT_CRM);
		case ACCOUNT_ACCOUNT_OPTIONS:
			switchToFrame();
			return isElementPresentUsingXpath(strAccountOptionsXpath, lplCoreConstents.BaseInMiliSec,
					ACCOUNT_ACCOUNT_OPTIONS);
		case ACCOUNT_CONVERT_ACCOUNT:
			switchToFrame();
			return isElementPresentUsingXpath(strConvertAccountXpath, lplCoreConstents.BaseInMiliSec,
					ACCOUNT_CONVERT_ACCOUNT);
		case ACCOUNT_CLOSE_ACCOUNT:
			switchToFrame();
			return isElementPresentUsingXpath(strCloseAccountXpath, lplCoreConstents.BaseInMiliSec,
					ACCOUNT_CLOSE_ACCOUNT);
		case ACCOUNT_COPY:
			return isElementPresentUsingXpath(strCopyXpath, lplCoreConstents.BaseInMiliSec, ACCOUNT_COPY);
		case ACCOUNT_COPY_2_0:
			switchWindow();
			return isElementPresentUsingXpath(strCopy2Xpath, lplCoreConstents.VERYHIGH, ACCOUNT_COPY_2_0);
		case ACCOUNT_ACH:
			return isElementPresentUsingXpath(strAccountACHXpath, ACCOUNT_ACH);
		case ACCOUNT_WIRE:
			return isElementPresentUsingXpath(strAccountWireXpath, ACCOUNT_WIRE);
		case ACCOUNT_JOURNAL:
			return isElementPresentUsingXpath(strAccountJournalXpath, ACCOUNT_JOURNAL);
		case ACCOUNT_MULTI_JOURNAL:
			return isElementPresentUsingXpath(strAccountAddChangeRecurringXpath, ACCOUNT_MULTI_JOURNAL);
		case ACCOUNT_ADD_CHANGE_RECURRING:
			return isElementPresentUsingXpath(strAccountAddChangeRecurringXpath, ACCOUNT_ADD_CHANGE_RECURRING);
		case ACCOUNT_WRITEOFF:
			return isElementPresentUsingXpath(strAccountWriteOffXpath, ACCOUNT_WRITEOFF);
		case ACCOUNT_COMPLEX_RETIREMENT:
			return isElementPresentUsingXpath(strAccountWriteOffXpath, ACCOUNT_COMPLEX_RETIREMENT);
		case ACCOUNT_ACH_TRANSFER:
			switchWindow();
			return isElementPresentUsingXpath(strACHTransferXpath, lplCoreConstents.BaseInMiliSec,
					ACCOUNT_ACH_TRANSFER);
		default:
		}
		return false;
	}

	/**
	 * This method is used to get Main Menu from Account Context Menu
	 *
	 * @param subMenu - name of the SubMenu
	 * @author pmanohar
	 * @since 09/09/2019
	 */
	private String getMainMenuForAccountSubMenu(String subMenu) {
		switch (subMenu) {
		case SUMMARY:
			return "View";
		case "Profile":
		case INVESTMENTS:
		case ORDERS:
		case ACTIVITY:
		case REQUESTS:
		case DOCUMENTS:
		case STATEMENTS:
			return "View";
		case "Address":
		case "Account Holder":
		case "Financials/Suitability":
		case "Account Options":
		case "Convert Account":
		case "Close Account":
		case "Link Account":
		case TIERED_ADVISORY_FEE_SCHEDULES:
		case CLIENT_FEE_SCHEDULE:
			return "Edit";
		case "Tax Harvesting":
			return "Edit";
		case "Rebalancing Frequency Change":
			return "Edit";
		case COPY:
			return COPY;
		case COPY_2_0:
			return COPY_2_0;
		case "ACH":
			return "Move Money";
		case "Check":
		case "Wire":
		case "Journal":
		case "Multi Journal":
		case "Add/Change Recurring":
		case "Writeoff":
		case "Complex Retirement":
			return "Move Money";
		case ACH_TRANSFER:
		case "Add Instructions":
			return "Move Money 2.0";
		case MUTUAL_FUNDS:
		case EQUITIES:
		case OPTIONS:
		case FIXED_INCOME:
		case "UIT":
		case "Buy Annuity":
		case "Buy Alternative Investment":
		case MODALCOMMISSIONCALCULATOR:
		case "BlueSky Pre-Order Check":
			return "Trade";
		case "Incoming Account Transfer":
		case OUTGOING_ACCOUNT_TRANSFER:
			return "Account Transfer";
		case RUN_REPORT:
		case SCHEDULE_REPORT:
		case ASSIGN_BENCHMARK:
		case PORTFOLIO_REVIEW:
		case PORTFOLIO_COMPARISON:
		case "Portfolio Rebalance":
			return "Reports";
		case CREATE_ONLINE_REQUEST:
			return CREATE_ONLINE_REQUEST;
		case EDIT_HOUSEHOLD_GROUP:
		case "Create New Household Group":
		case "Add to Household Group":
		case CREATE_NEW_USER_DEFINED_GROUP:
		case ADD_TO_USER_DEFINED_GROUP:
		case "Create Combined Statement Group":
			return "Group";
		case FORMS:
			return FORMS;
		case MODALCHANGEDIVIDENDOPTIONS:
			return "Security Management";
		default:
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE,
					"Retrieving the menu name for " + subMenu + SUBMENU, "Menu name should be retrieved",
					"Menu name is retrieved", "Failed to retrieve menu name for " + subMenu + SUBMENU);
		}
		return "";
	}
}