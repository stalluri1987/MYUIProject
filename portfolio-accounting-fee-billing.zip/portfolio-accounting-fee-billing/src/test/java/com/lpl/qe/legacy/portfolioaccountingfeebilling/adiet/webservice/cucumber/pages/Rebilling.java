package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> Rebilling.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for Rebilling</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class Rebilling extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 683;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String REPOSITORYLOCATION = "\\\\qa2000server\\QTP_Repository\\temp\\Abdul\\ADIET_Portfolio_Accounting\\";
	public static final String XLSX = ".xlsx";
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String REBILLING_PAGE_HEADER = "Rebilling Page Header";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String BROWSE_BUTTON = "Browse Button";
	public static final String PRECALCULATION = "PreCalculation";
	public static final String QA_AUTOMATION_USER = "qa-automation";
	public static final String OPTIONS = "options";
	public static final String DEFAULT_VALUE = "0.00";
	public static final String DOWNLOADEDFILEREPOSITORYLOCATION = LPLCoreConstents.getInstance().DefaultDownloadFolder;
	public static final String ACAT = "ACATs Termination";
	public static final String UPLOAD_BUTTON = "Upload Button";
	public static final String PORTFOLIO_NUMBER = "Portfolio Number";
	public static final String PRICING_MODEL_DISPLAYED = "Pricing Model displayed Successfully";
	public static final String PROCESS_BUTTON = "Process Button";
	public static final String CHECK_BOX = "Check Box";
	public static final String ACAT_TERM_SAMPLE_TEMPLATE_WITH_EXTENSION = "AcatsTermSampleTemplate.xlsx";
	public static final String ACAT_TERM_SAMPLE_TEMPLATE_LINK = "ACAT Termination Sample Template Link";
	public static final String TERMINATION_TYPE_DROPDOWN = "Termination Type Dropdown";
	public static final String TERMINATED_ACCOUNTS = "TerminatedAccounts";
	public static final String ADHOC_TERM_SAMPLE_TEMPLATE_WITH_EXTENSION = "AdhocTermSampleTemplate.xlsx";
	public static final String ADHOC_TERM_SAMPLE_TEMPLATE_LINK = "Adhoc Termination Sample Template Link";
	public static final String RECORD_DELETED = "Record Deleted";
	public static final String DELETE_BUTTON_IN_CONFIRMATION_POPUP = "Delete Button in confirmation pop up";
	public static final String DELETE_ADJUSTMENT_POPUP = "Delete Adjustment PopUp";
	public static final String PREMIUM_FEE_NOT_CALCULATED = "Premium Fee Not Calculated";
	public static final String PREMIUM_FEE_CALCULATED = "Premium Fee Calculated";
	public static final String ADJUSTMENT_DETAILS = "Adjustment Details";
	public static final String CLOSE_BUTTON = "Close Button";
	public static final String DATA_UPDATED = "Data Updated";
	public static final String DETAILS_SAVED_SUCCESSFULLY = "Details saved successfully";
	public static final String MODIFY_NET_CLIENT_CHARGE = "Modify Net Client Charge";
	public static final String MODIFY_ADMIN_FEE = "Modify Admin Fee";
	public static final String PORTFOLIO_LINK = "Portfolio Link";
	public static final String ADJUSTMENT_ADDED_SUCCESSFULLY = "Adjustment Added Successfully";
	public static final String ACCOUNT_NUMBER = "Account Number";
	public static final String SAVE_BUTTON = "Save Button";
	public static final String NOTES_TEXT = "Notes Text";
	public static final String CLEAR_GROSS_BROKER_PAYOUT = "Clear Gross Broker PayOut value";
	public static final String CLEAR_NET_CLIENT_CHARGE = "Clear Net Client Charge value";
	public static final String MODIFY_GROSS_BROKER_PAYOUT = "Modify Gross Broker PayOut";
	public static final String GROSS_BROKER_PAYOUT = "Gross Broker PayOut";
	public static final String NET_CLIENT_CHARGE = "Net Client Charge";
	public static final String EFFECTIVE_DATE = "Effective date";
	public static final String QUARTER_END_DATE = "Quarter end date";
	public static final String EDIT_ADJUSTMENT_POPUP = "Edit Adjustment PreCalc Popup";
	public static final String ADD_ADJUSTMENT_POPUP = "Add Adjustment PreCalc Popup";
	public static final String SELECT_PRECALC = "Select PreCalc";
	public static final String ADD_ADJUSTMENT_BUTTON = "Add Adjustment Button";
	public static final String ADHOC_TERMINATION = "ADHOC Termination";
	public static final String ADHOC_TERMINATION_TAB = "Account Termination Tab";
	public static final String SEARCH_BUTTON = "Search Button";
	public static final String USERS_DROPDOWN = "Users Drop down";
	public static final String PRICING_MODEL_DROPDOWN = "Pricind Model Dropdown";
	public static final String STATUS_DROPDOWN = "Status Dropdown";
	public static final String SOURCE_DROPDOWN = "Source DropDown";
	public static final String ALL = "All";
	public static final String PENDING = "Pending";
	public static final String DELETE_BUTTON = "Delete Button";
	public static final String DELETE_POPUP_WINDOW = "Delete Pop Up Window";
	public static final String DELETE_ICON = "Delete Icon";
	public static final String PRECALC_SAMPLE_TEMPLATE = "PreCalcSampleTemplate";
	public static final String ACAT_SAMPLE_TEMPLATE = "AcatsTermSampleTemplate";
	public static final String FEECYCLE_SAMPLE_TEMPLATE = "FeeCycleSmapleTemplate";
	public static final String ADDHOC_TERM_TEMPLATE = "AdhocTermfilePath";
	public static final String USERNAME = "User Name";
	public static final String PRECALC = "PreCalc";
	public static final String ADJUSTMENT_TAB = "Adjustment Tab";
	public static final String FILE_UPLOADED_MESSAGE = "File Uploaded Message";
	public static final String PRECALC_SAMPLE_TEMPLATE_WITH_EXTENSION = "PreCalcSampleTemplate.xlsx";
	public static final String UPLOADED_BUTTON_ENABLE = "Uploaded Button Enable";
	public static final String FILETYPE_DROPDOWN = "File Type DropDown";
	public static final String PRECALC_SAMPLE_TEMPLATE_LINK = "Precalc Sample Template Link";
	public static final String FILE_FORMAT_HINT_TEXT = "File Format hint Text";
	public static final String UPLOADED_BUTTON_DISABLED = "Upload Button Disabled";
	public static final String LPL_SWS = "LPL SWS";
	public static final String EMPLOYEE_MODEL = "EMPLOYEE MODEL";
	public static final String REP_AUM = "REP AUM";
	public static final String NO_PRICING = "";
	public static final String PREMIUM_FEE = "Premium Fee";
	public static final String EMPLOYEE_REBATE = "Employee Rebate";
	public static final String SELECT_ALL = "Select All";
	public static final String PORTFOLIO_NMBER = "Portfolio Number";
	public static final String FEE_CYCLE_CHKBOX = "Fee Cycle checkBox";
	public static final String FEE_CYCLE_BROWSE = "Fee Cycle Browse";
	public static final String FEE_CYCLE_TEMPLATE = "Fee Cycle Sample";
	public static final String FEE_CYCLE = "Fee Cycle";
	public static final String SRC_FEE_CYCLE = "FeeCycle";
	public static final String TRADE_ADMIN_FEE = "Trade Admin Fee";
	public static final String ALL_USER = "Select All";
	public static final String DISABLED = "disabled";
	public static final String TRUE = "true";
	public static final String EXPORT_BUTTON = "Export button";
	public String strDownloadedFileFullPath = "";
	public long intTotalRows = 0;
	public static final String TOTAL_ROWS = "Total Rows";
	public static final String CLOSE_USERDROPDOWN = "Close User Drop Down";
	public static final String GLOBAL_BROKER_TERMINATION = "Global Broker Termination";
	public static final String GLOBAL_BROKER_TERM_SAMPLE_TEMPLATE_LINK = " GlobalBrokerTerm Sample Template Link";
	public static final String GLOBAL_BRK_TERM_SAMPLE_TEMPLATE_WITH_EXTENSION = "GlobalBrkTermSampleTemplate.xlsx";
	public static final String GLOBAL_BRK_SAMPLE_TEMPLATE = "GlobalBrkTermSampleTemplate";

	String acatTermfilePath = LPLCoreConstents.getInstance().DefaultDownloadFolder + "\\AcatsTermSampleTemplate.xlsx";
	String preCalcfilePath = LPLCoreConstents.getInstance().DefaultDownloadFolder + "\\PreCalcSampleTemplate.xlsx";
	String adhocTermfilePath = LPLCoreConstents.getInstance().DefaultDownloadFolder + "\\AdhocTermSampleTemplate.xlsx";
	String feeCyclefilePath = LPLCoreConstents.getInstance().DefaultDownloadFolder + "\\FeeCycleSampleTemplate.xlsx";
	String globalBrokerTermfilePath = LPLCoreConstents.getInstance().DefaultDownloadFolder
			+ "\\GlobalBrkTermSampleTemplate.xlsx";
	String strRebillingHeaderXpath;
	String strUploadsTabActiveXpath;
	String strFileTypeDropdownXpath;
	String strFileTypeOptionsXpath;
	String strBrowseButtonInUploadsXpath;
	String strUploadButtonDisableXpath;
	String strUploadButtonEnableXpath;
	String strFileFormatHintXpath;
	String strSampleTemplateLinkXpath;
	String strAdjustmentSearchButtonXpath;
	String strFileUploadedSucessfullyXpath;
	String strRecordAddedSucessfullyXpath;
	String strDeletePrecalRecordXpath;
	String strDeleteButtonXpath;
	String strDeletePopUpHeaderXpath;
	String strSourceDropDownXpath;
	String strUsersDropDownOptionsXpath;
	String strAdjustmentPricingModelDropDownXpath;
	String strPricingModelOptionsDropDownXpath;
	String strUserXpath;
	String strAdjustmentTabXpath;
	String strAdjustmentSourceDropDownXpath;
	String strAdjustmentSourceDefaultDropDownXpath;
	String strAdjustmentStatusDropDownXpath;
	String strAdjustmentStatusDefaultDropDownXpath;
	String strAdjustmentSearchFieldOptionsXpath;
	String strAddAdjustmentButtonXpath;
	String strAccountTerminationTabXpath;
	String strTerminationSourceDefaultDropDownXpath;
	String strBrowseInAccountTerminationXpath;
	String strUploadButtonXpath;
	String strAdjustmentSourceOptionsDropDownXpath;
	String strAdjustmentStatusOptionsDropDownXpath;
	String strGridHeaderFieldsXpath;
	String strTerminationSourceOptionsDropDownXpath;
	String strPremFeeXpath;
	String strPremFeeNotCalculatedXpath;
	String strDeleteIconXpath;
	String strDeleteAdjustmentPopUpXpath;
	String strEditAdjustmentPopUpXpath;
	String strPortfolioDisplayedInEditPopUpXpath;
	String strDeleteinAdjsPopUpXpath;
	String strRecordDeletedinSucessfullyXpath;
	String strSelectPrecalcOptionXpath;
	String strAddAdjustmentPopUpXpath;
	String strPortfolioTextBoxXpath;
	String strQuarterEndDateXpath;
	String strEffectiveDateXpath;
	String strModifyAdminFeeXpath;
	String strNetClientChargeXpath;
	String strGrossBrokerPayOutXpath;
	String strModifyNetClientChargeXpath;
	String strModifyGrossBrokerPayOutXpath;
	String strNotesTextAreaXpath;
	String strSaveButtonInAddAdjsXpath;
	String strPortfolioTextXpath;
	String strCloseButtonInAddAdjsXpath;
	String strCloseButtonInEditAdjsXpath;
	String strAdjustmentAddedSuccessfullyXpath;
	String strPortfolioLinkXpath;
	String strDataUpdatedXpath;
	String strTerminationDropdownXpath;
	String strACATSampleTemplateLinkXpath;
	String strBrowseInACATAccountTerminationXpath;
	String strACATUploadButtonEnableXpath;
	String strCheckButtonProcessXpath;
	String strProcessButonXpath;
	String strDeleteAdhocTermRecordXpath;
	String strEMAddPopUpXpath;
	String strEMEditPopUpXpath;
	String strEMGridXpath;
	String strREPAUMAddPopUpXpath;
	String strREPAUMEditPopUpXpath;
	String strREPAUMGridXpath;
	String strNoModelAddPopUpXpath;
	String strNoModelEditPopUpXpath;
	String strNoModelGridXpath;
	String strLPLSWSAddPopUpXpath;
	String strLPLSWSEditPopUpXpath;
	String strLPLSWSGridXpath;
	String strPortfolioNumberSearchXpath;
	String strAccountNoTextXpath;
	String strAdhocSampleTemplateLinkXpath;
	String strTradeAdminFeeXpath;
	String strModifyTradeAdminFeeXpath;
	String strTradeAdminFeeAddEditPopUpXpath;
	String strAdjExportButtonXpath;
	String strTotalRowsXpath;
	String strUserPopUpCloseXpath;
	String strPortfolioValueInEditAdjustmentPopupXpath;
	String strEMtobeValidatedData;
	String strPremiumFeetobeValidatedData;
	String strFeeCycleLinkSampleXpath;
	String strFeeCycleBrowseXpath;
	String strFeeCycleUploadXpath;
	String strFeeProcessButonXpath;
	String strPortfolioNumXpath;
	String strEmployeeRebateXpath;
	String strPremiumFeeXpath;
	String strGlobalBrokerTermSampleTemplateLinkXpath;

	public Rebilling(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to get the file location
	 * 
	 * @return String
	 *
	 * @author Abdul Hadi
	 * @since 08-31-2020
	 */
	public String getFileLocation(String dataFilename) {
		return REPOSITORYLOCATION + dataFilename + XLSX;
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strRebillingHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				REBILLING_PAGE_HEADER);
	}

	/**
	 * This method is used to
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iverifyUploadsTabisSelectedByDefault() {
		return isElementPresentUsingXpath(strUploadsTabActiveXpath, LPLCoreConstents.getInstance().LOWEST,
				strUploadsTabActiveXpath);
	}

	/**
	 * This method is used to click on File Type DropDown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/02/2020
	 */
	public boolean iClickonFileTypeDropDown() {
		return clickElementUsingXpath(strFileTypeDropdownXpath, FILETYPE_DROPDOWN);
	}

	/**
	 * This method is used to check File Type dropdown options
	 * 
	 * @param fileTypeOption
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean checkFileTypeDropDownOption(String fileTypeOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strFileTypeOptionsXpath, fileTypeOption), fileTypeOption);
	}

	/**
	 * This method is used to verify the availability of File Type dropdown options
	 * 
	 * @param fileTypeOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iVerifytheAvailabilityofFileTypeOptions(DataTable fileTypeOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = fileTypeOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkFileTypeDropDownOption(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					"Successfully able to see " + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify Browse button should be displayed
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iVerifyBrowsebuttonShouldbeDisplayed() {
		return isElementPresentUsingXpath(strBrowseButtonInUploadsXpath, LPLCoreConstents.getInstance().LOWEST,
				BROWSE_BUTTON);
	}

	/**
	 * This method is used to verify Upload button should be disable initially
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iVerifyUploadbuttonShouldbeDisable() {
		return isElementPresentUsingXpath(strUploadButtonDisableXpath, LPLCoreConstents.getInstance().LOWEST,
				UPLOADED_BUTTON_DISABLED);
	}

	/**
	 * This method is used to verify file format hint should be displayed
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iVerifyFileFormatHintMessage() {
		return isElementPresentUsingXpath(strFileFormatHintXpath, LPLCoreConstents.getInstance().LOWEST,
				FILE_FORMAT_HINT_TEXT);
	}

	/**
	 * This method is used to click on Precalc Sample Template Link
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iClickonPrecalcSampleTemplateLink() {
		return clickElementUsingXpath(strSampleTemplateLinkXpath, PRECALC_SAMPLE_TEMPLATE_LINK);
	}

	/**
	 * This method is used to verify whether Template downloaded successfully or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iShouldseeTemplateDownloadedSuccessfully() {
		boolean blnResult;
		// Wait till file downloads completes
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().HIGHEST);
		blnResult = checkIfFileExists(LPLCoreConstents.getInstance().DefaultDownloadFolder,
				PRECALC_SAMPLE_TEMPLATE_WITH_EXTENSION);
		return blnResult;
	}

	/**
	 * This method is used to enter required data in downloaded sample template
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @throws IOException
	 * @since 07/01/2020
	 */
	public void iEnteredRequiredData() throws IOException {
		// Wait till file downloads ready for edit
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		enterDiffrentTemplateDataIntoExcel(preCalcfilePath, PRECALC_SAMPLE_TEMPLATE);
	}

	/**
	 * This method is used to select PreCalculation option from File Type dropDown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/03/2020
	 */
	public boolean iSelectPreCalculationOptionFromFileTypeDropDown() {
		return selectValueFromDropdownUsingXpath(strFileTypeDropdownXpath, PRECALCULATION, FILETYPE_DROPDOWN);
	}

	/**
	 * This method is used to click on Browse button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iClickonBrowseButton() {
		return clickElementUsingXpath(strBrowseButtonInUploadsXpath, BROWSE_BUTTON);
	}

	/**
	 * This method is used to select the filled sample downloaded template
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iSelectedSampleDownloadedTemplate() {
		return uploadFile(getFileLocation(PRECALC_SAMPLE_TEMPLATE));
	}

	/**
	 * This method is used to verify Upload button should get enabled
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iVerifyUploadButtonGetEnabled() {
		return isElementPresentUsingXpath(strUploadButtonEnableXpath, LPLCoreConstents.getInstance().MEDIUM,
				UPLOADED_BUTTON_ENABLE);
	}

	/**
	 * This method is used to click on Upload button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iClickOnUploadButton() {
		return clickElementUsingXpath(strUploadButtonEnableXpath, UPLOAD_BUTTON);
	}

	/**
	 * This method is used to verify file uploaded successfully or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iVerifyFileUploadedSuccessfully() {
		return isElementPresentUsingXpath(strFileUploadedSucessfullyXpath, LPLCoreConstents.getInstance().HIGHEST,
				FILE_UPLOADED_MESSAGE);
	}

	/**
	 * This method is used to I click on Adjustment tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iClickOnAdjustmentTab() {
		return clickElementUsingXpath(strAdjustmentTabXpath, ADJUSTMENT_TAB);
	}

	/**
	 * This method is used to select Precal in Source dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iSelectPrecalInSourceDropdown() {
		waitTillVisibleUsingXpath(strSourceDropDownXpath, LPLCoreConstents.getInstance().HIGHEST, SOURCE_DROPDOWN);
		return selectValueFromDropdownUsingXpath(strSourceDropDownXpath, PRECALC, SOURCE_DROPDOWN);
	}

	/**
	 * This method is used to select user from User Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/09/2020
	 */
	public boolean selectUserFromUserDropdown() {
		return clickElementUsingXpath(getFormattedLocator(strUserXpath, QA_AUTOMATION_USER), QA_AUTOMATION_USER);
	}

	/**
	 * This method is used to click on Search button under Adjustment Tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iClickOnSearchButton() {
		boolean blnResult;
		blnResult = clickElementUsingXpath(strAdjustmentSearchButtonXpath, SEARCH_BUTTON);
		return blnResult;
	}

	/**
	 * This method is used to verify newly added record added successfully or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iVerifyNewlyAddedRecordSuccessfully() {
		return isElementPresentUsingXpath(
				getFormattedLocator(strRecordAddedSucessfullyXpath, testData.get("strPortfolioExcelData")),
				LPLCoreConstents.getInstance().HIGHEST, SOURCE_DROPDOWN);
	}

	/**
	 * This method is used to uploadFile a file
	 * 
	 * @param fileLocation
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean uploadFile(String fileLocation) {
		try {
			// Setting clipboard with file location
			setClipboardData(fileLocation);
			// native key strokes for CTRL, V and ENTER keys
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			return true;
		} catch (Exception exp) {
			return false;
		}
	}

	/**
	 * This method is used to set Clipboard Data
	 * 
	 * @param fileLocation
	 * @return void
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public void setClipboardData(String fileLocation) {
		StringSelection stringSelection = new StringSelection(fileLocation);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}

	/**
	 * This method is used to Enter Data Into Excel sheet
	 * 
	 * @param filePath
	 * @return void
	 *
	 * @author Abdul Hadi
	 * @throws IOException
	 * @since 07/01/2020
	 */
	public void enterDiffrentTemplateDataIntoExcel(String inputFile, String outPutFile) throws IOException {
		try (FileInputStream fileInputStream = new FileInputStream(new File(inputFile));
				XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);) {
			XSSFSheet worksheet = workbook.getSheetAt(0);
			if (inputFile.equals(preCalcfilePath)) {
				addRow(worksheet);
			} else if (inputFile.equals(globalBrokerTermfilePath)) {
				addFeeRow(worksheet);
			} else if (inputFile.equals(acatTermfilePath)) {
				addRowACATTermTemplate(worksheet);
			} else if (inputFile.equals(adhocTermfilePath)) {
				addRowTermTemplate(worksheet);
			} else if (inputFile.equals(feeCyclefilePath)) {
				addFeeRow(worksheet);
			}
			writeDataToExcel(workbook, outPutFile);
		} catch (IOException ex) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Getting file from the filePath location",
					"File should get from the file path location", "Got the file from file path sucessfully",
					"Exception occured while getting the file from the file path location: " + ex.getMessage(), false);
		}
	}

	/**
	 * This method is used to Enter Data Into Excel sheet
	 * 
	 * @param filePath
	 * @return void
	 *
	 * @author Abdul Hadi
	 * @throws IOException
	 * @since 01/08/2020
	 */
	private void writeDataToExcel(XSSFWorkbook workbook, String templateType) {
		try (FileOutputStream outFile = new FileOutputStream(new File(getFileLocation(templateType)))) {
			workbook.write(outFile);
		} catch (IOException ex) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Entering data into Excel file",
					"Data should enter into excel", "Data entered in excel sucessfully",
					"Exception occured while Adding data to excel. Error message: " + ex.getMessage(), false);
		}
	}

	/**
	 * This method is used to Add row in excel
	 * 
	 * @param worksheet
	 * @return void
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */

	private void addRow(XSSFSheet worksheet) {
		Row row1 = worksheet.createRow((short) 1);
		row1.createCell(0).setCellValue(testData.get("strQtrendDateExcelData"));
		row1.createCell(1).setCellValue(testData.get("strPortfolioExcelData"));
		row1.createCell(3).setCellValue(testData.get("strBrokerExcelData"));
		row1.createCell(4).setCellValue(testData.get("strEffectiveDateExcelData"));
		row1.createCell(5).setCellValue(testData.get("strNetClientChargeExcelData"));
		row1.createCell(6).setCellValue(testData.get("strGrossBrokerPayOutExcelData"));
		row1.createCell(8).setCellValue(testData.get("strAdminfeeExcelData"));
	}

	/**
	 * This method is used to click on Delete icon in results table
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/09/2020
	 */
	public boolean clickOnDeleteIcon() {
		return clickElementUsingXpath(strDeletePrecalRecordXpath, DELETE_ICON);
	}

	/**
	 * This method is used to check delete confirmation pop up
	 * 
	 * @author Abdul Hadi
	 * @since 07/09/2020
	 */
	public boolean deleteConfirmationPopupDisplayed() {
		return isElementPresentUsingXpath(strDeletePopUpHeaderXpath, LPLCoreConstents.getInstance().FAIR,
				DELETE_POPUP_WINDOW);

	}

	/**
	 * This method is used to click on Delete button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/09/2020
	 */
	public boolean clickOnDeleteButton() {
		return clickElementUsingXpath(strDeleteButtonXpath, DELETE_BUTTON);
	}

	/**
	 * This method is used to check search field options
	 * 
	 * @param searchFieldOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean checkSearchFieldsptions(String searchFieldOptions) {
		return isElementPresentUsingXpath(getFormattedLocator(strAdjustmentSearchFieldOptionsXpath, searchFieldOptions),
				searchFieldOptions);
	}

	/**
	 * This method is used to verify search field options In adjustment Tab
	 * 
	 * @param searchFieldOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean verifySearchFieldOptionsInAdjustmentTab(DataTable searchFieldOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFieldOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkSearchFieldsptions(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify default value in source dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean verifyDefaultValueInSourceDropdown() {
		return isElementPresentUsingXpath(getFormattedLocator(strAdjustmentSourceDefaultDropDownXpath, ALL), ALL);
	}

	/**
	 * This method is used to verify default value in status dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean verifyDefaultValueInStatusDropdown() {
		return isElementPresentUsingXpath(getFormattedLocator(strAdjustmentStatusDefaultDropDownXpath, PENDING), ALL);
	}

	/**
	 * This method is used to click on Source Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean clickOnSourceDropdown() {
		return clickElementUsingXpath(strAdjustmentSourceDropDownXpath, SOURCE_DROPDOWN);
	}

	/**
	 * This method is used to check source dropdown options
	 * 
	 * @param sourceDropdownOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/08/2020
	 */
	public boolean checkSourceDropdownOptions(String sourceDropdownOptions) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strAdjustmentSourceOptionsDropDownXpath, sourceDropdownOptions),
				sourceDropdownOptions);
	}

	/**
	 * This method is used to verify availability of Source Dropdown Options
	 * 
	 * @param sourceDropdownOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean verifyAvailabilityOfSourceDropdownOptions(DataTable sourceDropdownOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = sourceDropdownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkSourceDropdownOptions(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click On status Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean clickOnStatusDropdown() {
		return clickElementUsingXpath(strAdjustmentStatusDropDownXpath, STATUS_DROPDOWN);
	}

	/**
	 * This method is used to click On Pricing Model Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/18/2020
	 */
	public boolean clickOnPricingModelDropdown() {
		return clickElementUsingXpath(strAdjustmentPricingModelDropDownXpath, PRICING_MODEL_DROPDOWN);
	}

	/**
	 * This method is used to check Status dropdown options
	 * 
	 * @param statusDropdownOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/08/2020
	 */
	public boolean checkStatusDropdownOptions(String statusDropdownOptions) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strAdjustmentStatusOptionsDropDownXpath, statusDropdownOptions),
				statusDropdownOptions);
	}

	/**
	 * This method is used to verify availability of status Dropdown Options
	 * 
	 * @param statusDropdownOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean verifyAvailabilityOfStatusDropdownOptions(DataTable statusDropdownOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = statusDropdownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkStatusDropdownOptions(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check Pricing Model dropdown options
	 * 
	 * @param pricingModelDropdownOptions
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/18/2020
	 */
	public boolean checkPricingModelDropdownOptions(String pricingModelDropdownOptions) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strPricingModelOptionsDropDownXpath, pricingModelDropdownOptions),
				pricingModelDropdownOptions);
	}

	/**
	 * This method is used to verify availability of Pricing Model Dropdown Options
	 * 
	 * @param pricingModelDropdownOptions
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/18/2020
	 */
	public boolean verifyAvailabilityOfPricingModelDropdownOptions(DataTable pricingModelDropdownOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = pricingModelDropdownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkPricingModelDropdownOptions(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click on Users Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean clickOnUsersDropdown() {
		return clickElementUsingXpath(strUsersDropDownOptionsXpath, USERS_DROPDOWN);
	}

	/**
	 * This method is used to verify availability of Users Dropdown options
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean verifyAvailabilityOfUsersDropdownOptions() {
		return isElementPresentUsingXpath(getFormattedLocator(strUserXpath, QA_AUTOMATION_USER), QA_AUTOMATION_USER);
	}

	/**
	 * This method is used to check for search Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean checkForSearchButton() {
		return isElementPresentUsingXpath(strAdjustmentSearchButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				SEARCH_BUTTON);
	}

	/**
	 * This method is used to check for Adjustment Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean checkForAdjustmentButton() {
		return isElementPresentUsingXpath(strAddAdjustmentButtonXpath, LPLCoreConstents.getInstance().MEDIUM,
				ADD_ADJUSTMENT_BUTTON);
	}

	/**
	 * This method is used to click on Account Termination Tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean clickOnAccountTerminationTab() {
		return clickElementUsingXpath(strAccountTerminationTabXpath, ADHOC_TERMINATION_TAB);
	}

	/**
	 * This method is used to verify default value in termination Source Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean verifyDefaultValueInTerminationSourceDropdown() {
		boolean blnResult = false;
		boolean checkForDropDown;
		checkForDropDown = isElementPresentUsingXpath(
				getFormattedLocator(strTerminationSourceOptionsDropDownXpath, ADHOC_TERMINATION), SOURCE_DROPDOWN);
		if (checkForDropDown)
			blnResult = isElementPresentUsingXpath(
					getFormattedLocator(strTerminationSourceOptionsDropDownXpath, ADHOC_TERMINATION),
					ADHOC_TERMINATION);
		return blnResult;
	}

	/**
	 * This method is used to check Termination Source Options
	 * 
	 * @param terminationSourceOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean checkTerminationSourceOptions(String terminationSourceOptions) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strTerminationSourceOptionsDropDownXpath, terminationSourceOptions),
				terminationSourceOptions);
	}

	/**
	 * This method is used to verify Termination Source Dropdown Options
	 * 
	 * @param terminationSourceOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean verifyTerminationSourceDropdownOptions(DataTable terminationSourceOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = terminationSourceOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkTerminationSourceOptions(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check for Browse Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean checkForBrowseButton() {
		return isElementPresentUsingXpath(strBrowseInAccountTerminationXpath, LPLCoreConstents.getInstance().LOWEST,
				BROWSE_BUTTON);
	}

	/**
	 * This method is used to check for Upload Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean checkForUploadButton() {
		return isElementPresentUsingXpath(strUploadButtonXpath, LPLCoreConstents.getInstance().LOWEST, UPLOAD_BUTTON);
	}

	/**
	 * This method is used to check for Adhoc Termination Sample TemplateLink
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/07/2020
	 */
	public boolean checkForAdhocTerminationSampleTemplateLink() {
		return isElementPresentUsingXpath(strAdhocSampleTemplateLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				ADHOC_TERM_SAMPLE_TEMPLATE_LINK);
	}

	/**
	 * This method is used to click on Add Adjustment button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean clickOnAddAdjustmentButton() {
		return clickElementUsingXpath(strAddAdjustmentButtonXpath, ADD_ADJUSTMENT_BUTTON);
	}

	/**
	 * This method is used to select Precalc
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean selectPrecalc() {
		return clickElementUsingXpath(strSelectPrecalcOptionXpath, SELECT_PRECALC);
	}

	/**
	 * This method is used to Add Adjustment for PreCalc pop up displayed or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean seeaAddAdjustmentforPreCalcPopup() {
		return isElementPresentUsingXpath(strAddAdjustmentPopUpXpath, LPLCoreConstents.getInstance().FAIR,
				ADD_ADJUSTMENT_POPUP);
	}

	/**
	 * This method is used to Edit Adjustment for PreCalc pop up displayed or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean seeaEditAdjustmentforPreCalcPopup() {
		waitTillVisibleUsingXpath(
				getFormattedLocator(strPortfolioValueInEditAdjustmentPopupXpath, testData.get("strPortfolioTextBox")),
				500, PORTFOLIO_LINK);
//This operation takes more than 1000 seconds to execute, Hence hard coded test data since we wont have LPl core constant for this number
		return isElementPresentUsingXpath(strEditAdjustmentPopUpXpath, 1200, EDIT_ADJUSTMENT_POPUP);
	}

	/**
	 * This method is used to enter Portfolio number
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean enterPortfolioNumber() {
		return enterTextUsingXpath(strPortfolioTextBoxXpath, testData.get("strPortfolioTextBox"), PORTFOLIO_NUMBER);
	}

	/**
	 * This method is used to select Quarter end date
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean selectQuarterEnddate() {
		waitTillVisibleUsingXpath(strQuarterEndDateXpath, LPLCoreConstents.getInstance().HIGHEST, QUARTER_END_DATE);
		return enterTextUsingXpath(strQuarterEndDateXpath, testData.get("strQuarterEndDate"), QUARTER_END_DATE);
	}

	/**
	 * This method is used to select Effective date
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean selectEffectivedate() {
		waitTillVisibleUsingXpath(strEffectiveDateXpath, LPLCoreConstents.getInstance().HIGHEST, EFFECTIVE_DATE);
		return enterTextUsingXpath(strEffectiveDateXpath, testData.get("strEffectiveDate"), EFFECTIVE_DATE);
	}

	/**
	 * This method is used to enter Net client charge
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean enterNetclientCharge() {
		waitTillVisibleUsingXpath(strNetClientChargeXpath, LPLCoreConstents.getInstance().HIGHEST, NET_CLIENT_CHARGE);
		return enterTextUsingXpath(strNetClientChargeXpath, testData.get("strNetClientCharge"), NET_CLIENT_CHARGE);
	}

	/**
	 * This method is used to enter Gross broker payout
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean enterGrossBrokerPayout() {
		return enterTextUsingXpath(strGrossBrokerPayOutXpath, testData.get("strGrossBrokerPayOut"),
				GROSS_BROKER_PAYOUT);
	}

	/**
	 * This method is used to enter Gross broker payout
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean modifyGrossBrokerPayout() {
		return enterTextUsingXpath(strModifyGrossBrokerPayOutXpath, testData.get("strModifyGrossBrokerPayOut"),
				MODIFY_GROSS_BROKER_PAYOUT);
	}

	/**
	 * This method is used to clear Net Client Charge Text
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/13/2020
	 */
	public boolean clearNetClientChargeText() {
		return enterTextUsingXpath(strModifyNetClientChargeXpath, DEFAULT_VALUE, CLEAR_NET_CLIENT_CHARGE);
	}

	/**
	 * This method is used to clear Gross Broker Payout Text
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/13/2020
	 */
	public boolean clearGrossBrokerPayoutText() {
		return enterTextUsingXpath(strModifyGrossBrokerPayOutXpath, DEFAULT_VALUE, CLEAR_GROSS_BROKER_PAYOUT);
	}

	/**
	 * This method is used to enter Notes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean enterNotes() {
		return enterTextUsingXpath(strNotesTextAreaXpath, testData.get("strNotesTextArea"), NOTES_TEXT);
	}

	/**
	 * This method is used to click on Save
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean clickonSave() {
		return clickElementUsingXpath(strSaveButtonInAddAdjsXpath, SAVE_BUTTON);
	}

	/**
	 * This method is used to enter Account number
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean enterAccountNumber() {
		return enterTextUsingXpath(strPortfolioTextXpath, testData.get("strPortfolioTextBox"), ACCOUNT_NUMBER);
	}

	/**
	 * This method is used to verify Adjustment added successfully
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean verifyAdjustmentAddedSuccessfully() {
		// This operation takes more than 700 seconds to execute, Hence hard coded test
		// data since we wont have LPl core constant for this number
		waitTillVisibleUsingXpath(strPortfolioLinkXpath, 800, PORTFOLIO_LINK);
		return isElementPresentUsingXpath(strPortfolioLinkXpath, ADJUSTMENT_ADDED_SUCCESSFULLY);
	}

	/**
	 * This method is used to click Portfolio link
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean clickPortfolioLink() {
		waitTillVisibleUsingXpath(strPortfolioLinkXpath, 500, PORTFOLIO_LINK);
		return clickElementUsingXpath(strPortfolioLinkXpath, PORTFOLIO_LINK);
	}

	/**
	 * This method is used to modify Admin fee
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean modifyAdminFee() {
		return enterTextUsingXpath(strModifyAdminFeeXpath, testData.get("strModifyAdminFee"), MODIFY_ADMIN_FEE);
	}

	/**
	 * This method is used to modify Net client charge
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean modifyNetclientCharge() {
		return enterTextUsingXpath(strModifyNetClientChargeXpath, testData.get("strModifyNetClientCharge"),
				MODIFY_NET_CLIENT_CHARGE);
	}

	/**
	 * This method is used to verify details saved successfully
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean verifyDetailsSavedSuccessfully() {
		// This operation takes more than 1000 seconds to execute, Hence hard coded test
		// data since we wont have LPl core constant for this number
		return isElementPresentUsingXpath(strDataUpdatedXpath, 1200, DATA_UPDATED);
	}

	/**
	 * This method is used to click on Close
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean clickonClose() {
		return clickElementUsingXpath(strCloseButtonInAddAdjsXpath, CLOSE_BUTTON);
	}

	/**
	 * This method is used to verify Adjustment details updated successfully
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean verifyAdjustmentDetailsUpdatedSuccessfully() {
		return isElementPresentUsingXpath(strAdjustmentAddedSuccessfullyXpath, LPLCoreConstents.getInstance().LOWEST,
				ADJUSTMENT_DETAILS);
	}

	/**
	 * This method is used to verify premium fee calculated successfully
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean verifyPremiumFeeCalculatedSuccessfully() {
		return isElementPresentUsingXpath(strPremFeeXpath, LPLCoreConstents.getInstance().HIGHEST,
				PREMIUM_FEE_CALCULATED);
	}

	/**
	 * This method is used to verify premium fee not calculated as expected
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/13/2020
	 */
	public boolean verifyPremiumFeeNotCalculatedAsExpected() {
		return isElementPresentUsingXpath(strPremFeeNotCalculatedXpath, LPLCoreConstents.getInstance().HIGHEST,
				PREMIUM_FEE_NOT_CALCULATED);
	}

	/**
	 * This method is used to click on Delete icon
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean clickOnDelete() {
		return clickElementUsingXpath(strDeleteIconXpath, DELETE_ICON);
	}

	/**
	 * This method is used to check delete confirmation pop up
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean checkIfDeleteConfirmationPopupDisplayed() {
		return isElementPresentUsingXpath(strDeleteAdjustmentPopUpXpath, LPLCoreConstents.getInstance().MEDIUM,
				DELETE_ADJUSTMENT_POPUP);
	}

	/**
	 * This method is used to click on Delete in confirmation pop up
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean clickonDeleteinConfirmationPopup() {
		return clickElementUsingXpath(strDeleteinAdjsPopUpXpath, DELETE_BUTTON_IN_CONFIRMATION_POPUP);
	}

	/**
	 * This method is used to verify record deleted successfully
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/10/2020
	 */
	public boolean verifyRecordDeletedSuccessfully() {
		return isElementPresentUsingXpath(strRecordDeletedinSucessfullyXpath, LPLCoreConstents.getInstance().LOWEST,
				RECORD_DELETED);
	}

	/**
	 * This method is used to click on ADHOC Termination Sample Template Link
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/07/2020
	 */
	public boolean iClickonAdhocTermSampleTemplateLink() {
		return clickElementUsingXpath(strAdhocSampleTemplateLinkXpath, ADHOC_TERM_SAMPLE_TEMPLATE_LINK);
	}

	/**
	 * This method is used to verify whether Adhoc Term Template downloaded
	 * successfully or not
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/07/2020
	 */
	public boolean iShouldseeAdhocTermTemplateDownloadedSuccessfully() {
		boolean blnResult;
		blnResult = checkIfFileExists(LPLCoreConstents.getInstance().DefaultDownloadFolder,
				ADHOC_TERM_SAMPLE_TEMPLATE_WITH_EXTENSION);
		// Wait till file downloads completes
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().LOWEST);
		return blnResult;
	}

	/**
	 * This method is used to Enter Data Into Adhoc Tem Template
	 * 
	 * @param adhocTermfilePath
	 * @return void
	 *
	 * @author Sowmya Nagarajappa
	 * @throws IOException
	 * @since 08/07/2020
	 */

	public void enterDataIntoExcelTermTemplate() throws IOException {
		// Wait till file downloads ready for edit
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		enterDiffrentTemplateDataIntoExcel(adhocTermfilePath, ADDHOC_TERM_TEMPLATE);
	}

	/**
	 * This method is used to Add row in Term Template
	 * 
	 * @param worksheet
	 * @return void
	 *
	 * @author Sowmya Nagarajpppa
	 * @since 08/07/2020
	 */
	public void addRowTermTemplate(XSSFSheet worksheet) {
		Row row1 = worksheet.createRow((short) 1);
		row1.createCell(0).setCellValue(testData.get("strAccountNumberExcelData"));
		row1.createCell(1).setCellValue(testData.get("strTerminationDateExcelData"));
		row1.createCell(2).setCellValue(testData.get("strTerminationReasonExcelData"));

	}

	/**
	 * This method is used to enter required data in downloaded Adhoc Term sample
	 * template
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @throws IOException
	 * @since 08/07/2020
	 */
	public void iEnteredRequiredAdhocTermData() throws IOException {
		enterDiffrentTemplateDataIntoExcel(adhocTermfilePath, ADDHOC_TERM_TEMPLATE);
	}

	/**
	 * This method is used to click on Browse button and select Term File Path
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/01/2020
	 */
	public boolean iClickonTerminationBrowseButton() {
		return clickElementUsingXpath(strBrowseInAccountTerminationXpath, BROWSE_BUTTON);
	}

	/**
	 * This method is used to select the filled sample downloaded template
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/07/2020
	 */
	public boolean iSelectedAdhocTermSampleDownloadedTemplate() {
		return uploadFile(adhocTermfilePath);
	}

	/**
	 * This method is used to select TerminatedAccounts in Source dropdown
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/07/2020
	 */
	public boolean iSelectTerminatedAccountsInSourceDropdown() {
		return selectValueFromDropdownUsingXpath(strSourceDropDownXpath, TERMINATED_ACCOUNTS, SOURCE_DROPDOWN);
	}

	/**
	 * This method is used to check Status dropdown options
	 * 
	 * @param gridHeaderFields
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/20/2020
	 */
	public boolean checkGridHeaderFields(String gridHeaderFields) {
		return isElementPresentUsingXpath(getFormattedLocator(strGridHeaderFieldsXpath, gridHeaderFields),
				gridHeaderFields);
	}

	/**
	 * This method is used to verify availability of status Dropdown Options
	 * 
	 * @param gridHeaderFields
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/20/2020
	 */
	public boolean verifyAvailabilityOfHeaderfieldsinAdjustmentGrid(DataTable gridHeaderFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = gridHeaderFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkGridHeaderFields(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method clicks Termination Dropdown
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 08/20/2020
	 */
	public boolean clickOnTerminationDropdown() {
		return clickElementUsingXpath(strTerminationDropdownXpath, TERMINATION_TYPE_DROPDOWN);
	}

	/**
	 * This method to select ACAT Termination from Dropdown
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 08/20/2020
	 */
	public boolean selectAcat() {
		waitTillVisibleUsingXpath(strTerminationDropdownXpath, LPLCoreConstents.getInstance().HIGHEST,
				TERMINATION_TYPE_DROPDOWN);
		return selectValueFromDropdownUsingXpath(strTerminationDropdownXpath, ACAT, ACAT);
	}

	/**
	 * This method is used to check for ACAT Termination Sample TemplateLink
	 * 
	 * @return boolean
	 *
	 * @author abagchi
	 * @since 08/20/2020
	 */
	public boolean checkForAcatTerminationSampleTemplateLink() {
		return isElementPresentUsingXpath(strACATSampleTemplateLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				ACAT_TERM_SAMPLE_TEMPLATE_LINK);
	}

	/**
	 * This method clicks ACAT Template Download
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 08/20/2020
	 */
	public boolean iClickonAcatTermSampleTemplateLink() {
		return clickElementUsingXpath(strACATSampleTemplateLinkXpath, ACAT_TERM_SAMPLE_TEMPLATE_LINK);
	}

	/**
	 * This method puts data in ACAT Template
	 * 
	 * @return
	 * @author abagchi
	 * @since 8/22/2020
	 */
	public void iEnteredRequiredACATTermData() throws IOException {
		// Wait till file downloads ready for edit
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		enterDiffrentTemplateDataIntoExcel(acatTermfilePath, ACAT_SAMPLE_TEMPLATE);
	}

	/**
	 * This method is used to Add row in ACAT Term Template
	 * 
	 * @param worksheet
	 * @return void
	 *
	 * @author abagchi
	 * @since 08/22/2020
	 */
	private void addRowACATTermTemplate(XSSFSheet worksheet) {
		Row row1 = worksheet.createRow((short) 1);
		row1.createCell(0).setCellValue(testData.get("strAccountExcelData"));
		row1.createCell(1).setCellValue(testData.get("strCExcelData"));
		row1.createCell(2).setCellValue(testData.get("strStatExcelData"));
		row1.createCell(3).setCellValue(testData.get("strDYExcelData"));
		row1.createCell(4).setCellValue(testData.get("strBRKRExcelData"));
		row1.createCell(5).setCellValue(testData.get("strOCCExcelData"));
		row1.createCell(6).setCellValue(testData.get("strTrnExcelData"));
		row1.createCell(7).setCellValue(testData.get("strRepData"));
		row1.createCell(8).setCellValue(testData.get("strControlExcelData"));
		row1.createCell(9).setCellValue(testData.get("strOpenExcelData"));
		row1.createCell(10).setCellValue(testData.get("strValidExcelData"));
		row1.createCell(11).setCellValue(testData.get("strWhoExcelData"));
		row1.createCell(12).setCellValue(testData.get("strProdClassExcelData"));
		row1.createCell(13).setCellValue(testData.get("strSubfirmExcelData"));
	}

	/**
	 * This method selects Browse button to select ACAT Termination Template
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 8/22/2020
	 */
	public boolean iClickonACATTerminationBrowseButton() {
		return clickElementUsingXpath(strBrowseInACATAccountTerminationXpath, BROWSE_BUTTON);
	}

	/**
	 * This method uploads ACAT Template Download
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 08/20/2020
	 */
	public boolean iSelectedACATTermSampleDownloadedTemplate() {
		return uploadFile(getFileLocation(ACAT_SAMPLE_TEMPLATE));
	}

	/**
	 * This method Verifies ACAT Template Download successfully
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 08/20/2020
	 */

	public boolean iShouldseeACATTermTemplateDownloadedSuccessfully() {
		// Wait till file downloads completes
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().HIGHEST);
		return checkIfFileExists(DOWNLOADEDFILEREPOSITORYLOCATION, ACAT_TERM_SAMPLE_TEMPLATE_WITH_EXTENSION);
	}

	/**
	 * This method clicks on upload button
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 08/20/2020
	 */
	public boolean iClickOnACATUploadButton() {
		boolean blnResult;
		blnResult = clickElementUsingXpath(strACATUploadButtonEnableXpath, UPLOAD_BUTTON);
		deleteFile(REPOSITORYLOCATION, ACAT_TERM_SAMPLE_TEMPLATE_WITH_EXTENSION);
		return blnResult;
	}

	/**
	 * This method is used to verify Pricing Model displayed in Add Adjustment Pop
	 * up
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyPricingModelDisplayedAddPopUp() {
		// This operation takes more than 300 seconds to execute, Hence hard coded test
		// data since we wont have LPl core constant for this number
		return isElementPresentUsingXpath(strLPLSWSAddPopUpXpath, 400, LPL_SWS);
	}

	/**
	 * This method is used to verify Pricing Model displayed in Adjustment Grid
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyPricingModelDisplayedGrid() {
		return isElementPresentUsingXpath(strLPLSWSGridXpath, LPLCoreConstents.getInstance().HIGH, LPL_SWS);
	}

	/**
	 * This method is used to verify Pricing Model displayed in Edit Adjustment Pop
	 * up
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyPricingModelDisplayedEditPopUp() {
		return isElementPresentUsingXpath(strLPLSWSEditPopUpXpath, LPLCoreConstents.getInstance().HIGH, LPL_SWS);
	}

	/**
	 * This method is used to verify EM Pricing Model displayed in Add Adjustment
	 * Pop up
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyEMPricingModelDisplayedAddPopUp() {
		return isElementPresentUsingXpath(strEMAddPopUpXpath, 400, EMPLOYEE_MODEL);
	}

	/**
	 * This method is used to verify EM Pricing Model displayed in Adjustment Grid
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyEMPricingModelDisplayedGrid() {
		return isElementPresentUsingXpath(strEMGridXpath, LPLCoreConstents.getInstance().HIGH, EMPLOYEE_MODEL);
	}

	/**
	 * This method is used to verify EM Pricing Model displayed in Edit Adjustment
	 * Pop up
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyEMPricingModelDisplayedEditPopUp() {
		return isElementPresentUsingXpath(strEMEditPopUpXpath, LPLCoreConstents.getInstance().HIGH, EMPLOYEE_MODEL);
	}

	/**
	 * This method is used to verify SAM AUM Pricing Model displayed in Add
	 * Adjustment Pop up
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyREPAUMPricingModelDisplayedAddPopUp() {
		return isElementPresentUsingXpath(strREPAUMAddPopUpXpath, LPLCoreConstents.getInstance().HIGH, REP_AUM);
	}

	/**
	 * This method is used to verify SAM AUM Pricing Model displayed in Adjustment
	 * Grid
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyREPAUMPricingModelDisplayedGrid() {
		String repAumText = getTextUsingXpath(strREPAUMGridXpath, REP_AUM).trim();
		return REP_AUM.equalsIgnoreCase(repAumText);
	}

	/**
	 * This method is used to verify SAM AUM Pricing Model displayed in Edit
	 * Adjustment Pop up
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyREPAUMPricingModelDisplayedEditPopUp() {
		return isElementPresentUsingXpath(strREPAUMEditPopUpXpath, LPLCoreConstents.getInstance().HIGH, REP_AUM);
	}

	/**
	 * This method is used to verify No Pricing Model displayed in Add Adjustment
	 * Pop up
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyNoPricingModelDisplayedAddPopUp() {
		return isElementPresentUsingXpath(strNoModelAddPopUpXpath, LPLCoreConstents.getInstance().VERYHIGH, NO_PRICING);
	}

	/**
	 * This method is used to verify No Pricing Model displayed in Adjustment Grid
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyNoPricingModelDisplayedGrid() {
		return isElementPresentUsingXpath(strNoModelGridXpath, NO_PRICING);
	}

	/**
	 * This method is used to verify No Pricing Model displayed in Edit Adjustment
	 * Pop up
	 * 
	 * @param
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 08/25/2020
	 */
	public boolean iVerifyNoPricingModelDisplayedEditPopUp() {
		return isElementPresentUsingXpath(strNoModelEditPopUpXpath, LPLCoreConstents.getInstance().VERYHIGH,
				NO_PRICING);
	}

	/**
	 * This method is used to click on Close on Edit Adjustment Pop Up
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 09/07/2020
	 */
	public boolean clickonCloseEditAdj() {
		return clickElementUsingXpath(strCloseButtonInEditAdjsXpath, CLOSE_BUTTON);
	}

	/**
	 * This method is used to enter Account number
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 09/07/2020
	 */
	public boolean enterAccountNoInAddAdjPopUp() {
		waitTillVisibleUsingXpath(strAccountNoTextXpath, ACCOUNT_NUMBER);
		clickElementUsingXpath(strAccountNoTextXpath, ACCOUNT_NUMBER);
		return enterTextUsingXpath(strAccountNoTextXpath, testData.get("strAccountNoTextBox"), ACCOUNT_NUMBER);
	}

	/**
	 * This method is used to enter Account number in Search field
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 09/07/2020
	 */
	public boolean enterAccountNumberSearchField() {
		return enterTextUsingXpath(strPortfolioTextXpath, testData.get("strAccountNoTextBox"), ACCOUNT_NUMBER);
	}

	/**
	 * This method is used to click on Process Adjustement checkbox
	 * 
	 * @return booean
	 * @author Arunaditya Bagchi
	 * @since 08/30/2020
	 */
	public boolean iClickOnCheckBox() {
		return clickElementUsingXpath(strCheckButtonProcessXpath, CHECK_BOX);
	}

	/**
	 * This method is used to click on Process Adjustement Button
	 * 
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 08/30/2020
	 */

	public boolean iClickOnProcessButton() {
		return clickElementUsingXpath(strProcessButonXpath, PROCESS_BUTTON);
	}

	/**
	 * This method is used to Enter Portfolio Number
	 * 
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 08/30/2020
	 */
	public boolean enterAccountNumberinAdjustment() {
		return enterTextUsingXpath(strPortfolioNumberSearchXpath, testData.get("strAccountExcelData"),
				PORTFOLIO_NUMBER);
	}

	/**
	 * This method select Fee cycle in User Dropdown
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/17/2020
	 */
	public boolean iSelectFeeCycleInFileTypeDropdown() {
		return selectValueFromDropdownUsingXpath(strFileTypeDropdownXpath, FEE_CYCLE, FILETYPE_DROPDOWN);
	}

	/**
	 * This method click Fee cycle link and download
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/17/2020
	 */

	public boolean iClickonFeeCycleSampleTemplateLink() {
		return clickElementUsingXpath(strFeeCycleLinkSampleXpath, FEE_CYCLE_TEMPLATE);
	}

	/**
	 * This method verifies download of Fee cycle Template
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/17/2020
	 */
	public boolean iShouldseeFeeCycleTemplateDownloadedSuccessfully() {
		// Wait till file downloads completes
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().HIGHEST);
		return checkIfFileExists(LPLCoreConstents.getInstance().DefaultDownloadFolder, FEECYCLE_SAMPLE_TEMPLATE);
	}

	/**
	 * This method enters Fee Cycle Data in download Template
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/17/2020
	 */
	public void iEnteredRequiredFeeCycleData() throws IOException {
		// Wait till file downloads completes before entering data
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		enterDiffrentTemplateDataIntoExcel(feeCyclefilePath, FEECYCLE_SAMPLE_TEMPLATE);
	}

	/**
	 * This method Creates Excel Rows
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/17/2020
	 */
	public void addFeeRow(XSSFSheet worksheet) {
		Row row1 = worksheet.createRow((short) 1);
		row1.createCell(0).setCellValue(testData.get("strFeePortfolioExcelData"));
		row1.createCell(1).setCellValue(testData.get("strCycleExcelData"));

	}

	/**
	 * This method is used to click browse button for Fee cycle Template
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/21/2020
	 */
	public boolean iClickonFeeCycleBrowseButton() {
		boolean blnResult;
		blnResult = clickElementUsingXpath(strFeeCycleBrowseXpath, FEE_CYCLE_BROWSE);
		// Wait till browse window opens
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		return blnResult;
	}

	/**
	 * This method is used to select filled up Fee cycle Template
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/21/2020
	 */
	public boolean iSelectedFeeCycleDownloadedTemplate() {
		return uploadFile(getFileLocation(FEECYCLE_SAMPLE_TEMPLATE));
	}

	/**
	 * This method is used to click Upload button for Fee cycle Template
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/21/2020
	 */

	public boolean iClickOnFeeCycleUploadButton() {
		waitTillVisibleUsingXpath(strFeeCycleUploadXpath, LPLCoreConstents.getInstance().HIGHEST, UPLOAD_BUTTON);
		return clickElementUsingXpath(strFeeCycleUploadXpath, UPLOAD_BUTTON);
	}

	/**
	 * This method is used to verify Fee cycle Upload
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/21/2020
	 */
	public boolean iVerifyFeeFileUploadedSuccessfully() {
		waitTillVisibleUsingXpath(strFileUploadedSucessfullyXpath, LPLCoreConstents.getInstance().HIGHEST,
				FILE_UPLOADED_MESSAGE);
		// Delete if the file already exist
		deleteFile(REPOSITORYLOCATION, FEECYCLE_SAMPLE_TEMPLATE);
		return isElementPresentUsingXpath(strFileUploadedSucessfullyXpath, LPLCoreConstents.getInstance().MEDIUM,
				FILE_UPLOADED_MESSAGE);
	}

	/**
	 * This method is used to click checkboxes for uploaded data
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/21/2020
	 */
	public boolean iClickonFeeCycleChekBox() {
		return clickElementUsingXpath(strCheckButtonProcessXpath, FEE_CYCLE_CHKBOX);
	}

	/**
	 * This method is used to click Process button
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/21/2020
	 */

	public boolean iClickonFeeCycleProcess() {
		return clickElementUsingXpath(strFeeProcessButonXpath, PROCESS_BUTTON);
	}

	/**
	 * This method is used to select Fee cycle in source Dropdown
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/22/2020
	 */
	public boolean iSelectFeecycleInSourceDropdown() {
		waitTillVisibleUsingXpath(strSourceDropDownXpath, LPLCoreConstents.getInstance().HIGHEST, SOURCE_DROPDOWN);
		return selectValueFromDropdownUsingXpath(strSourceDropDownXpath, SRC_FEE_CYCLE, SOURCE_DROPDOWN);
	}

	/**
	 * This method is used to Enter Portfolio number for Fee cycle data
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 9/22/2020
	 */
	public boolean enterFeePortfolioNumber() {
		return enterTextUsingXpath(strPortfolioNumXpath, testData.get("strFeePortfolioExcelData"), PORTFOLIO_NMBER);
	}

	/**
	 * This method is used to select Select All from User Dropdown
	 * 
	 * @return boolean
	 *
	 * @author abagchi
	 * @since 9/22/2020
	 */
	public boolean selectFeeUserFromUserDropdown() {
		return clickElementUsingXpath(getFormattedLocator(strUserXpath, SELECT_ALL), USERNAME);
	}

	/**
	 * This method is used to validate Employee Rebate Value
	 * 
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 08/30/2020
	 */
	public boolean iVerifyEMRebate() {
		boolean blnResult = false;
		waitTillVisibleUsingXpath(strEmployeeRebateXpath, EMPLOYEE_REBATE);
		String employeeRebateText = getTextUsingXpath(strEmployeeRebateXpath, EMPLOYEE_REBATE).trim();
		if (testData.get("strEMtobeValidatedData").equalsIgnoreCase(employeeRebateText)) {
			blnResult = true;
		}
		return blnResult;
	}

	/**
	 * This method is used to wait for Ten minutes for Fee cycle job
	 * 
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 09/22/2020
	 */

	public void waitForTenMinutes() {
		// Wait 10 minutes as the Fee cycle job takes 10 minutes
		LPLCoreSync.staticWait(600000);
	}

	/**
	 * This method is used to validate Employee Rebate Value
	 * 
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 08/30/2020
	 */
	public boolean iVerifyPremiumFee() {
		boolean blnResult = false;
		waitTillVisibleUsingXpath(strPremiumFeeXpath, PREMIUM_FEE);
		String premiumFeeText = getTextUsingXpath(strPremiumFeeXpath, PREMIUM_FEE).trim();
		if (testData.get("strPremiumFeetobeValidatedData").equalsIgnoreCase(premiumFeeText)) {
			blnResult = true;
		}
		return blnResult;
	}

	/**
	 * This method is used to verify Trade Admin Fee text is displayed on Add/Edit
	 * Adjustment Pop up
	 * 
	 * @param
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 10/29/2020
	 */
	public boolean iVerifyTradeAdminFeeIsDisplayedOnAdjustmentPopup() {
		return isElementPresentUsingXpath(strTradeAdminFeeAddEditPopUpXpath, LPLCoreConstents.getInstance().VERYHIGH,
				TRADE_ADMIN_FEE);
	}

	/**
	 * This method is used to verify Trade Admin Fee is non Editable in Edit
	 * Adjustment Pop up
	 * 
	 * @param
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 10/29/2020
	 */
	public boolean iVerifyTradeAdminFeeIsNonEditableOnEditAdjustmentPopup() {
		String nonEditable = getAttributeUsingXpath(strModifyTradeAdminFeeXpath, DISABLED, TRADE_ADMIN_FEE);
		return (TRUE.equals(nonEditable));
	}

	/**
	 * This method is used to verify Trade Admin Fee is non Editable in Add
	 * Adjustment Pop up
	 * 
	 * @param
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 10/29/2020
	 */
	public boolean iVerifyTradeAdminFeeIsNonEditableOnAddAdjustmentPopup() {
		String nonEditable = getAttributeUsingXpath(strTradeAdminFeeXpath, DISABLED, TRADE_ADMIN_FEE);
		return (TRUE.equals(nonEditable));
	}

	/**
	 * This method is used to recalculate GBP which consider Trade Admin Fee while
	 * calculation after changing the NCC on Edit Adjustment Pop up
	 * 
	 * @param
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/2/2020
	 */
	public boolean iVerifyRecalculationForGBP() {
		clickElementUsingXpath(strModifyAdminFeeXpath, MODIFY_ADMIN_FEE);
		clickElementUsingXpath(strModifyNetClientChargeXpath, NET_CLIENT_CHARGE);
		float adminFee = Float.parseFloat(getTextUsingXpath(strModifyAdminFeeXpath, MODIFY_ADMIN_FEE));
		float tradeAdminFee = Float.parseFloat(getTextUsingXpath(strModifyTradeAdminFeeXpath, TRADE_ADMIN_FEE));
		float grossBrokerPayout = Float
				.parseFloat(getTextUsingXpath(strModifyGrossBrokerPayOutXpath, GROSS_BROKER_PAYOUT));
		clickElementUsingXpath(strModifyAdminFeeXpath, MODIFY_ADMIN_FEE);
		float netClientCharge = Float.parseFloat(getTextUsingXpath(strModifyNetClientChargeXpath, NET_CLIENT_CHARGE));
		float expGBP = netClientCharge - (adminFee + tradeAdminFee);
		return Float.compare(grossBrokerPayout, expGBP) == 0;
	}

	/**
	 * This method is used to select All User from User Dropdown
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/11/2020
	 */
	public boolean selectAllUserFromUserDropdown() {
		return clickElementUsingXpath(getFormattedLocator(strUserXpath, ALL_USER), USERNAME);
	}

	/**
	 * This method is used to select REP AUM in Pricing Model dropdown
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/11/2020
	 */
	public boolean iSelectRepAumFromPricingModelDropdown() {
		waitTillVisibleUsingXpath(strAdjustmentPricingModelDropDownXpath, LPLCoreConstents.getInstance().HIGHEST,
				PRICING_MODEL_DROPDOWN);
		return selectValueFromDropdownUsingXpath(strAdjustmentPricingModelDropDownXpath, REP_AUM,
				PRICING_MODEL_DROPDOWN);
	}

	/**
	 * This method is used to Delete all the existing record for the account under
	 * test
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11/18/2020
	 */
	public boolean clickOnDeleteButtonExistingRecords() {
		boolean ifAdjustmentRecordExist = isElementPresentUsingXpath(strTotalRowsXpath, 30);
		while (ifAdjustmentRecordExist) {
			clickElementUsingXpath(strDeletePrecalRecordXpath, DELETE_ICON);
			isElementPresentUsingXpath(strDeletePopUpHeaderXpath, LPLCoreConstents.getInstance().FAIR,
					DELETE_POPUP_WINDOW);
			clickElementUsingXpath(strDeleteButtonXpath, DELETE_BUTTON);
			ifAdjustmentRecordExist = isElementPresentUsingXpath(strTotalRowsXpath, 30);
			if (!ifAdjustmentRecordExist)
				break;
		}
		return true;
	}

	/**
	 * This method is used to select user from User Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajapp
	 * @since 11/18/2020
	 */
	public boolean closeTheUserDropdown() {
		return clickElementUsingXpath(strUserPopUpCloseXpath, CLOSE_USERDROPDOWN);
	}

	/**
	 * This method to select ACAT Termination from Dropdown
	 * 
	 * @return boolean
	 * @author rbalusam
	 * @since 01/19/2021
	 */
	public boolean selectGlobalBrokerTermination() {
		waitTillVisibleUsingXpath(strTerminationDropdownXpath, LPLCoreConstents.getInstance().HIGHEST,
				TERMINATION_TYPE_DROPDOWN);
		return selectValueFromDropdownUsingXpath(strTerminationDropdownXpath, GLOBAL_BROKER_TERMINATION,
				GLOBAL_BROKER_TERMINATION);
	}

	/**
	 * This method is used to check for Global Broker Termination Sample
	 * TemplateLink
	 * 
	 * @return boolean
	 *
	 * @author rbalusam
	 * @since 01/20/2021
	 */
	public boolean checkForGlobalBrokerTerminationSampleTemplateLink() {
		return isElementPresentUsingXpath(strGlobalBrokerTermSampleTemplateLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, GLOBAL_BROKER_TERM_SAMPLE_TEMPLATE_LINK);
	}

	/**
	 * This method clicks Global Broker Term Template Download
	 * 
	 * @return boolean
	 * @author rbalusam
	 * @since 01/20/2021
	 */
	public boolean iClickonGlobalBrokerTermSampleTemplateLink() {
		return clickElementUsingXpath(strGlobalBrokerTermSampleTemplateLinkXpath,
				GLOBAL_BROKER_TERM_SAMPLE_TEMPLATE_LINK);
	}

	/**
	 * This method Verifies Global Broker Term Template Download successfully
	 * 
	 * @return boolean
	 * @author rbalusam
	 * @since 01/20/2021
	 */
	public boolean iShouldseeGlobalBrokerTermTemplateDownloadedSuccessfully() {
		boolean blnResult;
		// Wait till file downloads completes
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().HIGHEST);
		blnResult = checkIfFileExists(LPLCoreConstents.getInstance().DefaultDownloadFolder,
				GLOBAL_BRK_TERM_SAMPLE_TEMPLATE_WITH_EXTENSION);
		return blnResult;
	}

	/**
	 * This method puts data in Global Broker Template
	 * 
	 * @return
	 * @author rbalusam
	 * @since 1/21/2021
	 */
	public void iEnteredRequiredGlobalBrokerTermData() throws IOException {
		// Wait till file downloads ready for edit
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().HIGHINMILLISEC);
		enterDiffrentTemplateDataIntoExcel(globalBrokerTermfilePath, GLOBAL_BRK_SAMPLE_TEMPLATE);
	}

	/**
	 * This method uploads Global Broker Template Download
	 * 
	 * @return boolean
	 * @author rbalusam
	 * @since 01/21/2021
	 */
	public boolean iSelectedGlobalBrokerTermSampleDownloadedTemplate() {
		return uploadFile(getFileLocation(GLOBAL_BRK_SAMPLE_TEMPLATE));
	}
}
