package com.lpl.qe.portfolioaccountingfeebilling.householdingCAG.web;

import java.awt.AWTException;

import org.testng.annotations.Test;

import com.dataprovider.DataProviderClass;
import com.dataprovider.DataProviderFactory;
import com.dataprovider.REQUEST_TYPE;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.annotations.NeedsDriver;
import com.lpl.qe.blackbird.clientworks.web.utils.LoginUtility;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject.EditHouseholdData;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.CommonUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.HouseholdCreateUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.HouseholdEditUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.LoginLogoutUtility;

public class EditHouseholdAndAddRemoveClients {
	private static final String SHEET_NAME = "EditHouseholdData";
	private static final String EXCEL_FILE = "src/test/resources/testdata/HouseholdGroupExcel.xlsx";
	@NeedsDriver
	@DataProviderFactory(requestType = REQUEST_TYPE.POJO, fileName = EXCEL_FILE, sheetName = SHEET_NAME, range = "1-1")
	@Test(dataProvider = "UniversalRowProvider", dataProviderClass = DataProviderClass.class)
	public void createHousehold(EditHouseholdData editHHData)
			throws InterruptedException, AWTException{
		
		//ClientworksCommon clientworksCommon = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		CommonUtility clientworksCommonUtility = BasePage.initialize(DriverFactory.getDriver(), CommonUtility.class);
		HouseholdCreateUtility householdCreateUtility = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreateUtility.class);
		HouseholdEditUtility householdEditUtility = BasePage.initialize(DriverFactory.getDriver(), HouseholdEditUtility.class);
		LoginLogoutUtility.loginToCW();
		LoginUtility.userLogin(editHHData.getUserName(), editHHData.getPassword());
		clientworksCommonUtility.clickOnGroupsTab();
		clientworksCommonUtility.enterHouseholdNameToSearch(editHHData.getGroupName());
		clientworksCommonUtility.clickSearchHouseholdButton();
		clientworksCommonUtility.clickOnHouseholdName(editHHData.getGroupID());
		clientworksCommonUtility.isHouseholdDashbaordPageDisplayed();
		clientworksCommonUtility.clickEditHouseholdButton();
		householdEditUtility.clickEditHHpencilIcon();
		householdEditUtility.isEditHouseholdPageDisplayed();
		householdCreateUtility.enterClientNames(editHHData.getClientName1());
		householdCreateUtility.selectClientName();
		householdEditUtility.clickOnPrimaryRadioButton(editHHData.getClientName1());
		householdEditUtility.removeClient(editHHData.getClientName1());
		householdEditUtility.verifySelectPrimaryErrorMsg();
		householdCreateUtility.clickCloseButton();
		householdCreateUtility.isChangesNotSavedPopUpDisplayed();
		householdCreateUtility.clickGoBack();
		householdCreateUtility.clickCloseButton();
		householdCreateUtility.isChangesNotSavedPopUpDisplayed();
		householdCreateUtility.clickProceedToClose();
		clientworksCommonUtility.isHouseholdDashbaordPageDisplayed();
		clientworksCommonUtility.clickEditHouseholdButton();
		householdEditUtility.clickEditHHpencilIcon();
		householdEditUtility.isEditHouseholdPageDisplayed();
		householdCreateUtility.enterClientNames(editHHData.getClientName1());
		householdCreateUtility.selectClientName();
		householdEditUtility.verifyTrackerForAddedClient(editHHData.getClientName1());
		householdEditUtility.verifyExpandedChevron();
		householdEditUtility.removeClient(editHHData.getClientName1());
		householdEditUtility.verifyTrackerForRemovedClient(editHHData.getClientName1());
		householdEditUtility.verifyExpandedChevron();
		householdEditUtility.clickUndoButtonOnTracker(editHHData.getClientName1());
		householdEditUtility.verifyRemovedClientAddedTile(editHHData.getClientName1());
		householdEditUtility.clickReviewHouseholdButton();
		householdEditUtility.clickContentsChevronReviewHHpage();
		householdEditUtility.clickAccountChevronReviewHHPage(editHHData.getClientName1());
		householdEditUtility.verifyAccountDetails(editHHData.getClientName1());
		householdEditUtility.verifyDefaultNoOfAccountsDisplayed(editHHData.getClientName1());
		householdEditUtility.clickSubmitChanges();
		householdEditUtility.verifyConfirmationPageHHUpdatedMsg();
		householdEditUtility.clickEditHHpencilIcon();
		householdEditUtility.isEditHouseholdPageDisplayed();
		householdEditUtility.removeClient(editHHData.getClientName1());
		householdCreateUtility.enterClientNames(editHHData.getClientName1());
		householdCreateUtility.selectClientName();
		householdEditUtility.verifyTrackerForAddedClient(editHHData.getClientName1());
		householdEditUtility.clickUndoButtonOnTracker(editHHData.getClientName1());
		householdEditUtility.clickReviewHouseholdButton();
		householdEditUtility.clickSubmitChanges();
		householdEditUtility.verifyConfirmationPageHHUpdatedMsg();
		householdCreateUtility.clickCloseButton();
		LoginLogoutUtility.closeBrowser();
	}

}
