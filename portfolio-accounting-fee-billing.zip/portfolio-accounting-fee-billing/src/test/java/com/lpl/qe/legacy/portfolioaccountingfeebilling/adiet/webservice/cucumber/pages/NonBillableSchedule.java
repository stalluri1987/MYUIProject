package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> NonBillableSchedule.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for NonBillableSchedule</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class NonBillableSchedule extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 818;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String NON_BILLABLE_SCHEDULE_PAGE_HEADER = "Non Billable Schedule Page Header";
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String SUCCESSFULLY_ABLE_TO_SEE = "Successfully be able to see ";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String OPTIONS = "options";
	public static final String SEARCH_TEXTBOX = "Search Textbox";
	public static final String EDMDATA = "EDM Data";
	public static final String POPULATEDRECORD = "Populated Record";
	public static final String SEARCHBOX = "Search Box";
	public static final String ADD_NEW_BUTTON = "Add New Button";
	public static final String SECURITY_NO_FLD = "Security Number field";
	public static final String START_DATE = "Start Date";
	public static final String END_DATE = "End Date";
	public static final String BILLING_CATEGORY= "Billing Category";
	public static final String SAVE_BUTTON = "Save Button";
	public static final String CLOSE_BUTTON = "Close Button";
	public static final String DATA_SAVED_MSG ="Data Saved Message";
	public static final String EDIT_LINK = "Edit Link";
	public static final String DELETE_BUTTON = "Delete Button";
	public static final String DATE_PICKER = "Date Picker";
	public static final String YES_BUTTON = "Yes Button";
	String strAddNewButtonXpath;
	String strSecurityNOXpath;
	String strStarDateinpopupXpath;
	String strEndDateinpopupXpath;
	String strBillingCatinpopupXpath;
	String strSaveButtonXpath;
	String strCloseButtonXpath;
	String strDataSavedMsgXpath;
	String strEditLinkButtonXpath;
	String strDeleteButtonXpath;
	String strYesButtonXpath;
	String strDatePickerXpath;

	String strNonBillableScheduleHeaderXpath;
	String strEdmDataFieldHeaderTextXpath;
	String strDefautTextSearchXpath;
	String strOverrideEdmDataFieldHeaderFieldTextXpath;
	String strSearchBoxXpath;
	String strPopulatedValueXpath;
	String strEdmDataXpath;
	String strYesButtonXpaths;

	public NonBillableSchedule(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strNonBillableScheduleHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				NON_BILLABLE_SCHEDULE_PAGE_HEADER);
	}

	/**
	 * This method is used to check search box with default placeholder text
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 01-20-2020
	 */
	public boolean searchBoxWithDefaultPlaceholderTextDisplayed() {
		return isElementPresentUsingXpath(strDefautTextSearchXpath, LPLCoreConstents.getInstance().LOWEST,
				SEARCH_TEXTBOX);
	}

	/**
	 * This method is used to check The Availability of EDM Data grid header field
	 * options Options
	 * 
	 * @param headerField
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 11-20-2020
	 */

	public boolean iVerifyTheAvailabilityOfEdmDataHeaderFields(String headerField) {
		return isElementPresentUsingXpath(getFormattedLocator(strEdmDataFieldHeaderTextXpath, headerField),
				LPLCoreConstents.getInstance().LOWEST, headerField + OPTIONS);
	}

	/**
	 * This method is used to check The Availability of EDM Data grid header fields
	 * options Options
	 * 
	 * @param headerFields
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 11-20-2020
	 */
	public boolean iVerifyTheAvailabilityOfEdmDataHeaderFields(DataTable headerFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = headerFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = iVerifyTheAvailabilityOfEdmDataHeaderFields(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of Override EDM Data grid
	 * header field options Options
	 * 
	 * @param headerField
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 11-20-2020
	 */

	public boolean iVerifyTheAvailabilityOfOvverideEdmDataHeaderField(String headerField) {
		return isElementPresentUsingXpath(getFormattedLocator(strOverrideEdmDataFieldHeaderFieldTextXpath, headerField),
				LPLCoreConstents.getInstance().LOWEST, headerField + OPTIONS);
	}

	/**
	 * This method is used to check The Availability of Override EDM Data grid
	 * header fields options Options
	 * 
	 * @param headerFields
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 11-20-2020
	 */
	public boolean iVerifyTheAvailabilityOfOvverideEdmDataHeaderFields(DataTable headerFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = headerFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = iVerifyTheAvailabilityOfOvverideEdmDataHeaderField(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to enter CUSIP/Security No/FBVA Security/Aggregated Fund
	 * ID in Search box
	 *
	 * @param data
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 02-11-2021
	 */
	public boolean iEnterDataInSearchBox(String data) {
		return enterTextUsingXpath(strSearchBoxXpath, data, SEARCHBOX);
	}

	/**
	 * This method is used to clicked on populated data when CUSIP/Security No/FBVA
	 * Security/Aggregated Fund ID get entered in Search box
	 *
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 02-11-2021
	 */
	public boolean iClickOnPopulatedData() {
		return clickElementUsingXpath(strPopulatedValueXpath, POPULATEDRECORD);
	}

	/**
	 * This method is used to check EDM data is displayed
	 *
	 * @param data
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 02-11-2021
	 */
	public boolean iVerifyEDMData(String data) {
		boolean blnResult = false;
		List<WebElement> lst = getWebElementsUsingXpath(strEdmDataXpath, EDMDATA);
		List<String> strings = new ArrayList<>();
		for (WebElement e : lst) {
			strings.add(e.getText().trim());
		}
		if (strings.contains(data)) {
			blnResult = true;
		}
		return blnResult;
	}
	/**
	 * This method is used to click Add New Button	 
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */
	public boolean clickonAddNewButton() {
		return clickElementUsingXpath(strAddNewButtonXpath, ADD_NEW_BUTTON);
	}
	/**
	 * This method is used to verify the Security Number displayed in pop up
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */

	public boolean verifySecurityNoDisplay() {
		boolean blnResult = false;
		String strSecurity = testData.get("strSecurityNo");
		waitTillVisibleUsingXpath(strSecurityNOXpath, SECURITY_NO_FLD);
		String strSecurityNoText = getTextUsingXpath(strSecurityNOXpath, SECURITY_NO_FLD).trim();
		if (strSecurity.equalsIgnoreCase(strSecurityNoText) == true) {
			blnResult = true;
		}
		return blnResult;
	}
	/**
	 * This method is used to enter start date
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */

	public boolean enterStartDate() {
		waitTillVisibleUsingXpath(strStarDateinpopupXpath,LPLCoreConstents.getInstance().HIGHEST, START_DATE);
		clickElementUsingXpath(strStarDateinpopupXpath, START_DATE);
		return clickElementUsingXpath(strDatePickerXpath, DATE_PICKER);
		}
	/**
	 * This method is used to enter end date
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */

	public boolean enterEndDate() {
		waitTillVisibleUsingXpath(strEndDateinpopupXpath,LPLCoreConstents.getInstance().HIGHEST, END_DATE);
		clickElementUsingXpath(strEndDateinpopupXpath, END_DATE);
		return clickElementUsingXpath(strDatePickerXpath, DATE_PICKER);
	}
	/**
	 * This method is used to enter Billing Category
	 * @param data
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */

	public boolean enterBillingCategory(String strBillingCategory) {
		waitTillVisibleUsingXpath(strBillingCatinpopupXpath, LPLCoreConstents.getInstance().HIGHEST, BILLING_CATEGORY);
		return selectValueFromDropdownUsingXpath(strBillingCatinpopupXpath, strBillingCategory, BILLING_CATEGORY);
	}
	/**
	 * This method is used to click Save button
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */

	public boolean clickSaveButton() {
		return clickElementUsingXpath(strSaveButtonXpath, SAVE_BUTTON);
	}
	/**
	 * This method is used to click Close button
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */

	public boolean clickCloseButton() {
		return clickElementUsingXpath(strCloseButtonXpath, CLOSE_BUTTON);
	}
	/**
	 * This method is used to verify Data saved
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */

	public boolean verifyDataSaved() {
		return isElementPresentUsingXpath(strDataSavedMsgXpath, LPLCoreConstents.getInstance().LOWEST,
				DATA_SAVED_MSG);
	}
	/**
	 * This method is used to click Edit Link
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */

	public boolean clickEditLinkButton() {
		waitTillVisibleUsingXpath(strEditLinkButtonXpath, LPLCoreConstents.getInstance().HIGHEST, EDIT_LINK);
		return clickElementUsingXpath(strEditLinkButtonXpath, EDIT_LINK);
	}
	/**
	 * This method is used to click Delete button
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */
	public boolean clickDeleteButton() {
		waitTillVisibleUsingXpath(strDeleteButtonXpath, LPLCoreConstents.getInstance().HIGHEST, DELETE_BUTTON);
		return clickElementUsingXpath(strDeleteButtonXpath, DELETE_BUTTON);
	
	}

	/**
	 * This method is used to click Yes confirmation Button
	 * @return boolean
	 * @author Arunaditya Bagchi
	 * @since 03-11-2021
	 */
	public boolean clickYesButton() {
		
		waitTillVisibleUsingXpath(strYesButtonXpath, LPLCoreConstents.getInstance().HIGHEST, YES_BUTTON);
		return clickElementUsingXpath(strYesButtonXpath, YES_BUTTON);
	
	}

}

