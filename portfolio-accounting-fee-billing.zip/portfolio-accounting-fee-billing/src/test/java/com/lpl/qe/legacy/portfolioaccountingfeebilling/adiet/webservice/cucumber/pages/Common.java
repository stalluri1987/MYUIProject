package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import LPLCoreDriver.LPLCoreUtil;
import LPLCoreDriver.WebToolKit.Link;
import LPLCoreDriver.WebToolKit.SelectDropDown;
import LPLCoreDriver.WebToolKit.WebEdit;

/**
 * <br>
 * <b> Title: </b> CaseAdminCommon.java</br>
 * <br>
 * <b> Description: </b> Utility methods for interacting with webpage
 * objects</br>
 * <br>
 * <b>Methods:</br>
 * </b> <br>
 * clickElementUsingXpath : Function is used for click on the web element using
 * xpath locator string</br>
 * <br>
 * waitTillVisible : Function is used for wait for the web element using xpath
 * locator string to become visible</br>
 * <br>
 * getWebElements : This method is used to get list of webelements for a given
 * locator</br>
 * <br>
 * clickElement : Function is used for click on the web element using By
 * object</br>
 * <br>
 * clickOnElement : This method is used to click on any web element by using
 * Java script executor click or a normal click</br>
 * <br>
 * isElementPresent : Function is used for check if the web element is present
 * on the page using xpath locator</br>
 * <br>
 * isElementPresent : Function is used for check if the web element is present
 * on the page using xpath locator and wait for specified time if not available
 * immediately</br>
 * <br>
 * isElementPresent : Function is used for check if the web element is present
 * on the page using By object and wait for specified time if not available
 * immediately</br>
 * <br>
 * getText : Function is used to retrieve text of the web element using By
 * object</br>
 * <br>
 * getText : Function is used to retrieve text of the web element using object
 * of a WebElement</br>
 * <br>
 * getText : Function is used to retrieve text from the WebElement using xpath
 * locator</br>
 * <br>
 * getText : Function is used to retrieve text for list of webelements using
 * objects of a WebElement</br>
 * <br>
 * getAttribute : Function is used to retrieve the specified attribute of the
 * web element using object of a WebElement</br>
 * <br>
 * getFormattedLocator : Function is used to substitute the plaeceholders in the
 * given locator string with the given</br>
 * <br>
 * getDropdownValues : This method returns all the available values from the
 * Select dropdown based on xpath</br>
 * <br>
 * getBy : This method returns By object for given locator string based on
 * xpath</br>
 * <br>
 * getByID : This method returns By object for given locator string based on
 * id</br>
 * <br>
 * getWebElement : This method returns WebElement object for given By
 * object</br>
 * <br>
 * getWebElementUsingXpath : This method returns WebElement object for given
 * locator string based on xpath</br>
 * <br>
 * getWebElementUsingId : This method returns WebElement object for given
 * locator string based on id</br>
 * <br>
 * getWebElementUsingCss :This method returns WebElement object for given
 * locator string based on CSS</br>
 * isFileDownloaded : This method checks if a file was downloaded and if so,
 * deletes it * <br>
 *
 * @author pmanohar
 * @since 07-05-2019
 */

public class Common extends LPLCoreDriver {

	public static final String TEXT_ATTRIBUTE = "text";
	public static final String EMPTY_STRING = "";
	public static final String PLACEHOLDER = "%s";
	public static final String ENABLED = "ENABLED";
	public static final String DISPLAYED = "DISPLAYED";
	public static final String SELECTED = "SELECTED";
	public static final String AND_IT_IS_SELECTED = " And it is selected";
	public static final String AND_IT_IS_NOT_SELECTED = " And it is not selected";
	public static final String FIELD = "field";
	public static final String SPACE = " ";
	public static final String LOCATOR = "Locator: ";
	public static final String FOR = "for";
	public static final String ELEMENT = "element";
	public static final String USER_CHECKS_FOR = "User checks for";
	public static final String ELEMENT_LOCATOR_TYPE = "element.locatorType:";
	public static final String USER_COULD_NOT_FIND_THE = "User could not find the";
	public static final String USER_SHOULD_FIND = "User should find";
	public static final String USER_FINDS_THE = "User finds the";
	public static final String DROP_DOWN_OBJECT_IS_NOT_DISPLAYED = "DropDown object is not displayed.";
	public static final String FROM = " from ";
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String DROPDOWN_TEXT = " dropdown";
	public static final String SUCESSFULLY_ABLE_SEE = " Successfully be able to see ";
	public static final String IS_DISABLED = " is disabled";
	public static final String IS_ENABLED = " is enabled";
	public static final String IS_NOT_DISABLED = " is not disabled";
	public static final String XLSX_EXTENSION = ".xlsx";
	public static final String CSV_EXTENSION = ".csv";
	public static final String PDF_EXTENSION = ".pdf";
	public static final String ZIP_EXTENSION = ".zip";
	public static final String REPLACED_CHARACTER = "";
	public static final String ACTUAL_NAME = "Actual Name: ";
	public static final String EXPECTED_NAME = " Expected";
	public static final String QFX_EXTENSION = ".qfx";
	public static final String REQUIRED_DATE = "Required date";
	public static final String MONTH_YEAR = "Month and year";
	public static String strError = EMPTY_STRING;
	public static final String TOTAL_RECORDS_COUNT = "Total Records Count";
	public static final String NO_RECORDS_FOUND = "No records Found";
	public static final String NUMERIC_REGEX = "[^0-9]";
	public static final String TOTAL_RECORDS_FOUND = "Total Records Found";
	public String emptyStr;
	LPLCoreConstents lplCoreConstents = LPLCoreConstents.getInstance();

	WebEdit webEdit;
	LPLCoreUtil lplcoretil;

	public Common(WebDriver browserDriver) {
		// Initializing the driver
		this.driver = browserDriver;
		// Initializing the Webedit class
		webEdit = new WebEdit();
		lplcoretil = new LPLCoreUtil();
	}

	/**********************************************************************
	 * Click methods
	 **********************************************************************/
	/**
	 * clickOnElement: This method is used to click on any web element by using Java
	 * script executor click or a normal click.
	 *
	 * @return N/A
	 * @author Prabhakaran Manoharan
	 * @parameter maxTimeSeconds - Maximum time to wait for the Webelement byLocator
	 *            - To click on any By locator
	 * @since 13-Aug-2019
	 */
	private boolean clickOnElement(int maxTimeSecondsToWaitForElement, By byLocator, String elementName,
			String locatorType, String locator) {
		boolean blnResult = false;
		try {
//			 wait for webelement
			WebElement webElement = LPLCoreUtil.waitForWebElement(maxTimeSecondsToWaitForElement, byLocator);
//			 Click on webelement
			click(webElement);
			blnResult = true;
		} catch (Exception e) {
			// Failing the test as click action was not successful
			writeStepToReporter(testType.CLICK.name(), blnResult, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, e.getMessage() == null ? "" : e.getMessage());
		}
		return blnResult;
	}

	/**
	 * This method is used for click on the web element and if unsuccessful use JS
	 * click
	 *
	 * @param webElement
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean click(WebElement webElement) {
		try {
			// Normal click on webelement
			webElement.click();
			return true;
		} catch (Exception ex) {
			// Java Executor click on by locator
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(LPLCoreConstents.JSCLICK, webElement);
			return false;
		}
	}

	/**
	 * This method is used for click on the web element using xpath locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingXpath(String locator, String elementName) {
		// Clicking on element using xpath locator
		return clickOnElement(lplCoreConstents.UNIT, By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for click on the web element using xpath locator string
	 *
	 * @param locator
	 * @param waitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingXpath(String locator, int waitTimeInSeconds, String elementName) {
		// Clicking on element using xpath locator
		return clickOnElement(waitTimeInSeconds, By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for click on the web element using id locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingId(String locator, String elementName) {
		// Clicking on element using ID locator
		return clickOnElement(lplCoreConstents.UNIT, By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for click on the web element using css locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingCss(String locator, String elementName) {
		// Clicking on element using CSS locator
		return clickOnElement(lplCoreConstents.UNIT, By.cssSelector(locator), elementName, LPLCoreConstents.CSS,
				locator);
	}

	/**********************************************************************
	 * Wait methods
	 **********************************************************************/

	/**
	 * This method is used for wait for the web element(Max 10 secs) using By object
	 * to become visible
	 *
	 * @param by
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisible(By by, String elementName, String locatorType, String locator) {
		// waiting for element for given By object
		boolean blnResult = LPLCoreSync.waitTillVisible(driver, by, lplCoreConstents.HIGHEST);
		if (!blnResult)
			// failing the test when element is not found
			writeStepToReporter(testType.WAITTILLVISIBLE.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					locatorType, locator, lplCoreConstents.BaseInMiliSec);
		// returning true when element is found
		return blnResult;
	}

	/**
	 * This method is used for wait for the web element(for specified time) using By
	 * object to become visible
	 *
	 * @param by
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisible(By by, int maxWaitTimeInSeconds, String elementName, String locatorType,
			String locator) {
		// waiting for element for given By object up to specified time if not found
		// immediately
		boolean blnResult = LPLCoreSync.waitTillVisible(driver, by, maxWaitTimeInSeconds);
		// Writing results of this step to the reporter
		writeStepToReporter(testType.WAITTILLVISIBLE.name(), blnResult, LPLCoreConstents.TRUE, elementName, locatorType,
				locator, maxWaitTimeInSeconds);
		return blnResult;
	}

	/**
	 * This method is used for wait for the web element using xpath locator string
	 * to become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingXpath(String locator, String elementName) {
		// waiting for element using Xpath locator
		return waitTillVisible(By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using xpath
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingXpath(String locator, int maxWaitTimeInSeconds, String elementName) {
		// waiting for element using Xpath locator up to specified time
		return waitTillVisible(By.xpath(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for wait for the web element using ID locator string to
	 * become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingId(String locator, String elementName) {
		// waiting for element using ID
		return waitTillVisible(By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using ID
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingId(String locator, int maxWaitTimeInSeconds, String elementName) {
		// waiting for element using Xpath locator up to specified time
		return waitTillVisible(By.id(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for wait for the web element using css locator string to
	 * become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingCss(String locator, String elementName) {
		// waiting for element using Css locator
		return waitTillVisible(By.cssSelector(locator), elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using css
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingCss(String locator, int maxWaitTimeInSeconds, String elementName) {
		// waiting for element using Css locator up to specified time
		return waitTillVisible(By.cssSelector(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.CSS,
				locator);
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED)
	 *
	 * @param locatorType
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresent(String elementState, String locatorType, String locator, String elementName) {
		// Retrieveing the Web element for given locator type and locator
		WebElement webElement = getWebElement(elementName, locatorType, locator);
		// return true is element is present else false
		return LPLCoreUtil.isElementPresent(elementState, webElement);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * xpath locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorXpath
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String locatorXpath, String elementName) {
		boolean blnResult = false;
		// Retrieveing the Web element for given xpath locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			// Failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.XPATH, locatorXpath, EMPTY_STRING);
		// Returns true if element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using xpath locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String elementState, String locator, String elementName) {
		// Checking for element for given state using Xpath locator
		return isElementPresent(elementState, LPLCoreConstents.XPATH, locator, elementName);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * xpath locator and wait for specified time if not available immediately
	 *
	 * @param locatorXpath
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String locatorXpath, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement using xpath locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath, maxWaitTimeInSeconds);
		// Checking if element is present
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			// Failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.XPATH, locatorXpath, EMPTY_STRING);
		}
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * ID locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorId
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String locatorId, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement using ID locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		// Checking if element is present
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			// Failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.ID, locatorId, EMPTY_STRING);
		}
		// return true when element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * ID locator and wait for specified time if not available immediately
	 *
	 * @param locatorId
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String locatorId, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement for given ID locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId, maxWaitTimeInSeconds);
		// Checking if element is found
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			// failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.ID, locatorId, EMPTY_STRING);
		}
		// return true if element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using ID locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String elementState, String locator, String elementName) {
		// Checking if the element is present using the Id locator
		return isElementPresent(elementState, LPLCoreConstents.ID, locator, elementName);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * Css locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorCss
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String locatorCss, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement using Css locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		// Checking if the element is present
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			// Failing the test if the element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.CSS, locatorCss, EMPTY_STRING);
		// returns true if element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * Css locator and wait for specified time if not available immediately
	 *
	 * @param locatorCss
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String locatorCss, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement using Css locator and waits for specified timime if
		// element is not found immediately
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss, maxWaitTimeInSeconds);
		// Checking if the element is present
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			// Failing the test if the element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.CSS, locatorCss, EMPTY_STRING);
		// returns true if element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using Css locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String elementState, String locator, String elementName) {
		// Checking for elementstate using Css
		return isElementPresent(elementState, LPLCoreConstents.CSS, locator, elementName);
	}

	/*************************************************
	 * Get text Methods
	 ******************************************************************/
	/**
	 * This method is used to retrieve the specified attribute of the web element
	 * using object of a WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @param attributeName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getAttribute(WebElement webElement, String elementName, String attributeName, String locatorType,
			String locator) {
		boolean blnResult = false;
		String text;
		// Retrieving the attribute value for the given element
		text = Link.getLinkAttribute(webElement, attributeName);
		if (text != null)
			blnResult = true;
		String test = attributeName.equalsIgnoreCase(TEXT_ATTRIBUTE) ? testType.GETTEXT.name()
				: testType.GETATTRIBUTE.name();
		if (!blnResult)
			// Failing the test if retrieved attribute value is null
			writeStepToReporter(test, blnResult, LPLCoreConstents.TRUE, elementName, locatorType, locator,
					attributeName);
		// returns the retrieved text
		return (text != null ? text : "");
	}

	/**
	 * This method is used to retrieve text of the web element using object of a
	 * WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getText(WebElement webElement, String elementName, String locatorType, String locator) {
		// returns the text attribute for the given webelement
		return getAttribute(webElement, elementName, TEXT_ATTRIBUTE, locatorType, locator).trim();
	}

	/**
	 * This method is used to retrieve text from the WebElement using xpath locator.
	 *
	 * @param locatorXpath the locator xpath
	 * @param elementName  the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingXpath(String locatorXpath, String elementName) {
		// retrieving the webelement using xpath locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		// retrieving the text attribute for the webelement
		return getText(webElement, elementName, LPLCoreConstents.XPATH, locatorXpath);
	}

	/**
	 * This method is used to retrieve text from the WebElement using ID locator.
	 *
	 * @param locatorId   the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingId(String locatorId, String elementName) {
		// Retrieving the webelement using ID locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		// Retrieving the text attribute of the given webelement using ID locator
		return getText(webElement, elementName, LPLCoreConstents.ID, locatorId);
	}

	/**
	 * This method is used to retrieve text from the WebElement using Css locator.
	 *
	 * @param locatorCss  the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingCss(String locatorCss, String elementName) {
		// Retrieving the webelement using Css locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		// Retrieving the text attribute of the given webelement using Css locator
		return getText(webElement, elementName, LPLCoreConstents.CSS, locatorCss);
	}

	/**
	 * This method is used to retrieve text for list of webelements using xpath of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingXpath(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		// Retrieving the list of webelements using Xpath locator
		List<WebElement> webElements = getWebElementsUsingXpath(locator, elementName);
		for (WebElement webElement : webElements)
			// Retrieving the list of value(text) for the given webelements using Xpath
			// locator
			values.add(getText(webElement, elementName, LPLCoreConstents.XPATH, locator));
		return values;
	}

	/**
	 * This method is used to retrieve text for list of webelements using ID of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingId(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		// Retrieving the list of webelements using ID locator
		List<WebElement> webElements = getWebElementsUsingId(locator, elementName);
		for (WebElement webElement : webElements)
			// Retrieving the list of value(text) for the given webelements using ID locator
			values.add(getText(webElement, elementName, LPLCoreConstents.ID, locator));
		return values;
	}

	/**
	 * This method is used to retrieve text for list of webelements using Css of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingCss(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		// Retrieving the list of webelements using ID locator
		List<WebElement> webElements = getWebElementsUsingCss(locator, elementName);
		for (WebElement webElement : webElements)
			// Retrieving the list of value(text) for the given webelements using ID locator
			values.add(getText(webElement, elementName, LPLCoreConstents.CSS, locator));
		return values;
	}

	/**
	 * This method is used to retrieve specified attribute value of the web element
	 * using object of a WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getAttributeValue(WebElement webElement, String attributeName, String elementName,
			String locatorType, String locator) {
		// Retrieving the value of the specified attribute for given locator type and
		// locator
		return getAttribute(webElement, elementName, attributeName, locatorType, locator).trim();
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using xpath locator.
	 *
	 * @param locatorXpath the locator xpath
	 * @param elementName  the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingXpath(String locatorXpath, String attributeName, String elementName) {
		// Retrieving the webelement using xpath locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		// Retrieving the value of the specified attribute for given xpath locator
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.XPATH, locatorXpath);
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using ID locator.
	 *
	 * @param locatorId   the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingId(String locatorId, String attributeName, String elementName) {
		// Retrieving the webelement using ID locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		// Retrieving the value of the specified attribute for given ID locator
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.ID, locatorId);
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using Css locator.
	 *
	 * @param locatorCss  the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingCss(String locatorCss, String attributeName, String elementName) {
		// Retrieving the webelement using Css locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		// Retrieving the value of the specified attribute for given Css locator
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.CSS, locatorCss);
	}

	/**
	 * This method returns WebElement object for given locator
	 *
	 * @param elementName
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	private WebElement getWebElement(String elementName, String locatorType, String locator) {
		WebElement webElement = null;
		// Waiting the webelement using given locator type and locator
		webElement = LPLCoreSync.waitForWebElement(driver, locatorType, locator, lplCoreConstents.BaseInMiliSec);
		if (webElement == null)
			// Failing the test if webelement is not found
			writeStepToReporter(testType.GETWEBELEMENT.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, EMPTY_STRING);
		// Returns Webelement if found
		return webElement;
	}

	/**
	 * This method returns WebElement object for given locator. Waits for specified
	 * time if element not found immediately
	 *
	 * @param elementName
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	private WebElement getWebElement(String elementName, String locatorType, String locator, int maxWaitTimeInSeconds) {
		WebElement webElement = null;
		// Waiting the webelement using given locator type and locator. Max wait time is
		// maxWaitTimeInSeconds
		webElement = LPLCoreSync.waitForWebElement(driver, locatorType, locator, maxWaitTimeInSeconds);
		if (webElement == null)
			// Failing the test if webelement is not found
			writeStepToReporter(testType.GETWEBELEMENT.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, EMPTY_STRING);
		// Returns Webelement if found
		return webElement;
	}

	/**
	 * This method returns WebElement object for given xpath locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingXpath(String locator, String elementName) {
		// Retrieves the web element using xpath locator
		return getWebElement(elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method returns WebElement object for given ID locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingId(String locator, String elementName) {
		// Retrieves the web element using Id locator
		return getWebElement(elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method returns WebElement object for given Css locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingCss(String locator, String elementName) {
		// Retrieves the web element using Css locator
		return getWebElement(elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used to get list of webelements for the given By object
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElements(By by, String elementName, String locatorType, String locator) {
		List<WebElement> webElementList = new ArrayList<>();
		try {
			// Waiting for weblements using By object
			webElementList = LPLCoreUtil.waitForListOfWebElements(lplCoreConstents.FAIR, by);
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			// Failing the test when exception occurs
			writeStepToReporter(testType.GETWEBELEMENTS.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, strError);
		}
		return webElementList;
	}

	/**
	 * This method is used to get list of webelements for a given xpath locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingXpath(String locator, String elementName) {
		// Retrieving the list of webelements using Xpath locator
		return getWebElements(By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used to get list of webelements for a given id locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingId(String locator, String elementName) {
		// Retrieving the list of webelements using ID locator
		return getWebElements(By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used to get list of webelements for a given Css locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingCss(String locator, String elementName) {
		// Retrieving the list of webelements using Css locator
		return getWebElements(By.cssSelector(locator), elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used to get number of elements for given Xpath locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingXpath(String locator, String elementName) {
		// Retrieving the number of webelements using Xpath locator
		return getWebElementsUsingXpath(locator, elementName).size();
	}

	/**
	 * This method is used to get number of elements for given ID locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingId(String locator, String elementName) {
		// Retrieving the number of webelements using ID locator
		return getWebElementsUsingId(locator, elementName).size();
	}

	/**
	 * This method is used to get number of elements for given locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingCss(String locator, String elementName) {
		// Retrieving the number of webelements using Css locator
		return getWebElementsUsingCss(locator, elementName).size();
	}

	/**
	 * This method is used to enter text using By object
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterText(By by, String textToEnter, String locatorType, String locator, String elementName) {
		boolean blnResult = false;
		// Clearing the existing text from text box
		blnResult = webEdit.clearWebEditValue(driver, by);
		if (!blnResult)
			// Failing the test if the text is nto cleared successfully
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"User clears the text  for " + elementName + SPACE + FIELD,
					"User should be able to clear the text for " + elementName + SPACE + FIELD, "Text is cleared",
					"User could not clear the text for " + elementName + " field. Locator Type: " + locatorType + SPACE
							+ LOCATOR + locator + " " + webEdit.strError,
					true);
		// Entering the text in the textbox
		blnResult = webEdit.setWebEditValue(driver, by, textToEnter);
		if (!blnResult)
			// Failing the test if the text is not entered successfully
			LPLCoreReporter
					.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
							"User enter the text " + textToEnter + SPACE + FOR + SPACE + elementName + SPACE + FIELD,
							"User should be able to enter the text "
									+ textToEnter + SPACE + FOR + SPACE + elementName + SPACE + FIELD,
							"Text is entered",
							"User could not enter the text " + textToEnter + SPACE + FOR + SPACE + elementName
									+ " field. Locator Type: " + locatorType + SPACE + LOCATOR + locator + " "
									+ webEdit.strError,
							true);
		return blnResult;
	}

	/**
	 * This method is used to enter text using Xpath locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingXpath(String locator, String textToEnter, String elementName) {
		// enter text in text box identified using xpath locator
		return enterText(By.xpath(locator), textToEnter, LPLCoreConstents.XPATH, locator, elementName);
	}

	/**
	 * This method is used to enter text using ID locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingId(String locator, String textToEnter, String elementName) {
		// enter text in text box identified using Id locator
		return enterText(By.id(locator), textToEnter, LPLCoreConstents.ID, locator, elementName);
	}

	/**
	 * This method is used to enter text using Css locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingCss(String locator, String textToEnter, String elementName) {
		// enter text in text box identified using Css locator
		return enterText(By.cssSelector(locator), textToEnter, LPLCoreConstents.CSS, locator, elementName);
	}

	/**
	 * This method is used to substitute the placeholders in the given locator
	 * string with the given argument values
	 *
	 * @param locator
	 * @param arguments
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public String getFormattedLocator(String locator, String... arguments) {
		boolean blnResult = true;
		String formattedLocator = locator;
		// Retrieving the number of placeholders
		int numberOfPlaceholders = StringUtils.countMatches(locator, PLACEHOLDER);
		// Checking if the number of placeholders is equal to number of arguments passed
		if (numberOfPlaceholders != arguments.length)
			blnResult = false;
		if (!blnResult)
			// Failing the test if number of placeholders is not equal to number of
			// arguments passed
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validating if the number of placeholders in locator string matches the number of arguments passed to replace them",
					"Number of placeholders in locator string should match the number of arguments passed to replace them",
					"Number of placeholders in locator string match with the number of arguments passed to replace them",
					"Number of placeholders in locator string does should match the number of arguments passed to replace them. Number of placeholders: "
							+ numberOfPlaceholders + ". Number of arguments passed: " + arguments.length
							+ ". Locator - " + locator + " Arguments - " + String.join(",", arguments),
					LPLCoreConstents.FALSE);

		for (int i = 0; i < arguments.length; i++) {
			// Replacing the placeholders with the arguments passed
			formattedLocator = formattedLocator.replaceFirst("%s", arguments[i]);
		}
		return formattedLocator;
	}

	/**
	 * This method is used to print the report log
	 *
	 * @param testType
	 * @param blnResult
	 * @param whatResultIsPassed
	 * @param elementName
	 * @param locatorType
	 * @param locator
	 * @author Prabhakaran Manoharan
	 * @since 08-27-2019
	 */
	public void writeStepToReporter(String testType, boolean blnResult, boolean whatResultIsPassed, String elementName,
			String locatorType, String locator, String errorMessage) {
		setErrorMessage(!errorMessage.equals(EMPTY_STRING) ? "Error: " + errorMessage : EMPTY_STRING);
		switch (testType.toUpperCase()) {
		case "GETWEBELEMENT":
			// Report logger for getWebElement methods
			LPLCoreReporter
					.writeStepToReporter(blnResult, whatResultIsPassed,
							"User retrieves the webelement for  " + elementName + SPACE + ELEMENT,
							"User should find the webelement " + elementName + SPACE + ELEMENT,
							"User finds the webelement for " + elementName + SPACE + ELEMENT,
							"User could not retrieve the webelement for" + elementName + SPACE + ELEMENT_LOCATOR_TYPE
									+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
							LPLCoreConstents.FALSE);
			break;
		case "GETWEBELEMENTS":
			// Report logger for getWebElements methods
			LPLCoreReporter
					.writeStepToReporter(blnResult, whatResultIsPassed,
							"User retrieves the webelements for  " + elementName + SPACE + ELEMENT,
							"User should find the webelements " + elementName + SPACE + ELEMENT,
							"User finds the webelements for " + elementName + SPACE + ELEMENT,
							"User could not retrieve the webelements for " + elementName + SPACE + ELEMENT_LOCATOR_TYPE
									+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
							LPLCoreConstents.FALSE);
			break;
		case "ISELEMENTPRESENT":
			// Report logger for isElementPresent methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					USER_CHECKS_FOR + SPACE + elementName + SPACE + ELEMENT,
					USER_SHOULD_FIND + SPACE + elementName + SPACE + ELEMENT,
					USER_FINDS_THE + SPACE + elementName + SPACE + ELEMENT,
					USER_COULD_NOT_FIND_THE + SPACE + elementName + SPACE + ELEMENT + SPACE + ELEMENT_LOCATOR_TYPE
							+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
					LPLCoreConstents.FALSE);
			break;
		case "CLICK":
			// Report logger for Click methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User clicks on " + elementName + SPACE + ELEMENT,
					"User should be able to click the " + elementName + SPACE + ELEMENT,
					"User clicked the " + elementName + SPACE + ELEMENT,
					"User could not click the " + elementName + SPACE + ELEMENT_LOCATOR_TYPE + SPACE + locatorType
							+ SPACE + LOCATOR + locator + " " + strError,
					true);
			break;
		default:
			break;
		}
	}

	/**
	 * This method is used to print the report log
	 *
	 * @param testType
	 * @param blnResult
	 * @param whatResultIsPassed
	 * @param elementName
	 * @param locatorType
	 * @param locator
	 * @param maxWaitTimeInSeconds
	 * @author Prabhakaran Manoharan
	 * @since 08-27-2019
	 */
	public void writeStepToReporter(String testType, boolean blnResult, boolean whatResultIsPassed, String elementName,
			String locatorType, String locator, int maxWaitTimeInSeconds) {
		switch (testType.toUpperCase()) {
		case "WAITTILLVISIBLE":
			// Report logger for waitTillVisible methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User waits for " + elementName + " element. Max wait time is " + maxWaitTimeInSeconds + " secs",
					elementName + " element should appear", elementName + " is visible",
					elementName + " is not visible. Locator Type: " + locatorType + SPACE + LOCATOR + locator, true);
			break;
		case "WAITTILLINVISIBLE":
			// Report logger for waitTillInvisible methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User waits for " + elementName + " element to disappear. Max wait time is " + maxWaitTimeInSeconds
							+ " secs",
					elementName + " element should disappear", elementName + " element has disappeared",
					elementName + " is still visible. Locator Type: " + locatorType + SPACE + LOCATOR + locator, true);
			break;
		default:
			break;
		}
	}

	/**
	 * This method contains list of constants for different checks performed on UI
	 * dusing webdriver
	 */
	public enum testType {
		// Constants for commonly used webdriver methods
		GETWEBELEMENT, GETWEBELEMENTS, ISELEMENTPRESENT, CLICK, GETTEXT, GETATTRIBUTE, WAITTILLVISIBLE,
		WAITTILLINVISIBLE
	}

	/**
	 * This method is used for check if the check box selected on the page using Id
	 * locator
	 *
	 * @param locatorId
	 * @param elementName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/08/2019
	 */
	public boolean isCheckBoxSelected(String locatorId, String elementName) {
		// Retrieving the weblement
		WebElement webElement = getWebElementUsingId(locatorId, elementName);
		// Checking if checkbox is selected
		return webElement.isSelected();
	}

	/**
	 * This method is used for check if the check box selected on the page using Id
	 * locator
	 *
	 * @param locatorId
	 * @param elementName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/08/2019
	 */
	public boolean checkIfSelected(String locatorId, String elementName) {
		// Check if check box is selected
		boolean blnResult = false;
		// Wait for webelement using ID locator
		LPLCoreSync.waitForWebElement(driver, LPLCoreConstents.ID, locatorId, lplCoreConstents.FAIRINMILLISEC);
		// Retrieving the webelement using ID locator
		WebElement getElement = getWebElementUsingId(locatorId, elementName);
		// checking if checkbox is selected using ID locator
		blnResult = getElement.isSelected();
		if (blnResult) {
			// Passing the step if checkbox is selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_CHECKS_FOR + elementName + AND_IT_IS_SELECTED,
					USER_SHOULD_FIND + elementName + AND_IT_IS_SELECTED,
					USER_FINDS_THE + elementName + AND_IT_IS_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, true);
		} else {
			// Failing the step if checkbox is not selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.FALSE,
					USER_CHECKS_FOR + elementName + AND_IT_IS_NOT_SELECTED,
					USER_SHOULD_FIND + elementName + AND_IT_IS_NOT_SELECTED,
					USER_FINDS_THE + elementName + AND_IT_IS_NOT_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, false);
		}

		return blnResult;
	}

	/**
	 * This method returns WebElement object for given By object
	 *
	 * @param by
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElement(By by) {
		WebElement webElement = null;
		try {
			// Identify the webelement based on By object
			webElement = driver.findElement(by);
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the web element", "Web element should be retrieved", "Web element was retrieved",
					"Could not retreive the web element", true);
		}
		return webElement;
	}

	/**
	 * This method is used for getting value from the style tag
	 *
	 * @return String
	 * @author Pooja Navdeti
	 * @since 08/26/2019
	 */
	public String getCSSValueId(String elementId, String cssValue) {
		// Retrieving the Css value for the element
		return driver.findElement(By.id(elementId)).getCssValue(cssValue);
	}

	/**
	 * This method returns WebElement object for given locator string based on xpath
	 *
	 * @param locator
	 * @return By
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingXpath(String locator) {
		WebElement webElement = null;
		try {
			// Retrieving the webelement based on Xpath locator
			webElement = driver.findElement(By.xpath(locator));
		} catch (Exception e) {
			// Failing the test when exception occurs
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the web element", "Web element should be retrieved", "Web element was retrieved",
					"Could not retrieve the web element", true);
		}
		return webElement;
	}

	/**
	 * Function is used for check if the web element is Not present on the page
	 *
	 * @param locatorXpath
	 * @return boolean
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementNotPresentUsingXpath(String locatorXpath) {
		// Checking if the element is not present on the page
		return !LPLCoreSync.waitTillVisible(driver, By.xpath(locatorXpath), lplCoreConstents.LOWEST);
	}

	/**
	 * This method is used to set the error message to strError variable
	 *
	 * @param errorMessage
	 * @author Prudhvi Raj M
	 * @since 08-28-2019
	 */
	public static void setErrorMessage(String errorMessage) {
		// Initializing the strError variable with the exception/error message
		strError += errorMessage;
	}

	/**
	 * This method is used to check whether file is downloaded and Delete it.
	 *
	 * @param downloadedPath
	 * @param fileName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08-28-2019
	 */
	public boolean checkIfFileDownloadedAndDeleted(String downloadedPath, String fileName) {
		boolean checkIfFileDownloaded;
		boolean blnResult = false;
		checkIfFileDownloaded = checkIfFileExists(downloadedPath, fileName);
		if (checkIfFileDownloaded) {
			blnResult = deleteFile(downloadedPath, fileName);
		}
		return blnResult;
	}

	/**
	 * This method is used to check whether the file exists
	 *
	 * @param downloadedPath
	 * @param fileName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08-30-2019
	 */
	public boolean checkIfFileExists(String downloadedPath, String fileName) {
		boolean ifFileExist = false;

		File file = new File(downloadedPath);
		File[] files = file.listFiles();
		for (File singleFile : files) {
			if (singleFile.getName().contains(fileName)) {
				ifFileExist = true;
				return ifFileExist;
			}
		}
		return ifFileExist;
	}

	/**
	 * This method is used to delete the files.
	 *
	 * @param downloadedPath
	 * @param fileName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08-30-2019
	 */

	public boolean deleteFile(String downloadedPath, String fileName) {
		try {
			File file = new File(downloadedPath);
			File[] files = file.listFiles();
			for (File singleFile : files) {
				if (singleFile.getName().contains(fileName)) {
					return singleFile.delete();
				}
			}
			return false;
		} catch (Exception ex) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Delete file",
					"File should delete sucessfully", "File deleted sucessfully",
					"Exception occured while deleting the file. Error message: " + ex.getMessage(), false);
			return false;
		}
	}

	/**
	 * This method is used to select the dropdown value by text using xpath
	 *
	 * @param dropdownXpath
	 * @param valueToSelect
	 * @param elementName
	 * @return boolean
	 * @author H Abdul Hadi
	 * @since 07-03-2020
	 */
	public boolean selectValueFromDropdownUsingXpath(String dropdownXpath, String valueToSelect, String elementName) {
		LPLCoreSync.staticWait(lplCoreConstents.LOW);
		SelectDropDown selectDropDown = new SelectDropDown(driver, By.xpath(dropdownXpath));
		boolean blnResult = selectDropDown.selectValueByVisibleText(valueToSelect);
		if (!blnResult) {
			setErrorMessage(selectDropDown.strError);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Select " + valueToSelect + FROM + elementName + DROPDOWN_TEXT,
					valueToSelect + FROM + elementName + " dropdown should be selected",
					"Selected " + valueToSelect + FROM + elementName + DROPDOWN_TEXT,
					"Failed to select to " + valueToSelect + FROM + elementName + " dropdown using locator["
							+ dropdownXpath + "]. Error: " + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to select the dropdown value by text using Id
	 *
	 * @param dropdownXpath
	 * @param valueToSelect
	 * @param elementName
	 * @return boolean
	 * @author H Abdul Hadi
	 * @since 07-03-2020
	 */
	public boolean selectValueFromDropdownUsingId(String dropdownId, String valueToSelect, String elementName) {
		LPLCoreSync.staticWait(lplCoreConstents.LOW);
		SelectDropDown selectDropDown = new SelectDropDown(driver, By.id(dropdownId));
		boolean blnResult = selectDropDown.selectValueByVisibleText(valueToSelect);
		if (!blnResult) {
			setErrorMessage(selectDropDown.strError);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Select " + valueToSelect + FROM + elementName + DROPDOWN_TEXT,
					valueToSelect + FROM + elementName + " dropdown should be selected",
					"Selected " + valueToSelect + FROM + elementName + DROPDOWN_TEXT,
					"Failed to select to " + valueToSelect + FROM + elementName + " dropdown using locator["
							+ dropdownId + "]. Error: " + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to accept alert popup
	 *
	 * @return void
	 * @author nbajaj
	 * @return
	 * @since 07-16-2020
	 */
	public boolean acceptAlert() {
		boolean blnResult = false;
		try {
			Alert alert = driver.switchTo().alert();
			alert.accept();
			blnResult = true;
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			// Failing the test when exception occurs
			writeStepToReporter(testType.CLICK.name(), false, LPLCoreConstents.TRUE, "Ok Alert", "Pop up", null,
					strError);
		}
		return blnResult;
	}

	/**
	 * Function is used to close the driver
	 *
	 * @return void
	 * @author Abdul Hadi
	 * @since 08/05/2020
	 */
	public void closeDriver() {
		driver.close();
	}

	/**
	 * Function is used to get the Active Browser Tabs
	 *
	 * @return ArrayList<String>
	 * @author Abdul Hadi
	 * @since 08/05/2020
	 */
	public List<String> getActiveBrowserTabs() {
		return new ArrayList<>(driver.getWindowHandles());
	}

	/**
	 * Function is used to switch To newly opened tab
	 * 
	 * @param browserActiveTabs
	 * @return void
	 * @author Abdul Hadi
	 * @since 08/05/2020
	 */
	public void switchToFirstTab(List<String> browserActiveTabs) {
		driver.switchTo().window(browserActiveTabs.get(0));
	}

	/**
	 * Function is used to switch to first tab
	 * 
	 * @param browserActiveTabs
	 * @return void
	 * @author Abdul Hadi
	 * @since 08/05/2020
	 */
	public void switchToSecondTab(List<String> browserActiveTabs) {
		driver.switchTo().window(browserActiveTabs.get(1));
	}

	/**
	 * Function is used for check if element is enabled using xpath
	 *
	 * @param xpath
	 * @param elementName
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/14/2020
	 */
	public boolean isElementEnabled(String xpath, String element) {
		boolean blnResult;
		// Retrieving the weblement
		WebElement webElement = getWebElementUsingXpath(xpath);
		// Checking if element is enabled
		blnResult = webElement.isEnabled();
		if (blnResult)
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"User checks for  " + element + IS_ENABLED, "User should find " + element + IS_ENABLED,
					"User finds the " + element + IS_ENABLED,
					"Failed to see radio button" + IS_ENABLED + element + SPACE + ELEMENT + strError, true);
		return blnResult;
	}

	/**
	 * This method is used to check if the element is disabled using xpath
	 * 
	 * @param xpath
	 * @param elementName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/31/2020
	 **/
	public boolean isRadioButtonSelected(String xpath, String elementName) {
		boolean blnResult;
		// Retrieving the weblement
		WebElement webElement = getWebElementUsingXpath(xpath);
		// Checking if radio button is selected
		blnResult = webElement.isSelected();
		if (blnResult)
			// Passing the step if radio button is selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_CHECKS_FOR + elementName + AND_IT_IS_SELECTED,
					USER_SHOULD_FIND + elementName + AND_IT_IS_SELECTED,
					USER_FINDS_THE + elementName + AND_IT_IS_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, true);
		else
			// Failing the step if radio button is not selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.FALSE,
					USER_CHECKS_FOR + elementName + AND_IT_IS_NOT_SELECTED,
					USER_SHOULD_FIND + elementName + AND_IT_IS_NOT_SELECTED,
					USER_FINDS_THE + elementName + AND_IT_IS_NOT_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, false);

		return blnResult;
	}

	/**
	 * This method is used to verify Color
	 * 
	 * @return boolean
	 *
	 * @author Pullaiah
	 * @since 11/19/2020
	 */
	public String iverifyColor(String xpath) {
		String color = driver.findElement(By.xpath(xpath)).getCssValue("color").trim();
		String[] colorHexa;
		colorHexa = color.replace("rgba(", "").split(",");
		return String.format("#%02x%02x%02x", Integer.parseInt(colorHexa[0].trim()),
				Integer.parseInt(colorHexa[1].trim()), Integer.parseInt(colorHexa[2].trim()));
	}

	/**
	 * This method is used to check if the element is disabled
	 * 
	 * @param String
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/31/2020
	 **/
	public boolean isElementDisabled(String xpath, String element) {
		boolean blnResult;
		blnResult = !isElementEnabled(xpath, element);
		if (blnResult)
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_CHECKS_FOR + element + IS_DISABLED, USER_SHOULD_FIND + element + IS_DISABLED,
					USER_FINDS_THE + element + IS_DISABLED,
					USER_COULD_NOT_FIND_THE + element + IS_DISABLED + SPACE + ELEMENT + strError, true);
		return blnResult;
	}

	/**
	 * This method is used to check if the radio button is not selected
	 * 
	 * @param xpath
	 * @param element
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/31/2020
	 **/
	public boolean isRadioButtonNotSelected(String xpath, String element) {
		boolean blnResult;
		blnResult = !isRadioButtonSelected(xpath, element);
		if (blnResult)
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_CHECKS_FOR + element + IS_DISABLED, USER_SHOULD_FIND + element + IS_DISABLED,
					USER_FINDS_THE + element + IS_DISABLED,
					USER_COULD_NOT_FIND_THE + element + IS_DISABLED + element + SPACE + ELEMENT + strError, true);
		return blnResult;
	}

	/**
	 *
	 * @param cleartext
	 * @param elementName
	 * @return Boolean
	 * @author Krishna Vakalapudi
	 * @since 11/05/2020
	 */
	public boolean clearTextUsingXpath(String locator) {
		boolean blnResult = false;
		WebElement webElement = driver.findElement(By.xpath(locator));
		if (webElement != null) {
			webElement.clear();
			blnResult = true;
		}
		return blnResult;
	}

	/**
	 * This method is used to refresh the webpage
	 * 
	 * @return void
	 * @author Abdul Hadi
	 * @since 01/19/2020
	 */
	public void refreshTheWebpage() {
		driver.navigate().refresh();
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * xpath locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorXpath
	 * @param elementName
	 * @return String
	 * @author Sowmya Nagarajappa
	 * @since 11/20/2020
	 */
	public boolean isElementPresentUsingXpath(String locatorXpath, int maxWaitTimeInSeconds) {
		boolean blnResult = false;
		// Retrieveing the Web element for given xpath locator
		WebElement webElement = getWebElement(LPLCoreConstents.XPATH, locatorXpath, maxWaitTimeInSeconds);
		if (webElement == null)
			blnResult = false;
		else
			blnResult = LPLCoreUtil.isElementPresent(webElement);
		return blnResult;
	}

	/**
	 * This method returns WebElement object for given locator
	 *
	 * @param elementName
	 * @return WebElement
	 * @author Sowmya Nagarajappa
	 * @since 11-20-2020
	 */
	private WebElement getWebElement(String locatorType, String locator, int maxWaitTimeInSeconds) {
		WebElement webElement = null;
		// Waiting the webelement using given locator type and locator
		webElement = LPLCoreSync.waitForWebElement(driver, locatorType, locator, maxWaitTimeInSeconds);
		return webElement;
	}

	/**
	 * This method is used to validate if the downloaded file name contains expected
	 * file name
	 * 
	 * @param exportedFileName
	 * @author Krishna Vakalapudi
	 * @since 11-26-2020
	 */
	public boolean isFileDownloadedWithCorrectName(String exportedFileName) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().BaseInMiliSec);
		waitTillFileDownloaded(LPLCoreUtil.getLatestFilefromDir(lplCoreConstents.DefaultDownloadFolder));
		// validating if the downloaded file name contains expected file name

		if (LPLCoreUtil.getLatestFilefromDir(lplCoreConstents.DefaultDownloadFolder).getName()
				.contains(exportedFileName))
			return true;
		else {
			emptyStr += ACTUAL_NAME + LPLCoreUtil.getLatestFilefromDir(lplCoreConstents.DefaultDownloadFolder).getName()
					+ EXPECTED_NAME + exportedFileName + " ";
			return false;
		}
	}

	/**
	 * This method is used to wait till the file is downloaded
	 * 
	 * @param dwonloadedFile - Download File Name
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11-26-2020
	 */
	public void waitTillFileDownloaded(File downloadedFile) {
		// wait for File download to happen.
		int startTime = 0;
		try {
			// while loop time
			while (startTime <= LPLCoreConstents.getInstance().HIGHEST) {
				if (downloadedFile.exists()) {
					break;
				} else {
					startTime += LPLCoreConstents.getInstance().LOW;
					LPLCoreSync.staticWait(LPLCoreConstents.getInstance().LOW);
				}
			}
		} catch (Exception e) {
			emptyStr += e.getMessage();
		}
	}

	/**
	 * This method is used to check if the dropdown option is selected or not.
	 * 
	 * @param xpath
	 * @param string
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 11/26/2020
	 **/
	public boolean isDropDownOptionSelected(String xpath, String elementName) {
		boolean blnResult;
		// Retrieving the weblement
		WebElement webElement = getWebElementUsingXpath(xpath);
		// Checking if radio button is selected
		blnResult = webElement.isSelected();
		if (blnResult)
			// Passing the step if dropdown option is selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_CHECKS_FOR + elementName + AND_IT_IS_SELECTED,
					USER_SHOULD_FIND + elementName + AND_IT_IS_SELECTED,
					USER_FINDS_THE + elementName + AND_IT_IS_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, true);
		else
			// Failing the step if dropdown option is not selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.FALSE,
					USER_CHECKS_FOR + elementName + AND_IT_IS_NOT_SELECTED,
					USER_SHOULD_FIND + elementName + AND_IT_IS_NOT_SELECTED,
					USER_FINDS_THE + elementName + AND_IT_IS_NOT_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, false);

		return blnResult;
	}

	/**
	 * This method is used to pick past date from calendar.
	 * 
	 * @param String
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 12/17/2020
	 **/
	public boolean pickDateFromCalendar(String monthLocator, String dateLocator, String locator, String yearAndMonth,
			String requiredDate) {
		boolean monthBlnResult = false;
		boolean dateBlnResult = false;
		String month;
		// Retrieving the weblement
		WebElement monthLoc = getWebElement(MONTH_YEAR, LPLCoreConstents.XPATH, monthLocator,
				LPLCoreConstents.getInstance().LOW);
		WebElement backButtonLoc = getWebElementUsingXpath(locator);
		// To get required month and year
		while (true) {
			month = monthLoc.getText();
			// To check current month and year displayed in calendar are required month and
			// year
			if (month.equals(yearAndMonth)) {
				monthBlnResult = true;
				break;
			}
			// to go to previous month or year by clicking next or previous buttons
			else
				backButtonLoc.click();
		}
		dateBlnResult = clickElementUsingXpath(getFormattedLocator(dateLocator, requiredDate), REQUIRED_DATE);
		return (monthBlnResult && dateBlnResult);
	}

	/**
	 * This method is used to tab out of any editable web element.
	 * 
	 * @param xpath
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 12/17/2020
	 **/
	public void clickOnTabButton(String locator) {
		WebElement webElement = getWebElementUsingXpath(locator);
		webElement.sendKeys(Keys.TAB);
	}

	/**
	 * This method is used to get Date Format as per LPL Standard Report Calendar
	 * 
	 * @param calendar
	 * @return String
	 *
	 * @author Siddharth Gupta
	 * @since 12/14/2020
	 */
	public String getDateFormat(Calendar calendar) {
		DateFormat dateFormat = null;
		int month = calendar.get(Calendar.MONTH);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		if (dayOfMonth < 10) {
			if (month < 9)
				dateFormat = new SimpleDateFormat("M/d/yyyy");
			else
				dateFormat = new SimpleDateFormat("MM/d/yyyy");
		} else {
			if (month < 9)
				dateFormat = new SimpleDateFormat("M/dd/yyyy");
			else
				dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		}
		return dateFormat.format(calendar.getTime());
	}

	/**
	 * This method is used to verify count of accounts displayed
	 * 
	 * @param strAccountsTotalCountXpath
	 * @param strTotalRecordsFoundXpath
	 * @param strNoRecoundFoundXpath
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 01/18/2021
	 */

	// Verify count of Accounts Displayed | 0
	public boolean verifyCountOfAccountsDisplayed(String strAccountsTotalCountXpath, String strTotalRecordsFoundXpath,
			String strNoRecoundFoundXpath) {
		boolean blnResult = false;
		String totalRecordsCountText = getTextUsingXpath(strAccountsTotalCountXpath, TOTAL_RECORDS_COUNT).trim();
		String intValue = totalRecordsCountText.replaceAll(NUMERIC_REGEX, EMPTY_STRING);
		int totalRecordCount = Integer.parseInt(intValue);
		if (totalRecordCount > 0) {
			List<WebElement> totalRecordsFound = getWebElementsUsingXpath(strTotalRecordsFoundXpath,
					TOTAL_RECORDS_FOUND);
			int totaRecordsFoundCount = totalRecordsFound.size();
			if (totaRecordsFoundCount == totalRecordCount)
				blnResult = true;
		} else {
			blnResult = isElementPresentUsingXpath(strNoRecoundFoundXpath, NO_RECORDS_FOUND);
		}
		return blnResult;
	}

	/**
	 * This method is used to check if the dropdown value is selected or not.
	 * 
	 * @param xpath
	 * @param string
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 01/20/2020
	 **/
	public boolean isDropDownValueSelected(String xpath, String elementName) {
		boolean blnResult;
		// Retrieving the weblement
		Select select = new Select(driver.findElement(By.xpath(xpath)));
		WebElement option = select.getFirstSelectedOption();
		String drpdwnSelectedVal = option.getText();
		// Checking if Selected value is displayed in dropdown
		blnResult = (elementName.equals(drpdwnSelectedVal));
		if (blnResult)
			// Passing the step if dropdown option is selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_CHECKS_FOR + elementName + AND_IT_IS_SELECTED,
					USER_SHOULD_FIND + elementName + AND_IT_IS_SELECTED,
					USER_FINDS_THE + elementName + AND_IT_IS_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, true);
		else
			// Failing the step if dropdown option is not selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.FALSE,
					USER_CHECKS_FOR + elementName + AND_IT_IS_NOT_SELECTED,
					USER_SHOULD_FIND + elementName + AND_IT_IS_NOT_SELECTED,
					USER_FINDS_THE + elementName + AND_IT_IS_NOT_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, false);

		return blnResult;
	}

	/**
	 * Function is used to switch to Third tab
	 * 
	 * @param browserActiveTabs
	 * @return void
	 * @author Siddharth Gupta
	 * @since 02/19/2021
	 */
	public void switchToThirdTab(List<String> browserActiveTabs) {
		driver.switchTo().window(browserActiveTabs.get(2));
	}

	/**
	 * Function is used to switch to Original(Home) Tab/Handle
	 * 
	 * @param originalHandle
	 * @return void
	 * @author Siddharth Gupta
	 * @since 02/19/2021
	 */
	public void switchToOriginalHandle(String originalHandle) {
		for (String handle : driver.getWindowHandles()) {
			if (!handle.equals(originalHandle)) {
				driver.switchTo().window(handle);
				driver.close();
			}
		}
		driver.switchTo().window(originalHandle);
	}

	/**
	 * This method is used to Log-in in new tab opening
	 * 
	 * @return void
	 * @author Abdul Hadi
	 * @since 02/23/2021
	 */
	public void logInNewTabOpening() {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		windowsSecurityLoginForChrome("corp\\" + loginCredentials.get("Username"), loginCredentials.get("Password"));
		// Wait to handle the second time windows authentication attempt
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
	}

	/**
	 * This method is used to get random decimal digits
	 *
	 * 
	 * @return String
	 * @author Siddharth Gupta
	 * @since 02/23/2021
	 */
	public String getRandomDecimalDigit() {
		int min = 414;
		int max = 555;
		Random random = new Random();
		double doubleRandom = min + random.nextFloat() * (max - min);
		double doubleRoundUp = Math.round(doubleRandom * 100.0) / 100.0;
		return Double.toString(doubleRoundUp);
	}
	
	/**
	 * This method is used to get current date
	 *
	 * 
	 * @return String
	 * @author Krishna Vakalapudi
	 * @since 04/09/2021
	 */
	public String getCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		String strDate = dateFormat.format(new Date());
		return strDate;
	}
	
	/**
	 * This method is used to get first date of the current month as per LPL Standard Report Calendar Format
	 * 
	 * @param calendar
	 * @return String
	 *
	 * @author Siddharth Gupta
	 * @since 06/14/2021
	 */
	public String getFirstDateOfTheCurrentMonth(Calendar calendar) {
		DateFormat dateFormat = null;
		int month = calendar.get(Calendar.MONTH); // this takes current date
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		if (dayOfMonth < 10) {
			if (month < 9)
				dateFormat = new SimpleDateFormat("M/d/yyyy");
			else
				dateFormat = new SimpleDateFormat("MM/d/yyyy");
		}
		
		return dateFormat.format(calendar.getTime());
	}
}
