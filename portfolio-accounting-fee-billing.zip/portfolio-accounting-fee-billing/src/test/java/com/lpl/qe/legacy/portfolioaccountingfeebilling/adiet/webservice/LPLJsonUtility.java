package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class LPLJsonUtility {

    static String strError = "";
    static String strMessage = "";

    /**
     * This method is used to get the map containing the json object element names and its values for given json(string) and element path
     *
     * @param jsonString
     * @param elementPath
     * @return Map<String, String>
     * @author pmanohar
     * @since 9.17.2020
     */
	/*
	 * public static Map<String, String> getJsonObjectElements(String jsonString,
	 * String elementPath) { Map<String, String> jsonObjectElements = new
	 * HashMap<>(); try { DocumentContext jsonContext = JsonPath.parse(jsonString);
	 * Map<String, Object> control = jsonContext.read(elementPath); for
	 * (Map.Entry<String, Object> mapElement : control.entrySet())
	 * jsonObjectElements.put(mapElement.getKey(),
	 * String.valueOf(mapElement.getValue())); } catch (PathNotFoundException e) {
	 * writeResultForInvalidPath(elementPath); } return jsonObjectElements; }
	 */

    /**
     * This method is used to get the List of maps containing the json object element names and its values for given json(string) and element path
     *
     * @param jsonString
     * @param elementPath
     * @return List<Map < String, String>>
     * @author pmanohar
     * @since 9.17.2020
     */
	/*
	 * public static List<Map<String, String>> getListOfJsonObjectElements(String
	 * jsonString, String elementPath) { String[] elementsToExclude =
	 * {"renameStateOrd","hold","jobStatus","predCurrentJobStateOrd",
	 * "predCurrentJobStateName", "jobStateOrd", "jobStateName", "predAsOfDate",
	 * "predAsOfTime", "predJobStatus","asOfDate","asOfTime"}; List<Map<String,
	 * String>> listOfJsonObjectElements = new ArrayList<>(); try { Map<String,
	 * String> jsonObjectElements; DocumentContext jsonContext =
	 * JsonPath.parse(jsonString); List<Map<String, Object>> elements =
	 * jsonContext.read(elementPath); for (Map<String, Object> element : elements) {
	 * jsonObjectElements = new HashMap<>(); for (Map.Entry<String, Object>
	 * mapElement : element.entrySet()) if
	 * (!Arrays.asList(elementsToExclude).contains((mapElement.getKey())))
	 * jsonObjectElements.put(mapElement.getKey(),
	 * String.valueOf(mapElement.getValue()));
	 * listOfJsonObjectElements.add(jsonObjectElements); } } catch
	 * (PathNotFoundException e) { writeResultForInvalidPath(elementPath); } return
	 * listOfJsonObjectElements; }
	 */

    /**
     * This method is used to get the text from the file as a string using the file name(along with its path)
     *
     * @param filePath
     * @return String
     * @author kmcbarne
     * @since 9.17.2020
     */
    public static String readTextFromFile(String filePath) {
        String data = "";
        try {
            File file = new File(filePath);
            BufferedReader br = new BufferedReader(new FileReader(file));
            String text;
            while ((text = br.readLine()) != null)
                data += text;
            br.close();
        } catch (IOException e) {
            LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE,
                    LPLCoreConstents.TRUE,
                    "Read data from file[" + filePath + "]",
                    "Data should be successfully read from the file",
                    "Data is successfully read",
                    "Unable to read the data from file[" + filePath + "]. Please check the file path");
        }
        return data;
    }

    /**
     * This method is used to compare the two maps(expected vs actual) and return true if they contain the same set of values else false.
     * StrMessage variable is initialized with expected and actual values.
     * StrError variable is initialized with error details in case of any mismatch.
     *
     * @param expected
     * @param actual
     * @return boolean
     * @author pmanohar
     * @since 9.17.2020
     */
    public static boolean compareMaps(Map<String, String> expected, Map<String, String> actual) {
        resetStrErrorAndMessage();
        Map<String, String> expectedMap = expected;
        List<String> expectedKeys = new ArrayList<>(expected.keySet());
        List<String> actualKeys = new ArrayList<>(actual.keySet());
        List<String> missingKeys = getMissingValues(expectedKeys, actualKeys);
        if (missingKeys.size() > 0) {
            setStrError("Missing keys in Actual Result Map -> " + String.join(", ", missingKeys));
            for (String value : missingKeys)
                expectedMap.remove(value);
        }

        List<String> mismatchValues = new ArrayList<>();
        for (Map.Entry<String, String> expectedMapElement : expectedMap.entrySet()) {
            String expectedKey = expectedMapElement.getKey();
            String expectedValue = expectedMapElement.getValue();
            String actualValue = actual.get(expectedKey);
            if (!actualValue.equals(expectedValue))
                mismatchValues.add(expectedKey + "[Expected: " + expectedValue + " Actual: " + actualValue + "]");
        }
        if (mismatchValues.size() > 0)
            setStrError("Following Keys have values not matching with expected value -> " + String.join(", ", mismatchValues));
        setStrMessage("Expected : " + expected + " Actual: " + actual);
        return missingKeys.size() == 0 && mismatchValues.size() == 0;
    }

    /**
     * This method is used to compare the two list of maps(expected vs actual) and return true if they contain the same set of values else false.
     * StrMessage variable is initialized with expected and actual values.
     * StrError variable is initialized with error details in case of any mismatch.
     *
     * @param expectedListOfMaps
     * @param actualListOfMaps
     * @return boolean
     * @author pmanohar
     * @since 9.17.2020
     */
    public static boolean compareListOfMaps(List<Map<String, String>> expectedListOfMaps, List<Map<String, String>> actualListOfMaps) {
        resetStrErrorAndMessage();
        if (expectedListOfMaps.size() == 0 && actualListOfMaps.size() == 0) {
            setStrMessage("There are no values expected. Expected Json Elements: " + expectedListOfMaps + ". Actual Json Element: " + actualListOfMaps);
            return true;
        }
        setStrMessage("Expected Json Elements: " + expectedListOfMaps + ". Actual Json Element: " + actualListOfMaps);
        List<Map<String, String>> missingMaps = new ArrayList<>();
        for (Map<String, String> map : expectedListOfMaps)
            if (!isMapPresentInList(map, actualListOfMaps))
                missingMaps.add(map);
        if (missingMaps.size() > 0)
            setStrError("Missing Json Elements are : " + missingMaps);
        return missingMaps.size() == 0;
    }

    /**
     * This method is used to check if the given map(set of key-value pair) is present in the list of map.
     *
     * @param expectedMap
     * @param mapList
     * @return boolean
     * @author pmanohar
     * @since 9.17.2020
     */
    public static boolean isMapPresentInList(Map<String, String> expectedMap, List<Map<String, String>> mapList) {
        for (Map<String, String> map : mapList)
            if (areMapsSame(expectedMap, map)) return true;
        return false;
    }

    /**
     * This method is used to check if the given map object contains same set of keys and values.
     *
     * @param expected
     * @param actual
     * @return boolean
     * @author pmanohar
     * @since 9.17.2020
     */
    public static boolean areMapsSame(Map<String, String> expected, Map<String, String> actual) {
        Map<String, String> expectedMap = expected;
        List<String> mismatchValues = new ArrayList<>();
        for (Map.Entry<String, String> expectedMapElement : expectedMap.entrySet()) {
            String expectedKey = expectedMapElement.getKey();
            String expectedValue = expectedMapElement.getValue();
            String actualValue = actual.get(expectedKey);
            if (!actualValue.equals(expectedValue))
                mismatchValues.add(expectedKey + "[Expected: " + expectedValue + " Actual: " + actualValue + "]");
        }
        return mismatchValues.size() == 0;
    }

    /**
     * This method is used to compare two lists to see if they have same set of values(order can be different) and return true if they are same
     *
     * @param expectedValuesList - expected list of values
     * @param actualValuesList   - actual list of values
     * @return boolean
     * @author pmanohar
     * @since 6/10/2020
     */
    public static boolean compareLists(List<String> expectedValuesList, List<String> actualValuesList) {
        String[] expectedValuesArray = convertListToArray(expectedValuesList);
        String[] actualValuesArray = convertListToArray(actualValuesList);
        return compareArrays(expectedValuesArray, actualValuesArray);
    }

    /**
     * This method is used to compare two arrays to see if they have same set of values(order can be different) and return true if they are same
     *
     * @param expectedValues - array of expected values
     * @param actualValues   - array of actual values
     * @return boolean
     * @author pmanohar
     * @since 9.17.2020
     */
    public static boolean compareArrays(String[] expectedValues, String[] actualValues) {
        Arrays.sort(expectedValues);
        Arrays.sort(actualValues);
        strMessage += "Expected values - [" + String.join(", ", expectedValues) + "]. Actual values - [" + String.join(", ", actualValues) + "]. ";
        return Arrays.equals(expectedValues, actualValues);
    }

    /**
     * This method is used to compare the 2 arrays(expected vs actual) and return the values which are missing in the actual array
     *
     * @param expectedValues - array of expected values
     * @param actualValues   - array of actual values
     * @return List<String>
     * @author pmanohar
     * @since 9.17.2020
     */
    public static List<String> getMissingValues(String[] expectedValues, String[] actualValues) {
        Map<String, Boolean> results = new HashMap<>();
        List<String> missingValues = new ArrayList<>();
        for (String expectedValue : expectedValues) {
            for (String actualValue : actualValues)
                if (actualValue.equals(expectedValue))
                    results.put(expectedValue, true);
            if (!results.containsKey(expectedValue))
                results.put(expectedValue, false);
            missingValues.add(expectedValue);
        }
        Map<String, Boolean> filteredResult = results.entrySet().stream().filter(map -> map.getValue() == false).collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));
        return new ArrayList<>(filteredResult.keySet());
    }

    /**
     * This method is used to compare the 2 lists(expected vs actual) and return the values which are missing in the actual list
     *
     * @param expectedValues - list of expected values
     * @param actualValues   - list of actual values
     * @return List<String>
     * @author pmanohar
     * @since 9.17.2020
     */
    public static List<String> getMissingValues(List<String> expectedValues, List<String> actualValues) {
        String[] expectedValuesArray = convertListToArray(expectedValues);
        String[] actualValuesArray = convertListToArray(actualValues);
        return getMissingValues(expectedValuesArray, actualValuesArray);
    }

    /**
     * This method is used to convert the list to an string array
     *
     * @param list - List that need to be converted into string array
     * @return String[]
     * @author pmanohar
     * @since 6/10/2020
     */
    public static String[] convertListToArray(List<String> list) {
        String[] str = new String[list.size()];
        Object[] objectArray = list.toArray();
        int i = 0;
        for (Object obj : objectArray)
            str[i++] = (String) obj;
        return str;
    }

    /**
     * This method is used to initialize the strError variable with error information required for reporting when test fails
     *
     * @param text - Error message
     * @author pmanohar
     * @since 9.17.2020
     */
    public static void setStrError(String text) {
        strError += text;
    }

    /**
     * This method is used to initialize the strMessage variable with information required for reporting
     *
     * @param text - Error message
     * @author pmanohar
     * @since 9.17.2020
     */
    public static void setStrMessage(String text) {
        strMessage += text;
    }

    /**
     * This method is used to return the value stored in strError variable
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getStrError() {
        return strError;
    }

    /**
     * This method is used to return the value stored in strMessage variable
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getStrMessage() {
        return strMessage;
    }

    /**
     * This method is used to reset the value of strError to empty string
     *
     * @author pmanohar
     * @since 9.17.2020
     */
    public static void resetStrError() {
        strError = "";
    }

    /**
     * This method is used to reset the value of strMessage to empty string
     *
     * @author pmanohar
     * @since 9.17.2020
     */
    public static void resetStrMessage() {
        strMessage = "";
    }

    /**
     * This method is used to reset the value of strMessage and strError to empty string
     *
     * @author pmanohar
     * @since 9.17.2020
     */
    public static void resetStrErrorAndMessage() {
        resetStrError();
        resetStrMessage();
    }


    /**
     * This method is used to reset the value of strMessage and strError to empty string
     *
     * @param elementPath - path of the element in the json
     * @author pmanohar
     * @since 9.17.2020
     */
    public static void writeResultForInvalidPath(String elementPath) {
        LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE,
                LPLCoreConstents.TRUE,
                "Retrieve the Json Array/Object for the given path[" + elementPath + "]",
                "Element should be retrieved successfully",
                "Element is retrieved successfully",
                "Unable to retrieve element for path[" + elementPath + "]. Please check the element path.");
    }
}
