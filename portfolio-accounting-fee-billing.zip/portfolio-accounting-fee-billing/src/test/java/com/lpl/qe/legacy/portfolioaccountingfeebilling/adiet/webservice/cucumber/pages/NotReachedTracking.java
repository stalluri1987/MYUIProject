package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> NotReachedTracking.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for NotReachedTracking</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * NotReachedTracking : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author Abdul Hadi
 * @since 06/11/2020
 *        </p>
 */

public class NotReachedTracking extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 904;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String NOT_REACHED_TRACKING_PAGE_HEADER = "Not Reached Tracking Page Header";
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String SUCESSFULLY_ABLE_TO_SEE = "Successfully be able to see ";
	public static final String OPTION = "options";
	public static final String EXPORT_NOTIFICATION = "Export Notification";
	public static final String TRACKING_STATUS_DRPDWN = "Tracking status dropdown";

	String strNotReachedTrackingHeaderXpath;
	String strTrackingDropDownXpath;
	String strColumnsInReportsXpath;
	String strTotalAccountsCountXpath;
	String strTrackingDropDownOptionsXpath;
	String strTotalRecordsFoundXpath;
	String strNoRecoundFoundXpath;
	String strExportNotificationXpath;
	String strTrackingStatusNotReachedDropdownXpath;

	public NotReachedTracking(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/11/2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strNotReachedTrackingHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				NOT_REACHED_TRACKING_PAGE_HEADER);
	}

	/**
	 * This method is used to check If Option Available In Tracking Status Dropdown
	 * 
	 * @param trackingOption
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/24/2020
	 */

	public boolean checkIfOptionsAvailableInTrackingStatusDropdown(String trackingOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strTrackingDropDownOptionsXpath, trackingOption),
				LPLCoreConstents.getInstance().HIGH, trackingOption);
	}

	/**
	 * This method is used to check If Options Available In Tracking Status Dropdown
	 * 
	 * @param trackingOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/24/2020
	 */
	// To verify the options available in the dropdown TrackingStatus
	public boolean verifyOptionsAvailableInTrackingStatusDropdown(DataTable trackingOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = trackingOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTION);
			blnResult = checkIfOptionsAvailableInTrackingStatusDropdown(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If Column Available In Report
	 * 
	 * @param columnInReport
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/24/2020
	 */
	public boolean checkIfColumnsAvailableInReport(String columnInReport) {
		return isElementPresentUsingXpath(getFormattedLocator(strColumnsInReportsXpath, columnInReport),
				LPLCoreConstents.getInstance().HIGH, columnInReport);
	}

	/**
	 * This method is used to check If Columns Available In Report
	 * 
	 * @boolean columnsInReport
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/24/2020
	 */
	// To verify the options available in the dropdown TrackingStatus
	public boolean verifyColumnsAvailableInReport(DataTable columnsInReport) {
		boolean blnResult = false;
		List<Map<String, String>> filters = columnsInReport.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTION);
			blnResult = checkIfColumnsAvailableInReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/24/2020
	 */
	public boolean verifyCountOfAccountsDisplayed() {
		return verifyCountOfAccountsDisplayed(strTotalAccountsCountXpath, strTotalRecordsFoundXpath,
				strNoRecoundFoundXpath);
	}

	/**
	 * This method is used to verify selected value in Tracking Status Drop Down
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/19/2020
	 */
	public boolean verifyValueIsSelectedInTrackingStatusDropdown(String selectedValue) {
		return isDropDownValueSelected(strTrackingDropDownXpath, selectedValue);
	}

	/**
	 * This method is used to check Export Notification button is enabled
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/19/2020
	 */
	public boolean verifyExportNotificationIsEnabled() {
		return isElementPresentUsingXpath(ENABLED, strExportNotificationXpath, EXPORT_NOTIFICATION);
	}

	/**
	 * This method is used to check Export Notification button is displayed
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/19/2020
	 */
	public boolean verifyExportNotificationIsDisplayed() {
		return isElementPresentUsingXpath(DISPLAYED, strExportNotificationXpath, EXPORT_NOTIFICATION);
	}

	/**
	 * This method is used to select value in Tracking status Drop Down
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/19/2020
	 */
	public boolean selectValueInTrackingStatusDropdown(String drpdwnValue) {
		selectValueFromDropdownUsingXpath(strTrackingDropDownXpath, drpdwnValue, TRACKING_STATUS_DRPDWN);
		return verifyValueIsSelectedInTrackingStatusDropdown(drpdwnValue);
	}

	/**
	 * This method is used to check Export Notification is disabled
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/23/2020
	 */
	public boolean verifyExportNotificationIsDisabled() {
		return !isElementPresentUsingXpath(ENABLED, strExportNotificationXpath, EXPORT_NOTIFICATION);
	}

	/**
	 * This method is used to select option from the dropdown TrackingStatus
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 02/24/2020
	 */

	public boolean selectAllOptionInTrackingStatusDropdown(String dropDownOptionToSelect) {
		return selectValueFromDropdownUsingXpath(strTrackingStatusNotReachedDropdownXpath, dropDownOptionToSelect,
				TRACKING_STATUS_DRPDWN);
	}
}
