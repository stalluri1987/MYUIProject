package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> AccountUpdatesAndInfo.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for AccountUpdatesAndInfo</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */
public class AccountUpdatesAndInfo extends Common implements ILocatorInitialize {
	static final int PAGE_IDENTIFIER = 678;
	Map<String, HashMap<String, String>> pageObjectMap;
	String strAccountNoTextBoxXpath;
	String strSearchButtonXpath;
	String strExportButtonXpath;
	String strBulkUpdateButtonXpath;
	String strViewADGroupsLinkXpath;
	String strAccountNoResultsLinkXpath;
	String strPlaceholderTextXpath;
	String strAllTableHeadersXpath;
	String strAccountUpdatesAndInfoHeaderXpath;
	String strFileProcessingStatusHeaderXpath;
	String strFeeTypeIconLinkXpath;
	String strAccountDetailsHeaderXpath;
	String strUpdateFeeTypePopUpHeaderXpath;
	String strFeeTypeLabelXpath;
	String strFlatRadioButtonXpath;
	String strFlatTextBoxXpath;
	String strIconBesideTextBoxXpath;
	String strTieredRadioButtonXpath;
	String strTieredDropdownXpath;
	String strCancelButtonXpath;
	String strConfirmaChangesButtonXpath;
	String strFeeTypeFieldXpath;
	String strFlatLabelXpath;
	String strFlatFeeValueXpath;
	String strTieredLabelXpath;
	String strTieredScheduleXpath;
	String strTierScheduleTableHeadersXpath;
	String strHHNoFieldXpath;
	String strHHNoColumnXpath;
	String strHHColumnValueXpath;
	String strHouseholdFieldXpath;
	String strGroupIdAndGroupNameXpath;
	String strFeesCreditsTabXpath;
	String strFeesCreditsFieldsXpath;
	String strGridHeadersXpath;
	String strFeeCreditAdjFieldXpath;
	String strConfirmAddButtonDisabledXpath;
	String strDeleteTextFromDescriptionFieldXpath;
	String strAuditLogTabXpath;
	String strDateRangeLabelXpath;
	String strAuditLogFieldXpath;
	String strDateRangeDropDownFieldsXpath;
	String strSearchButtonEnabledXpath;
	String strExportButtonEnabledXpath;
	String strFiservInfoTabXpath;
	String strFiservInfoFieldsXpath;
	String strUnTermMarkXpath;
	String strUntermDateXpath;
	String strFiservInfoXpath;
	String strFeeCyclesXpath;
	String strTermdateXpath;
	String strTIDSFieldsXpath;
	String strTIDSTabXpath;
	String strInceptionToDateOptionXpath;
	String strSleevesFieldXpath;
	String strSleevesTabXpath;
	String strBillingSettingsTabXpath;
	String strAcntAllTableHeadersXpath;
	String strTransactionTabXpath;
	String strTransactionGridHeaderXpath;
	String strB2AConvDateLabelXpath;
	String strAccountStatusLabelXpath;
	String strProgramSNConvDateLabelXpath;
	String strPerformanceFieldsXpath;
	String strLast180DaysOptionXpath;
	String strPerformanceTabXpath;
	String strMissingAccountPopupLabelsXpath;
	String strSmallAccountFeeDropdownXpath;
	String strInsertAccountRecordButtonXpath;
	String strFeeTypeOptionsXpath;
	String strFeeCycleDropdownXpath;
	String strCreateButtonXpath;
	String strMissingAccountsPopupXpath;
	String strWarningMessageXpath;
	String strMissingAccountPopupCancelXpath;
	String strClickSmallAccountFeeDropdownXpath;
	String strClickFeeCycleDropdownXpath;
	String strSaveButtonXpath;
	String strAdvisoryRateChangeFieldXpath;
	String strAdvisoryRateChangeFieldCalXpath;
	String strstrAdvisoryRateCalMonthXpath;
	String strstrAdvisoryRateCalDateXpath;
	String strstrAdvisoryRateCalBackButtonXpath;
	String strConfirmButtonXpath;
	String strHeaderSortButtonXpath;
	String strDateRangeDrpdwnXpath;
	String strTransacionGridXpath;
	String strTransactionDatesXpath;
	String strInceptionDateXpath;
	String strTxnSearchButtonXpath;
	String strStartDateXpath;
	String strEndDateXpath;
	String strFiservInceptDateXpath;
	String strFlatFeeCalcDateTextBoxXpath;
	String strFlatFeeInvalidDateTextXpath;
	String strPayingAccTextBoxXpath;
	String strAccSearchXpath;
	String strAccSearchTextBoxXpath;
	String strAccSearchButtonXpath;
	String strTargetIconXpath;
	String strTargetFeeCreditTextBoxXpath;
	String strTargetFeeCreditOkButtonXpath;
	String strNewFeeCreditXpath;
	String strFeeCreditAdjXpath;
	String strAddButtonXpath;
	String strGridDetailsXpath;
	String strUnTermButtonXpath;
	String strTermDateTextBoxXpath;
	String strTermLetterDateTextBoxXpath;
	String strTermReasonXpath;
	String strPricingModelHDRXpath;
	String strPricingModelFLDXpath;
	String strUninceptButtonXpath;
	String strInceptDateTextBoxXpath;
	String strDoNotInceptCheckBoxXpath;
	String strTermLetterInvalidDateTextXpath;
	String strNewFeeCreditAmount;
	String strReactivationDateXpath;
	String strReactivationDateNullXpath;
	String strReactivationDateValueXpath;
	String strConfirmationPopUpXpath;

	public static final String PRICING_MODEL_HEADER = "Pricing Model Header";
	public static final String PRICING_MODEL_FLD = "Pricing Model Field Value";
	public static final String HAMBURGER = "Hamburger Icon";
	public static final String SEARCHBUTTON = "Search Button";
	public static final String EXPORTBUTTON = "Export Button";
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String ACCOUNT_UPDATES_AND_INFO_PAGE_HEADER = "Account updates and Info Page Header";
	public static final String USERNAME = "Username";
	public static final String PASSWORD = "Password";
	public static final String HH_COLUMN_VALUE = "HH Column Value";
	public static final String GROUPID_AND_GROUPNAME = "GroupId and GroupNameme";
	public static final String ACCOUNT_DETAILS_HEADER = "Account Details Header";
	public static final String UPDATE_FEETYPE_POPUP_HEADER = "Update FeeType PopUp Header";
	public static final String FEETYPE_LABEL = "FeeType Label";
	public static final String FLAT_RADIO_BUTTON = "Flat radio Button";
	public static final String FLAT_TEXTBOX = "Flat Textbox";
	public static final String ICON_BESIDE_FLAT_TEXTBOX = "Icon Beside TextBox";
	public static final String TIERED_RADIO_BUTTON = "Tiered Radio Button";
	public static final String TIERED_DROPDOWN = "Tiered Dropdown";
	public static final String CANCELBUTTON = "Cancel Button";
	public static final String CONFIRM_FEE_CHANGES_BUTTON = "Confirm Fee Changes Button";
	public static final String FEETYPE_FIELD = "Fee Type field";
	public static final String FLATTYPE_LABEL = "Flat label";
	public static final String TIERED_SCHEDULE = "Tiered Schedule";
	public static final String TIERED_LABEL = "Tiered label";
	public static final String FLAT_RATE_WITH_FORMAT = "Flat rate with format";
	public static final String HHNO_FIELD = "HH No Field";
	public static final String HOUSEHOLD_FIELD = "Household Field";
	public static final String HHNO_COLUMN = "HH No Column";
	public static final String SUCESSFULLY_ABLE_SEE = " Successfully be able to see ";
	public static final String FAILED_TO_SEE = " Failed to see ";
	public static final String SEARCHED_ACCOUNT = "Searched Account";
	public static final String ACCOUNT_NUMBER_TEXTBOX = "Account Number TextBox";
	public static final String ACCOUNT_NUMBER_LINK = "Account Number Link";
	public static final String FEETYPE_ICON_LINK = "FeeType Icon Link";
	public static final String OPTIONS = "options";
	public static final String FEES_CREDITS = "Fees Credits";
	public static final String FEE_CREDITS_ADJ = "Fee Credit Adj";
	public static final String ADD_BUTTON = "Add";
	public static final String DESCRIPTION_TEXTBOX = "Description";
	public static final String DEFAULT_TEXT = "Adjustment to Fee Credit";
	public static final String AUDIT_LOG_TAB = "Audit log tab";
	public static final String DATE_RANGE = "Date range";
	public static final String FISERV_INFO_TAB = "Fiserv Info Tab";
	public static final String TIDS_TAB = "TIDS tab";
	public static final String UN_TERM = "UnTerm";
	public static final String UN_TERM_DATE = "UnTermDate";
	public static final String FISERVTAB = "FiservTab";
	public static final String INCEPTION_TO_DATE = "Inception To Date ";
	public static final String SLEEVES_TAB = "Slevees tab";
	public static final String BILLINGSETTINGSTAB = "Billing Settings Tab";
	public static final String TRANSACTION_TAB = "Transaction tab";
	public static final String TRANSACTION_LOG_CSV_FILE_DOWNLOADED_FILENAME = "FiservTransactionLogCSV";
	public static final String B2ACONVDATE_VALUE = "B2AConvDate";
	public static final String ACCOUNT_STATUS_VALUE = "Account status";
	public static final String PROGRAMSNCONVDATE_VALUE = "Program SN";
	public static final String PERFORMANCE_TAB = "Performance tab ";
	public static final String LAST_180_DAYS = "Last 180 Days";
	public static final String INSERT_ACCOUNT_RECORD_BUTTON = "Insert account record button";
	public static final String WARNING_MESSAGE = "Warning message";
	public static final String INSERTING_MISSINGACCOUNT_POPUP = "Missing Account Popup";
	public static final String CREATEBUTTON = "Cancel button";
	public static final String SMALL_ACCOUNT_FEE = "Small Account Fee";
	public static final String FEECYCLE = "Fee Cycle";
	public static final String ADVISORY_RATE_CHANGE = "Advisory Rate Change ";
	public static final String SAVE_BUTTON = "Save button";
	public static final String CONFIRM_BUTTON = "Confirm button";
	public static final String USER_SHOULD_BE_ABLE_TO_CLICK = "User should be able to click";
	public static final String SUCCESSFULLY_ABLE_TO_CLICK = "Successfully able to click";
	public static final String FAILED_TO_CLICK = "Failed to click";
	public static final String TRANSACTION_DATA = "Transaction Data";
	public static final String DATE_RANGE_DRPDWN = "Date Range dropdown";
	public static final String TXN_DATES = "Transaction Dates";
	public static final String INCEPTION_DATE = "Inception Date";
	public static final String START_DATE = "Start Date";
	public static final String END_DATE = "End Date";
	public static final String DATEFORMAT = "MM/dd/yyyy";
	public static final String FLATFEE_CALCDATE_TEXTBOX = "Flat Fee Calc Date TextBox";
	public static final String PAYINGLPL_TEXTBOX = "Paying LPL Account number TextBox Field";
	public static final String ACC_SEARCH = "Account Details Search";
	public static final String ACC_SEARCH_TEXTBOX = "Account Details Search Field";
	public static final String TARGET_ICON = "Fee Credit Target Icon";
	public static final String TARGET_FEE_CREDIT_TEXTBOX = "Target Fee Credit TextBox";
	public static final String NEW_FEE_CREDIT = "New Fee Credit Field";
	public static final String FEE_CREDIT_ADJ = "Fee Credit Adj Field";
	public static final String GRID_DETAILS = "Fee Credit Grid Details";
	public static final String DOLLAR_SIGN = "$";
	public static final String UNTERM_BUTTON = "Unterm Button";
	public static final String TERM_DATE = "Term Date";
	public static final String TERM_REASON = "Term Reason";
	public static final String TERM_LETTER_DATE = "Term Letter Date";
	public static final String BLANK_VALUE = "�";
	public static final String UNINCEPT_BUTTON = "Unincept Button";
	public static final String INCEPT_DATE = "Incept Date";
	public static final String DONOTINCEPT_CHECKBOX = "Do Not Incept Check Box";
	public static final String SWS_PREMIUM = "SWS Premium";
	public static final String EMPLOYEE_MODEL = "Employee Model";
	public static final String REPAUM = "Rep AUM";
	public static final String BLANK = "Blank";
	public static final String EXCEPTION = "Exception";
	public static final String REACTIVATION_DATE = "Reactivation date";
	public static final String CONFIRMATION_POPUP = "Confirmation popup";

	public AccountUpdatesAndInfo(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to Log in ADIET Application
	 * 
	 * @return void
	 *
	 * @author Abdul Hadi
	 * @since 01-16-2020
	 */
	public void logInToAdietApplication() {
		for (int i = 0; i < 2; i++) {
			windowsSecurityLoginForChrome("corp\\" + loginCredentials.get(USERNAME), loginCredentials.get(PASSWORD));
			// Wait to handle the second time windows authentication attempt
			LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strAccountUpdatesAndInfoHeaderXpath, LPLCoreConstents.getInstance().HIGH,
				ACCOUNT_UPDATES_AND_INFO_PAGE_HEADER);
	}

	/**
	 * This method is used to check If Element Exist Using Placeholder Text
	 * 
	 * @param placeholderText
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean checkIfElementExistUsingPlaceholderText(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strPlaceholderTextXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean checkIfElementExistUsingTableHeaderText(String tableHeaderTextText) {
		return isElementPresentUsingXpath(getFormattedLocator(strAllTableHeadersXpath, tableHeaderTextText),
				tableHeaderTextText);
	}

	/**
	 * This method is used to verify The Availability Of Search Fields
	 * 
	 * @param searchFieldsOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean verifyTheAvailabilityOfSearchFields(DataTable searchFieldsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFieldsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingPlaceholderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to enter Account Number
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean enterAccountNumber() {
		return enterTextUsingXpath(strAccountNoTextBoxXpath, testData.get("strAccountNumber"), ACCOUNT_NUMBER_TEXTBOX);
	}

	/**
	 * This method is used to Click On Search Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean iClickOnSearchButton() {
		return clickElementUsingXpath(strSearchButtonXpath, SEARCHBUTTON);
	}

	/**
	 * This method is used to verify Result for the Searched Account
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean verifyResultShowsTheSearchedAccount() {
		boolean blnResult;
		String searchedAccountResult = getTextUsingXpath(strAccountNoResultsLinkXpath, SEARCHED_ACCOUNT).trim();
		blnResult = searchedAccountResult.equals(testData.get("strAccountNumber"));
		return blnResult;
	}

	/**
	 * This method is used to verify The Fields In Search Results
	 * 
	 * @param searchResultsOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean verifyTheDisplayOfFieldsInSearchResults(DataTable searchResultsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchResultsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to Click the Export Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean iClickOnExportButton() {
		return clickElementUsingXpath(strExportButtonXpath, EXPORTBUTTON);
	}

	/**
	 * This method is used verify whether the file is Downloaded And Deleted
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean verifyDownloadedFileAndDelete() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileName"));
	}

	/**
	 * This method is used to Click On Account No
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean iClickOnAccountNoLink() {
		return clickElementUsingXpath(strAccountNoResultsLinkXpath, LPLCoreConstents.getInstance().HIGH,
				ACCOUNT_NUMBER_LINK);

	}

	/**
	 * This method is used to check Account details page loaded or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isAccountDetailsPageLoaded() {
		return isElementPresentUsingXpath(strAccountDetailsHeaderXpath, LPLCoreConstents.getInstance().LOW,
				ACCOUNT_DETAILS_HEADER);
	}

	/**
	 * This method is used to Click On Icon lick beside Fee Type
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean iClickOnFeeTypeIconLink() {
		return clickElementUsingXpath(strFeeTypeIconLinkXpath, FEETYPE_ICON_LINK);
	}

	/**
	 * This method is used to check Pop up loaded or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isPopUpLoaded() {
		return isElementPresentUsingXpath(strUpdateFeeTypePopUpHeaderXpath, LPLCoreConstents.getInstance().LOW,
				UPDATE_FEETYPE_POPUP_HEADER);
	}

	/**
	 * This method is used to check Fee Type label is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isFeeTypeLabelPresent() {
		return isElementPresentUsingXpath(strFeeTypeLabelXpath, LPLCoreConstents.getInstance().LOW, FEETYPE_LABEL);
	}

	/**
	 * This method is used to check Flat radio button is selected or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isFlatRadioButtonSelected() {
		return isRadioButtonSelected(strFlatRadioButtonXpath, FLAT_RADIO_BUTTON);
	}

	/**
	 * This method is used to check Flat radio button is not selected.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 08/16/2020
	 */
	public boolean isFlatRadioButtonNotSelected() {
		return isRadioButtonNotSelected(strFlatRadioButtonXpath, FLAT_RADIO_BUTTON);
	}

	/**
	 * This method is used to check Flat textbox is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isTextBoxForFlatRatePresent() {
		return isElementPresentUsingXpath(strFlatTextBoxXpath, LPLCoreConstents.getInstance().LOW, FLAT_TEXTBOX);
	}

	/**
	 * This method is used to check Icon(%) beside Flat textbox is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isIconBesideTextBoxPresent() {
		return isElementPresentUsingXpath(strIconBesideTextBoxXpath, LPLCoreConstents.getInstance().LOW,
				ICON_BESIDE_FLAT_TEXTBOX);
	}

	/**
	 * This method is used to check Tiered radio button is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isTieredRadioButtonDisabled() {
		return isElementDisabled(strTieredRadioButtonXpath, TIERED_RADIO_BUTTON);
	}

	/**
	 * This method is used to check Tiered radio button is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 08/14/2020
	 */
	public boolean isTieredRadioButtonSelected() {
		return isRadioButtonSelected(strTieredRadioButtonXpath, TIERED_RADIO_BUTTON);
	}

	/**
	 * This method is used to check Tiered dropdown is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isDropdownForTieredPresent() {
		return isElementPresentUsingXpath(strTieredDropdownXpath, LPLCoreConstents.getInstance().LOW, TIERED_DROPDOWN);
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 08/14/2020
	 */
	public boolean checkIfFieldExistUsingTableHeaderText(String tableHeaderTextText) {
		return isElementPresentUsingXpath(getFormattedLocator(strTierScheduleTableHeadersXpath, tableHeaderTextText),
				tableHeaderTextText);
	}

	/**
	 * This method is used to verify The Availability Of Search Fields
	 * 
	 * @param searchFieldsOptions
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 08/14/2020
	 */
	public boolean verifyTheAvailabilityOfTierSCheduleTableFields(DataTable searchFieldsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFieldsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfFieldExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check Cancel button is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isCancelButtonEnabled() {
		return isElementEnabled(strCancelButtonXpath, CANCELBUTTON);
	}

	/**
	 * This method is used to check Confirm Changes button is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/09/2020
	 */
	public boolean isConfirmFeeChangesButtonDisabled() {
		return isElementDisabled(strConfirmaChangesButtonXpath, CONFIRM_FEE_CHANGES_BUTTON);
	}

	/**
	 * This method is used to check Fee Type field is present or not in Account
	 * details page.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/24/2020
	 */
	public boolean isFeeTypeFieldPresent() {
		return isElementPresentUsingXpath(strFeeTypeFieldXpath, LPLCoreConstents.getInstance().LOW, FEETYPE_FIELD);
	}

	/**
	 * This method is used to check Flat label is present or not in Account details
	 * page.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/24/2020
	 */
	public boolean isFlatLabelPresent() {
		return isElementPresentUsingXpath(strFlatLabelXpath, LPLCoreConstents.getInstance().LOW, FLATTYPE_LABEL);
	}

	/**
	 * This method is used to check Flat rate with format is correct or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/24/2020
	 */
	public boolean isFlatRateIsCorrectWithFormat() {
		return isElementPresentUsingXpath(strFlatFeeValueXpath, LPLCoreConstents.getInstance().LOW,
				FLAT_RATE_WITH_FORMAT);
	}

	/**
	 * This method is used to check Tiered label is present or not in Account
	 * details page.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/24/2020
	 */
	public boolean isTieredLabelPresent() {
		return isElementPresentUsingXpath(strTieredLabelXpath, LPLCoreConstents.getInstance().LOW, TIERED_LABEL);
	}

	/**
	 * This method is used to check Tiered Schedule is correct or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 07/24/2020
	 */
	public boolean isTieredScheduleCorrect() {
		return isElementPresentUsingXpath(strTieredScheduleXpath, LPLCoreConstents.getInstance().LOW, TIERED_SCHEDULE);
	}

	/**
	 * This method is used to check HH No field is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 08/13/2020
	 */
	public boolean isHHNoFieldPresent() {
		return isElementPresentUsingXpath(strHHNoFieldXpath, LPLCoreConstents.getInstance().LOW, HHNO_FIELD);
	}

	/**
	 * This method is used to check HH No Column is present or not in search result.
	 * 
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 08/13/2020
	 */
	public boolean isHHNoColumnPresent() {
		return isElementPresentUsingXpath(strHHNoColumnXpath, LPLCoreConstents.getInstance().LOW, HHNO_COLUMN);
	}

	/**
	 * This method is used to check HH No value for Account
	 * 
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 08/13/2020
	 */
	public boolean toVerifyHHColumnValue() {
		return isElementPresentUsingXpath(getFormattedLocator(strHHColumnValueXpath, testData.get("strHHColumnValue")),
				LPLCoreConstents.getInstance().LOW, HH_COLUMN_VALUE);
	}

	/**
	 * This method is used to check Household field is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 08/13/2020
	 */
	public boolean isHouseholdFieldPresent() {
		return isElementPresentUsingXpath(strHouseholdFieldXpath, LPLCoreConstents.getInstance().LOW, HOUSEHOLD_FIELD);
	}

	/**
	 * This method is used to check GroupId And Group Name for Account in Account
	 * Details Page
	 * 
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 08/13/2020
	 */
	public boolean toVerifyGroupIdAndGroupName() {
		return isElementPresentUsingXpath(
				getFormattedLocator(strGroupIdAndGroupNameXpath, testData.get("strGroupIdAndGroupName")),
				LPLCoreConstents.getInstance().LOW, GROUPID_AND_GROUPNAME);
	}

	/**
	 * This method is used to Click On Fees Credits Tab
	 * 
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 10/28/2020
	 */
	public boolean iClickonFeesCreditsTab() {
		return clickElementUsingXpath(strFeesCreditsTabXpath, LPLCoreConstents.getInstance().LOW, FEES_CREDITS);
	}

	/**
	 * This method is used to verify display of fields in Fees Credits tab
	 * 
	 * @param searchFieldsOptions
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 10/28/2020
	 */
	public boolean verifyDisplayOfFieldsInFeesCreditsTab(DataTable fieldsFeesCredits) {
		boolean blnResult = false;
		List<Map<String, String>> filters = fieldsFeesCredits.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyDisplayOfFieldsInFeesCreditsTab(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}

		return blnResult;
	}

	/**
	 * This method is used to check If fields Exist Using TableHeaderText
	 * 
	 * @param fieldsFeesCredits
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 10/29/2020
	 */
	public boolean verifyDisplayOfFieldsInFeesCreditsTab(String fieldsFeesCredits) {
		return isElementPresentUsingXpath(getFormattedLocator(strFeesCreditsFieldsXpath, fieldsFeesCredits),
				LPLCoreConstents.getInstance().LOWEST, fieldsFeesCredits + OPTIONS);
	}

	/**
	 * This method is used to verify display fields in grid header
	 * 
	 * @param gridHeaders
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 10/28/2020
	 */
	public boolean verifyDisplayOfFieldsInGridHeaders(DataTable gridHeaders) {
		boolean blnResult = false;
		List<Map<String, String>> filters = gridHeaders.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyDisplayOfFieldsInGridHeaders(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If fields Exist Using TableHeaderText
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 10/29/2020
	 */
	public boolean verifyDisplayOfFieldsInGridHeaders(String gridHeaders) {
		return isElementPresentUsingXpath(getFormattedLocator(strGridHeadersXpath, gridHeaders),
				LPLCoreConstents.getInstance().LOWEST, gridHeaders + OPTIONS);
	}

	/**
	 * This method is used to enter Value In Fee Credit Adj Field
	 * 
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 10/29/2020
	 */
	public boolean enterValueInFeeCreditAdjField() {
		clickElementUsingXpath(strFeeCreditAdjFieldXpath, LPLCoreConstents.getInstance().LOW, FEE_CREDITS_ADJ);
		return enterTextUsingXpath(strFeeCreditAdjFieldXpath, testData.get("strFeeCreditAdjField"), FEE_CREDITS_ADJ);
	}

	/**
	 * This method is used to check Add button is present or not.
	 * 
	 * @return boolean
	 *
	 * @author Pinki Sarkar
	 * @since 10/29/2020
	 */
	public boolean isConfirmAddButtonButtonDisabled() {
		return isElementDisabled(strConfirmAddButtonDisabledXpath, ADD_BUTTON);
	}

	/**
	 * This method is used to delete text from Description field.
	 * 
	 * @return boolean
	 *
	 * @authorPinki Sarkar
	 * @since 10/29/2020
	 */
	public boolean iDeleteTextFromDescriptionField() {
		clickElementUsingXpath(strDeleteTextFromDescriptionFieldXpath, LPLCoreConstents.getInstance().LOW,
				DESCRIPTION_TEXTBOX);
		return clearTextUsingXpath(strDeleteTextFromDescriptionFieldXpath);
	}

	/**
	 * This method is used to click on Audit Log tab
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/17/2020
	 */
	public boolean clickOnAuditLogTab() {
		return clickElementUsingXpath(strAuditLogTabXpath, AUDIT_LOG_TAB);
	}

	/**
	 * This method is used to check Audit log grid fields present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/17/2020
	 */
	public boolean verifyFieldsDisplayedInAuditLogTab(DataTable auditlogTableFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = auditlogTableFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedInAuditLogTabUsingText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check Audit log grid fields present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/17/2020
	 */
	public boolean verifyFieldsDisplayedInAuditLogTabUsingText(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strAuditLogFieldXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check Date Range label present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/17/2020
	 */
	public boolean verifyDateRangeLabelIsPresent() {
		return isElementPresentUsingXpath(strDateRangeLabelXpath, LPLCoreConstents.getInstance().LOW, DATE_RANGE);
	}

	/**
	 * This method is used to check Date Change dropdown all values present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/17/2020
	 */
	public boolean verifyFieldsDisplayedDateRangeDropDown(DataTable dateRangeDropDownfields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = dateRangeDropDownfields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedDateRangeDropDownUsingText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check Date Change dropdown all values present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/17/2020
	 */
	public boolean verifyFieldsDisplayedDateRangeDropDownUsingText(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strDateRangeDropDownFieldsXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check Search button is enabled or not in Audit log
	 * tab.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/17/2020
	 */
	public boolean isSearchButtonEnabled() {
		return isElementEnabled(strSearchButtonEnabledXpath, SEARCHBUTTON);
	}

	/**
	 * This method is used to check Export button is enabled or not in Audit log
	 * tab.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/17/2020
	 */
	public boolean isExportButtonEnabled() {
		return isElementEnabled(strExportButtonEnabledXpath, EXPORTBUTTON);
	}

	/**
	 * This method is used to click on fiserv info tab.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/19/2020
	 */

	public boolean clickOnFiservInfoTab() {
		return clickElementUsingXpath(strFiservInfoTabXpath, FISERV_INFO_TAB);
	}

	/**
	 * This method is used to check all fields in Fiserv Info tab present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/19/2020
	 */
	public boolean verifyFieldsDisplayedInFiservInfoTab(DataTable fiservInfoFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = fiservInfoFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedForFiservInfoTabUsingText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to Click on Fiserv Info Tab
	 * 
	 * @return boolean
	 *
	 * @author Pullaiah
	 * @since 11/19/2020
	 */
	public boolean iClickonFiservInfoTab() {
		return clickElementUsingXpath(strFiservInfoXpath, FISERVTAB);
	}

	/**
	 * This method is used to verify Unterm Date
	 * 
	 * @return boolean
	 *
	 * @author Pullaiah
	 * @since 11/19/2020
	 */
	public boolean verifyUntermDate() {
		return clickElementUsingXpath(strFiservInfoXpath, UN_TERM_DATE);
	}

	/**
	 * This method is used to verify FeeCycle Color
	 * 
	 * @return boolean
	 *
	 * @author Pullaiah
	 * @since 11/19/2020
	 */
	public boolean verifyFeeCycleColor(String redColor) {
		String strColor = iverifyColor(strFeeCyclesXpath);
		return redColor.equalsIgnoreCase(strColor);
	}

	/**
	 * This method is used to
	 * 
	 * @return boolean
	 *
	 * @author Pullaiah
	 * @since 11/19/2020
	 */
	public boolean verifyTermDateColor(String redColor) {
		String strColor = iverifyColor(strTermdateXpath);
		return redColor.equalsIgnoreCase(strColor);
	}

	/**
	 * This method is used to verify FisevInfo PageLoads
	 * 
	 * @return boolean
	 *
	 * @author Pullaiah
	 * @since 11/19/2020
	 */
	public boolean verifyPageLoadsFisevInfo() {
		return isElementPresentUsingXpath(strFiservInfoXpath, LPLCoreConstents.getInstance().HIGH, FISERVTAB);
	}

	/**
	 * This method is used to check all fields in Fiserv Info tab present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/19/2020
	 */
	public boolean verifyFieldsDisplayedForFiservInfoTabUsingText(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strFiservInfoFieldsXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check all fields in TIDS tab present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/26/2020
	 */
	public boolean verifyFieldsDisplayedInTIDSTab(DataTable tIDSFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = tIDSFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedForTIDSTabUsingText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check grid header in transaction tab present
	 * 
	 * @param gridHeader
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12/07/2020
	 */
	public boolean verifyGridHeadersUnderTransactionTab(String gridHeader) {
		return isElementPresentUsingXpath(getFormattedLocator(strTransactionGridHeaderXpath, gridHeader),
				LPLCoreConstents.getInstance().MEDIUM, gridHeader);
	}

	/**
	 * This method is used to check grid headers in transaction tab present
	 * 
	 * @param gridHeaders
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12/07/2020
	 */
	public boolean verifyGridHeadersUnderTransactionTab(DataTable gridHeaders) {
		boolean blnResult = false;
		List<Map<String, String>> filters = gridHeaders.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyGridHeadersUnderTransactionTab(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check all fields in TIDS tab present or not
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/26/2020
	 */
	public boolean verifyFieldsDisplayedForTIDSTabUsingText(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strTIDSFieldsXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to click on fiserv info tab.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/26/2020
	 */
	public boolean clickOnTIDSTab() {
		return clickElementUsingXpath(strTIDSTabXpath, TIDS_TAB);
	}

	/**
	 * This method is used to check Inception To Date option is selected by default
	 * in date range dropdown.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 11/26/2020
	 */
	public boolean verifyInceptionToDateOptionIsSelectedByDefault() {
		return isDropDownOptionSelected(strInceptionToDateOptionXpath, INCEPTION_TO_DATE);
	}

	/**
	 * This method is used to check Sleeves is present on the Account details tab
	 * 
	 * @return boolean
	 *
	 * @author Saritha akkaraju
	 * @since 11/25/2020
	 */
	public boolean verifySleevesfieldispresent() {
		return isElementPresentUsingXpath(strSleevesTabXpath, SLEEVES_TAB);
	}

	/**
	 * This method is used to click on Sleeves tab.
	 * 
	 * @return boolean
	 *
	 * @author Saritha Akkaraju
	 * @since 11/25/2020
	 */

	public boolean clickOnSleevesTab() {
		return clickElementUsingXpath(strSleevesTabXpath, SLEEVES_TAB);
	}

	/**
	 * This method is used to check all fields in Sleeves tab present or not
	 * 
	 * @return boolean
	 *
	 * @author Saritha Akkaraju
	 * @since 11/25/2020
	 */
	public boolean verifyFieldsDisplayedForSleevesTabUsingText(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strSleevesFieldXpath, placeholderText), placeholderText);
	}

	/**
	 * This method is used to check all fields in Sleeves tab present or not
	 * 
	 * @return boolean
	 *
	 * @author Saritha akkaraju
	 * @since 11/25/2020
	 */
	public boolean verifythefieldsdisplayedinSleevestab(DataTable sleevesFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = sleevesFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedForSleevesTabUsingText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify The Fields In Search Results
	 * 
	 * @param searchResultsOptions
	 * @return boolean
	 *
	 * @author Pullaiah G
	 * @since 12/2/2020
	 */
	public boolean verifyTheDisplayOfFieldsInSearchResultsAcc(DataTable searchResultsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchResultsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTableHeaderTexts(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Pullaiah G
	 * @since 12/02/2020
	 */
	public boolean checkIfElementExistUsingTableHeaderTexts(String tableHeaderTextText) {
		return isElementPresentUsingXpath(getFormattedLocator(strAcntAllTableHeadersXpath, tableHeaderTextText),
				LPLCoreConstents.getInstance().MEDIUM, tableHeaderTextText);
	}

	/**
	 * This method is used to verify Billing Settings Tab on Account Details popup
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 11/26/2020
	 */
	public boolean iVerifyBillingSettingsTabIsDisplayed() {
		return isElementPresentUsingXpath(strBillingSettingsTabXpath, LPLCoreConstents.getInstance().LOW,
				BILLINGSETTINGSTAB);
	}

	/**
	 * This method is used to click on Transaction tab.
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12/07/2020
	 */
	public boolean clickOnTransactionsTab() {
		return clickElementUsingXpath(strTransactionTabXpath, TRANSACTION_TAB);
	}

	/**
	 * This method is used verify whether the Transaction log CSV file is Downloaded
	 * or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12/11/2020
	 */
	public boolean verifyTransactionLogCsvFileDownloadedSucessfully() {
		return isFileDownloadedWithCorrectName(TRANSACTION_LOG_CSV_FILE_DOWNLOADED_FILENAME);
	}

	/**
	 * This method is used verify B2AConvDate value
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12/16/2020
	 */
	public boolean verifyB2AConvDateValueShouldBlank() {
		return isElementPresentUsingXpath(strB2AConvDateLabelXpath, LPLCoreConstents.getInstance().MEDIUM,
				B2ACONVDATE_VALUE);
	}

	/**
	 * This method is used verify verify Account status value
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12/16/2020
	 */
	public boolean verifyAccountStatusValue() {
		return isElementPresentUsingXpath(strAccountStatusLabelXpath, LPLCoreConstents.getInstance().MEDIUM,
				ACCOUNT_STATUS_VALUE);
	}

	/**
	 * This method is used verify Program SN value
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12/16/2020
	 */
	public boolean verifyProgramSNValue() {
		return isElementPresentUsingXpath(strProgramSNConvDateLabelXpath, LPLCoreConstents.getInstance().MEDIUM,
				PROGRAMSNCONVDATE_VALUE);
	}

	/**
	 * This method is used to click on performance tab.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/04/2020
	 */
	public boolean clickOnPerformanceTab() {
		return clickElementUsingXpath(strPerformanceTabXpath, PERFORMANCE_TAB);
	}

	/**
	 * This method is used to check Last 180 days option is selected by default in
	 * date range dropdown.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/04/2020
	 */
	public boolean verifyLast180DaysOptionIsSelectedByDefault() {
		return isDropDownOptionSelected(strLast180DaysOptionXpath, LAST_180_DAYS);
	}

	/**
	 * This method is used to check all fields in performance tab present or not
	 * 
	 * @param DataTable
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/04/2020
	 */
	public boolean verifyTheDisplayOfFieldsInPerformanceTab(DataTable fieldsPerformance) {
		boolean blnResult = false;
		List<Map<String, String>> filters = fieldsPerformance.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedForPerformanceTabUsingText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check all fields in performance tab present or not
	 * 
	 * @param String
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/04/2020
	 */
	public boolean verifyFieldsDisplayedForPerformanceTabUsingText(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strPerformanceFieldsXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check all fields in Add missing account record to
	 * LPLMastered_Accounts popup
	 * 
	 * @param DataTable
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyTheDisplayOfFieldsInDisplayedPopup(DataTable popupFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = popupFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedForPopupUsingText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check all fields in Add missing account record to
	 * LPLMastered_Accounts popup
	 * 
	 * @param String
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyFieldsDisplayedForPopupUsingText(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strMissingAccountPopupLabelsXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check warning message for missing account in
	 * LPLMAstered_Accounts table.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyWarningMessageForMissingAccount() {
		return isElementPresentUsingXpath(strWarningMessageXpath, LPLCoreConstents.getInstance().MEDIUM,
				WARNING_MESSAGE);
	}

	/**
	 * This method is used to check Add missing account record to
	 * LPLMastered_Accounts popup is displayed.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyMissingAccountPopUpDisplayed() {
		return isElementPresentUsingXpath(strMissingAccountsPopupXpath, LPLCoreConstents.getInstance().MEDIUM,
				INSERTING_MISSINGACCOUNT_POPUP);
	}

	/**
	 * This method is used to click on Create link in ADIET screen.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean clickOnCreateLink() {
		return clickElementUsingXpath(strCreateButtonXpath, CREATEBUTTON);
	}

	/**
	 * This method is used to check all options in Small Account Fee Dropdown
	 * 
	 * @param DataTable
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyTheDisplayOfOptionsForSmallAccountFeeDropdown(DataTable dropdownOptions) {
		clickElementUsingXpath(strClickSmallAccountFeeDropdownXpath, SMALL_ACCOUNT_FEE);
		boolean blnResult = false;
		List<Map<String, String>> filters = dropdownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedForSmallAccountFeeDropdown(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		clickElementUsingXpath(strClickSmallAccountFeeDropdownXpath, SMALL_ACCOUNT_FEE);
		return blnResult;
	}

	/**
	 * This method is used to check all options in Small Account Fee Dropdown
	 * 
	 * @param String
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyFieldsDisplayedForSmallAccountFeeDropdown(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strSmallAccountFeeDropdownXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check all options in Fee Cycle Dropdown
	 * 
	 * @param DataTable
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyTheDisplayOfOptionsForFeeCycleDropdown(DataTable dropdownOptions) {
		clickElementUsingXpath(strClickFeeCycleDropdownXpath, FEECYCLE);
		boolean blnResult = false;
		List<Map<String, String>> filters = dropdownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFieldsDisplayedForFeeCycleDropdown(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		clickElementUsingXpath(strClickFeeCycleDropdownXpath, FEECYCLE);
		return blnResult;
	}

	/**
	 * This method is used to check all options in Fee Cycle Dropdown
	 * 
	 * @param String
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyFieldsDisplayedForFeeCycleDropdown(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strFeeCycleDropdownXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check both flat and tiered options for Fee Type field
	 * 
	 * @param DataTable
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyTheDisplayOfOptionsForFeeTypeField(DataTable options) {
		boolean blnResult = false;
		List<Map<String, String>> filters = options.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyOptionsDisplayedForFeeTypeField(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check both flat and tiered options for Fee Type field
	 * 
	 * @param String
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean verifyOptionsDisplayedForFeeTypeField(String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strFeeTypeOptionsXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check Insert Account Record button is disabled or not.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean validateInsertAccountRecordButtonDisabled() {
		return isElementDisabled(strInsertAccountRecordButtonXpath, INSERT_ACCOUNT_RECORD_BUTTON);
	}

	/**
	 * This method is used to click on Cancel button in popup.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean clickOnCancelButtonInPopup() {
		return clickElementUsingXpath(strMissingAccountPopupCancelXpath, CANCELBUTTON);
	}

	/**
	 * This method is used to enter date for Advisory Rate Change filed in ADIET.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean enterDateInAdvisoryRateChangeField() {
		clickElementUsingXpath(strAdvisoryRateChangeFieldCalXpath, LPLCoreConstents.getInstance().LOW,
				ADVISORY_RATE_CHANGE);
		boolean blnResult = pickDateFromCalendar(strstrAdvisoryRateCalMonthXpath, strstrAdvisoryRateCalDateXpath,
				strstrAdvisoryRateCalBackButtonXpath, testData.get("strAdvisoryRateChangeMonth"),
				testData.get("strAdvisoryRateChangeDate"));
		clickOnTabButton(strAdvisoryRateChangeFieldXpath);
		return blnResult;
	}

	/**
	 * This method is used to click on save button in ADIET.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean clickOnSaveButton() {
		return clickElementUsingXpath(strSaveButtonXpath, LPLCoreConstents.getInstance().MEDIUM, SAVE_BUTTON);
	}

	/**
	 * This method is used to enter date for Advisory Rate Change filed in ADIET.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean deleteDateInAdvisoryRateChangeField() {
		clickElementUsingXpath(strAdvisoryRateChangeFieldXpath, LPLCoreConstents.getInstance().LOW,
				ADVISORY_RATE_CHANGE);
		return clearTextUsingXpath(strAdvisoryRateChangeFieldXpath);
	}

	/**
	 * This method is used to click on Confirm button.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 12/16/2020
	 */
	public boolean clickOnConfirmButton() {
		return clickElementUsingXpath(strConfirmButtonXpath, LPLCoreConstents.getInstance().MEDIUM, CONFIRM_BUTTON);
	}

	/**
	 * This method is used to click on Sort buttons in Peformance tab.
	 * 
	 * @return boolean
	 *
	 * @author Arunaditya Bagchi
	 * @since 12/17/2020
	 */

	public boolean clickOnAllPerformanceHeader(DataTable headerOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = headerOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementClickedUsingTransactionTabHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_CLICK + filterName, USER_SHOULD_BE_ABLE_TO_CLICK + filterName,
					SUCCESSFULLY_ABLE_TO_CLICK + filterName, FAILED_TO_CLICK + filterName + " : " + Common.strError);
		}
		return blnResult;

	}

	/**
	 * This method is used to validate individual header element
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean checkIfElementClickedUsingTransactionTabHeaderText(String tableHeaderTextText) {
		return isElementPresentUsingXpath(getFormattedLocator(strHeaderSortButtonXpath, tableHeaderTextText),
				tableHeaderTextText);
	}

	/**
	 * This method is used to verify selected value in Date Range Drop Down
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 12/18/2020
	 */
	public boolean verifyValueIsSelectedInDateRangeDropdown(String selectedValue) {
		return isDropDownValueSelected(strDateRangeDrpdwnXpath, selectedValue);

	}

	/**
	 * This method is used to verify transaction data is displayed
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 12/18/2020
	 */
	public boolean verifyTransactionDataIsDisplayed() {
		return isElementPresentUsingXpath(DISPLAYED, strTransacionGridXpath, TRANSACTION_DATA);
	}

	/**
	 * This method is used to select value in Date Range Drop Down
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @since 12/18/2020
	 */
	public boolean selectValueInDateRangeDropdown(String drpdwnValue) {
		selectValueFromDropdownUsingXpath(strDateRangeDrpdwnXpath, drpdwnValue, DATE_RANGE_DRPDWN);
		return verifyValueIsSelectedInDateRangeDropdown(drpdwnValue);
	}

	/**
	 * This method is used to verify transaction date is displayed within selected
	 * date range
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @throws ParseException 
	 * 
	 * @since 12/21/2020
	 */
	public boolean checkDateInDateRange(int days) throws ParseException {
		boolean blnResult = false;
		if (isElementNotPresentUsingXpath(strTransactionDatesXpath)) {
			blnResult = true;
		} else {
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(DATEFORMAT);
			SimpleDateFormat dateFormat1 = new SimpleDateFormat(DATEFORMAT);
			LocalDate locDate = LocalDate.now();
			locDate = (locDate).minusDays(days);
			String date = dateFormat.format(locDate);
			Date date1 = dateFormat1.parse(date);
			blnResult = verifyTransactions(date1);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify transaction date is displayed within selected
	 * date range
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @throws ParseException 
	 * 
	 * @since 1/6/2020
	 */
	public boolean verifyTransactions(Date date) throws ParseException {
		boolean blnResult = false;
		List<String> dateValues = null;
		dateValues = getTextForWebElementsUsingXpath(strTransactionDatesXpath, TXN_DATES);
		for (String dateValue : dateValues) {
			SimpleDateFormat dateFormat1 = new SimpleDateFormat(DATEFORMAT);
			Date dateToCheck = dateFormat1.parse(dateValue);
			if (dateToCheck.compareTo(date) > 0 || dateToCheck.compareTo(date)==0) {
				blnResult = true;
			} else {
				blnResult = false;
				break;
			}
		}
		return blnResult;
	}

	public boolean clickOnAllSleevesHeader(DataTable headerOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = headerOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementClickedUsingSleevesTabHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_CLICK + filterName, USER_SHOULD_BE_ABLE_TO_CLICK + filterName,
					SUCCESSFULLY_ABLE_TO_CLICK + filterName, FAILED_TO_CLICK + filterName + " : " + Common.strError);
		}
		return blnResult;

	}

	/**
	 * This method is used to validate individual header element
	 * 
	 * @return boolean
	 * @author sakkaraj
	 * @since 12/28/2020
	 */
	public boolean checkIfElementClickedUsingSleevesTabHeaderText(String tableHeaderTextText) {
		return isElementPresentUsingXpath(getFormattedLocator(strHeaderSortButtonXpath, tableHeaderTextText),
				tableHeaderTextText);
	}

	/**
	 * This method is used to verify transaction date is displayed after starting
	 * year date
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @throws ParseException 
	 * 
	 * @since 12/28/2020
	 */
	public boolean checkDateInYearToDateRange() throws ParseException {
		boolean blnResult = false;
		SimpleDateFormat dateFormat1 = new SimpleDateFormat(DATEFORMAT);
		Date date = dateFormat1.parse(testData.get("strYearDate"));
		if (isElementNotPresentUsingXpath(strTransactionDatesXpath)) {
			blnResult = true;
		} else
			blnResult = verifyTransactions(date);
		return blnResult;
	}

	/**
	 * This method is used to Click On Search Button under Transaction tab
	 * 
	 * @return boolean
	 *
	 * @author Manish Prajapati
	 * @since 12/28/2020
	 */
	public boolean iClickOnSearchButtonUnderTransactionTab() {
		return clickElementUsingXpath(strTxnSearchButtonXpath, SEARCHBUTTON);
	}

	/**
	 * This method is used to verify transaction date is displayed after inception
	 * date
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * @throws ParseException 
	 * 
	 * @since 12/28/2020
	 */
	public boolean checkDateInInceptionToDateRange() throws ParseException {
		boolean blnResult = false;
		SimpleDateFormat dateFormat1 = new SimpleDateFormat(DATEFORMAT);
		waitTillVisibleUsingXpath(strTransactionDatesXpath,INCEPTION_DATE);
		Date date = dateFormat1.parse(getTextUsingXpath(strInceptionDateXpath, INCEPTION_DATE));
		if (isElementNotPresentUsingXpath(strTransactionDatesXpath)) {
			blnResult = true;
		} else
			blnResult = verifyTransactions(date);

		return blnResult;
	}

	/**
	 * This method is used to enter date
	 * 
	 * @return boolean
	 *
	 * @author Manish Prajapati
	 * @since 12/31/2020
	 */
	public boolean enterDate(String locator, String date) {
		WebElement dateBox = getWebElementUsingXpath(strStartDateXpath);
		dateBox.clear();
		dateBox.sendKeys(testData.get("strStartDate"));
		dateBox.sendKeys(Keys.ENTER);
		return true;
	}

	/**
	 * This method is used to enter Start date
	 * 
	 * @return boolean
	 *
	 * @author Manish Prajapati
	 * @since 12/31/2020
	 */
	public boolean startDate() {
		return enterDate(strStartDateXpath, testData.get("strStartDate"));
	}

	/**
	 * This method is used to enter End date
	 * 
	 * @return boolean
	 *
	 * @author Manish Prajapati
	 * @since 12/31/2020
	 */
	public boolean endDate() {
		return enterDate(strEndDateXpath, testData.get("strEndDate"));
	}

	/**
	 * This method is used to verify transaction date is displayed within custom
	 * date range
	 * 
	 * @return boolean
	 * @author Manish Prajapati
	 * 
	 * @since 12/31/2020
	 */
	public boolean checkDateInCustomRange() {
		boolean blnResult = false;
		List<String> dateValues = null;
		if (isElementNotPresentUsingXpath(strTransactionDatesXpath)) {
			blnResult = true;
		} else {
			dateValues = getTextForWebElementsUsingXpath(strTransactionDatesXpath, TXN_DATES);
			for (String dateValue : dateValues) {
				if (dateValue.compareTo(testData.get("strStartDate")) > 0
						&& dateValue.compareTo(testData.get("strEndDate")) < 0) {
					blnResult = true;
				} else {
					blnResult = false;
					break;
				}
			}
		}
		return blnResult;
	}

	/**
	 * This method is used to enter Account Number for Inception Date
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/30/2020
	 */
	public boolean enterAccountNumberForInceptionDate() {
		return enterTextUsingXpath(strAccountNoTextBoxXpath, testData.get("strAccountNumberInceptDate"),
				ACCOUNT_NUMBER_TEXTBOX);
	}

	/**
	 * This method is used to verify Inception Date value as Red color
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 12/30/2020
	 */
	public boolean verifyInceptionDateValueAsRedColor(String redColor) {
		String strColor = iverifyColor(strFiservInceptDateXpath);
		return redColor.equalsIgnoreCase(strColor);
	}

	/**
	 * This method is used to enter LPL Account Number
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/15/2021
	 */
	public boolean enterLPLAccountNumber() {
		return enterTextUsingXpath(strAccountNoTextBoxXpath, testData.get("strLPLAccNumber"), ACCOUNT_NUMBER_TEXTBOX);
	}

	/**
	 * This method is used to Enter Invalid Date in the FlatFeeCalcDate field
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/15/2021
	 */
	public boolean enterInvalidDateInTheFlatFeeCalcDateField() {
		clickElementUsingXpath(strFlatFeeCalcDateTextBoxXpath, LPLCoreConstents.getInstance().LOW,
				FLATFEE_CALCDATE_TEXTBOX);
		clearTextUsingXpath(strFlatFeeCalcDateTextBoxXpath);
		enterTextUsingXpath(strFlatFeeCalcDateTextBoxXpath, testData.get("strValidDate"), FLATFEE_CALCDATE_TEXTBOX);
		clickElementUsingXpath(strBillingSettingsTabXpath, LPLCoreConstents.getInstance().LOW, BILLINGSETTINGSTAB);
		clearTextUsingXpath(strFlatFeeCalcDateTextBoxXpath);
		return enterTextUsingXpath(strFlatFeeCalcDateTextBoxXpath, testData.get("strInvalidDate"),
				FLATFEE_CALCDATE_TEXTBOX);
	}

	/**
	 * This method is used to Verify the Invalid Date Error message for
	 * FlatFeeCalcDate in Billing Setting Tab
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/15/2020
	 */
	public boolean verifyTheInvalidDateErrorMessage() {
		clickOnTabButton(strFlatFeeCalcDateTextBoxXpath);
		clickElementUsingXpath(strSaveButtonXpath, LPLCoreConstents.getInstance().MEDIUM, SAVE_BUTTON);
		return isElementPresentUsingXpath(strSaveButtonXpath, LPLCoreConstents.getInstance().MEDIUM,
				WARNING_MESSAGE);
	}

	/**
	 * This method is used to Click On Paying LPL AccountNo Field
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/21/2021
	 */
	public boolean clickOnPayingLPLAccountNoField() {
		return clickElementUsingXpath(strPayingAccTextBoxXpath, PAYINGLPL_TEXTBOX);
	}

	/**
	 * This method is used to Click On Account Details Search
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/21/2021
	 */
	public boolean clickOnAccountDetailsSearch() {
		return clickElementUsingXpath(strAccSearchXpath, ACC_SEARCH);
	}

	/**
	 * This method is used to Enter Closed or Terminated Account in Search Box
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/15/2021
	 */
	public boolean enterClosedOrTerminatedAccount() {
		clickElementUsingXpath(strAccSearchTextBoxXpath, LPLCoreConstents.getInstance().LOW, ACC_SEARCH_TEXTBOX);
		clearTextUsingXpath(strAccSearchTextBoxXpath);
		return enterTextUsingXpath(strAccSearchTextBoxXpath, testData.get("strTerminatedAccNum"), ACC_SEARCH_TEXTBOX);
	}

	/**
	 * This method is used to search for Closed or Terminated Account
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/21/2021
	 */
	public boolean searchForClosedOrTerminatedAccount() {
		return clickElementUsingXpath(strAccSearchButtonXpath, SEARCHBUTTON);
	}

	/**
	 * This method is used to verify the PayingLPLAccountNo TextBox is Disabled
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/21/2021
	 */
	public boolean verifyThePayingLPLAccountNoTextBoxIsDisabled() {
		clickElementUsingXpath(strPayingAccTextBoxXpath, PAYINGLPL_TEXTBOX);
		return isElementDisabled(strPayingAccTextBoxXpath, PAYINGLPL_TEXTBOX);
	}

	/**
	 * This method is used to click on Target Icon
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/27/2021
	 */
	public boolean clickOnTargetIcon() {
		return clickElementUsingXpath(strTargetIconXpath, TARGET_ICON);
	}

	/**
	 * This method is used to Enter the Target Fee Credit Balance
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/27/2021
	 */
	public boolean enterTheTargetFeeCreditBalance() {
		clickElementUsingXpath(strTargetFeeCreditTextBoxXpath, LPLCoreConstents.getInstance().LOW,
				TARGET_FEE_CREDIT_TEXTBOX);
		strNewFeeCreditAmount = getRandomDecimalDigit();
		enterTextUsingXpath(strTargetFeeCreditTextBoxXpath, strNewFeeCreditAmount, TARGET_FEE_CREDIT_TEXTBOX);
		return clickElementUsingXpath(strTargetFeeCreditOkButtonXpath, TARGET_ICON);
	}

	/**
	 * This method is used to Verify the Balance in new Fee credit Balance Field
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/27/2021
	 */
	public boolean verifyTheBalanceInNewFeeCreditBalanceField() {
		String getNewFeeCreditResult = getTextUsingXpath(strNewFeeCreditXpath, NEW_FEE_CREDIT).trim();
		String getFormatedNumber = DOLLAR_SIGN + strNewFeeCreditAmount;
		return getNewFeeCreditResult.equals(getFormatedNumber)
				? isElementPresentUsingXpath(strNewFeeCreditXpath, LPLCoreConstents.getInstance().MEDIUM,
						NEW_FEE_CREDIT)
				: LPLCoreConstents.FALSE;
	}

	/**
	 * This method is used to Verify the amount in Fee Credit Adj Field
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/27/2021
	 */
	public boolean verifyTheAmountInFeeCreditAdjField() {
		return isElementPresentUsingXpath(strFeeCreditAdjXpath, LPLCoreConstents.getInstance().MEDIUM, FEE_CREDIT_ADJ);
	}

	/**
	 * This method is used to click on Add Button
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/27/2021
	 */
	public boolean clickOnAddButton() {
		return clickElementUsingXpath(strAddButtonXpath, ADD_BUTTON);
	}

	/**
	 * This method is used to verify the new row inserted in Grid
	 * 
	 * @return boolean
	 *
	 * @author Siddharth Gupta
	 * @since 01/27/2021
	 */
	public boolean verifyTheNewRowInsertedInGrid() {
		String getActivityCode = getTextUsingXpath(strGridDetailsXpath, GRID_DETAILS).trim();
		return getActivityCode.equals(testData.get("strActivityCode"))
				? isElementPresentUsingXpath(strGridDetailsXpath, LPLCoreConstents.getInstance().MEDIUM, GRID_DETAILS)
				: LPLCoreConstents.FALSE;
	}

	/**
	 * This method is used to verify the Unterm clears Term Date field
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/02/2021
	 */
	public boolean iClickOnUntermButton() {
		return clickElementUsingXpath(strUnTermButtonXpath, UNTERM_BUTTON);
	}

	/**
	 * This method is used to verify the Term Date field is deleted
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/02/2021
	 */
	public boolean verifyTermDateIsRemoved() {
		String termDate = getTextUsingXpath(strTermDateTextBoxXpath, TERM_DATE).trim();
		return termDate.contentEquals(BLANK_VALUE);
	}

	/**
	 * This method is used to verify the Term Reason field is deleted
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/02/2021
	 */
	public boolean verifyTermReasonIsRemoved() {
		return isElementNotPresentUsingXpath(strTermReasonXpath);
	}

	/**
	 * This method is used to verify the Term Letter Date field is deleted
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/02/2021
	 */
	public boolean verifyTermLetterdateIsRemoved() {
		String termLetterDate = getTextUsingXpath(strTermLetterDateTextBoxXpath, TERM_LETTER_DATE).trim();
		return termLetterDate.contentEquals(null);
	}

	/**
	 * This method is used to Verify the Presence of Pricing Model in Account update
	 * and Info Screen
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Arunaditya Bagchi
	 * @since 01/15/2020
	 */

	public boolean checkPricingModelFieldPresent() {
		return isElementPresentUsingXpath(strPricingModelHDRXpath, LPLCoreConstents.getInstance().HIGHEST,
				PRICING_MODEL_HEADER);
	}

	/**
	 * This method is used to Verify Pricing Model field with proper Type in Account
	 * update and Info Screen
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Arunaditya Bagchi
	 * @return
	 * @since 01/15/2020
	 * @Modified by H Abdul Hadi
	 * @Modified date 03/04/2021
	 */
	public boolean checkPricingModelFieldWithType(String pricingModelType) {
		switch (pricingModelType.trim()) {
		case SWS_PREMIUM:
			return checkPricingModelField(testData.get("strSWSPricingModel"));
		case EMPLOYEE_MODEL:
			return checkPricingModelField(testData.get("strEMPricingModel"));
		case REPAUM:
			return checkPricingModelField(testData.get("strREPPricingModel"));
		case BLANK:
			return checkPricingModelField(BLANK_VALUE);
		case EXCEPTION:
			return checkPricingModelField(testData.get("strExceptionPricingModel"));
		default:
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Validate if " + pricingModelType + " Pricing Model Type displayed or not",
					"Proper " + pricingModelType + " Pricing Model Type shoud be Displayed",
					"Proper " + pricingModelType + " Pricing Model Type is Displayed",
					"Invalid [" + pricingModelType + " Pricing Model Type] is passed");

		}
		return false;
	}

	/**
	 * This method is used to Verify Pricing Model for Account update and Info
	 * Screen
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Arunaditya Bagchi
	 * @since 01/15/2020
	 */

	public boolean checkPricingModelField(String pricingModelType) {
		waitTillVisibleUsingXpath(strPricingModelFLDXpath, PRICING_MODEL_FLD);
		String strPricingModelText = getTextUsingXpath(strPricingModelFLDXpath, PRICING_MODEL_FLD).trim();
		return pricingModelType.equalsIgnoreCase(strPricingModelText);
	}

	/**
	 * This method is used to click on Unincept button
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/10/2021
	 */
	public boolean iClickOnUninceptButton() {
		return clickElementUsingXpath(strUninceptButtonXpath, UNINCEPT_BUTTON);
	}

	/**
	 * This method is used to validate if Incept Date is removed
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/10/2021
	 */
	public boolean iVerifyInceptDateRemoved() {
		return getTextUsingXpath(strInceptDateTextBoxXpath, INCEPT_DATE).trim().isEmpty();
	}

	/**
	 * This method is used to validate if Do Not Incept Check box is visible
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/10/2021
	 */
	public boolean iVerifyDoNotInceptCheckboxIsVisible() {
		return isElementPresentUsingXpath(strDoNotInceptCheckBoxXpath, LPLCoreConstents.getInstance().LOW,
				DONOTINCEPT_CHECKBOX);
	}

	/**
	 * This method is used to click on Do Not Incept Checkbox
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/10/2021
	 */
	public boolean iClickonDoNotInceptCheckbox() {
		return clickElementUsingXpath(strDoNotInceptCheckBoxXpath, DONOTINCEPT_CHECKBOX);
	}

	/**
	 * This method is used to verify Do Not Incept Checkbox is checked
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 02/10/2021
	 */
	public boolean iVerifyDoNotInceptCheckboxIsChecked() {
		return getWebElementUsingXpath(strDoNotInceptCheckBoxXpath, DONOTINCEPT_CHECKBOX).isSelected();
	}

	/**
	 * This method is used to Enter Invalid Date in the TermLetterDate field
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 02/13/2021
	 */
	public boolean enterInvalidDateInTheTermLetterDateField() {
		return enterTextUsingXpath(strTermLetterDateTextBoxXpath, testData.get("strInvalidDate"),
				FLATFEE_CALCDATE_TEXTBOX);
	}

	/**
	 * This method is used to Verify the Invalid Date Error message for
	 * TermLetterDate in Billing Setting Tab
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 02/13/2021
	 */
	public boolean verifyTheInvalidDateErrorMessageForTermLetterDate() {
		clickOnTabButton(strTermLetterDateTextBoxXpath);
		clickElementUsingXpath(strSaveButtonXpath, LPLCoreConstents.getInstance().MEDIUM, SAVE_BUTTON);
		return isElementPresentUsingXpath(strTermLetterInvalidDateTextXpath, LPLCoreConstents.getInstance().MEDIUM,
				WARNING_MESSAGE);
	}

	/**
	 * This method is used to check If Reactivation date filed is present in Account
	 * Details page
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 04/9/2021
	 */
	public boolean iVerifyReactivationDateFieldPresent() {
		return isElementPresentUsingXpath(strReactivationDateXpath, REACTIVATION_DATE);
	}

	/**
	 * This method is used to check If Reactivation date has null value
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 04/9/2021
	 */
	public boolean iVerifyReactivationDateHasNullValue() {
		String reactivationDate = getTextUsingXpath(strReactivationDateNullXpath, REACTIVATION_DATE).trim();
		return reactivationDate.contentEquals(BLANK_VALUE);
	}

	/**
	 * This method is used to check If Reactivation date has enabled.
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 04/9/2021
	 */
	public boolean iVerifyReactivationDateHasEnabled() {
		return isElementEnabled(strReactivationDateValueXpath, REACTIVATION_DATE);
	}

	/**
	 * This method is used to check If Reactivation date can be changed
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 04/9/2021
	 */
	public boolean iVerifyReactivationDateCanHaveDifferentDate() {
		clickElementUsingXpath(strReactivationDateValueXpath, LPLCoreConstents.getInstance().LOW, REACTIVATION_DATE);
		boolean blnResult = enterTextUsingXpath(strReactivationDateValueXpath, testData.get("strReactivationDate"),
				REACTIVATION_DATE);
		clickOnTabButton(strReactivationDateValueXpath);
		return blnResult;
	}

	/**
	 * This method is used to check If confirmation popup displayed after saving
	 * Reactivation date
	 * 
	 * @return boolean
	 *
	 * @author Krishna Vakalapudi
	 * @since 04/9/2021
	 */
	public boolean iVerifyConfirmPopupDisplayed() {
		return isElementPresentUsingXpath(strConfirmationPopUpXpath, LPLCoreConstents.getInstance().LOW,
				CONFIRMATION_POPUP);
	}
}
