package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;

/**
 * <p>
 * <br>
 * <b> Title: </b> BelowMinimumTrackingStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for BelowMinimumTracking</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * BelowMinimumTrackingStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class BelowMinimumTrackingStepDef extends CommonStepDef {

	@Then("^I verify the options available in CorrBD dropdown$")
	public void verifyTheOptionsAvailableinCorrBDdropdown(DataTable corrBDDropdownOptions) {
		boolean blnResult = belowMinimumTracking.verifyOptionsAvailableInCorrBDDropdown(corrBDDropdownOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the options available in CorrBD dropdown", "User should be able to see all dropdown options",
				"Successfully able to see all dropdown options",
				"Failed to see all dropdown options : " + Common.strError);
	}

	@Then("^I select All option in CorrBD dropdown fields$")
	public void selectAlloptionInCorrBDdropdownfields() {
		boolean blnResult = belowMinimumTracking.selectAllOptionInCorrBDDropdownFields();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select option All from the dropdown",
				"User should be able to select option All from dropdown",
				"Successfully selected option All from the dropdown",
				"Failed to select option All : " + Common.strError);
	}

	@Then("^I verify the options available in Tracking Status dropdown$")
	public void verifyTheOptionsAvailableinTrackingStatusDropdown(DataTable trackinStatusDropdownOptions) {
		boolean blnResult = belowMinimumTracking
				.verifyOptionsAvailableInTrackingStatusDropdown(trackinStatusDropdownOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the options available in Tracking Status dropdown",
				"User should be able to see all dropdown options", "Successfully able to see all dropdown options",
				"Failed to see all dropdown options : " + Common.strError);
	}

	@Then("^I select (.+) option in Tracking Status dropdown fields$")
	public void selectAlloptionInTrackingStatusDropdown(String dropDownOptionToSelect) {
		boolean blnResult = belowMinimumTracking.selectAllOptionInTrackingStatusDropdown(dropDownOptionToSelect);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select option " + dropDownOptionToSelect + " from the dropdown",
				"User should be able to select option " + dropDownOptionToSelect + " from dropdown",
				"Successfully selected option " + dropDownOptionToSelect + " from the dropdown",
				"Failed to select option " + dropDownOptionToSelect + " : " + Common.strError);
	}

	@Then("^I verify the count of Accounts is displayed$")
	public void verifyTheCountofAccountsShouldbeDisplayed() {
		boolean blnResult = belowMinimumTracking.verifyCountOfAccountsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify count of accounts displayed",
				"User should be able to see count of accounts", "Successfully count of accounts is displayed",
				"Failed to display of count of records : " + Common.strError);
	}

	@Then("^I verify availability of all fields in the grid$")
	public void verifyTheDisplayOfFieldsAsperTheSelectedOptions(DataTable availabilityOfFieldsInGrid) {
		boolean blnResult = belowMinimumTracking.verifyAvailabilityOfAllFieldsInGrid(availabilityOfFieldsInGrid);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify available fields are displayed in the grid",
				"User should be able to see all the available fields in the grid",
				"Successfully all the fields are displayed",
				"Failed to display all the available fields in the grid : " + Common.strError);
	}

	@Then("^I select AXA option in CorrBD dropdown fields$")
	public void selectAXAoptionInCorrBDdropdownfields() {
		boolean blnResult = belowMinimumTracking.selectAXAOptionInCorrBDDropdownFields();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select option All from the dropdown",
				"User should be able to select option All from dropdown",
				"Successfully selected option All from the dropdown",
				"Failed to select option All : " + Common.strError);
	}

	@Then("^I select LPL option in CorrBD dropdown fields$")
	public void selectLPLoptionInCorrBDdropdownfields() {
		boolean blnResult = belowMinimumTracking.selectLPLoptionInCorrBDdropdownfields();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select option LPL from the dropdown",
				"User should be able to select option LPL from dropdown",
				"Successfully selected option LPL from the dropdown",
				"Failed to select option LPL : " + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
