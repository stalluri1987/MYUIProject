package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;

/**
 * <p>
 * <br>
 * <b> Title: </b> SourceOfFundsStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for SourceOfFunds</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * SourceOfFundsStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class SourceOfFundsStepDef extends CommonStepDef {

	@And("^I click on Firm field and select LPL Financial option from dropdown$")
	public void iClickonFirmFieldAndSelectLPLFinancialOptionFromDropdown() {
		boolean blnResult = sourceOfFunds.selectLPLFinancialFromFirmDropDownUsingXpath();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Firm dropdown, select LPL Financial option",
				"User should be able to select LPL Financial option",
				"Successfully able to select LPL Financial option",
				"Failed to select LPL Financial option : " + Common.strError);
	}

	@And("^I verify the availability of all sections$")
	public void iVerifyTheAvailabilityOfAllSections(DataTable availableSections) {
		boolean blnResult = sourceOfFunds.verifyTheAvailabilityOfAllSections(availableSections);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of sections for user having read/write access",
				"User should be able to see all the sections", "Successfully able to see all sections",
				"Failed to see all the sections : " + Common.strError);
	}

	@And("^I verify the availability of fields in Select Account section$")
	public void iVerifyTheAvailabilityOfFieldsInSelectAccountSection(DataTable availableFields) {
		boolean blnResult = sourceOfFunds.verifyFieldsInSelectAccountSection(availableFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of fields under Select Account section",
				"User should be able to see all the fields under Select Account section",
				"Successfully able to see all fields under Select Account section",
				"Failed to see all the fields under Select Account section : " + Common.strError);
	}

	@And("^I verify the availability of fields in Select Filters section$")
	public void iVerifyTheAvailabilityOfFieldsInSelectFiltersSection(DataTable availableFields) {
		boolean blnResult = sourceOfFunds.verifyFieldsInSelectFiltersSection(availableFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of fields under Select Filters section",
				"User should be able to see all the fields under Select Filters section",
				"Successfully able to see all fields under Select Filters section",
				"Failed to see all the fields under Select Filters section : " + Common.strError);
	}

	@And("^I verify the availability of fields in Activity section$")
	public void iVerifyTheAvailabilityOfFieldsInActivitySection(DataTable availableFields) {
		boolean blnResult = sourceOfFunds.verifyFieldsInActivitySection(availableFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of fields under Activity section",
				"User should be able to see all the fields under Activity section",
				"Successfully able to see all fields under Activity section",
				"Failed to see all the fields under Activity section : " + Common.strError);
	}

	@And("^I verify the availability of fields in Reports section$")
	public void iVerifyTheAvailabilityOfFieldsInReportsSection(DataTable availableFields) {
		boolean blnResult = sourceOfFunds.verifyFieldsInReportsSection(availableFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of fields under Reports section",
				"User should be able to see all the fields under Reports section",
				"Successfully able to see all fields under Reports section",
				"Failed to see all the fields under Reports section : " + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
