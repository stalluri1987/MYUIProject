package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.steps;

import java.util.List;
import java.util.Map;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.BankSweepGroupPage;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class NewBankSweepGroupStepDef extends CommonStepDef{
	public static final String MODALFRAME = "iframe-modal-frame";
	static final String TEST_DATA_PATH = "\\\\qa2000server\\QTP_Repository\\Grouping\\TestData\\Client_TestData.xlsx";
	public static final String FIELDS = "fields";
	public static final String USERNAME = "Username";
	public static final String PASSWORD = "Password";
	public static final String AXALOGIN = "strAXALogin";
	public static final String SUPPORTVIEWOPTION = "strSupportViewOption";
	public static final String SUPPORTVIEWDATA = "strSupportViewData";
	String firstName = "";
	String accountNumber = "";
	
	
	@Then("I should see Bank Sweep summary page")
	public void i_should_see_bank_sweep_summary_page() {
		common.waitForPageLoading();
		boolean blnResult = bankSweepGroupPage.seeBankSweepSummaryPage();
	       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	                    "When User click on the group name", 
	                    "User should click group name successfully ",
	                    "User is able to see the bank sweep summary page successfully",
	                    "Failed to see the bank sweep summary page" + common.getStrError());
	}
	
	@Then("I Verify the Summary page top banner")
	public void i_verify_the_summary_page_top_banner() {
		common.waitForPageLoading();
		boolean blnResult = bankSweepGroupPage.seeTopBannerSummaryPage();
	       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	                    "When User click on the group name", 
	                    "User should click group name successfully ",
	                    "User is able to see the bank sweep summary page successfully",
	                    "Failed to see the bank sweep summary page" + common.getStrError());
	}
	
	@Then("I Verify Summary section header")
	public void i_verify_summary_section_header() {
		common.waitForPageLoading();
		boolean blnResult = bankSweepGroupPage.seeSummarySectionHeader();
	       LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	                    "When User click on the group name", 
	                    "User should click group name successfully ",
	                    "User is able to see the bank sweep summary page successfully",
	                    "Failed to see the bank sweep summary page" + common.getStrError());
	}
	
	@Then("^I should see following fields in summary page$")
    public void i_should_see_following_fields_in_summary_page(DataTable field) {
          common.waitForPageLoading();
           LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
           List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
           for (Map<String, String> data : userGuidesFields) {
                  boolean blnResult = bankSweepGroupPage.displayAccountDetailsInSummaryPage(data.get("fields"));
                  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                               "Validate that listed fields " + data.get("fields") + " available",
                               "User should able to see the  " + data.get("fields") + "fields",
                               " listed field values is " + data.get("fields") + " visible",
                               "Failed : listed field values " + data.get("fields") + "are NOT visible");
           }             
    }
    @Then("I Verify the Edit button in Dashboard and Summary page")
    public void i_verify_the_edit_button_in_dashboard_and_summary_page() {
          common.waitForPageLoading();
          boolean blnResult = bankSweepGroupPage.displayEditbuttonInDashboardAndSummaryPage();
           LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When is able to see the edit button both dashboard and summary page", 
                        "User should see the edit button both dashboard and summary page successfully ",
                        "User is able to see the edit button both dashboard and summary page successfully",
                        "Failed to see the edit button both dashboard and summary page" + common.getStrError());
    }
    @When("I click on Edit button")
    public void i_click_on_edit_button() {
          common.waitForPageLoading();
          boolean blnResult = bankSweepGroupPage.clickEditButtonInSummaryPage();
           LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When User click on the edit button", 
                        "User should click edit button successfully ",
                        "User is able to see the edit page successfully",
                        "Failed to see the edit page" + common.getStrError());
    }
    @Then("I Verify the page Title")
    public void i_verify_the_page_title() {
          common.waitForPageLoading();
          boolean blnResult = bankSweepGroupPage.verifyPageTitleInEditPage();
           LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When is able to see the edit page", 
                        "User should see the edit page successfully ",
                        "User is able to see the edit page successfully",
                        "Failed to see the edit page" + common.getStrError());
    }
    
    @Then("^I should see following fields in edit page$")
    public void i_should_see_following_fields_in_edit_page(DataTable field) {
          common.waitForPageLoading();
           LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
           List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
           for (Map<String, String> data : userGuidesFields) {
                  boolean blnResult = bankSweepGroupPage.displayDetailsInEditPage(data.get("fields"));
                  LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                               "Validate that listed fields " + data.get("fields") + " available",
                               "User should able to see the  " + data.get("fields") + "fields",
                               " listed field values is " + data.get("fields") + " visible",
                               "Failed : listed field values " + data.get("fields") + "are NOT visible");
           }             
    }
    
    @When("I navigate to Related Groups section in right panel")
    public void i_navigate_to_related_groups_section_in_right_panel() {
    	common.waitForPageLoading();
        boolean blnResult = bankSweepGroupPage.verifyRelatedGroupsSection();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                      "When user is in the BS summary page", 
                      "User should see Related group section successfully ",
                      "User is able to see  Related group section successfully",
                      "Failed to see  Related group section" + common.getStrError());
    }
    
    @When("I click on the Household group")
    public void i_click_on_the_household_group() {
    	common.waitForPageLoading();
        boolean blnResult = bankSweepGroupPage.clickOnRelatedGroupsHousehold();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                      "When user is in the BS summary page", 
                      "User should see Related group section successfully ",
                      "User is able to click on Household successfully",
                      "Failed to click on Household group" + common.getStrError());
    }
    
    @When("I click on the User Defined group")
    public void i_click_on_the_user_defined_group() {
    	common.waitForPageLoading();
        boolean blnResult = bankSweepGroupPage.clickOnRelatedGroupsUserDefined();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                      "When user is in the BS summary page", 
                      "User should see Related group section successfully ",
                      "User is able to click on User Defined Group successfully",
                      "Failed to click on User Defined group" + common.getStrError());
    }
    
    @When("I click on Review button in BS summary page")
    public void i_click_on_review_button_in_bs_summary_page() {
    	common.waitForPageLoading();
        boolean blnResult = bankSweepGroupPage.clickOnBSReviewButton();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                      "When user is in the BS Edit group page", 
                      "User should see Reivew button successfully ",
                      "User is able to click on Review button successfully",
                      "Failed to click on Review button" + common.getStrError());
    }
    
    @Then("I should see Review BS page")
    public void i_should_see_review_bs_page() {
    	common.waitForPageLoading();
        boolean blnResult = bankSweepGroupPage.seeReviewBSPage();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                      "When user is in the BS Edit group page", 
                      "User should click on Reivew button successfully ",
                      "User is able to see BS Review page successfully",
                      "Failed to see BS Review page" + common.getStrError());
    }
    
    @Then("I verify contents in Review BS page")
    public void i_verify_contents_in_review_bs_page() {
    	common.waitForPageLoading();
        boolean blnResult = bankSweepGroupPage.verifyReviewBSPageContents();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                      "When user is in the BS Edit group page", 
                      "User should click on Reivew button successfully ",
                      "User is able to see BS Review page successfully",
                      "Failed to see BS Review page" + common.getStrError());
    }
    
    @Then("I should see remove member button")
    public void i_should_see_remove_member_button() {
    	common.waitForPageLoading();
        boolean blnResult = bankSweepGroupPage.seeRemoveMemberButton();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                      "When user is in the BS Edit group page", 
                      "User should click on Reivew button successfully ",
                      "User is able to see BS Review page successfully",
                      "Failed to see BS Review page" + common.getStrError());
    }
    
    @Then("I should see BS group summary page and update success message")
	public void i_should_see_bs_group_summary_page_and_update_success_message() {
		common.waitForPageLoading();
		boolean blnResult = bankSweepGroupPage.seeGroupUpdateMessage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in Add to Groups page",
				"User should successfully add client to UDG",
				"User is able to see the group updated message successfully",
				"Failed to see the group updated message" + common.getStrError());
	}
    
    @Then("I Verify the convert to Two point Zero section in right panel")
    public void i_verify_the_convert_to_two_point_zero_section_in_right_panel() {
          common.waitForPageLoading();
          boolean blnResult = bankSweepGroupPage.seeConvertToTwoPointZeroSection();
           LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When User should see the convert to 2.0 section in Right panel", 
                        "User should see the convert to 2.0 section in Right panel successfully ",
                        "User is able to see the convert to 2.0 section in Right panel successfully",
                        "Failed to see the convert to 2.0 section in Right panel" + common.getStrError());
    } 
 @When("I click on Click Here hyperlink from right panel")
 public void i_click_on_click_here_hyperlink_from_right_panel() {
    common.waitForPageLoading();
     boolean blnResult = bankSweepGroupPage.ClickHereHyperLinkInConvertToTwoPointZeroSection();
      LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                   "When user is the convert to 2.0 section in Right panel", 
                   "User should click the CLICK HERE hyperlink in the convert to 2.0 section in Right panel successfully ",
                   "User is able to click the CLICK HERE hyperlink in the convert to 2.0 section in Right panel successfully",
                   "Failed to click the CLICK HERE hyperlink in the convert to 2.0 section in Right panel" + common.getStrError());
 }
 @Then("I should see New Household Set up Page")
    public void i_should_see_new_household_set_up_page() {
          common.waitForPageLoading();
          boolean blnResult = bankSweepGroupPage.verifyNewHouseholdSetupPage();
           LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When User click on CLICK HERE hyperlink in the convert to 2.0 section in Right panel", 
                        "User should see the New Household Setup Page successfully ",
                        "User is able to see the New Household Setup Page successfully",
                        "Failed to see the New Household Setup Page" + common.getStrError());
    }

@When("^I click first primary radio button$")
public void i_click_first_primary_radio_button() {
    boolean blnResult = bankSweepGroupPage.clickfirstPrimarybutton();
    common.waitForPageLoading();
    LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                 "When User selects first primary radio button",
                 "User should able to first primary radio button",
                 "User is able to first primary radio button successfully",
                 "Failed to click first primary radio button" + common.getStrError());
}

@Then("I Verify the convert to Two point Zero section for Related groups contains Household")
public void i_verify_the_convert_to_two_point_zero_section_for_related_groups_contains_household() {
      boolean blnResult = bankSweepGroupPage.seeVerbiageUnderConvertTwoPointZeroSection();
      LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                    "When User is in BS group dashboard page",
                    "User is able to see the convert to Two point Zero section for Related groups contains Household",
                    "User is able to see the convert to Two point Zero section for Related groups contains Household successfully",
                    "Failed to see the convert to Two point Zero section for Related groups contains Household" + common.getStrError());
}





}
