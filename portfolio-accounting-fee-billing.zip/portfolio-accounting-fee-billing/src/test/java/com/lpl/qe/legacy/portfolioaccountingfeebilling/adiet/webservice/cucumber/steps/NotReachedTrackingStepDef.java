package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> NotReachedTrackingStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for NotReachedTracking</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * NotReachedTrackingStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class NotReachedTrackingStepDef extends CommonStepDef {

	@Given("^I verify the options available in Tracking Status dropdown list$")
	public void iverifytheavailabilityofTrackingstatusdropdownoptions(DataTable trackingDropDownOptions) {
		boolean blnResult = notReachedTracking.verifyOptionsAvailableInTrackingStatusDropdown(trackingDropDownOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the options available in Tracking Status dropdown",
				"User should be able to see all Tracking Status dropdown options",
				"Successfully able to see all Tracking Status dropdown options",
				"Failed to see all Tracking Status dropdown options : " + Common.strError);
	}

	@Given("^I verify the availability of columns in the report$")
	public void iverifytheavailabilityofcolumnsinthereport(DataTable columnsInReport) {
		boolean blnResult = notReachedTracking.verifyColumnsAvailableInReport(columnsInReport);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of all columns in report", "User should be able to see all columns in report",
				"Successfully able to see all columns in report",
				"Failed to all columns in report : " + Common.strError);
	}

	@Given("^I verify the count of Accounts should be displayed$")
	public void iverifythecountofAccountsshouldbedisplayed() {
		boolean blnResult = notReachedTracking.verifyCountOfAccountsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify count of accounts displayed",
				"User should be able to see count of accounts", "Successfully count of accounts is displayed",
				"Failed to display of count of records : " + Common.strError);
	}

	@And("^I verify Not Warned is selected by default$")
	public void iVerifyNotWarnedIsSelectedByDefault() {
		boolean blnResult = notReachedTracking
				.verifyValueIsSelectedInTrackingStatusDropdown(testData.get("strNotWarned"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Not Warned is selected in Tracking status dropdown",
				"User should be able to see Not Warned is selected in Tracking status dropdown",
				"Successfully Not Warned is selected in Tracking status dropdown",
				"Failed Not Warned is not selected in Tracking status dropdown : " + Common.strError);
	}

	@And("^I verify Export Notification is enabled$")
	public void iVerifyExportNotificationIsEnabled() {
		boolean blnResult = notReachedTracking.verifyExportNotificationIsEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Export Notification is enabled",
				"User should be able to see Export Notification is enabled",
				"Successfully Export Notification is enabled",
				"Failed Export Notification is not enabled : " + Common.strError);
	}

	@And("^I verify Export Notification is displayed$")
	public void iVerifyExportNotificationIsDisplayed() {
		boolean blnResult = notReachedTracking.verifyExportNotificationIsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Export Notification is displayed",
				"User should be able to see Export Notification", "Successfully Export Notification is displayed",
				"Failed to see Export Notification button : " + Common.strError);
	}

	@When("^I select Warned in Tracking Status dropdown$")
	public void iSelectWarnedInTrackingStatusDropdown() {
		boolean blnResult = notReachedTracking.selectValueInTrackingStatusDropdown(testData.get("strWarned"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Warned is selected in Tracking Satus Dropdown", "User should be able to see Warned is selected",
				"Successfully Warned is selected", "Failed to select Warned in dropdown : " + Common.strError);
	}

	@And("^I verify Export Notification is disabled$")
	public void verifyExportNotificationIsDisabled() {
		boolean blnResult = notReachedTracking.verifyExportNotificationIsDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Export Notification is disabled",
				"User should be able to see Export Notification is disabled",
				"Successfully Export Notification is disabled",
				"Failed Export Notification is not disabled : " + Common.strError);
	}

	@And("^I select To Be Termed in Tracking Status dropdown$")
	public void iSelectToBeTermedInTrackingStatusDropdown() {
		boolean blnResult = notReachedTracking.selectValueInTrackingStatusDropdown(testData.get("strToBeTermed"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify To Be Termed is selected in Tracking Satus Dropdown",
				"User should be able to see To Be Termed is selected", "Successfully To Be Termed is selected",
				"Failed to select To Be Termed in dropdown : " + Common.strError);
	}

	@When("^I select All in Tracking Status dropdown$")
	public void iSelectAllInTrackingStatusDropdown() {
		boolean blnResult = notReachedTracking.selectValueInTrackingStatusDropdown(testData.get("strAll"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify All is selected in Tracking Satus Dropdown", "User should be able to see All is selected",
				"Successfully All is selected", "Failed to select All in dropdown : " + Common.strError);
	}

	@Then("^I select (.+) option in Not Reached Tracking Status dropdown fields$")
	public void selectAlloptionInTrackingStatusDropdown(String dropDownOptionToSelect) {
		boolean blnResult = notReachedTracking.selectAllOptionInTrackingStatusDropdown(dropDownOptionToSelect);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select option " + dropDownOptionToSelect + " from the dropdown",
				"User should be able to select option " + dropDownOptionToSelect + " from dropdown",
				"Successfully selected option " + dropDownOptionToSelect + " from the dropdown",
				"Failed to select option " + dropDownOptionToSelect + " : " + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
