package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> SourceOfFunds.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for SourceOfFunds</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class SourceOfFunds extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 822;
	public static final String LPL_FINANCIAL = "LPL Financial";
	Map<String, HashMap<String, String>> pageObjectMap;
	String strSourceOfFundsHeaderXpath;
	String strSectionHeaderTextXpath;
	String strSelectAccountSectionFieldsTextXpath;
	String strSelectFiltersSectionFieldsTextXpath;
	String strActivitySectionFieldsTextXpath;
	String strReportsSectionFieldsTextXpath;
	String strFirmDropDownXpath;
	public static final String SOURCE_OF_FUND_PAGE_HEADER = "Source Of Funds Page Header";
	public static final String SECTION_HEADER_TEXT = "Section Header Text";
	public static final String SELECT_ACCOUNT_SECTION_FIELDS = "Select Account Section Fields";
	public static final String SELECT_FILTERS_SECTION_FIELDS = "Select Filters Section Fields";
	public static final String ACTIVITY_SECTION_FIELDS = "Activity Section Fields";
	public static final String REPORTS_SECTION_FIELDS = "Reports Section Fields";
	public static final String SELECT_ACCOUNT_FIELD_TEXT = "Select Account Field Text";
	public static final String SELECT_FILTERS_FIELD_TEXT = "Select Filters Field Text";
	public static final String ACTIVITY_FIELD_TEXT = "Activity Field Text";
	public static final String REPORTS_FIELD_TEXT = "Reports Field Text";
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see";
	public static final String VERIFY_THE_AVAILABILITY_OF = "Verify the availability of";
	public static final String FAILED_TO_SEE = "Failed to see";
	public static final String IN_REPORTS_SECTION = "in Reports section";
	public static final String IN_ACTIVITY_SECTION = "in Activity section";
	public static final String IN_SELECT_FILTERS_SECTION = "in Select Filters section";
	public static final String IN_SELECT_ACCOUNT_SECTION = "in Select Account section";
	public static final String SECTION = "section";
	public static final String FIRM_DROPDOWN = "Firm Dropdown";
	public static final String OPTIONS = "options";

	public SourceOfFunds(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @param locatorXpath
	 * @param elementName
	 * @return String
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strSourceOfFundsHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				SOURCE_OF_FUND_PAGE_HEADER);
	}

	/**
	 * This method is used to check if section header exist
	 * 
	 * @param sectionHeaderOption
	 * @return String
	 * @author Abdul Hadi
	 * @since 06/08/2020
	 */
	public boolean checkIfElementExistUsingSectionHeaderText(String sectionHeaderOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strSectionHeaderTextXpath, sectionHeaderOption),
				sectionHeaderOption);
	}

	/**
	 * This method is used to check if Select Account section fields exists
	 * 
	 * @param fieldOption
	 * @return String
	 * @author Sowmya Nagarajappa
	 * @since 07/21/2020
	 */
	public boolean checkIfElementExistUsingTextSelectAccount(String fieldOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strSelectAccountSectionFieldsTextXpath, fieldOption),
				fieldOption);
	}

	/**
	 * This method is used to check if Select Filters section fields exists
	 * 
	 * @param fieldOption
	 * @return String
	 * @author Sowmya Nagarajappa
	 * @since 07/21/2020
	 */
	public boolean checkIfElementExistUsingTextSelectFilters(String fieldOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strSelectFiltersSectionFieldsTextXpath, fieldOption),
				fieldOption);
	}

	/**
	 * This method is used to check if Select Filters section fields exists
	 * 
	 * @param fieldOption
	 * @return String
	 * @author Sowmya Nagarajappa
	 * @since 07/21/2020
	 */
	public boolean checkIfElementExistUsingTextActivity(String fieldOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strActivitySectionFieldsTextXpath, fieldOption),
				fieldOption);
	}

	/**
	 * This method is used to check if Select Filters section fields exists
	 * 
	 * @param fieldOption
	 * @return String
	 * @author Sowmya Nagarajappa
	 * @since 07/21/2020
	 */
	public boolean checkIfElementExistUsingTextReports(String fieldOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strReportsSectionFieldsTextXpath, fieldOption),
				fieldOption);
	}

	/**
	 * This method is used to check if Select Filters section fields exists
	 * 
	 * @param
	 * @return String
	 * @author Sowmya Nagarajappa
	 * @since 07/21/2020
	 */
	public boolean selectLPLFinancialFromFirmDropDownUsingXpath() {
		return selectValueFromDropdownUsingXpath(strFirmDropDownXpath, LPL_FINANCIAL, FIRM_DROPDOWN);
	}

	/**
	 * This method is used to check If all sections are present on Source of Funds
	 * screen
	 * 
	 * @param availableSections
	 * @return boolean
	 * @author Sowmya Nagarajappa
	 * @since 07/10/2020
	 */
	public boolean verifyTheAvailabilityOfAllSections(DataTable availableSections) {
		boolean blnResult = false;
		List<Map<String, String>> sections = availableSections.asMaps(String.class, String.class);
		for (Map<String, String> data : sections) {
			String sectionName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingSectionHeaderText(sectionName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					VERIFY_THE_AVAILABILITY_OF + sectionName + SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + sectionName + SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + sectionName + SECTION,
					FAILED_TO_SEE + sectionName + SECTION + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If all fields are present on Select Account
	 * section
	 * 
	 * @param availableFields
	 * @return boolean
	 * @author Sowmya Nagarajappa
	 * @since 07/10/2020
	 */
	public boolean verifyFieldsInSelectAccountSection(DataTable availableFields) {
		boolean blnResult = false;
		List<Map<String, String>> fields = availableFields.asMaps(String.class, String.class);
		for (Map<String, String> data : fields) {
			String fieldName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTextSelectAccount(fieldName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					VERIFY_THE_AVAILABILITY_OF + fieldName + IN_SELECT_ACCOUNT_SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + fieldName + IN_SELECT_ACCOUNT_SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + fieldName + IN_SELECT_ACCOUNT_SECTION,
					FAILED_TO_SEE + fieldName + IN_SELECT_ACCOUNT_SECTION + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If all fields are present on Select Filters
	 * section
	 * 
	 * @param availableFields
	 * @return boolean
	 * @author Sowmya Nagarajappa
	 * @since 07/10/2020
	 */
	public boolean verifyFieldsInSelectFiltersSection(DataTable availableFields) {
		boolean blnResult = false;
		List<Map<String, String>> fields = availableFields.asMaps(String.class, String.class);
		for (Map<String, String> data : fields) {
			String fieldName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTextSelectFilters(fieldName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					VERIFY_THE_AVAILABILITY_OF + fieldName + IN_SELECT_FILTERS_SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + fieldName + IN_SELECT_FILTERS_SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + fieldName + IN_SELECT_FILTERS_SECTION,
					FAILED_TO_SEE + fieldName + IN_SELECT_FILTERS_SECTION + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If all fields are present on Activity section
	 * 
	 * @param availableFields
	 * @return boolean
	 * @author Sowmya Nagarajappa
	 * @since 07/10/2020
	 */
	public boolean verifyFieldsInActivitySection(DataTable availableFields) {
		boolean blnResult = false;
		List<Map<String, String>> fields = availableFields.asMaps(String.class, String.class);
		for (Map<String, String> data : fields) {
			String fieldName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTextActivity(fieldName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					VERIFY_THE_AVAILABILITY_OF + fieldName + IN_ACTIVITY_SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + fieldName + IN_ACTIVITY_SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + fieldName + IN_ACTIVITY_SECTION,
					FAILED_TO_SEE + fieldName + IN_ACTIVITY_SECTION + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If all fields are present on Reports section
	 * 
	 * @param availableFields
	 * @return boolean
	 * @author Sowmya Nagarajappa
	 * @since 07/10/2020
	 */
	public boolean verifyFieldsInReportsSection(DataTable availableFields) {
		boolean blnResult = false;
		List<Map<String, String>> fields = availableFields.asMaps(String.class, String.class);
		for (Map<String, String> data : fields) {
			String fieldName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTextReports(fieldName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					VERIFY_THE_AVAILABILITY_OF + fieldName + IN_REPORTS_SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + fieldName + IN_REPORTS_SECTION,
					USER_SHOULD_BE_ABLE_TO_SEE + fieldName + IN_REPORTS_SECTION,
					FAILED_TO_SEE + fieldName + IN_REPORTS_SECTION + Common.strError);
		}
		return blnResult;
	}
}
