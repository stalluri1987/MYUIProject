package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.AccountListTool;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.AccountUpdatesAndInfo;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.ActivityDashboard;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.BelowMinimumTracking;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.FBVADashboard;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.FeeBilling;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.FileProcessingStatus;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.HomePageFBVA;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Menu;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.NonBillableSchedule;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.NotReachedTracking;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.PortfolioAccounting;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.ProgramFeeManagement;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Rebilling;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Reporting;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.ReportingNextGen;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.SourceOfFunds;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.StyleCodeMapping;

import LPLCoreDriver.LPLCoreDriver;
import PageObjectLibrary.ClientManagement_AccountsTab;
import PageObjectLibrary.ClientManagement_Common;
import PageObjectLibrary.IASTradingCommon;
import PageObjectLibrary.LoginPage;

/**
 * <p>
 * <br>
 * <b> Title: </b> CommonStepDef.java</br>
 * <br>
 * <b> Description: </b> All page object creation</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * CommonStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class CommonStepDef extends LPLCoreDriver {

	static ClientManagement_Common cmCommon;
	static LoginPage loginPage;
	static FileProcessingStatus homepage;
	static Common common;
	static ClientManagement_AccountsTab cmaccounttab;
	static IASTradingCommon iasTradingCmn;
	static AccountListTool accountListTool;
	static AccountUpdatesAndInfo accountUpdatesAndInfoPage;
	static ActivityDashboard activityDashboard;
	static FBVADashboard fbvaDashboard;
	static FeeBilling feeBilling;
	static FileProcessingStatus fileProcessingStatus;
	static Menu menu;
	static NonBillableSchedule nonBillableSchedule;
	static ProgramFeeManagement programFeeManagement;
	static Rebilling rebilling;
	static Reporting reporting;
	static ReportingNextGen reportingNextGen;
	static SourceOfFunds sourceOfFunds;
	static StyleCodeMapping styleCodeMapping;
	static BelowMinimumTracking belowMinimumTracking;
	static NotReachedTracking notReachedTracking;
	static PortfolioAccounting portfolioAccounting;
	static HomePageFBVA homepagesfbva;

	public static void initialize() {

		cmCommon = new ClientManagement_Common(driver);
		loginPage = new LoginPage(driver);
		homepage = new FileProcessingStatus(driver);
		common = new Common(driver);
		cmaccounttab = new ClientManagement_AccountsTab(driver);
		iasTradingCmn = new IASTradingCommon(driver);
		accountUpdatesAndInfoPage = new AccountUpdatesAndInfo(driver);
		accountListTool = new AccountListTool(driver);
		activityDashboard = new ActivityDashboard(driver);
		fbvaDashboard = new FBVADashboard(driver);
		feeBilling = new FeeBilling(driver);
		fileProcessingStatus = new FileProcessingStatus(driver);
		menu = new Menu(driver);
		nonBillableSchedule = new NonBillableSchedule(driver);
		programFeeManagement = new ProgramFeeManagement(driver);
		rebilling = new Rebilling(driver);
		reporting = new Reporting(driver);
		reportingNextGen = new ReportingNextGen(driver);
		sourceOfFunds = new SourceOfFunds(driver);
		styleCodeMapping = new StyleCodeMapping(driver);
		belowMinimumTracking = new BelowMinimumTracking(driver);
		notReachedTracking = new NotReachedTracking(driver);
		portfolioAccounting = new PortfolioAccounting(driver);
		homepagesfbva = new HomePageFBVA(driver);
	}
}
