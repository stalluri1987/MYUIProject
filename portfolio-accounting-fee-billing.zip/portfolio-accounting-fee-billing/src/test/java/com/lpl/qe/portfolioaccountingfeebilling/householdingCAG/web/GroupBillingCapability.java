package com.lpl.qe.portfolioaccountingfeebilling.householdingCAG.web;

import java.awt.AWTException;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

import com.dataprovider.DataProviderClass;
import com.dataprovider.DataProviderFactory;
import com.dataprovider.REQUEST_TYPE;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.annotations.NeedsDriver;
import com.lpl.qe.blackbird.clientworks.web.utils.LoginUtility;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.blackbird.utilities.ScreenshotUtils;
import com.lpl.qe.blackbird.wait.TimeoutType;
import com.lpl.qe.CAG.BillingCapability;
import com.lpl.qe.CAG.ClientworksCommon;
import com.lpl.qe.portfolioaccountingfeebilling.householding.constants.BillingCapabilityEnum;
import com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject.BillingCapabilityData;
import com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject.HouseholdGroupData;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.BillingCapabilityUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.CommonUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.LoginLogoutUtility;

import PageObjectLibrary.HomePage;

public class GroupBillingCapability {
	
	private static final String SHEET_NAME = "BillingCapabilityData";
	private static final String EXCEL_FILE = "src/test/resources/testdata/HouseholdGroupExcel.xlsx";
	@NeedsDriver
	@DataProviderFactory(requestType = REQUEST_TYPE.POJO, fileName = EXCEL_FILE, sheetName = SHEET_NAME, range = "1-1")
	@Test(dataProvider = "UniversalRowProvider", dataProviderClass = DataProviderClass.class)
	public void createAndEditFlatfeeBilling(BillingCapabilityData billingCapabilityData)
			throws InterruptedException, AWTException{
		
		//ClientworksCommon clientworksCommon = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		CommonUtility clientworksCommonUtility = BasePage.initialize(DriverFactory.getDriver(), CommonUtility.class);
	//	BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		BillingCapabilityUtility groupBillingUtility = BasePage.initialize(DriverFactory.getDriver(), BillingCapabilityUtility.class);
		
		LoginLogoutUtility.loginToCW();
		LoginUtility.userLogin(billingCapabilityData.getUserName(), billingCapabilityData.getPassword());
		clientworksCommonUtility.clickOnGroupsTab();
		clientworksCommonUtility.enterHouseholdNameToSearch(billingCapabilityData.getGroupName());
		clientworksCommonUtility.clickSearchHouseholdButton();
		clientworksCommonUtility.clickOnHouseholdName(billingCapabilityData.getGroupID());
		clientworksCommonUtility.isHouseholdDashbaordPageDisplayed();
		clientworksCommonUtility.clickEditHouseholdButton();
		groupBillingUtility.clickStreamlineBilling();
		
//		groupBillingUtility.verifyEligibleAcctsGridHeaders();
//		groupBillingUtility.removeAcctFromEligibleAcctGrid();
//		groupBillingUtility.verifyRemoveAcctWarningMsg();
//		groupBillingUtility.addAcctFromEligibleAcctGrid();
//		groupBillingUtility.verifyRemoveAcctWarningMsgNotDisplayed();
//		groupBillingUtility.clickApprovebillingButton();
		
		groupBillingUtility.verifyHouseholdCapabilityTraker();
		groupBillingUtility.verifyHouseholdNameInCapabilityTraker(billingCapabilityData.getGroupName());
		groupBillingUtility.verifyBillingTrakerchevronDisplayed();
		groupBillingUtility.verifyBankSweepTitleInTraker();
		groupBillingUtility.verifyBankSweepNameInTraker();
		groupBillingUtility.verifyBillingCapabilityTitleInTraker();
		groupBillingUtility.verifyInProgressStatusInTraker();
		groupBillingUtility.verifyReadyToSignHeaderInTraker();
		groupBillingUtility.verifyBillingNameInTraker(billingCapabilityData.getGroupName());
		groupBillingUtility.clickFlatFeeTab();
		groupBillingUtility.verifyFlatFeeHeader(BillingCapabilityEnum.BILLINGFLATHEADER.toString());
		groupBillingUtility.clickFlatValueEditIcon();
		groupBillingUtility.enterFlatValue(billingCapabilityData.getFlatFeeValue());
		groupBillingUtility.clickFlatFeeSelectedHeader();
		groupBillingUtility.verifyFlatFeeDecimalBillingPage(billingCapabilityData.getDecimalFlatValue());
		groupBillingUtility.clickDoneEditingButton();
		groupBillingUtility.verifyReviewPageIsDisplayed();
		groupBillingUtility.clickEditDetailsInReviewPage();
		groupBillingUtility.clickProgressiveTieredTab();
		groupBillingUtility.clickScheduleEditIcon();
		groupBillingUtility.clickScheduleValue1();
		groupBillingUtility.clickDoneEditingButton();
		groupBillingUtility.verifyHouseholdCapabilityTraker();
		groupBillingUtility.verifyBillingTrakerchevronDisplayed();
		groupBillingUtility.verifyBankSweepGridInTraker();
		groupBillingUtility.verifyInProgressStatusInTraker();
		
		groupBillingUtility.clickCreateHouseholdBillingSet();
		groupBillingUtility.verifyCreateBillingConfMsgDisplayed();
		groupBillingUtility.clickCloseButtonInConfirmationPage();
		groupBillingUtility.verifyFlatFeeDecimalDashboardPage(billingCapabilityData.getDecimalFlatValue()); 
		clientworksCommonUtility.clickEditHouseholdButton();
		groupBillingUtility.clickEditBillingPencilIcon();
		groupBillingUtility.clickContentPanelInBillingDetailsPage();
		groupBillingUtility.clickAcctPanelInBillingDetailsPage();
		groupBillingUtility.verifyEditBillingDetailsPageIsDisplayed();
		groupBillingUtility.clickFlatFeeTab();
		groupBillingUtility.verifyFlatFeeHeader(BillingCapabilityEnum.BILLINGFLATHEADER.toString());
		groupBillingUtility.clickFlatValueEditIcon();
		groupBillingUtility.enterFlatValue(billingCapabilityData.getFlatFeeValue());
		groupBillingUtility.clickFlatFeeSelectedHeader();
//		groupBillingUtility.clickApprovebillingButton();
		
		groupBillingUtility.clickDoneEditingButton();
		groupBillingUtility.verifyFlatFeeDecimalReviewPage(billingCapabilityData.getDecimalFlatValue());
		groupBillingUtility.verifyReviewPageIsDisplayed();
		groupBillingUtility.acctPanelInReviewPage();
		groupBillingUtility.acctDetailsPanelInReviewPage();
		groupBillingUtility.submitChangesButton();
		groupBillingUtility.verifyFlatFeeDecimalConfirmationPage(billingCapabilityData.getDecimalFlatValue());
		groupBillingUtility.verifyEditBillingSucessMsg();
		groupBillingUtility.verifyPrepareToSignaturePresent();
		groupBillingUtility.seeBillingUpdatedMsgInConfPage(billingCapabilityData.getGroupName(), BillingCapabilityEnum.UPDATEDCONFMSG.toString());
		groupBillingUtility.verifyBillingNameInConfirmationPage(billingCapabilityData.getGroupName(), BillingCapabilityEnum.UPDATEDCONFMSG1.toString());
		groupBillingUtility.verifyAlrtMsgInBillingGrid(BillingCapabilityEnum.ALERTTEXT.toString());
//		groupBillingUtility.verifyColumnNamesInBillingGrid(BillingCapabilityEnum.COL1.toString()),BillingCapabilityEnum.COL2.toString()),BillingCapabilityEnum.COL3.toString()),BillingCapabilityEnum.COL4.toString()),BillingCapabilityEnum.COL5.toString());
		groupBillingUtility.contentChevronInBillingConfPage();
		groupBillingUtility.verifycontentChevronExpandedInBillingConfPage();
		groupBillingUtility.verifyAcctPanelNotExpandedInBillingConfPage();
		groupBillingUtility.clickAcctChevronBillingConfPage();
		groupBillingUtility.verifyAcctPanelExpandedInBillingConfPage();
		groupBillingUtility.contentChevronInBillingConfPage();
		groupBillingUtility.verifyContentchevronCollapsedBillingConfPage();
		groupBillingUtility.contentChevronInBillingConfPage();
		groupBillingUtility.verifyAcctPanelExpandedInBillingConfPage();
		
		groupBillingUtility.clickEditBillingPencilIcon();
		groupBillingUtility.deleteBillingCapabilityButton();
		groupBillingUtility.verifyGoBackButtonFromDeletePopup();
		groupBillingUtility.verifyDeleteButtonFromDeletePopup();
		groupBillingUtility.goBackButtonFromDeletePopup();
		groupBillingUtility.verifyEditBillingDetailsPageIsDisplayed();
		groupBillingUtility.deleteBillingCapabilityButton();
		groupBillingUtility.deleteButtonFromDeletePopup();
		groupBillingUtility.seeRedColorDeleteBillingTraker();
		
		groupBillingUtility.doneDeletingButton();
		groupBillingUtility.deleteBillingCapabilityConfMessage();
		groupBillingUtility.verifyHouseholdStreamlineBilling();
		LoginLogoutUtility.closeBrowser();
		
	}
	
	    
	}
		

