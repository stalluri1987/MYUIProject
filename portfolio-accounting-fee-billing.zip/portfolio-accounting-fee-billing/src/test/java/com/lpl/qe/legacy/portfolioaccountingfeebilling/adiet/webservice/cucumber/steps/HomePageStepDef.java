package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;

/**
 * <p>
 * <br>
 * <b> Title: </b> HomePageStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for HomePage</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * HomePageStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class HomePageStepDef extends CommonStepDef {

	public static final String PAGE_IS_LOADED = " page is loaded";
	public static final String ACCOUNT_LIST_TOOL = "Account List Tool";
	public static final String ACCOUNT_UPDATES_AND_INFO = "Account Updates And Info";
	public static final String ACTIVITY_DASHBOARD = "Activity Dashboard";
	public static final String ADVISORY_FEE_BILLING = "Advisory Fee Billing";
	public static final String FBVA_DASHBOARD = "FBVA Dashboard";
	public static final String ADIET_APPLICATION_HOME = "ADIET Application Home";
	public static final String NON_BILLABLE_SCHEDULE = "Non Billable Schedule";
	public static final String PROGRAM_FEE_MANAGEMENT = "Program Fee Management";
	public static final String REBILLING_TEXT = "Rebilling";
	public static final String REPORTING_TEXT = "Reporting";
	public static final String REPORTING_NEXTGEN = "Reporting NextGen";
	public static final String SOURCE_OF_FUNDS = "Source Of funds";
	public static final String STYLE_CODE_MAPPING = "Style Code Mapping";
	public static final String BELOW_MINIMUM_TRACKING = "Below Minimum Tracking";
	public static final String NOT_REACHED_TRACKING = "Not Reached Tracking";
	public static final String PORTFOLIO_ACCOUNTING = "Portfolio Accounting";
	public static final String FBVA_FILE_STATUS_GRID = "FBVA  files Status  grid";

	// Added generic step definition which validates all ADIET page loads
	@Then("^I should land on (Account List Tool|Account Updates And Info|Activity Dashboard|Advisory Fee Billing|FBVA Dashboard|ADIET Application Home|Non Billable Schedule|Program Fee Management|Rebilling|Reporting|Reporting NextGen|Source Of funds|Style Code Mapping|Below Minimum Tracking|Not Reached Tracking|Portfolio Accounting) page$")
	public void validatePageLoad(String pageName) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().HIGH);
		boolean blnResult = false;
		switch (pageName.trim()) {
		case ACCOUNT_LIST_TOOL:
			blnResult = accountListTool.isPageLoaded();
			break;
		case ACCOUNT_UPDATES_AND_INFO:
			blnResult = accountUpdatesAndInfoPage.isPageLoaded();
			break;
		case ACTIVITY_DASHBOARD:
			blnResult = activityDashboard.isPageLoaded();
			break;
		case ADVISORY_FEE_BILLING:
			blnResult = feeBilling.isPageLoaded();
			break;
		case FBVA_DASHBOARD:
			blnResult = fbvaDashboard.isPageLoaded();
			break;
		case ADIET_APPLICATION_HOME:
			blnResult = fileProcessingStatus.isPageLoaded();
			break;
		case NON_BILLABLE_SCHEDULE:
			blnResult = nonBillableSchedule.isPageLoaded();
			break;
		case PROGRAM_FEE_MANAGEMENT:
			blnResult = programFeeManagement.isPageLoaded();
			break;
		case REBILLING_TEXT:
			blnResult = rebilling.isPageLoaded();
			break;
		case REPORTING_TEXT:
			blnResult = reporting.isPageLoaded();
			break;
		case REPORTING_NEXTGEN:
			blnResult = reportingNextGen.isPageLoaded();
			break;
		case SOURCE_OF_FUNDS:
			blnResult = sourceOfFunds.isPageLoaded();
			break;
		case STYLE_CODE_MAPPING:
			blnResult = styleCodeMapping.isPageLoaded();
			break;
		case BELOW_MINIMUM_TRACKING:
			blnResult = belowMinimumTracking.isPageLoaded();
			break;
		case NOT_REACHED_TRACKING:
			blnResult = notReachedTracking.isPageLoaded();
			break;
		case PORTFOLIO_ACCOUNTING:
			blnResult = portfolioAccounting.isPageLoaded();
			break;
		case FBVA_FILE_STATUS_GRID:
			blnResult = homepagesfbva.isPageLoaded();
			break;

		default:
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate if " + pageName + PAGE_IS_LOADED, pageName + " page should be loaded",
					pageName + PAGE_IS_LOADED, "Invalid page name[" + pageName + "] is passed");
			break;
		}
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if " + pageName + PAGE_IS_LOADED, pageName + " page should be loaded",
				pageName + PAGE_IS_LOADED, pageName + " page is not loaded");
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
