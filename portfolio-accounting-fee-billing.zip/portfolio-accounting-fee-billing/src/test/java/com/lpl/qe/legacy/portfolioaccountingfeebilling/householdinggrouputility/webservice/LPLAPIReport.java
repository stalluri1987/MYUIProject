package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.webservice;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.lplhtmlreport.lib.htmlReport;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class LPLAPIReport extends htmlReport {

    public static final String HTML_START = "<html>";
    public static final String HTML_END = "</html>";
    public static final String BODY_START = "<body>";
    public static final String BODY_END = "</body>";
    public static String endpoint = "";
    public static String methodType = "";
    public static String requestPayload = "";
    public static String responseTime = "";
    public static String statusCode = "";
    public static String statusLine = "";
    public static String responseData = "";
    public static String payloadType = "";
    public static boolean ntlmAuthentication = false;
    public static Map<String, String> requestHeaders = new HashMap<>();
    public static Map<String, String> responseHeaders = new HashMap<>();
    public static Map<String, String> queryParams = new HashMap<>();
    public static Map<String, String> formParams = new HashMap<>();
    public static Map<String, String> ntlmCredentials = new HashMap<>();

    /**
     * This method is used to generate html report containing all the API details(input and output)
     *
     * @param restAPIInfo
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String generateHTMLReport(LPLRestAPIInfo restAPIInfo) {
        setData(restAPIInfo);
        String reportFilePath = "";
        try {
            Date date = new Date();
            SimpleDateFormat df = new SimpleDateFormat("HH" + "mm" + "ss" + "SSS");
            String strglobaldatetime = df.format(date);
            reportFilePath = LPLCoreReporter.strGlobalScreenshotFolder + "Rest API Details" + "_" + strglobaldatetime
                    + HTML;
            BufferedWriter bw = new BufferedWriter(new FileWriter(reportFilePath));
            bw.write(HTML_START + getHead() + BODY_START + getBody() + BODY_END + HTML_END);
            bw.close();
        } catch (IOException e) {
            LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Generate HTML Report for API call",
                    "HTML Report should be successfully generated",
                    "HTML Report is successfully generated",
                    "Exception occurred while generating the report. Error message: " + e.getMessage(), false);
        }
        return reportFilePath;
    }

    /**
     * This method is used to set data about the API using the given LPLRestAPIInfo object
     *
     * @param restAPIInfo
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static void setData(LPLRestAPIInfo restAPIInfo) {
        endpoint = restAPIInfo.getEndpoint();
        methodType = restAPIInfo.getMethodType();
        responseTime = restAPIInfo.getResponseTime();
        statusCode = restAPIInfo.getStatusCode();
        statusLine = restAPIInfo.getStatusLine();
        payloadType = restAPIInfo.getPayloadType();

        if (payloadType.equalsIgnoreCase("json"))
            requestPayload = restAPIInfo.getRequestPayload();
        else if (payloadType.equalsIgnoreCase("x-www-form-urlencoded"))
            formParams = restAPIInfo.getRequestFormParameters();

        if (!restAPIInfo.getRequestHeaders().isEmpty())
            requestHeaders = restAPIInfo.getRequestHeaders();
        if (!restAPIInfo.getQueryParams().isEmpty())
            queryParams = restAPIInfo.getQueryParams();
        if (!restAPIInfo.getResponseHeaders().isEmpty())
            responseHeaders = restAPIInfo.getResponseHeaders();
        if (!restAPIInfo.getRequestFormParameters().isEmpty())
            formParams = restAPIInfo.getRequestFormParameters();
        responseData = restAPIInfo.getResponseData();
        if (restAPIInfo.getNtlmAuthentication()) {
            ntlmAuthentication = true;
            ntlmCredentials.put("Username", restAPIInfo.getNtlmUserName());
            ntlmCredentials.put("Password", "*************");
        }
    }

    /**
     * This method is used to get the content of head tab for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getHead() {
        return "<head><title>API Report</title><link rel=\"stylesheet\" type=\"text/css\" href=\"http://qa2000server/Automation_Snapshots/CSS/Report.css\"/><link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\"/></head>";
    }

    /**
     * This method is used to get the content of body tab for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getBody() {
        return BODY_START
                + "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><div style=\"text-align:center\"><div class=\"w3-panel w3-display-container w3-border w3-indigo\"><strong>API DETAILS</strong></div><hr>"
                + getBasicInfoAndTabNames() + "</div>" + getRequestHeaderTable() + getQueryParamTable()
                + (!methodType.equalsIgnoreCase("GET") ? getRequestBody() : "") + getResponseHeaderTable()
                + getResponseDataTable() + (ntlmAuthentication ? getAuthorizationDetails() : "") + BODY_END;
    }

    /**
     * This method is used to get the API details(endpoint, method type, response time, status code and status line) and tab names for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getBasicInfoAndTabNames() {
        String basicInfo = "<table id=\"01\"><tbody><tr><td><strong>Endpoint</strong></td><td>: " + endpoint
                + "</td></tr><tr><td><strong>Method Type</strong></td><td>: " + methodType
                + "</td></tr><tr><td><strong>Response Time (Millisecond)</strong></td><td>: " + responseTime
                + "</td></tr><tr><td><strong>Status Code</strong></td><td>: " + statusCode
                + "</td></tr><tr><td><strong>Status Line</strong></td><td>: " + statusLine
                + "</td></tr></tbody></table><br>";
        String tabNames = getTabNames();
        return basicInfo + tabNames;
    }

    /**
     * This method is used to get the tab names for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getTabNames() {
        List<String> tabs = new ArrayList<>();
        String[] tabNames = {"Request Headers", "Query Parameters", "Request Payload", "Response Headers",
                "Response Data", "Authorization"};
        for (String tabName : tabNames)
            tabs.add(tabName);

        if (ntlmAuthentication)
            tabs.add("Authorization");

        String htmlText = "<button class=\"w3-button w3-indigo\" onclick=\"document.getElementById('%s').style.display='block'\"><i class=\"w3-xxlarge fa fa-h-square\" aria-hidden=\"true\">%s</i></button>&nbsp;&nbsp;";
        String htmlForTabName = "";
        for (String tabName : tabNames) {
            if (tabName.equalsIgnoreCase("Request Payload") && methodType.equalsIgnoreCase("GET"))
                continue;
            htmlForTabName += String.format(htmlText, tabName, tabName);
        }
        return htmlForTabName;

    }

    /**
     * This method is used to get the Request Header details for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getRequestHeaderTable() {
        String rowsTemplate = "<tr><td>%s</td><td>%s</td></tr>";
        String rows = "";
        for (Map.Entry<String, String> param : requestHeaders.entrySet()) {
            rows += String.format(rowsTemplate, param.getKey(), param.getValue());
        }
        if (requestHeaders.isEmpty())
            rows = "<tr><td></td><td><pre>There are no request headers for this request</pre></td></tr>";
        String htmlText = "<div id=\"Request Headers\" class=\"w3-panel w3-display-container w3-border w3-indigo\" style=\"display: block;\"><span onclick=\"this.parentElement.style.display='none'\" class=\"w3-button w3-red w3-display-topright\">Close</span><h3>Request Headers</h3><table class=\"w3-table-all\"><tbody><tr></tr>"
                + rows + "</tbody></table></div>";
        return htmlText;
    }

    public static String getAuthorizationDetails() {
        String rowsTemplate = "<tr><td>%s</td><td>%s</td></tr>";
        String rows = "";
        for (Map.Entry<String, String> param : ntlmCredentials.entrySet()) {
            rows += String.format(rowsTemplate, param.getKey(), param.getValue());
        }
        if (ntlmCredentials.isEmpty())
            rows = "<tr><td></td><td><pre>There is no authorization required for this API</pre></td></tr>";
        String htmlText = "<div id=\"Authorization\" class=\"w3-panel w3-display-container w3-border w3-indigo\" style=\"display: block;\"><span onclick=\"this.parentElement.style.display='none'\" class=\"w3-button w3-red w3-display-topright\">Close</span><h3>Authorization</h3><table class=\"w3-table-all\"><tbody><tr></tr>"
                + rows + "</tbody></table></div>";
        return htmlText;
    }

    /**
     * This method is used to get the query parameters details for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getQueryParamTable() {
        String rowsTemplate = "<tr><td>%s</td><td>%s</td></tr>";
        String rows = "";
        for (Map.Entry<String, String> param : queryParams.entrySet()) {
            rows += String.format(rowsTemplate, param.getKey(), param.getValue());
        }
        if (queryParams.isEmpty())
            rows = "<tr><td></td><td><pre>There are no query parameters for this request</pre></td></tr>";
        String htmlText = "<div id=\"Query Parameters\" class=\"w3-panel w3-display-container w3-border w3-indigo\" style=\"display: block;\"><span onclick=\"this.parentElement.style.display='none'\" class=\"w3-button w3-red w3-display-topright\">Close</span><h3>Query Parameters</h3><table class=\"w3-table-all\"><tbody><tr></tr>"
                + rows + "</tbody></table></div>";
        return htmlText;
    }

    public static String getRequestBody() {
        if(payloadType.equalsIgnoreCase("x-www-form-urlencoded"))
            return getFormParameters();
        else if(payloadType.equalsIgnoreCase("json"))
            return getRequestBodyTable();
        return "";
    }

    /**
     * This method is used to get the Request Body details for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getRequestBodyTable() {
        String rowsTemplate = "<tr><td></td><td><pre>%s</pre></td></tr>";
        String row = String.format(rowsTemplate, getPrettyJson(requestPayload));
        String htmlText = "<div id=\"Request Payload\" class=\"w3-panel w3-display-container w3-border w3-indigo\" style=\"display: block;\"><span onclick=\"this.parentElement.style.display='none'\" class=\"w3-button w3-red w3-display-topright\">Close</span><h3>Request Payload</h3><table class=\"w3-table-all\"><tbody><tr></tr>"
                + row + "</tbody></table></div>";
        return htmlText;
    }

    /**
     * This method is used to get the request payload form parameters details for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getFormParameters() {
        String rowsTemplate = "<tr><td>%s</td><td>%s</td></tr>";
        String rows = "";
        for (Map.Entry<String, String> param : formParams.entrySet()) {
            rows += String.format(rowsTemplate, param.getKey(), param.getValue());
        }
        String htmlText = "<div id=\"Request Payload\" class=\"w3-panel w3-display-container w3-border w3-indigo\" style=\"display: block;\"><span onclick=\"this.parentElement.style.display='none'\" class=\"w3-button w3-red w3-display-topright\">Close</span><h3>Form Parameters</h3><table class=\"w3-table-all\"><tbody><tr></tr>"
                + rows + "</tbody></table></div>";
        return htmlText;
    }

    /**
     * This method is used to get the Response header details for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getResponseHeaderTable() {
        String rowsTemplate = "<tr><td>%s</td><td>%s</td></tr>";
        String rows = "";
        for (Map.Entry<String, String> param : responseHeaders.entrySet()) {
            rows += String.format(rowsTemplate, param.getKey(), param.getValue());
        }
        String htmlText = "<div id=\"Response Headers\" class=\"w3-panel w3-display-container w3-border w3-indigo\" style=\"display: block;\"><span onclick=\"this.parentElement.style.display='none'\" class=\"w3-button w3-red w3-display-topright\">Close</span><h3>Response Headers</h3><table class=\"w3-table-all\"><tbody><tr></tr>"
                + rows + "</tbody></table></div>";
        return htmlText;
    }

    /**
     * This method is used to get the Response data for html report
     *
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getResponseDataTable() {
        String rowsTemplate = "<tr><td></td><td><pre>%s</pre></td></tr>";
        String row = String.format(rowsTemplate, getPrettyJson(responseData));
        String htmlText = "<div id=\"Response Data\" class=\"w3-panel w3-display-container w3-border w3-indigo\" style=\"display: block;\"><span onclick=\"this.parentElement.style.display='none'\" class=\"w3-button w3-red w3-display-topright\">Close</span><h3>Response Data</h3><table class=\"w3-table-all\"><tbody><tr></tr>"
                + row + "</tbody></table></div>";
        return htmlText;
    }

    /**
     * This method is used to return formatted(pretty format) json string
     *
     * @param strValue
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getPrettyJson(String strValue) {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            JsonParser jp = new JsonParser();
            JsonElement je = jp.parse(strValue);
            return gson.toJson(je);
        } catch (Exception e) {
            return getPrettyHTML(strValue);
        }

    }

    /**
     * This method is used to return formatted(pretty format) html string
     *
     * @param htmlString
     * @return String
     * @author pmanohar
     * @since 9.17.2020
     */
    public static String getPrettyHTML(String htmlString) {
        try {
            Document doc = Jsoup.parse(htmlString);   // pretty print HTML
            return doc.toString().replace("<", "&lt;");
        } catch (Exception e) {
            return "API Response is neither in JSON or HTML format.";
        }
    }

}
