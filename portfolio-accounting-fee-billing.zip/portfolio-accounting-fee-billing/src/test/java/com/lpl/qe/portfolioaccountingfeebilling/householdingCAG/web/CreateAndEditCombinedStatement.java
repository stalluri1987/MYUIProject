package com.lpl.qe.portfolioaccountingfeebilling.householdingCAG.web;

import java.awt.AWTException;

import org.testng.annotations.Test;

import com.dataprovider.DataProviderClass;
import com.dataprovider.DataProviderFactory;
import com.dataprovider.REQUEST_TYPE;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.annotations.NeedsDriver;
import com.lpl.qe.blackbird.clientworks.web.utils.LoginUtility;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.portfolioaccountingfeebilling.householding.constants.CombinedStatementEnum;
import com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject.CombinedStatementData;
import com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject.CreateHouseholdData;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.BankSweepUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.CombinedStatementCapabilityUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.CommonUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.HouseholdCreateUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.LoginLogoutUtility;

public class CreateAndEditCombinedStatement {
	
	private static final String SHEET_NAME = "CombinedStatementData";
	private static final String EXCEL_FILE = "src/test/resources/testdata/HouseholdGroupExcel.xlsx";
	@NeedsDriver
	@DataProviderFactory(requestType = REQUEST_TYPE.POJO, fileName = EXCEL_FILE, sheetName = SHEET_NAME, range = "2-2")
	@Test(dataProvider = "UniversalRowProvider", dataProviderClass = DataProviderClass.class)
	public void createHousehold(CombinedStatementData dataCS)
			throws InterruptedException, AWTException{
		
		//ClientworksCommon clientworksCommon = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		CommonUtility clientworksCommonUtility = BasePage.initialize(DriverFactory.getDriver(), CommonUtility.class);
		HouseholdCreateUtility householdCreateUtility = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreateUtility.class);
		CombinedStatementCapabilityUtility combinedStmtCapabilityUtility = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapabilityUtility.class); 
		BankSweepUtility bankSweepUtility = BasePage.initialize(DriverFactory.getDriver(), BankSweepUtility.class); 
		LoginLogoutUtility.loginToCW();
		LoginUtility.userLogin(dataCS.getUserName(), dataCS.getPassword());
		clientworksCommonUtility.clickOnGroupsTab();
		householdCreateUtility.clickCreateGroup();
		householdCreateUtility.clickCreateGroupHousehold();
		householdCreateUtility.isNewHouseholdPageDisplayed();
		householdCreateUtility.enterClientNames(dataCS.getClientName1());
		householdCreateUtility.selectClientName();
		householdCreateUtility.clickCreateHousehold();
		householdCreateUtility.verifyHHCreatedMesgConfPage();
		bankSweepUtility.clickBankSweepLink();
		bankSweepUtility.verifyBankSweepCreatedSuccessMsg(dataCS.getGroupName());
		combinedStmtCapabilityUtility.verifyCombinedStmtOptionalText();
		combinedStmtCapabilityUtility.clickCombinedStatementLink();
		combinedStmtCapabilityUtility.validateNewCombinedStmtPage(CombinedStatementEnum.NEWCOMBINEDSTATEMENTHEADERTEXT.toString(), 
				CombinedStatementEnum.COMBINEDSTATEMENTSTATICTEXT.toString(), CombinedStatementEnum.COMBINEDSTATEMENTTEXT.toString(),
				dataCS.getGroupName());
		combinedStmtCapabilityUtility.validateContentsPanelCombinedStmt();
		combinedStmtCapabilityUtility.validateContentsPanelClientsCombinedStmt();
		combinedStmtCapabilityUtility.validateAccountValueContentPanelCombinedStmt();
		combinedStmtCapabilityUtility.verifyTrackerForHousehold(dataCS.getGroupName());
		combinedStmtCapabilityUtility.verifyTrackerForBankSweep(dataCS.getGroupName());
		combinedStmtCapabilityUtility.verifyTrackerForCombinedStmt();
		combinedStmtCapabilityUtility.verifyCombinedStmtSection(CombinedStatementEnum.COMBINESSTMTADDRESSFIELD.toString(), 
				CombinedStatementEnum.COMBINEDSTMTSSNTAXIDFIELD.toString());
		combinedStmtCapabilityUtility.validateEditCombinedStmtPage();
		combinedStmtCapabilityUtility.validateReviewCombinedStmtPage(CombinedStatementEnum.COMBINEDSTMTLETTERWIDGETTITLE.toString(), 
				CombinedStatementEnum.COMBINEDSTMTLETTERWIDGETCONTENT.toString(), dataCS.getCombinedStatementName(), CombinedStatementEnum.PRIMARYACCOUNTFIELD.toString(),
				CombinedStatementEnum.MAILINGADDRESSFIELD.toString(), dataCS.getMailingAddLine1(), dataCS.getMailingAddLine2());
		combinedStmtCapabilityUtility.clickCreateCombinedStmtButton();
	}

}
