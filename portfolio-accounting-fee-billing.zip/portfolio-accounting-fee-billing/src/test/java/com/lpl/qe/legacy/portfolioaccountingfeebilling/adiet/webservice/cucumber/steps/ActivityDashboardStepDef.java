package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;


/**
 * <p>
 * <br>
 * <b> Title: </b> ActivityDashboardStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for ActivityDashboard</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * ActivityDashboardStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class ActivityDashboardStepDef extends CommonStepDef {

	@And("^I verify the availability of columns in the activity report$")
	public void iverifytheavailabilityofcolumnsintheactivityreport(DataTable columnsInReport) {
		boolean blnResult = activityDashboard.verifyColumnsAvailableInactivityReport(columnsInReport);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of all columns in report", "User should be able to see all columns in report",
				"Successfully able to see all columns in report",
				"Failed to all columns in report : " + Common.strError);
	}

	@And("^I verify the availability of checkbox for Change Type$")
	public void iVerifyTheAvailabilityOfCheckboxForChangeType(DataTable checkboxOnPage) {
		boolean blnResult = activityDashboard.verifyCheckBoxAvailable(checkboxOnPage);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of checkbox for Change Type",
				"User should be able to see all checkbox for Change Type",
				"Successfully able to see all checkbox for Change Type",
				"Failed to see all checkbox for Change Type : " + Common.strError);
	}

	@And("^I verify All checkbox is selected$")
	public void iVerifyAllCheckboxIsSelected() {
		boolean blnResult = activityDashboard.verifyAllCheckboxIsSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify All checkbox is selected",
				"User should be able to see All checkbox is selected", "Successfully All checkbox is selected",
				"Failed All checkbox is not selected : " + Common.strError);
	}

	@When("^I select Last 7 days from Date Range dropdown$")
	public void iSelectLast7DaysFromDateRangeDropdown() {
		boolean blnResult = activityDashboard.selectValueInDateRangeDropdown(testData.get("strLast7Days"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Last 7 Days is selected in Tracking Satus Dropdown",
				"User should be able to see Last 7 Days is selected", "Successfully Last 7 Days is selected",
				"Failed to select Last 7 Days in dropdown : " + Common.strError);
	}

	@When("^I click on Search button under Activity Dashboard$")
	public void iClickOnSearchButtonUnderActivityDashboard() {
		boolean blnResult = activityDashboard.iClickOnSearchButtonUnderActivityDashboard();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Search button under Activity Dashboard",
				"User should able to click Search button under Activity Dashboard",
				"Successfully able to click Search button under Activity Dashboard",
				"Failed to click Search button under Activity Dashboard :" + Common.strError);
	}

	@And("^I verify Data is displayed$")
	public void verifyDataIsDisplayed() {
		boolean blnResult = activityDashboard.verifyActivityDataIsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Data is displayed on Activity Dashboard", "User should be able to see Data",
				"Successfully Data is displayed", "Failed to see data : " + Common.strError);
	}

	@And("^I verify Date format$")
	public void verifyDateFormat() {
		boolean blnResult = activityDashboard.verifyDateFormat();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Date format",
				"User should be able to see Date format", "Successfully Date format is correct",
				"Failed to get correct Date format : " + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
