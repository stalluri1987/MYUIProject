package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> ReportingStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for Reporting</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * ReportingStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class ReportingStepDef extends CommonStepDef {

	@Then("^I verify the availability of Ops Reporting Tab$")
	public void verifytheAvailabilityofOpsReportingTab() {
		boolean blnResult = reporting.iVerifytheAvailabilityofOpsReportingTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Ops Reporting Tab", "User should be able to see Ops Reporting Tab",
				"Successfully able to see Ops Reporting Tab", "Failed to see Ops Reporting Tab : " + Common.strError);
	}

	@Then("^I verify the availability of Master Account List For Models report link$")
	public void verifytheAvailabilityofMasterAccountListForModelsreportlink() {
		boolean blnResult = reporting.iVerifytheAvailabilityofMasterAccountListForModelsreportlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availiability Master Account List For Models report link",
				"User should be able Master Account List For Models report link",
				"Successfully able to Master Account List For Models report link",
				"Failed to see Master Account List For Models report link :  " + Common.strError);
	}

	@Then("^I click on Master Account List For Models$")
	public void clickOnMasterAccountListForModels() {
		boolean blnResult = reporting.iClickOnMasterAccountListForModels();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can able to Click on the Master Account List For Models report link",
				"User should be able to to Click on the Master Account List For Models report link",
				"Successfully able to Click on the Master Account List For Models report link",
				"Failed to Click on the Master Account List For Models report link : " + Common.strError);
	}

	@Then("^I verify the availability of MWP Strategist Payment Report link$")
	public void verifytheAvailabilityofMWPStrategistPaymentReportlink() {
		boolean blnResult = reporting.iVerifytheAvailabilityofMWPStrategistPaymentReportlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of MWP Reporting Strategist Payment Report link",
				"User should be able to see MWP Strategist Payment Report link",
				"Successfully able to see MWP Reporting Strategist Payment Report link",
				"Failed to see MWP Reporting Strategist Payment Report link : " + Common.strError);
	}

	@Then("^I click on MWP Strategist Payment Report$")
	public void clickOnMWPStrategistPaymentReport() {
		boolean blnResult = reporting.iClickOnMWPStrategistPaymentReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can able to Click on the MWP Strategist Link",
				"User should be able to to Click on the MWP Strategist Link",
				"Successfully able to Click on the MWP Strategist Link",
				"Failed to Click on the MWP Strategist Link : " + Common.strError);
	}

	@Then("^I Verify the Header of MWPStrategist Payment Report$")
	public void verifytheHeaderofMWPStrategistPaymentReport() {
		boolean blnResult = reporting.verifytheHeaderofMWPStrategistPaymentReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Header of the report is Displaying",
				"User should able to see the Header of the report is Displaying",
				"Successfully able to see that Header of the report is Displaying",
				"Failed to see that Header of the report is Displaying : " + Common.strError);
	}

	@Then("^I verify the availability of Billing QC Reporting Tab$")
	public void verifytheAvailabilityofBillingQCReportingTab() {
		boolean blnResult = reporting.iVerifytheAvailabilityofBillingQCReportingTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Billing QC Reporting Tab",
				"User should be able to see Billing QC Reporting Tab",
				"Successfully able to see Billing QC Reporting Tab",
				"Failed to see Billing QC Reporting Tab : " + Common.strError);
	}

	@Then("^I click on Billing QC Reporting Tab$")
	public void clickOnBillingQCReportingTab() {
		boolean blnResult = reporting.iclickOnBillingQCReportingTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can able to Click on Billing QC Reporting Tab",
				"User should be able to to Click on Billing QC Reporting Tab",
				"Successfully able to Click on Billing QC Reporting Tab",
				"Failed to Click on Billing QC Reporting Tab : " + Common.strError);
	}

	@Then("^I verify the availability of Billing Summary report link$")
	public void verifytheAvailabilityofBillingSummaryreportlink() {
		boolean blnResult = reporting.iverifytheAvailabilityofBillingSummaryreportlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availiability of Billing Summary report link",
				"User should be able to see Billing Summary report link",
				"Successfully able to see Billing Summary report link",
				"Failed to seeBilling Summary report link :  " + Common.strError);
	}

	@Then("^I click on Billing Summary$")
	public void clickOnBillingSummary() {
		boolean blnResult = reporting.iClickOnBillingSummary();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can able to Click on Billing Summary report link",
				"User should be able to to Click on Billing Summary report link",
				"Successfully able to Click on Billing Summary report link",
				"Failed to Click on Billing Summary report link : " + Common.strError);
	}

	@Then("^I should see Billing Summary report opened in new tab$")
	public void billingSummaryReportOpenedInNewTab() {
		boolean blnResult = reporting.billingSummaryReportOpenedinNewTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Billing Summary report opened in new tab",
				"User should be able to see Billing Summary report opened in new tab",
				"Successfully able to see Billing Summary report opened in new tab",
				"Failed to see Billing Summary report opened in new tab : " + Common.strError);
	}

	@Then("^I verify the display of header columns in Billing Summary report$")
	public void iverifythedisplayofheadercolumnsinBillingSummaryReport(DataTable searchResultOptions) {
		boolean blnResult = reporting.verifythedisplayofheadercolumnsinBillingSummaryReport(searchResultOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that display of fields for the searched Rep ID", "User should be able to see all search result",
				"Successfully able to see search results", "Failed to see search results : " + Common.strError);
	}

	@And("^I verify the availability of Prop MF FeeRebating Reporting Tab$")
	public void verifyTheAvailabilityOfPropMFFeeRebatingReportingTab() {
		boolean blnResult = reporting.iVerifyTheAvailabilityOfPropMFFeeRebatingReportingTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Prop MF FeeRebating Reporting Tab",
				"User should be able to see Prop MF FeeRebating Reporting Tab",
				"Successfully able to see Prop MF FeeRebating Reporting Tab",
				"Failed to see Prop MF FeeRebating Reporting Tab : " + Common.strError);
	}

	@When("^I click on Prop MF FeeRebating Reporting Tab$")
	public void clickOnPropMFFeeRebatingReportingTab() {
		boolean blnResult = reporting.iClickOnPropMFFeeRebatingReportingTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the Prop MF FeeRebating Reporting Tab",
				"User should be able to to Click on the Prop MF FeeRebating Reporting Tab",
				"Successfully able to Click on the Prop MF FeeRebating Reporting Tab",
				"Failed to Click on the Prop MF FeeRebating Reporting Tab : " + Common.strError);
	}

	@Then("^I verify the availability of Prop MF Rebate Daily Mkt Value report link$")
	public void verifyTheAvailabilityOfPropMFRebateDailyMktValueReportLink() {
		boolean blnResult = reporting.iVerifyTheAvailabilityOfPropMFRebateDailyMktValuerReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Prop MF Rebate Daily Mkt Value report link",
				"User should be able to see Prop MF Rebate Daily Mkt Value report link",
				"Successfully able to see Prop MF Rebate Daily Mkt Value report link",
				"Failed to see Prop MF Rebate Daily Mkt Value report link :  " + Common.strError);
	}

	@When("^I click on Prop MF Rebate Daily Mkt Value report link$")
	public void clickOnPropMFRebateDailyMktValueReportLink() {
		boolean blnResult = reporting.iClickOnPropMFRebateDailyMktValueReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the Prop MF Rebate Daily Mkt Value report link",
				"User should be able to Click on the Prop MF Rebate Daily Mkt Value report link",
				"Successfully able to Click on the Prop MF Rebate Daily Mkt Value report link",
				"Failed to Click on the Prop MF Rebate Daily Mkt Value report link : " + Common.strError);
	}

	@Then("^I should see Prop MF Rebate Daily Mkt Value report opened in new tab$")
	public void PropMFRebateDailyMktValueReportOpenedInNewTab() {
		boolean blnResult = reporting.propMFRebateDailyMktValueReportOpenedInNewTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Page Title of the Prop MF Rebate Daily Mkt Value report opened in new tab",
				"User should be able to see Prop MF Rebate Daily Mkt Value report opened in new tab",
				"Successfully able to see Prop MF Rebate Daily Mkt Value report opened in new tab",
				"Failed to see Prop MF Rebate Daily Mkt Value report opened in new tab : " + Common.strError);
	}

	@And("^I verify the availablity of search field option labels$")
	public void iVerifyTheAvailablityOfSearchFieldOptionLabels(DataTable dailyReportLabels) {
		boolean blnResult = reporting.verifyTheAvailablityOfSearchFieldOptionLabels(dailyReportLabels);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search field option labels",
				"User should be able to see all search field option labels",
				"Successfully able to see all search field option labels as expected",
				"Failed to see all search field option labels as expected : " + Common.strError);
	}

	@When("^I select the Start Date$")
	public void enterStartDate() {
		boolean blnResult = reporting.enterStartDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "User enter's the Start Date",
				"User should be able to enter Start Date", "Successfully able to enter Start Date",
				"Failed to enter Start Date : " + Common.strError);
	}

	@And("^I select the End Date$")
	public void enterEndDate() {
		boolean blnResult = reporting.enterEndDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "User enter's End Date",
				"User should be able to enter End Date", "Successfully able to enter End Date",
				"Failed to enter End Date : " + Common.strError);
	}

	@And("^I select the Entity from dropdown list$")
	public void selectEntityFromDropdownList() {
		boolean blnResult = reporting.selectEntityFromDropdownList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User select the Entity from dropdown list", "User should be able to select Entity from dropdown list",
				"Successfully able to select Entity from dropdown list",
				"Failed to select Entity from dropdown list :" + Common.strError);
	}

	@And("^I select the CUSIPs from dropdown list$")
	public void selectCUSIPsFromDropdownList() {
		boolean blnResult = reporting.selectCUSIPsFromDropdownList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User select the CUSIPs from dropdown list", "User should be able to select CUSIPs from dropdown list",
				"Successfully able to select CUSIPs from dropdown list",
				"Failed to select CUSIPs from dropdown list :" + Common.strError);
	}

	@And("^I click on View Report button$")
	public void clickOnViewReportButton() {
		boolean blnResult = reporting.iClickOnViewReportButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the View Report button",
				"User should be able to Click on the View Report button",
				"Successfully able to Click on the View Report button",
				"Failed to Click on the View Report button : " + Common.strError);
	}

	@Then("^I Verify the Header of Prop MF Rebate Daily Mkt Value Report$")
	public void verifyTheHeaderOfPropMFRebateDailyMktValueReport() {
		boolean blnResult = reporting.iVerifyTheHeaderOfPropMFRebateDailyMktValueReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Header of the report is Displaying",
				"User should able to see the Header of the report is Displaying",
				"Successfully able to see that Header of the report is Displaying",
				"Failed to see that Header of the report is Displaying : " + Common.strError);
	}

	@And("^I verify Date Range is present in Report$")
	public void verifyDateRangeIsPresentInReport() {
		boolean blnResult = reporting.iVerifyDateRangeIsPresentInReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Date Range is present in Report", "User should be able to see Date Range in Report",
				"Successfully able to see Date Range in Report",
				"Failed to see Date Range in Report : " + Common.strError);
	}

	@And("^I verify Entity is present in Report$")
	public void verifyEntityIsPresentInReport() {
		boolean blnResult = reporting.iVerifyEntityIsPresentInReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Entity is present in Report",
				"User should be able to see Entity in Report", "Successfully able to see Entity in Report",
				"Failed to see Entity in Report : " + Common.strError);
	}

	@And("^I verify the availablity of search field option labels in Report$")
	public void iVerifyTheAvailablityOfSearchFieldOptionLabelsInReport(DataTable dailyReportLabels) {
		boolean blnResult = reporting.verifyTheAvailablityOfSearchFieldOptionLabelsInReport(dailyReportLabels);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search field option labels in Daily Report",
				"User should be able to see all search field option labels",
				"Successfully able to see all search field option labels as expected",
				"Failed to see all search field option labels as expected : " + Common.strError);
	}

	@Then("^I verify the availability of Prop MF Rebate Monthly Account Level Detail Report link$")
	public void iVerifyTheAvailabilityOfPropMFRebateMonthlyAccountLevelDetailReportLink() {
		boolean blnResult = reporting.verifyTheAvailabilityOfPropMFRebateMonthlyAccountLevelDetailReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Prop MF Rebate Monthly Account Level Detail Report link",
				"User should be able to see Prop MF Rebate Monthly Account Level Detail Report link",
				"Successfully able to see  Prop MF Rebate Monthly Account Level Detail Report link",
				"Failed to see Prop MF Rebate Monthly Account Level Detail Report link : " + Common.strError);
	}

	@When("^I click on Prop MF Rebate Monthly Account Level Detail Report link$")
	public void iClickOnPropMFRebateMonthlyAccountLevelDetailReportLink() {
		boolean blnResult = reporting.clickOnPropMFRebateMonthlyAccountLevelDetailReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the Prop MF Rebate Monthly Account Level Detail Report link",
				"User should be able to Click on the Prop MF Rebate Monthly Account Level Detail Report link",
				"Successfully able to Click on the Prop MF Rebate Monthly Account Level Detail Report link",
				"Failed to Click on the Prop MF Rebate Monthly Account Level Detail Report link : " + Common.strError);
	}

	@Then("^I should see Prop MF Rebate Monthly Account Level Detail Report opened in new tab$")
	public void iShouldSeePropMFRebateMonthlyAccountLevelDetailReportOpenedInNewTab() {
		boolean blnResult = reporting.propMFRebateMonthlyAccountLevelDetailReportOpenedInNewTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Page Title of the Prop MF Rebate Monthly Account Level Detail Report opened in new tab",
				"User should be able to see Prop MF Rebate Monthly Account Level Detail Report opened in new tab",
				"Successfully able to see Prop MF Rebate Monthly Account Level Detail Report opened in new tab",
				"Failed to see Prop MF Rebate Monthly Account Level Detail Report opened in new tab : "
						+ Common.strError);
	}

	@And("^I verify the availablity of search field option labels for Monthly Account Level$")
	public void iVerifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyAccountLevel(DataTable monthlyReportLabels) {
		boolean blnResult = reporting
				.verifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyAccountLevel(monthlyReportLabels);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search field option labels in Monthly Account Level",
				"User should be able to see all search field option labels",
				"Successfully able to see all search field option labels as expected",
				"Failed to see all search field option labels as expected : " + Common.strError);
	}

	@When("^I select the Entity from dropdown list in Monthly Report$")
	public void iSelectTheEntityFromDropdownListInMonthlyReport() {
		boolean blnResult = reporting.selectTheEntityFromDropdownListInMonthlyReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User select the Entity from dropdown list in Monthly Report",
				"User should be able to select Entity from dropdown list",
				"Successfully able to select Entity from dropdown list",
				"Failed to select Entity from dropdown list : " + Common.strError);
	}

	@And("^I select the CUSIPs from dropdown list in Monthly Report$")
	public void iSelectTheCUSIPsFromDropdownListInMonthlyReport() {
		boolean blnResult = reporting.selectTheCUSIPsFromDropdownListInMonthlyReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User select the CUSIPs from dropdown list in Monthly Report",
				"User should be able to select CUSIPs from dropdown list",
				"Successfully able to select CUSIPs from dropdown list",
				"Failed to select CUSIPs from dropdown list :" + Common.strError);
	}

	@And("^I select the Month End Date$")
	public void iSelectTheMonthEndDate() {
		boolean blnResult = reporting.selectTheMonthEndDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "User enter's the Month End Date",
				"User should be able to enter Month End Date", "Successfully able to enter Month End Date",
				"Failed to enter Month End Date : " + Common.strError);
	}

	@And("^I click on View Report button in Monthly Report$")
	public void iClickOnViewReportButtonInMonthlyReport() {
		boolean blnResult = reporting.clickOnViewReportButtonInMonthlyReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the View Report button in Monthly Report",
				"User should be able to Click on the View Report button",
				"Successfully able to Click on the View Report button",
				"Failed to Click on the View Report button : " + Common.strError);
	}

	@Then("^I Verify the Header of Prop MF Rebate Monthly Account Level Detail Report$")
	public void iVerifyTheHeaderOfPropMFRebateMonthlyAccountLevelDetailReport() {
		boolean blnResult = reporting.verifyTheHeaderOfPropMFRebateMonthlyAccountLevelDetailReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Header of the report is Displaying in Monthly Report",
				"User should able to see the Header of the report is Displaying",
				"Successfully able to see that Header of the report is Displaying",
				"Failed to see that Header of the report is Displaying : " + Common.strError);
	}

	@And("^I verify Month End Date is present in Monthly Report$")
	public void iVerifyMonthEndDateIsPresentInMonthlyReport() {
		boolean blnResult = reporting.verifyMonthEndDateIsPresentInMonthlyReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Month End Date is present in Report", "User should be able to see Month End Date in Report",
				"Successfully able to see Month End Date in Report",
				"Failed to see Month End Date in Report : " + Common.strError);
	}

	@And("^I verify Entity is present in Monthly Report$")
	public void iVerifyEntityIsPresentInMonthlyReport() {
		boolean blnResult = reporting.verifyEntityIsPresentInMonthlyReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Entity is present in Monthly Report", "User should be able to see Entity in Monthly Report",
				"Successfully able to see Entity in Monthly Report",
				"Failed to see Entity in Monthly Report : " + Common.strError);
	}

	@And("^I verify the statement of Average Daily Position Value$")
	public void iVerifyTheStatementOfAverageDailyPositionValue() {
		boolean blnResult = reporting.verifyTheStatementOfAverageDailyPositionValue();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the statement of Average Daily Position Value",
				"User should be able to see the statement of Average Daily Position Value",
				"Successfully able to see the statement of Average Daily Position Value",
				"Failed to see the statement of Average Daily Position Value : " + Common.strError);
	}

	@And("^I verify the availablity of search field option labels for Monthly Report$")
	public void iVerifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyReport(DataTable monthlyReportLabels) {
		boolean blnResult = reporting
				.verifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyReport(monthlyReportLabels);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search field option labels in Monthly Report",
				"User should be able to see all search field option labels",
				"Successfully able to see all search field option labels as expected",
				"Failed to see all search field option labels as expected : " + Common.strError);
	}

	@Then("^I verify the availability of MWP Account Attributes Report link$")
	public void verifytheAvailabilityofMWPAccountAttributeslink() {
		boolean blnResult = reporting.iVerifytheAvailabilityofMWPAccountAttributesReportlink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of MWP Account Attributes Reporting Report link",
				"User should be able to see MWP Account Attributes Report link",
				"Successfully able to see MWP Account Attributes Report link",
				"Failed to see MWP Account Attributest Payment Report link : " + Common.strError);
	}

	@Then("^I verify the availability of Prop MF Monthly Credit Total by CUSIP Report link$")
	public void iVerifyTheAvailabilityOfPropMFMonthlyCreditTotalByCUSIPReportLink() {
		boolean blnResult = reporting.verifyTheAvailabilityOfPropMFMonthlyCreditTotalByCUSIPReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Prop MF Monthly Credit Total by CUSIP Report link",
				"User should be able to see Prop MF Monthly Credit Total by CUSIP Report link",
				"Successfully able to see Prop MF Monthly Credit Total by CUSIP Report link",
				"Failed to see Prop MF Monthly Credit Total by CUSIP Report link : " + Common.strError);
	}

	@Then("^I click on MWP Account Attributes Report$")
	public void clickOnMWPAccountAttributesReport() {
		boolean blnResult = reporting.iClickOnMWPAccountAttributesReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can able to Click on the MWP Account Attributes Link",
				"User should be able to to Click on the MWP Account Attributes Link",
				"Successfully able to Click on the MWP Account AttributesLink",
				"Failed to Click on the MWP Account Attributes Link : " + Common.strError);
	}

	@Then("^I Verify the Header of MWP Account Attributes Report$")
	public void verifytheHeaderofMWPAccountAttributesReport() {
		boolean blnResult = reporting.verifytheHeaderofMWPAccountAttributesReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Header of the report is Displaying",
				"User should able to see the Header of the report is Displaying",
				"Successfully able to see that Header of the report is Displaying",
				"Failed to see that Header of the report is Displaying : " + Common.strError);
	}

	@When("^I click on Prop MF Monthly Credit Total by CUSIP Report link$")
	public void iClickOnPropMFMonthlyCreditTotalByCUSIPReportLink() {
		boolean blnResult = reporting.clickOnPropMFMonthlyCreditTotalByCUSIPReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the Prop MF Monthly Credit Total by CUSIP Report link",
				"User should be able to Click on the Prop MF Monthly Credit Total by CUSIP Report link",
				"Successfully able to Click on the Prop MF Monthly Credit Total by CUSIP Report link",
				"Failed to Click on the Prop MF Monthly Credit Total by CUSIP Report link : " + Common.strError);
	}

	@Then("^I should see Prop MF Monthly Credit Total by CUSIP Report opened in new tab$")
	public void iShouldSeePropMFMonthlyCreditTotalByCUSIPReportOpenedInNewTab() {
		boolean blnResult = reporting.shouldSeePropMFMonthlyCreditTotalByCUSIPReportOpenedInNewTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Page Title of the Prop MF Monthly Credit Total by CUSIP Report opened in new tab",
				"User should be able to see Prop MF Monthly Credit Total by CUSIP Report opened in new tab",
				"Successfully able to see Prop MF Monthly Credit Total by CUSIP Report opened in new tab",
				"Failed to see Prop MF Monthly Credit Total by CUSIP Report opened in new tab : " + Common.strError);
	}

	@And("^I verify the availablity of search field option labels for Monthly Credit CUSIP Report$")
	public void iVerifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyCreditCUSIPReport(
			DataTable monthlyReportLabels) {
		boolean blnResult = reporting
				.verifyTheAvailablityOfSearchFieldOptionLabelsForMonthlyCreditCUSIPReport(monthlyReportLabels);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search field option labels in Monthly Credit CUSIP Report",
				"User should be able to see all search field option labels",
				"Successfully able to see all search field option labels as expected",
				"Failed to see all search field option labels as expected : " + Common.strError);
	}

	@When("^I select the Entity from dropdown list for CUSIP Report$")
	public void iSelectTheEntityFromDropdownListForCUSIPReport() {
		boolean blnResult = reporting.selectTheEntityFromDropdownListForCUSIPReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User select the Entity from dropdown list for CUSIP Report",
				"User should be able to select Entity from dropdown list",
				"Successfully able to select Entity from dropdown list",
				"Failed to select Entity from dropdown list : " + Common.strError);
	}

	@And("^I select the CUSIPs from dropdown list for CUSIP Report$")
	public void iSelectTheCUSIPsFromDropdownListForCUSIPReport() {
		boolean blnResult = reporting.selectTheCUSIPsFromDropdownListForCUSIPReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User select the CUSIPs from dropdown list for CUSIP Report",
				"User should be able to select CUSIPs from dropdown list",
				"Successfully able to select CUSIPs from dropdown list",
				"Failed to select CUSIPs from dropdown list :" + Common.strError);
	}

	@And("^I select the Month End Date from dropdown list$")
	public void iSelectTheMonthEndDateFromDropdownList() {
		boolean blnResult = reporting.selectTheMonthEndDateFromDropdownList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User enter's the Month End Date for CUSIP Report", "User should be able to enter Month End Date",
				"Successfully able to enter Month End Date", "Failed to enter Month End Date : " + Common.strError);
	}

	@And("^I click on View Report button for CUSIP Report$")
	public void iClickOnViewReportButtonForCUSIPReport() {
		boolean blnResult = reporting.clickOnViewReportButtonForCUSIPReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can be able to Click on the View Report button for CUSIP Report",
				"User should be able to Click on the View Report button",
				"Successfully able to Click on the View Report button",
				"Failed to Click on the View Report button : " + Common.strError);
	}

	@Then("^I Verify the Header of Prop MF Monthly Credit Total by CUSIP Report$")
	public void iVerifyTheHeaderOfPropMFMonthlyCreditTotalByCUSIPReport() {
		boolean blnResult = reporting.verifyTheHeaderOfPropMFMonthlyCreditTotalByCUSIPReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Header of the report is Displaying in CUSIP Report",
				"User should able to see the Header of the report is Displaying",
				"Successfully able to see that Header of the report is Displaying",
				"Failed to see that Header of the report is Displaying : " + Common.strError);
	}

	@And("^I verify Month End Date is present in CUSIP Report$")
	public void iVerifyMonthEndDateIsPresentInCUSIPReport() {
		boolean blnResult = reporting.verifyMonthEndDateIsPresentInCUSIPReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Month End Date is present in CUSIP Report",
				"User should be able to see Month End Date in Report",
				"Successfully able to see Month End Date in Report",
				"Failed to see Month End Date in Report : " + Common.strError);
	}

	@And("^I verify Entity is present in CUSIP Report$")
	public void iVerifyEntityIsPresentInCUSIPReport() {
		boolean blnResult = reporting.verifyEntityIsPresentInCUSIPReport();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Entity is present in CUSIP Report", "User should be able to see Entity in CUSIP Report",
				"Successfully able to see Entity in CUSIP Report",
				"Failed to see Entity in CUSIP Report : " + Common.strError);
	}

	@And("^I verify the statement of CUSIP Factor File$")
	public void iVerifyTheStatementOfCUSIPFactorFile() {
		boolean blnResult = reporting.verifyTheStatementOfCUSIPFactorFile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the statement of CUSIP Factor File",
				"User should be able to see the statement of CUSIP Factor File",
				"Successfully able to see the statement of CUSIP Factor File",
				"Failed to see the statement of CUSIP Factor File : " + Common.strError);
	}

	@And("^I verify the CUSIP Label$")
	public void iVerifyTheCUSIPLabel() {
		boolean blnResult = reporting.verifyTheCUSIPLabel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Label of CUSIP in Summary Report", "User should be able to see the Label of CUSIP",
				"Successfully able to see the Label of CUSIP", "Failed to see the Label of CUSIP : " + Common.strError);
	}

	@And("^I verify the Fund Name Label$")
	public void iVerifyTheFundNameLabel() {
		boolean blnResult = reporting.verifyTheFundNameLabel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Label of Fund Name in Summary Report", "User should be able to see the Label of Fund Name",
				"Successfully able to see the Label of Fund Name",
				"Failed to see the Label of Fund Name : " + Common.strError);
	}

	@And("^I verify the Credit Factor Label$")
	public void iVerifyTheCreditFactorLabel() {
		boolean blnResult = reporting.verifyTheCreditFactorLabel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Label of Credit Factor in Summary Report",
				"User should be able to see the Label of Credit Factor",
				"Successfully able to see the Label of Credit Factor",
				"Failed to see the Label of Credit Factor : " + Common.strError);
	}

	@And("^I verify the Total Credit Amount Label$")
	public void iVerifyTheTotalCreditAmountLabel() {
		boolean blnResult = reporting.verifyTheTotalCreditAmountLabel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Label of Total Credit Amount in Summary Report",
				"User should be able to see the Label of Total Credit Amount",
				"Successfully able to see the Label of Total Credit Amount",
				"Failed to see the Label of Total Credit Amount : " + Common.strError);
	}
	
	@And("^I verify the Average Position Value Label$")
	public void iVerifyTheAveragePositionValueLabel() {
		boolean blnResult = reporting.verifyTheStatementOfAveragePositionValueLabel();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Label of Average Position Value in Summary Report",
				"User should be able to see the Label of Average Position Value",
				"Successfully able to see the Label of Average Position Value",
				"Failed to see the Label of Average Position Value : " + Common.strError);
	}

	@When("^I click on MWP Termed Accts Active Sleeves$")
	public void clickOnMWPTermedAcctsActiveSleeves() {
		boolean blnResult = reporting.iClickOnMWPTermedAcctsActiveSleeves();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on MWP Termed Accts Active Sleeves link",
				"User should be able to click on MWP Termed Accts Active Sleeves link",
				"Successfully able to click on MWP Termed Accts Active Sleeves link",
				"Failed to click on MWP Termed Accts Active Sleeves link : " + Common.strError);
	}

	@Then("^I Verify the Header of MWP Termed Accts Active Sleeves$")
	public void verifyTheHeaderOfMWPTermedAcctsActiveSleeves() {
		boolean blnResult = reporting.iVerifyTheHeaderOfMWPTermedAcctsActiveSleeves();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Header of the report is Displaying",
				"User should able to see the Header of the report is Displaying",
				"Successfully able to see that Header of the report is Displaying",
				"Failed to see that Header of the report is Displaying : " + Common.strError);
	}

	@And("^I verify the availability of MWP Termed Accts Active Sleeves link$")
	public void verifyTheAvailabilityOfMWPTermedAcctsActiveSleevesLink() {
		boolean blnResult = reporting.iVerifyTheAvailabilityOfMWPTermedAcctsActiveSleevesLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of MWP Termed Accts Active Sleeves link",
				"User should be able to see MWP Termed Accts Active Sleeves link",
				"Successfully able to see MWP Termed Accts Active Sleeves link",
				"Failed to see MWP Termed Accts Active Sleeves link : " + Common.strError);
	}

	@Then("^I verify the display of header columns in MWP Termed Accts Active Sleeves Report$")
	public void iverifythedisplayofheadercolumnsinMWPTermedAcctsActiveSleeves(DataTable searchResultOptions) {
		boolean blnResult = reporting.verifythedisplayofheadercolumnsinMWPTermedAcctsActiveSleeves(searchResultOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that display of fields for the searched MWP Termed Accts Active Sleeves Report",
				"User should be able to see all search result", "Successfully able to see search results",
				"Failed to see search results : " + Common.strError);
	}

	@When("^I click on MWP Active Accts No Active Sleeves$")
	public void clickOnMWPActiveAcctsNoActiveSleeves() {
		boolean blnResult = reporting.iClickOnMWPActiveAcctsNoActiveSleeves();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on MWP Active Accts No Active Sleeves link",
				"User should be able to click on MWP Active Accts No Active Sleeves link",
				"Successfully able to click on MWP Active Accts No Active Sleeves link",
				"Failed to click on MWP Active Accts No Active Sleeves link : " + Common.strError);
	}

	@Then("^I Verify the Header of MWP Active Accts No Active Sleeves$")
	public void verifyTheHeaderOfMWPActiveAcctsNoActiveSleeves() {
		boolean blnResult = reporting.iVerifyTheHeaderOfMWPActiveAcctsNoActiveSleeves();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Header of the report is Displaying",
				"User should able to see the Header of the report is Displaying",
				"Successfully able to see that Header of the report is Displaying",
				"Failed to see that Header of the report is Displaying : " + Common.strError);
	}

	@And("^I verify the availability of MWP Active Accts No Active Sleeves$")
	public void verifyTheAvailabilityOfMWPActiveAcctsNoActiveSleeves() {
		boolean blnResult = reporting.iVerifyTheAvailabilityOfMWPActiveAcctsNoActiveSleevesLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of MWP Active Accts No Active Sleeves link",
				"User should be able to see MWP Active Accts No Active Sleeves link",
				"Successfully able to see MWP Active Accts No Active Sleeves link",
				"Failed to see MWP Active Accts No Active Sleeves link : " + Common.strError);
	}

	@Then("^I verify the display of header columns in MWP Active Accts No Active Sleeves Report$")
	public void iverifythedisplayofheadercolumnsinMWPActiveAcctsNoActiveSleeves(DataTable searchResultOptions) {
		boolean blnResult = reporting
				.verifythedisplayofheadercolumnsinMWPActiveAcctsNoActiveSleeves(searchResultOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that display of fields for the searched Rep ID", "User should be able to see all search result",
				"Successfully able to see search results", "Failed to see search results : " + Common.strError);
	}

	@Then("^I verify the availability of Account Level Reconciliation Report Link$")
	public void verifytheAvailabilityofAccountLevelReconciliationReportlink() {
		boolean blnResult = reporting.iVerifytheAvailabilityofAccountLevelReconciliationReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Account Level Reconciliation Report link",
				"User should be able to see Account Level Reconciliation Report link",
				"Successfully able to see Account Level Reconciliation Report link",
				"Failed to see Account Level Reconciliation Report link : " + Common.strError);
	}

	@Then("^I click on Account Level Reconciliation Report Link$")
	public void clickOnAccountLevelReconciliationReport() {
		boolean blnResult = reporting.iClickOnAccountLevelReconciliationReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can able to Click on the Account Level reconciliation Report Link",
				"User should be able to to Click on the Account Level Reconciliation Report Link",
				"Successfully able to Click on Account Level Reconciliation Report",
				"Failed to Click on Account Level Reconciliation Report : " + Common.strError);
	}
	@Then("^I verify the availability of Missing Firm ID Report Link$")
	public void verifytheAvailabilityofMissingFirmIDReportlink() {
		boolean blnResult = reporting.iVerifytheAvailabilityofMissingFirmIDReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Missing Firm ID Report link",
				"User should be able to see Missing Firm ID Report link",
				"Successfully able to see Missing Firm ID Report link",
				"Failed to see Missing Firm ID Report link : " + Common.strError);
	}

	@Then("^I click on Missing Firm ID Report Link$")
	public void clickOnMissingFirmIDReport() {
		boolean blnResult = reporting.iClickOnMissingFirmIDReportLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user can able to Click on the Missing Firm ID Report Link",
				"User should be able to to Click on the Missing Firm ID Report Link",
				"Successfully able to Click on Missing Firm ID Report",
				"Failed to Click on Missing Firm ID Report : " + Common.strError);
	}
	
	@Then("^I should see Missing FirmID Report opened in new tab$")
	public void MissingFirmIDOpenedInNewTab() {
	      boolean blnResult = reporting.missedFirmIDOpenedInNewTab();
	      LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
	              "Verify the Page Title of the  Missing FirmID Report opened in new tab",
	              "User should be able to see  Missing FirmID Report opened in new tab",
	              "Successfully able to see  Missing FirmID Report opened in new tab",
	              "Failed to see Missing FirmID Report opened in new tab : " + Common.strError);
	      }
	
    @Then("^I should see Account Level Reconilation Report opened in new tab$")
    public void AccountReconciliationReportOpenedInNewTab() {
         boolean blnResult = reporting.accountLevelReconciliationReportOpenedInNewTab();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                         "Verify the Page Title of the  Account Reconiciliation Report opened in new tab",
                         "User should be able to see  Account Reconiciliation Report opened in new tab",
                         "Successfully able to see  Account Reconiciliation Reportt opened in new tab",
                         "Failed to see Account Reconiciliation Report opened in new tab : " + Common.strError);
      }
 
    @Then("^I should see MWP Account Attributes Report opened in new tab$")
    public void MWPAccountAttributesReportOpenedInNewTab() {
         boolean blnResult = reporting. MWPAccountAttributesOpenedInNewTab();
         LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                         "Verify the Page Title of the  MWP Account Attributes Report opened in new tab",
                         "User should be able to see  MWP Account Attributes Report opened in new tab",
                         "Successfully able to see MWP Account Attributes Report opened in new tab",
                         "Failed to see MWP Account Attributes Report opened in new tab : " + Common.strError);
      }
		
	@Then("^I verify the availability of Termed GWP Accounts By Period Report Link$")
    public void verifytheAvailabilityofTermedGWPAccountsByPeriodReportlink() {
          boolean blnResult = reporting.iVerifytheAvailabilityofTermedGWPAccountsByPeriodReportLink();
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                       "Verify the availability of Termed GWP Accounts By Period Report link",
                       "User should be able to see Termed GWP Accounts By Period Report link",
                       "Successfully able to see Termed GWP Accounts By Period Report link",
                       "Failed to see Termed GWP Accounts By Period Report link : " + Common.strError);
    }

    @Then("^I click on Termed GWP Accounts By Period Report Link$")
    public void clickOnTermedGWPAccountsByPeriodReportReportLink() {
          boolean blnResult = reporting.iClickOnTermedGWPAccountsByPeriodReportLink();
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                       "Verify user can able to Click on the Termed GWP Accounts By Period Report Link",
                       "User should be able to to Click on the Termed GWP Accounts By Period Report Link",
                       "Successfully able to Click on Termed GWP Accounts By Period Report",
                       "Failed to Click on Termed GWP Accounts By Period Report : " + Common.strError);
    }
    @Then("^I should see Termed GWP Accounts By Period Report opened in new tab$")
       public void TermedAccountsByPeriodReportOpenedInNewTab() {
             boolean blnResult = reporting.termedGWPAccountsByPeriodReportOpenedInNewTab();
             LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                          "Verify the Page Title of the Termed Accounts By Period report opened in new tab",
                          "User should be able to see Termed Accounts By Period report opened in new tab",
                          "Successfully able to see Termed Accounts By Period report opened in new tab",
                          "Failed to see Termed Accounts By Period report opened in new tab : " + Common.strError);
       }
    @Then("^I click on View Report$")
    public void clickOnView_Report() {
          boolean blnResult = reporting.iClickOnViewReport();
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                              "Verify user can able to Click View Report",
                              "User should be able to to Click on the View Report",
                              "Successfully able to Click on View Report",
                              "Failed to Click on View Report : " + Common.strError);
     }    
    @Then("^I Verify the Header of Termed GWP Accounts By Period$")
    public void verifyTheHeaderOfTermedGWPAccountsByPeriod() {
          boolean blnResult = reporting.iVerifytheHeaderofTermedGWPAccountsByPeriod();
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                       "Verify the Header of the report is Displaying",
                       "User should able to see the Header of the report is Displaying",
                       "Successfully able to see that Header of the report is Displaying",
                       "Failed to see that Header of the report is Displaying : " + Common.strError);
    }
    @Then("^I verify the display of header columns in Termed GWP Accounts By Period$")
    public void verifythedisplayofheadercolumnsinTermedGWPAccountsByPeriod(DataTable reportColumns) {
          boolean blnResult = reporting.iverifythedisplayofheadercolumnsinTermedGWPAccountsByPeriod(reportColumns);
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                       "Verify the Header columns of the report is Displaying",
                       "User should able to see the Header columns of the report is Displaying",
                       "Successfully able to see that Header columns of the report is Displaying",
                       "Failed to see that Header columns of the report is Displaying : " + Common.strError);
      }
     @Then("^I verify the availability of Broker Accounts Report Link$")
     public void verifytheAvailabilityofBrokerAccountsReportlink() {
           boolean blnResult = reporting.iVerifytheAvailabilityofBrokerAccountReportlink();
           LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "Verify the availability of Broker Accounts Report link",
                        "User should be able to see Broker Accounts Report link",
                        "Successfully able to see Broker Accounts Report link",
                        "Failed to see Broker Accounts Report link : " + Common.strError);
       }
       @Then("^I click on Broker Accounts Report Link$")
       public void clickOnBrokerAccountReportt() {
             boolean blnResult = reporting.iClickOnBrokerAccountReportlink();
             LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                          "Verify user can able to Click on the Broker Accounts Link",
                          "User should be able to to Click on the Broker Accounts Link",
                          "Successfully able to Click on the Broker Accounts Link",
                          "Failed to Click on the Broker Accounts Link : " + Common.strError);
       }



	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
