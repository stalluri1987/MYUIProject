package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.LPLAPICommon;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.LPLRestAPIInfo;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CommonStepDef extends LPLCoreDriver {

//	public static final String VALIDATE_IF = "Validate if ";
//
//	int statusCode;
//	Response response;
//	String jsonResponseString;
//	String statusLine = null;
//	String strMethodName = null;
//
//	@When("^user calls a (.+) request for (.+)$")
//	public void makeRestServiceCall(String methodType, String methodName) {
//		strMethodName = methodName;
//
//		// getting the response object for given method name
//		response = Common.getRestResponse(methodType);
//
//		// Validating the response object for null value
//		if (response == null)
//			// Reporter for response object check
//			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
//					VALIDATE_IF + strMethodName + " method call return a response",
//					"Response object should not be null", "Response object is not null", "Response object is null.");
//		else
//			jsonResponseString = response.getBody().asString();
//	}
//
//	@Then("^user should see (.+) for status code$")
//	public void validateStatusCode(int expectedStatusCode) {
//		boolean blnResult = false;
//
//		// extracting the status code value
//		statusCode = response.statusCode();
//
//		// extracting the status line value
//		statusLine = response.statusLine();
//
//		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE, "Print the response json",
//				"Response json should be printed", "Response JSON: " + jsonResponseString, "Failed to print the json",
//				false);
//
//		// validating the response status code
//		blnResult = (statusCode == expectedStatusCode);
//
//		// Reporter for response status code
//		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
//				VALIDATE_IF + strMethodName + " method call return a status code of " + expectedStatusCode,
//				"Status code " + expectedStatusCode + " should be returned",
//				"Status code " + expectedStatusCode + " is returned", "Failed to return status code "
//						+ expectedStatusCode + ". Expected: 200 Actual: " + response.statusCode());
//
//		// validating the response status line
//		blnResult = statusLine.contains("200 OK");
//
//		// Reporter for response status line
//		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
//				VALIDATE_IF + strMethodName + " method call return a status line of HTTP/1.1 200 OK",
//				"Status line HTTP/1.1 200 OK should be returned", "Status line HTTP/1.1 200 OK is returned",
//				"Failed to return status line HTTP/1.1 200 OK. Expected: HTTP/1.1 200 OK Actual: "
//						+ response.statusLine());
//	}
//
//	@Before
//	public void beforeTest() {
//		LPLCoreDriver.StartSessionForWSTest();
//		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE, "", "", "", "");
//		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE, "", "", "", "");
//	}
//	
//	@After
//	public void afterTest() {
//		LPLCoreReporter.writeSummary();
//	}

	String methodName;
    String jsonResponseString;
    LPLRestAPIInfo restAPIInfo;
    String jobName;

    @Before
    public void beforeTest() {
        LPLCoreDriver.StartSessionForWSTest();
        LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE,
                 LPLCoreConstents.TRUE, "", "", "", "");
        LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE,
                LPLCoreConstents.TRUE, "", "", "", "");
    }

    @When("^user calls a (.+) request for (.+)$")
    public void makeRestServiceCall(String methodType, String methodName) {
        this.methodName = methodName;
        restAPIInfo = LPLAPICommon.readAPIDetailsFromFarm(methodType);
        jsonResponseString = LPLAPICommon.getRestResponse(methodType, methodName, restAPIInfo);
    }

    @Then("^user should see (.+) for status code$")
    public void validateStatusCode(int expectedStatusCode) {
        LPLAPICommon.validateStatusCode(methodName, Integer.valueOf(restAPIInfo.getStatusCode()), expectedStatusCode);
    }

    @Then("^user should see (.+) for status line$")
    public void validateStatusLine(String expectedStatusLine) {
        LPLAPICommon.validateStatusLine(methodName, restAPIInfo.getStatusLine(), expectedStatusLine);
    }
    
    @After
	public void afterTest() {
		LPLCoreReporter.writeSummary();
	}

}
