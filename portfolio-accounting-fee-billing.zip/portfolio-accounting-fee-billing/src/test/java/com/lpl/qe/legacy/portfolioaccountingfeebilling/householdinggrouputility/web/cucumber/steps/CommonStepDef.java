package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.BankSweepGroupPage;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.BillingCapabilityPage;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.CombinedStatementCapabilityPage;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.Common;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.HouseholdDashBoardPage;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.InvestmentManagementPage;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.Navigation;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.NewHouseholdPage;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages.UserDefinedGroupPage;

import LPLCoreDriver.LPLCoreDriver;
import PageObjectLibrary.HomePage;
import PageObjectLibrary.LoginPage;

public class CommonStepDef extends LPLCoreDriver {

	static NewHouseholdPage newHouseholdPage;
	static LoginPage loginPage;
	static HomePage homePage;
	static Common common;
	static Navigation navigation;
	static BillingCapabilityPage billingPage;
	static CombinedStatementCapabilityPage combinedStatementPage;
	static HouseholdDashBoardPage householdDashBoardPage;
	static InvestmentManagementPage investmentManagementPage;
	static UserDefinedGroupPage userDefinedGroupPage;
	static BankSweepGroupPage bankSweepGroupPage;

	public static void initialize() {
		newHouseholdPage = new NewHouseholdPage(driver);
		loginPage = new LoginPage(driver);
		common = new Common(driver);
		homePage = new HomePage(driver);
		navigation = new Navigation(driver);
		billingPage = new BillingCapabilityPage(driver);
		combinedStatementPage = new CombinedStatementCapabilityPage(driver);
		householdDashBoardPage =  new HouseholdDashBoardPage(driver);
		investmentManagementPage = new InvestmentManagementPage(driver);
		userDefinedGroupPage = new UserDefinedGroupPage(driver);
		bankSweepGroupPage = new BankSweepGroupPage(driver);
	}

}
