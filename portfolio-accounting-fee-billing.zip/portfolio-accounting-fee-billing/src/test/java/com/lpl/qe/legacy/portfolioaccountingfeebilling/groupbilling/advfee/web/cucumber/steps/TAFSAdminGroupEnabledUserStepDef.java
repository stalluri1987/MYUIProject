package com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TAFSAdminGroupEnabledUserStepDef extends CommonStepDef {
	Common commonMethods = new Common(driver);

	@When("^I click on Menu hamburger icon$")
	public void iClickonMenuHamburgericon() {
		boolean blnResult = tafsAdminGroupPage.clickonMenuHamburgericon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Menu hamburger icon",
				"User should able to click Menu hamburger icon", "Successfully able to click Menu hamburger icon",
				"Failed to click Menu hamburger icon :" + commonMethods.strError);
	}

	@When("^I choose Tools from list$")
	public void iChooseToolsfromlist() {
		boolean blnResult = tafsAdminGroupPage.chooseToolsFromlist();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Tools from Menu list",
				"User should able to click Tools from Menu list", "Successfully able to click Tools from Menu list",
				"Failed to click Tools from Menu list :" + commonMethods.strError);
	}

	@When("^I choose Fee Scheduling from list$")
	public void iChooseFeeSchedulingfromList() {
		boolean blnResult = tafsAdminGroupPage.chooseFeeSchedulingfromlist();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Choose Fee Scheduling from sub menu",
				"User should able to Choose Fee Scheduling from sub menu",
				"Successfully able to Choose Fee Scheduling from sub menu",
				"Failed to Choose Fee Scheduling from sub menu  :" + commonMethods.strError);
	}

	@Then("^I should land on Advisory Fee tab$")
	public void iShouldLandonAdvisoryFeeTab() {
		boolean blnResult = tafsAdminGroupPage.iShouldLandonAdvisoryFeeTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Advisory Fee tab", "User should be able to see Advisory Fee tab",
				"Successfully able to see Advisory Fee tab",
				"Failed to see Advisory Fee tab : " + commonMethods.strError);
	}

	@When("^I click on Master Rep textbox$")
	public void clickonMasterRepTextbox() {
		boolean blnResult = tafsAdminGroupPage.clickonMasterRepTextbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Master Rep textbox",
				"User should able to click Master Rep textbox", "Successfully able to click Master Rep textbox",
				"Failed to click Master Rep textbox :" + commonMethods.strError);
	}

	@When("^I select a Rep$")
	public void selectRep() {
		boolean blnResult = tafsAdminGroupPage.selectRep();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Rep from Search results",
				"User should able to Select Rep from Search results ",
				"Successfully able to Select Rep from Search results ",
				"Failed to Select Rep from Search results  :" + commonMethods.strError);
	}

	@Then("^I see the section - Create Your First Flat Fee$")
	public void checkCreateYourFirstFlatFeeSection() {
		boolean blnResult = tafsAdminGroupPage.checkCreateYourFirstFlatFeeSection();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Create Your First Flat Fee section",
				"User should be able to seeCreate Your First Flat Fee section ",
				"Successfully able to see Create Your First Flat Fee section",
				"Failed to see Create Your First Flat Fee section  : " + commonMethods.strError);
	}

	@Then("^I see the hint message - What are default flat fees\\?$")
	public void hintMessageForWhatAreDefaultFlatFee() {
		boolean blnResult = tafsAdminGroupPage.hintMessageForWhatAreDefaultFlatFee();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of What are default flat fees hint message",
				"User should be able to see What are default flat fees hint message",
				"Successfully able to see What are default flat fees hint message",
				"Failed to see What are default flat fees hint message : " + commonMethods.strError);
	}

	@Then("^I verify font used for message - What are default flat fees\\? is roboto$")
	public void verifyFontOfTheMessageWhatAreDefaultFlatFee() {
		boolean blnResult = tafsAdminGroupPage.robotFontUsedForWhatAreDefaultFlatFeeHint();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the font of text What are default flat fees hint message",
				"User should be able to see font used for What are default flat fees hint message is Roboto",
				"Successfully able to see font used for What are default flat fees hint message is Roboto",
				"Failed to see font used for What are default flat fees hint message is Roboto : "
						+ commonMethods.strError);
	}

	@Then("^I see the hint message - What is my default\\?$")
	public void hintMessageForWhatIsMyDefault() {
		boolean blnResult = tafsAdminGroupPage.hintMessageForWhatIsMyDefaultFlatFee();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of What is my default hint message",
				"User should be able to see What is my default hint message",
				"Successfully able to see What is my default hint message",
				"Failed to see What is my default hint message : " + commonMethods.strError);
	}

	@Then("^I verify font used for message - What is my default\\? is roboto$")
	public void verifyFontOfTheMessageWhatIsMyDefault() {
		boolean blnResult = tafsAdminGroupPage.robotFontUsedForWhatIsMyDefaultHint();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the font of What is my default hint message",
				"User should be able to see font used for What is my default hint message is Roboto",
				"Successfully able to see font used for What is my default hint message is Roboto",
				"Failed to see font used for What is my default hint message is Roboto : " + commonMethods.strError);
	}

	@Then("^I see the hint message - How would I edit a schedule\\?$")
	public void hintMessageForHowWouldiEditaSchedule() {
		boolean blnResult = tafsAdminGroupPage.hintMessageForHowWouldiEditaSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of How would I edit a schedule hint message",
				"User should be able to see How would I edit a schedule hint message",
				"Successfully able to see How would I edit a schedule hint message",
				"Failed to see How would I edit a schedule hint message : " + commonMethods.strError);
	}

	@Then("^I verify font used for message - How would I edit a schedule\\? is roboto$")
	public void verifyFontOfTheMessageHowWouldiEditaSchedulet() {
		boolean blnResult = tafsAdminGroupPage.robotFontUsedForHowWouldiEditaScheduleHint();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the font of How would I edit a schedule hint message",
				"User should be able to see font used for How would I edit a schedule hint message is Roboto",
				"Successfully able to see font used for How would I edit a schedule hint message is Roboto",
				"Failed to see font used for How would I edit a schedule hint message is Roboto : "
						+ commonMethods.strError);
	}

	@When("^I click on Create New Flat Fee$")
	public void clickOnCreateNewFlatFee() {
		boolean blnResult = tafsAdminGroupPage.strCreateNewFlatFeeButtonXpath();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Create New Flat Fee",
				"User should able to click Create New Flat Fee", "Successfully able to click Create New Flat Fee",
				"Failed to click Create New Flat Fee :" + commonMethods.strError);
	}

	@Then("^I should land on Create a Flat Fee Default page$")
	public void landOnCreateFlatFeeDefaultpage() {
		boolean blnResult = tafsAdminGroupPage.landOnCreateFlatFeeDefaultpage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Create a Flat Fee Default page", "User should be able to see Flat Fee Default page",
				"Successfully able to see Create a Flat Fee Default page",
				"Failed to see Create a Flat Fee Default page: " + commonMethods.strError);
	}

	@Then("^I see the hint message - What is the Minimum and Maximum rate for each platform\\?$")
	public void hintMessageForMaximumAndMinimumRateForEachPlatform() {
		boolean blnResult = tafsAdminGroupPage.hintMessageForMaximumAndMinimumRateForEachPlatform();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of What is the Minimum and Maximum hint message",
				"User should be able to see What is the Minimum and Maximum hint message",
				"Successfully able to see What is the Minimum and Maximum hint message",
				"Failed to see What is the Minimum and Maximumhint message: " + commonMethods.strError);
	}

	@Then("^I verify Minimum and Maximum rate for SAM platform in hint message$")
	public void isMinimumAndMaximumRateForSAMplatformPresent() {
		boolean blnResult = tafsAdminGroupPage.minimumAndMaximumRateForSAMplatformPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Minimum and Maximum rate for SAM platform is 0.0 to 2.5% in hint message",
				"User should be able to see Minimum and Maximum rate for SAM platform is 0.0 to 2.5% in hint message",
				"Successfully able to see Minimum and Maximum rate for SAM platform is 0.0 to 2.5% in hint message",
				"Failed to see Minimum and Maximum rate for SAM platform is 0.0 to 2.5% in hint message: "
						+ commonMethods.strError);
	}

	@Then("^I verify Minimum and Maximum rate for SWM platform in hint message$")
	public void isMinimumAndMaximumRateForSWMplatformPresent() {
		boolean blnResult = tafsAdminGroupPage.minimumAndMaximumRateForSWMplatformPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Minimum and Maximum rate for SWM platform is 0.0 to 3.0% in hint message",
				"User should be able to see Minimum and Maximum rate for SWM platform is 0.0 to 3.0% in hint message",
				"Successfully able to see Minimum and Maximum rate for SWM platform is 0.0 to 3.0% in hint message",
				"Failed to see Minimum and Maximum rate for SWM platform is 0.0 to 3.0% in hint message: "
						+ commonMethods.strError);
	}

	@Then("^I verify font used for message - What is the Minimum and Maximum rate for each platform\\? is roboto$")
	public void verifyFontOfTheMessageMinimumAndMaximumRateForEachPlatform() {
		boolean blnResult = tafsAdminGroupPage.robotFontUsedForMaximumAndMinimumRateForEachPlatformHint();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the font of What is the Minimum and Maximum rate for each platform hint message",
				"User should be able to see font used for What is the Minimum and Maximum rate for each platform hint message is Roboto",
				"Successfully able to see font used for What is the Minimum and Maximum rate for each platform hint message is Roboto",
				"Failed to see font used for What is the Minimum and Maximum rate for each platform hint message is Roboto : "
						+ commonMethods.strError);
	}

	@Then("^I verify that SAM platform is selected$")
	public void verifySAMplatformIsSelected() {
		boolean blnResult = tafsAdminGroupPage.verifySAMplatformIsSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of SAM platform selected checkbox",
				"User should be able to see SAM platform selected checkbox",
				"Successfully able to see SAM platform selected checkbox",
				"Failed to seeSAM platform selected checkbox : " + commonMethods.strError);
	}

	@Then("^I verify that SWM platform is selected$")
	public void verifySWMplatformIsSelected() {
		boolean blnResult = tafsAdminGroupPage.verifySWMplatformIsSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of SWM platform selected checkbox",
				"User should be able to see SWM platform selected checkbox",
				"Successfully able to see SWM platform selected checkbox",
				"Failed to see SWM platform selected checkbox : " + commonMethods.strError);
	}

	@Then("^I verify that Cancel button is enabled$")
	public void verifyCancelButtonIsEnabled() {
		boolean blnResult = tafsAdminGroupPage.verifyCancelButtonIsEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of enabled Cancel button", "User should be able to see enabled Cancel button ",
				"Successfully able to see enabled Cancel button",
				"Failed to see enabled Cancel button : " + commonMethods.strError);
	}

	@Then("^I verify that Create Default button is disabled$")
	public void verifyCreateDefaultbuttonIsDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifyCreateDefaultbuttonIsDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of disabled Create Default button",
				"User should be able to see disabled Create Default button",
				"Successfully able to see disabled Create Default button",
				"Failed to see disabled Create Default button : " + commonMethods.strError);
	}

	@When("^I enter valid Rate$")
	public void enterValidRate() {
		boolean blnResult = tafsAdminGroupPage.enterValidRate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter valid rate",
				"User should be able to Enter valid rate", "Successfully able to Enter valid rate",
				"Failed to Enter valid rate : " + commonMethods.strError);
	}

	@Then("^I verify that Create Default button is enabled$")
	public void verifyThatCreateDefaultbuttonIsEnabled() {
		boolean blnResult = tafsAdminGroupPage.verifyThatCreateDefaultbuttonIsEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of enabled Create Default button",
				"User should be able to see enabled Create Default button",
				"Successfully able to see enabled Create Default button", "Failed to see  : " + commonMethods.strError);
	}

	@When("^I click on Create Default$")
	public void clickOnCreateDefault() {
		boolean blnResult = tafsAdminGroupPage.clickOnCreateDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Create Default",
				"User should able to click Create Default", "Successfully able to click Create Default",
				"Failed to click Create Default :" + commonMethods.strError);
	}

	@Then("^I verify that Success message is shown$")
	public void verifySuccessMessageIsShown() {
		boolean blnResult = tafsAdminGroupPage.verifySuccessMessageIsShown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Success message", "User should be able to see Success message",
				"Successfully able to see Success message",
				"Failed to see Success message : " + commonMethods.strError);
	}

	@When("^I click on OK button$")
	public void clickOnOKbutton() {
		boolean blnResult = tafsAdminGroupPage.clickOnOKbutton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "click on OK button",
				"User should able to click OK button", "Successfully able to click OK button",
				"Failed to click OK button :" + commonMethods.strError);
	}

	@When("^I click on OK button in delete SAM confirmation pop up$")
	public void clickOnOKbuttonInDeleteSAMconfirmPopUp() {
		boolean blnResult = tafsAdminGroupPage.clickOnOKbuttonInDeleteSAMandSWMconfirmPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"click on OK button in delete SAM confirmation pop up",
				"User should able to click OK button in delete SAM confirmation pop up",
				"Successfully able to click OK button in delete SAM confirmation pop up",
				"Failed to click OK button in delete SAM confirmation pop up :" + commonMethods.strError);
	}

	@When("^I click on OK button in delete SWM confirmation pop up$")
	public void clickOnOKbuttonInDeleteSWMconfirmPopUp() {
		boolean blnResult = tafsAdminGroupPage.clickOnOKbuttonInDeleteSAMandSWMconfirmPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"click on OK button in delete SWM confirmation pop up",
				"User should able to click OK button in delete SWM confirmation pop up",
				"Successfully able to click OK button in delete SWM confirmation pop up",
				"Failed to click OK button in delete SWM confirmation pop up :" + commonMethods.strError);
	}

	@Then("^I should land on defaults list page$")
	public void shouldLandonDefaultListPage() {
		boolean blnResult = tafsAdminGroupPage.shouldLandonDefaultListPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of defaults list page", "User should be able to see defaults list page",
				"Successfully able to see defaults list page",
				"Failed to see defaults list page : " + commonMethods.strError);
	}

	@Then("^I verify the presence of flat fee default$")
	public void verifythePresenceofFlatfeeDefault() {
		boolean blnResult = tafsAdminGroupPage.verifythePresenceofFlatfeeDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of presence of flat fee default ",
				"User should be able to see presence of flat fee default",
				"Successfully able to see presence of flat fee default",
				"Failed to see presence of flat fee default : " + commonMethods.strError);
	}

	@Then("^I verify the menu items listed besides platform name$")
	public void verifyMenuItemsListedBesidesPlatformName(DataTable menuItems) {
		boolean blnResult = tafsAdminGroupPage.verifyMenuItemsListedBesidesPlatformName(menuItems);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of menu items listed besides platform name",
				"User should be able to see menu items listed besides platform name",
				"Successfully able to see menu items listed besides platform name",
				"Failed to see menu items listed besides platform name : " + commonMethods.strError);
	}

	@When("^I select View/Edit option$")
	public void iselectViewEditoption() {
		boolean blnResult = tafsAdminGroupPage.selectViewEditoption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on View/Edit option",
				"User should able to click View/Edit option", "Successfully able to click View/Edit option",
				"Failed to click View/Edit option :" + commonMethods.strError);
	}

	@Then("^I should land on Edit Flat Fee Default page$")
	public void ishouldLandonSelectViewEditoption() {
		boolean blnResult = tafsAdminGroupPage.ishouldLandonSelectViewEditoption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify Edit Flat Fee Default page landing", "User should be able to see Edit Flat Fee Default page",
				"Successfully able to see Edit Flat Fee Default page",
				"Failed to see Edit Flat Fee Default page : " + commonMethods.strError);
	}

	@Then("^I verify that SAM platform checkbox is disabled$")
	public void verifySAMplatformCheckboxisDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifySAMplatformCheckboxisDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of disabled platform checkbox",
				"User should be able to see disabled platform checkbox",
				"Successfully able to see disabled platform checkbox",
				"Failed to see disabled platform checkbox : " + commonMethods.strError);
	}

	@Then("^I verify that SWM platform checkbox is disabled$")
	public void verifySWMplatformCheckboxisDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifySWMplatformCheckboxisDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of disabled platform checkbox",
				"User should be able to see disabled platform checkbox",
				"Successfully able to see disabled platform checkbox",
				"Failed to see disabled platform checkbox : " + commonMethods.strError);
	}

	@Then("^I verify that Edit Default button is disabled$")
	public void verifyEditDefaultButtonisDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifyEditDefaultButtonisDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of disabled Edit Default button",
				"User should be able to see disabled Edit Default button",
				"Successfully able to see disabled Edit Default button",
				"Failed to see disabled Edit Default button : " + commonMethods.strError);
	}

	@When("^I edit rate to some other valid value$")
	public void ieditratetosomeothervalidvalue() {
		boolean blnResult = tafsAdminGroupPage.editRateToSomeOtherValidValue();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Edit rate value",
				"User should be able to Edit rate value", "Successfully able to Edit rate value",
				"Failed to Edit rate value : " + commonMethods.strError);
	}

	@Then("^I verify that Edit Default button is enabled$")
	public void verifyEditDefaultButtonisEnabled() {
		boolean blnResult = tafsAdminGroupPage.verifyEditDefaultButtonisEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of enabled Edit Default button",
				"User should be able to see enabled Edit Default button",
				"Successfully able to see enabled Edit Default button",
				"Failed to see enabled Edit Default button : " + commonMethods.strError);
	}

	@When("^I click on Edit Default$")
	public void clickOnEditDefault() {
		boolean blnResult = tafsAdminGroupPage.clickOnEditDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Edit Default",
				"User should able to click Edit Default", "Successfully able to click Edit Default",
				"Failed to click Edit Default :" + commonMethods.strError);
	}

	@When("^I select Delete option$")
	public void selectDeleteOption() {
		boolean blnResult = tafsAdminGroupPage.selectDeleteOption();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete option",
				"User should able to click Delete option", "Successfully able to click Delete option",
				"Failed to click Delete option :" + commonMethods.strError);
	}

	@Then("^I see a confirmation popup$")
	public void verifyConfirmationPopup() {
		boolean blnResult = tafsAdminGroupPage.verifyConfirmationPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of confirmation popup", "User should be able to see confirmation popup",
				"Successfully able to see confirmation popup",
				"Failed to see confirmation popup : " + commonMethods.strError);
	}

	@When("^I click on Create New button under Tiered Schedules$")
	public void clickOnCreateNewButtonUnderTieredSchedules() {
		boolean blnResult = tafsAdminGroupPage.clickOnCreateNewButtonUnderTieredSchedules();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Create New button",
				"User should able to click Create New button", "Successfully able to click Create New button",
				"Failed to click Create New button :" + commonMethods.strError);
	}

	@Then("^I land on Create New Schedule page$")
	public void landOnCreateNewSchedulePage() {
		boolean blnResult = tafsAdminGroupPage.landOnCreateNewSchedulePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Create New Schedule page",
				"User should be able to see Create New Schedule page",
				"Successfully able to see Create New Schedule page",
				"Failed to see Create New Schedule page: " + commonMethods.strError);
	}

	@Then("^I verify that the Save button is disabled$")
	public void verifyThatSaveButtonIsDisabled() {
		boolean blnResult = tafsAdminGroupPage.verifyThatSaveButtonIsDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Save button",
				"User should be able to Save button is disabled", "Successfully able to see Save button is disabled",
				"Failed to see Save button is disabled : " + commonMethods.strError);
	}

	@When("^I enter Schedule Name$")
	public void ienterScheduleName() {
		boolean blnResult = tafsAdminGroupPage.ienterScheduleName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Schedule Name",
				"User should be able to Enter Schedule Name", "Successfully able to Enter Schedule Name",
				"Failed to Enter Schedule Name : " + commonMethods.strError);
	}

	@When("^I enter Maximum Investment for first tier$")
	public void enterMaximumInvestmentForFirstTier() {
		boolean blnResult = tafsAdminGroupPage.enterMaximumInvestmentForFirstTier();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Maximum Investment for first tier",
				"User should be able to Enter Maximum Investment for first tier",
				"Successfully able to Enter Maximum Investment for first tier",
				"Failed to Enter Maximum Investment for first tier : " + commonMethods.strError);
	}

	@When("^I enter Fee Percentage for first tier$")
	public void enterFeePercentageForFirstTier() {
		boolean blnResult = tafsAdminGroupPage.enterFeePercentageForFirstTier();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Fee Percentage for first tier",
				"User should be able to Enter Fee Percentage for first tier",
				"Successfully able to Enter Fee Percentage for first tier",
				"Failed to Enter Fee Percentage for first tier : " + commonMethods.strError);
	}

	@When("^I click on Add Tier link$")
	public void clickOnAddTierLink() {
		boolean blnResult = tafsAdminGroupPage.clickOnAddTierLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Add Tier link",
				"User should able to click Add Tier link", "Successfully able to click Add Tier link",
				"Failed to click Add Tier link :" + commonMethods.strError);
	}

	@When("^I enter Maximum Investment for second tier$")
	public void ienterMaximumInvestmentforSecondTier() {
		boolean blnResult = tafsAdminGroupPage.ienterMaximumInvestmentforSecondTier();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Maximum Investment for second tier",
				"User should be able to Enter Maximum Investment for second tier",
				"Successfully able to Enter Maximum Investment for second tier",
				"Failed to Enter Maximum Investment for second tier : " + commonMethods.strError);
	}

	@When("^I enter Fee Percentage for second tier$")
	public void enterFeePercentageForSecondTier() {
		boolean blnResult = tafsAdminGroupPage.enterFeePercentageForSecondTier();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Fee Percentage for second tier",
				"User should be able to Enter Fee Percentage for second tier",
				"Successfully able to Enter Fee Percentage for second tier",
				"Failed to Enter Fee Percentage for second tier : " + commonMethods.strError);
	}

	@When("^I enter Fee Percentage for third tier$")
	public void enterFeePercentageForThirdTier() {
		boolean blnResult = tafsAdminGroupPage.enterFeePercentageForThirdTier();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Fee Percentage for third tier",
				"User should be able to Enter Fee Percentage for third tier",
				"Successfully able to Enter Fee Percentage for third tier",
				"Failed to Enter Fee Percentage for third tier : " + commonMethods.strError);
	}

	@Then("^I verify that the Save button is enabled$")
	public void verifyTheSaveButtonIsEnabled() {
		boolean blnResult = tafsAdminGroupPage.verifyTheSaveButtonIsEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Save button status",
				"User should be able to see Save button is enabled", "Successfully able to see Save button is enabled",
				"Failed to see Save button is enabled : " + commonMethods.strError);
	}

	@When("^I click on Save button$")
	public void clickOnSaveButton() {
		boolean blnResult = tafsAdminGroupPage.clickOnSaveButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Save button",
				"User should able to click Save button", "Successfully able to click Save button",
				"Failed to click Save button :" + commonMethods.strError);
	}

	@Then("^I get a success popup to save Tiered Schedules$")
	public void getConfirmationPopupToSaveTieredSchedules() {
		boolean blnResult = tafsAdminGroupPage.getSuccessPopupToSaveTieredSchedules();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the confirmation popup to save Tiered Schedules",
				"User should be able to see confirmation popup to save Tiered Schedules",
				"Successfully able to see confirmation popup to save Tiered Schedules",
				"Failed to see confirmation popup to save Tiered Schedules : " + commonMethods.strError);
	}

	@When("^I click on OK button in Tiered Schedules success popup$")
	public void clickOnOkButtonInTieredSchedulesSuccessPopup() {
		boolean blnResult = tafsAdminGroupPage.clickOnOkButtonInTieredSchedulesSuccessPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on OK button in Tiered Schedules confirmation popup",
				"User should able to click OK button in Tiered Schedules confirmation popup",
				"Successfully able to clickOK button in Tiered Schedules confirmation popup",
				"Failed to click OK button in Tiered Schedules confirmation popup :" + commonMethods.strError);
	}

	@When("^I click on OK button in Tiered manage Schedules success popup$")
	public void clickOnOkButtonInTieredManageSchedulesSuccessPopup() {
		boolean blnResult = tafsAdminGroupPage.clickOnOkButtonInTieredManageSchedulesSuccessPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on OK button in Tiered manage Schedules confirmation popup",
				"User should able to click OK button in Tiered manage Schedules confirmation popup",
				"Successfully able to clickOK button in Tiered manage Schedules confirmation popup",
				"Failed to click OK button in Tiered manage Schedules confirmation popup :" + commonMethods.strError);
	}

	@When("^I click on OK button in Tiered Schedules delete confirmation popup$")
	public void clickOnOkButtonInTieredSchedulesDeleteConfirmationPopup() {
		boolean blnResult = tafsAdminGroupPage.clickOnOkButtonInTieredSchedulesDeleteConfirmationPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on ", "User should able to click ",
				"Successfully able to click ", "Failed to click  :" + commonMethods.strError);
	}

	@When("^I verify the presence of new schedule$")
	public void verifyThePresenceOfNewSchedule() {
		boolean blnResult = tafsAdminGroupPage.verifyThePresenceOfNewSchedule();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the presence of newly added schedule", "User should be able to see newly added schedule",
				"Successfully able to see newly added schedule",
				"Failed to see newly added schedule : " + commonMethods.strError);
	}

	@When("^I verify Open menu item listed besides schedule name$")
	public void verifyOpenMenuItemListedBesidesScheduleName() {
		boolean blnResult = tafsAdminGroupPage.verifyOpenMenuItemListedBesidesScheduleName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the verify Open menu item listed besides schedule name",
				"User should be able to see Open menu item listed besides schedule name",
				"Successfully able to see Open menu item listed besides schedule name",
				"Failed to see Open menu item listed besides schedule name : " + commonMethods.strError);
	}

	@When("^I click on Schedule Menu Items hamburger link for New Tiered Schedule$")
	public void clickNewScheduleMenu() {
		boolean blnResult = tafsAdminGroupPage.clickNewScheduleMenu();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to click on Schedule Menu Items hamburger link for Tiered Schedule ",
				"User should be able to click on Schedule Menu Items hamburger link for Tiered Schedule",
				"User able to click on Schedule Menu Items hamburger link for Tiered Schedule",
				"User not able to click on Schedule Menu Items hamburger link for Tiered Schedule:  "
						+ commonMethods.strError);
	}

	@When("^I verify the menu items listed besides schedule name$")
	public void verifyMenuItemsListedBesidesScheduleName(DataTable menuItems) {
		boolean blnResult = tafsAdminGroupPage.verifyMenuItemsListedBesidesScheduleName(menuItems);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of menu items listed besides schedule name",
				"User should be able to see menu items listed besides schedule name",
				"Successfully able to see menu items listed besides schedule name",
				"Failed to see menu items listed besides schedule name : " + commonMethods.strError);
	}

	@When("^I select option - Select or Manage Platform Default$")
	public void selectOptionSelectOrManagePlatformDefault() {
		boolean blnResult = tafsAdminGroupPage.selectOptionSelectOrManagePlatformDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Select or Manage Platform Default option",
				"User should able to click on Select or Manage Platform Default option",
				"Successfully able to click on Select or Manage Platform Default option",
				"Failed to click on Select or Manage Platform Default option :" + commonMethods.strError);
	}

	@Then("^I should land on page - Select or Manage Platform Default$")
	public void selectOrManagePlatformDefaultPageNavigation() {
		boolean blnResult = tafsAdminGroupPage.selectOrManagePlatformDefaultPageNavigation();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Select or Manage Platform Default page",
				"User should be able to land on Select or Manage Platform Default page",
				"Successfully able to land on Select or Manage Platform Default page",
				"Failed to see land on Select or Manage Platform Default page: " + commonMethods.strError);
	}

	@Then("^I verify that SAM platform is available$")
	public void verifyThatSAMplatformIsAvailable() {
		boolean blnResult = tafsAdminGroupPage.verifyThatSAMplatformIsAvailable();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of SAM platform is available",
				"User should be able to see SAM platform is available",
				"Successfully able to see SAM platform is available",
				"Failed to see SAM platform availablity : " + commonMethods.strError);
	}

	@Then("^I see the hint message - Setting Your Default Schedules$")
	public void hintMessageSettingYourDefaultSchedulesDisplayed() {
		boolean blnResult = tafsAdminGroupPage.hintMessageSettingYourDefaultSchedulesDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Setting Your Default Schedules hint message",
				"User should be able to see Setting Your Default Schedules hint message",
				"Successfully able to see Setting Your Default Schedules hint message",
				"Failed to see Setting Your Default Schedules hint message : " + commonMethods.strError);
	}

	@Then("^I verify font used for message - Setting Your Default Schedules is roboto$")
	public void verifyFontOfTheMessageSettingYourDefaultSchedules() {
		boolean blnResult = tafsAdminGroupPage.robotFontUsedForSettingYourDefaultSchedulesHint();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the font of Setting Your Default Schedules hint message",
				"User should be able to see font used for Setting Your Default Schedules hint message is Roboto",
				"Successfully able to see font used for Setting Your Default Schedules hint message is Roboto",
				"Failed to see font used for Setting Your Default Schedules hint message is Roboto : "
						+ commonMethods.strError);
	}

	@When("^I select SAM checkbox$")
	public void selectSAMcheckbox() {
		boolean blnResult = tafsAdminGroupPage.selectSAMcheckbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select SAM checkbox",
				"User should able to select SAM checkbox", "Successfully able to select SAM checkbox",
				"Failed to select SAM checkbox  :" + commonMethods.strError);
	}

	@When("^I click on Save Defaults$")
	public void clickonSaveDefaults() {
		boolean blnResult = tafsAdminGroupPage.clickonSaveDefaults();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Save Defaults",
				"User should able to click Save Defaults", "Successfully able to click Save Defaults",
				"Failed to click Save Defaults :" + commonMethods.strError);
	}

	@Then("^I get a confirmation popup$")
	public void getConfirmationPopup() {
		boolean blnResult = tafsAdminGroupPage.getConfirmationPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of confirmation popup", "User should be able to see confirmation popup",
				"Successfully able to see confirmation popup",
				"Failed to see confirmation popup : " + commonMethods.strError);
	}

	@Then("^I get a success popup on manage schedule page$")
	public void getConfirmationPopupOnManageSchedulePage() {
		boolean blnResult = tafsAdminGroupPage.getSuccessPopupOnManageSchedulePage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of confirmation popup on manage schedule page",
				"User should be able to see confirmation popup on manage schedule page",
				"Successfully able to see confirmation popup on manage schedule page",
				"Failed to see confirmation popup on manage schedule page : " + commonMethods.strError);
	}

	@When("^I verify that new schedule is tagged as Default for SAM platform$")
	public void verifyThatNewScheduleIsTaggedAsDefaultForSAMplatform() {
		boolean blnResult = tafsAdminGroupPage.verifyThatNewScheduleIsTaggedAsDefaultForSAMplatform();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify that new schedule is tagged as Default for SAM platform",
				"User should be able to see new schedule is tagged as Default for SAM platform",
				"Successfully able to see new schedule is tagged as Default for SAM platform",
				"Failed to see new schedule is tagged as Default for SAM platform : " + commonMethods.strError);
	}

	@And("^I verify that new schedule is tagged as Default for SWM platform$")
	public void iVerifyThatNewScheduleIsTaggedAsDefaultForSWMPlatform() {
		boolean blnResult = tafsAdminGroupPage.verifyThatNewScheduleIsTaggedAsDefaultForSWMplatform();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify that new schedule is tagged as Default for SWM platform",
				"User should be able to see new schedule is tagged as Default for SWM platform",
				"Successfully able to see new schedule is tagged as Default for SWM platform",
				"Failed to see new schedule is tagged as Default for SWM platform : " + commonMethods.strError);
	}

	@When("^I select Delete option from listed menu item$")
	public void selectDeleteOptionFromListedMenuItem() {
		boolean blnResult = tafsAdminGroupPage.selectDeleteOptionFromListedMenuItem();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select Delete option from listed menu item",
				"User should able to Select Delete option from listed menu item",
				"Successfully able to Select Delete option from listed menu item",
				"Failed to Select Delete option from listed menu item :" + commonMethods.strError);
	}

	@Then("^I get a delete confirmation popup$")
	public void getDeleteConfirmationPopup() {
		boolean blnResult = tafsAdminGroupPage.getDeleteConfirmationPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of delete confirmation popup",
				"User should be able to see delete confirmation popup",
				"Successfully able to see delete confirmation popup",
				"Failed to see delete confirmation popup : " + commonMethods.strError);
	}

	@When("^I click on OK button for delete schedule popup$")
	public void clickOkOnDeleteConfirmationPopup() {
		boolean blnResult = tafsAdminGroupPage.clickOkOnDeleteConfirmationPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of delete confirmation popup",
				"User should be able to see delete confirmation popup",
				"Successfully able to see delete confirmation popup",
				"Failed to see delete confirmation popup : " + commonMethods.strError);
	}

	@When("^I verify that the new schedule is now deleted from list$")
	public void verifyTheNewScheduleDeletedFromlist() {
		boolean blnResult = tafsAdminGroupPage.verifyTheNewScheduleDeletedFromlist();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify the new schedule deleted from the list",
				"User should be able to see new schedule is deleted from list",
				"Successfully able to see new schedule is deleted from list",
				"Failed to see new schedule is deleted from list : " + commonMethods.strError);
	}

	@Then("^I verify that SWM platform is available$")
	public void verifyThatSWMplatformIsAvailable() {
		boolean blnResult = tafsAdminGroupPage.verifyThatSWMplatformIsAvailable();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availablity of SWM platform",
				"User should be able to see SWM platform", "Successfully able to see SWM platform",
				"Failed to see SWM platform : " + commonMethods.strError);
	}

	@When("^I select SWM checkbox$")
	public void selectSWMcheckbox() {
		boolean blnResult = tafsAdminGroupPage.selectSWMcheckbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select SWM checkbox",
				"User should able to Select SWM checkbox", "Successfully able to Select SWM checkbox",
				"Failed to Select SWM checkbox :" + commonMethods.strError);
	}

	@Then("^I verify Create New Flat button enabled$")
	public void verifyCreateNewFlatFeeButtonEnabled() {
		boolean blnResult = tafsAdminGroupPage.verifyCreateNewFlatFeeButtonEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify Create New Flat Fee Button Enabled",
				"User should able to see Create New Flat Fee Button enabled ",
				"Successfully able to see Create New Flat Fee Button enabled",
				"Failed to see Create New Flat Fee Button enabled :" + commonMethods.strError);
	}

	@Then("^I see the section Schedules for Master Rep$")
	public void verifyScheduleSectionPresent() {
		boolean blnResult = tafsAdminGroupPage.verifyScheduleSectionPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "verify schedule section presence",
				"User should able to see schedule section ", "Successfully able to see schedule section",
				"Failed to see schedule section  :" + commonMethods.strError);
	}

	@Then("^I verify Create New button enabled$")
	public void verifyCreateNsewEnabled() {
		boolean blnResult = tafsAdminGroupPage.verifyCreateNewButtonEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "verify Create New Button Enabled",
				"User should able to see CreateNewButton enabled ", "Successfully able to see CreateNewButton enabled",
				"Failed to see CreateNewButton enabled :" + commonMethods.strError);
	}

	@Then("^I see the section Create Your First Tiered Schedule$")
	public void verifyCreateYourFirstScheduleSection() {
		boolean blnResult = tafsAdminGroupPage.verifyCreateYourFirstScheduleSection();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify the section Create Your First Tiered Schedule displayed ",
				"User should able to see CreateNewButton enabled section Create Your First Tiered Schedule",
				"Successfully able to see Csection Create Your First Tiered Schedule",
				"Failed to see section Create Your First Tiered Schedule :" + commonMethods.strError);
	}

	@Then("^I verify Create New button disabled in flat section$")
	public void verifyCreateNewDisabledInFlatSecation() {
		boolean blnResult = tafsAdminGroupPage.verifyCreateNewDisabledInFlatSection();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify Create New Button Disabled in flat section",
				"User should able to see Create New Button disabled in flat section",
				"Successfully able to see Create New button disabled",
				"Failed to see Create New Button disabled :" + commonMethods.strError);
	}

	@Then("^I see the section - Flat Fee Defaults For Master Rep$")
	public void verifyFlatFeeDefaultSectionPresent() {
		boolean blnResult = tafsAdminGroupPage.verifyFlatFeeDefaultSectionPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify the section - Flat Fee Defaults For Master Rep present",
				"User should able to see the section - Flat Fee Defaults For Master Rep",
				"Successfully able to see the section - Flat Fee Defaults For Master Rep",
				"Failed to see the section - Flat Fee Defaults For Master Rep :" + commonMethods.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}