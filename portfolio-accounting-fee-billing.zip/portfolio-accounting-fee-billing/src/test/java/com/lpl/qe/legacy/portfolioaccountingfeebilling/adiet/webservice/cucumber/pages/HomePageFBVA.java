package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> FBVADashboard.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for FBVADashboard</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author nauahmed
 * @since 12-14-2020
 *        </p>
 */
public class HomePageFBVA extends Common implements ILocatorInitialize {
	static final int PAGE_IDENTIFIER = 1075;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String ADIET_HOME_PAGE_HEADER = "ADIET Home Page Header";
	public static final String OPTIONS = "options";
	public static final String FAILED_TO_SEE = "Failed to see";
	public static final String MODEL_LIST_LABEL = "FBVA GRID";
	static String strADIETHomePageXpath;
	static String strFBVAFileStatusXpath;
	static String strFlesGridXpath;

	public HomePageFBVA(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author nauahmed
	 * @since 12-14-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strADIETHomePageXpath, LPLCoreConstents.getInstance().LOWEST,
				ADIET_HOME_PAGE_HEADER);
	}

	/**
	 * This method is used to check the page elements of grid
	 * 
	 * @return boolean
	 *
	 * @author nauahmed
	 * @since 12-14-2020
	 */
	public boolean checkIfElementExistUsingPlaceholderText(String strPlaceholderTextXpath, String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strPlaceholderTextXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to check the status of grid
	 * 
	 * @return boolean
	 *
	 * @author nauahmed
	 * @since 12-14-2020
	 */
	public boolean verifFBVAFileStausgrid() {
		return isElementPresentUsingXpath(strFBVAFileStatusXpath, LPLCoreConstents.getInstance().LOWEST,
				MODEL_LIST_LABEL);
	}

	/**
	 * This method is used to check headers of the grid
	 * 
	 * @return boolean
	 *
	 * @author nauahmed
	 * @since 12-14-2020
	 */
	public boolean iverifyFBVAFileStatusGridHeader(DataTable header) {
		return verifyFields(strFlesGridXpath, header);
	}

	/**
	 * This method is used to check the fields of the grid
	 * 
	 * @return boolean
	 *
	 * @author nauahmed
	 * @since 12-14-2020
	 */
	private boolean verifyFields(String placeHolderLocator, DataTable searchFieldsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFieldsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingPlaceholderText(placeHolderLocator, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}
}