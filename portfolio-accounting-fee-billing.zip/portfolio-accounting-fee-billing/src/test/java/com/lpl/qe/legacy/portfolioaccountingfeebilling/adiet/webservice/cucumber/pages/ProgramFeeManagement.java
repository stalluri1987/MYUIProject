package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> ProgramFeeManagement.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for ProgramFeeManagement</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class ProgramFeeManagement extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 819;
	Map<String, HashMap<String, String>> pageObjectMap;
	FileProcessingStatus homepage;
	List<String> browserActiveTabs;

	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String SUCCESSFULLY_ABLE_TO_SEE = "Successfully be able to see ";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String PROGRAM_FEE_MANAGEMENT_HEADER = "Program Fee Management Page Header";
	public static final String REP_AUM = "REP AUM";
	public static final String LPL_SWS = "LPL SWS";
	public static final String FEE_COMPONENT_DROPDOWN = "Fee Component Dropdown";
	public static final String MMC_LINK = "MMC Link";
	public static final String NEXT_BUTTON = "Next Button";
	public static final String NEXT_BUTTON_DISABLED = "Next Button Disabled";
	public static final String NEXT_BUTTON_ENABLED = "Next Button Enabled";
	public static final String REP_AUM_MANAGE_SCHEDULE_HEADER = "REP AUM - Manage Schedule Header";
	public static final String MANAGE_SCHEDULE_TAB = "Manage Schedule Tab";
	public static final String SEARCH_BUTTON = "Search Button";
	public static final String RESET_BUTTON = "Reset Button";
	public static final String ADMIN_FEE = "Admin Fee";
	public static final String SWS_SERVICE_FEE = "SWS Service Fee";
	public static final String LPL_SWS_MANAGE_SCHEDULE_HEADER = "LPL SWS - Manage Schedule Header";
	public static final String HOME_BUTTON = "Home Button";
	public static final String SELECT_PLATFORM_DROPDOWN = "Select Platform";
	public static final String MS = "MS";
	public static final String MWP = "MWP";
	public static final String SAM = "SAM";
	public static final String ALL = "All";
	public static final String EMPTY_STRING = "";
	public static final String PREMIUM_MS_STANDARD_LINK = "Premium MS Standard";
	public static final String PREMIUM_MWP_STANDARD_LINK = "Premium MWP Standard";
	public static final String PREMIUM_SAM2_STANDARD_LINK = "Premium SAM2 Standard";
	public static final String SELECT_SCHEDULE_DROPDOWN = "Select Schedule Type";
	public static final String OPTION = " option";
	public static final String CUSTOM = "Custom";
	public static final String ONBOARDING = "Onboarding";
	public static final String MISCELLANEOUS = "Miscellaneous";
	public static final String CREATE_NEW_SCHEDULE_BUTTON = "Create New Schedule";
	public static final String NEW_SCHEDULE_WINDOWN = "New Schedule";
	public static final String PLATFORM_DROPDOWN = "SELECT PLATFORM";
	public static final String FEE_PERCENTAGE = "FEE PERCENTAGE TextBox";
	public static final String ADD_TIER_BUTTON = "Add Tier";
	public static final String SAVE_BUTTON = "Save";
	public static final String REP_ASSIGNMENT_TRAKING = "Rep Assignment Tracking Tab";
	public static final String MINIMUM_AUM = "Minimum AUM";
	public static final String DELETE_ACTION_BUTTON = "Delete";
	public static final String DELETE = "Delete";
	public static final String SELECT_SCHEDULE = "Select Schedule";
	public static final String ERROR_MESSAGE_ALERT = "Error Message Alert";
	public static final String CREATE_NEW_ASSIGNMENT_BUTTON = "Create New Assignment Button";
	public static final String NEW_ASSIGNMENT_WINDOW = "New Assignment Window";
	public static final String SEARCH_REP = "Search REP";
	public static final String SUBMIT_BUTTON = "Submit Button";
	public static final String SCHEDULE_NAME_DROPDOWN = "Schedule Name Dropdown";
	public static final String CANCEL_BUTTON = "Cancel Button";
	public static final String REP_AUM_STANDARD_LINK = "Rep AUM Standard Link";
	public static final String MINIMUMAUM_TIER1_DISABLED = "Minimum AUM Tier1 disabled";
	public static final String SWITCH_TO_STANDARD_SCHEDULE = "Switch to Active Standard";
	public static final String REP_NAME_TEXTBOX = "Rep Name TextBox";
	public static final String PRICING_MODEL_DROPDOWN = "Pricing Model DropDown";
	public static final String EXPORT_BUTTON = "Export Button";
	public static final String EXPORT_DROPDOWN = "Export Dropdown";
	public static final String ADMIN_FEE_SUMMARY_REPORT = "Admin Fee Summary Report";
	public static final String ASSIGNMENT_STATUS_DROPDOWN = "Assignment Status Dropdown";
	private static final String SCHEDULE_NAME_TEXTBOX = "SCHEDULE NAME TextBox";
	public static final String REPORT_BUTTON = "Report Button";
	public static final String VIEW_REPORT_DROPDOWN = "View Report Drop down";
	public static final String EXPORT_BUTTON_DISABLE = "Export Button Disable";
	public static final String EXPORT_BUTTON_ENABLE = "Export Button Enable";
	public static final String SCHEDULE_TYPE_DROPDOWN = "Schedule Type Drop down";
	public static final String SCHEDULE_TYPE = "Schedule Type";
	public static final String OPTIONS = "options";
	public static final String REP_ASSIGNMENT_REPORT = "REP Assignment Report";
	public static final String REP_ASSIGNMENT_REPORT_NAME = "Rep AssignmentReport";
	public static final String ADMIN_FEE_SCHEDULE_REPORTS = "Admin Fee Schedule Report";
	public static final String ADMIN_FEE_SCHEDULE_REPORTS_NAME = "AdminFeeScheduleReports";
	public static final String REP_AUM_ADMIN_FEE_REPORT = "REP AUM/Admin Fee Report";
	public static final String ADMIN_FEE_REPORT_NAME = "Rep AUMAdminFeeReport";
	public static final String BULK_UPLOAD_REPORT = "Bulk Upload Report";
	public static final String BULK_UPLOAD_REPORT_NAME = "BulkUploadReport";
	public static final String REP_AUM_REPORT_BY_PROGRAM_NAME = "Rep AUMByProgramReportDownload";
	public static final String EXPORT_BUTTON_UNDER_SCHEDULE_MANAGEMENT_TAB = "Export Button under schedule Management Tab";
	public static final String SCHEDULE_LIST_REPORT_EXPORTED = "ScheduleList";
	public static final String TRADE_ADMIN_FEE = "Trade Admin Fee";
	public static final String REP_AUM_TRADE_ADMIN_FEE_MANAGE_SCHEDULE_HEADER = "REP AUM - Trade Admin Fee : Manage Schedule";
	public static final String MASTER_ACCOUNT_MODEL_REPORT = "Master Account List for Models";
	public static final String HISTORICAL_BILLING_DETAILS_REPORT = "Historical Billing Details Report";
	public static final String ONBOARDING_PERIOD_TERMINATION_WARNINGS_REPORT = "Onboarding Period Termination Warnings";
	public static final String FLAT = "Flat";
	public static final String ENABLED_TEXT = "enabled";
	public static final String DISABLED_TEXT = "disabled";
	public static final String PROGRESSIVE_TIERED = "Progressive Tiered";
	public static final String TIERED = "Tiered";
	public static final String PROGRESSIVE_TIERED_LABEL_DISPLAYED = "Progressive Tier Structure:";
	public static final String FIRM_ASSIGNMENT_REPORT = "Firm Assignment Report";
	public static final String FIRM_ASSIGNMENT_REPORT_NAME = "Firm AssignmentReport";
	public static final String RPRT_ARROW_OPNHST = "Report Arrow Open Hist";
	public static final String PERIOD_END_DATE_OPNHST = "Period End Date Open Hist";
	public static final String SWS_FEE_TYPE_HDR = "SWS Fee Type Header";
	public static final String GNRT_RPRT_BTTN_OPNHST = "Generate Report Button";
	public static final String PERIOD_BEGIN_DATE_OPNHST = "Period Begin Date Field";
	public static final String PERIOD_BEGIN_DATE_CHKBX_OPNHST = "Period Begin Datecheck Box";
	public static final String STANDARD_FEE_SCHEDULE_TRADE_FEE_LINK = "Standard Flat Feeschedule - Trade Fee";
	public static final String STANDARD_FEE_SCHEDULE_TRADE_FEE_FLAT_FEE = "Standard Flat Feeschedule - Trade Fee - Flat Fee";
	public static final String REP_AUM_STANDARD_TIER_STRUCTURE = "Rep AUM Standard - Tier Structure";
	public static final String SWS_MS_STANDARD_TIER_STRUCTURE = "SWS MS Standard - Tier Structure";
	public static final String SWS_MWP_STANDARD_TIER_STRUCTURE = "SWS MWP Standard - Tier Structure";
	public static final String SWS_SAM2_STANDARD_TIER_STRUCTURE = "SWS SAM2 Standard - Tier Structure";
	public static final String SEARCH_FIRM = "Search Firm";
	public static final String START_DATE_ICON = "Start Date icon";
	public static final String END_DATE_ICON = "End Date icon";
	public static final String START_DATE = "Start Date";
	public static final String END_DATE = "End Date";
	public static final String AUTOMATION_TEST = "Automation Test";
	public static final String ENTER_NOTES = "Enter Notes";
	public static final String ASSIGNMENT_CREATED_SUCCESSFULLY = "Assignment Created Sucessfully";
	public static final String NEWLY_ADDED_ASSIGNMENT_RECORD = "Newly added assignment record";
	public static final String CANCEL_ASSIGNMENT_DROPDOWN = "Cancel Assignment Dropdown";
	public static final String CANCEL_ASSIGNMENT = "Cancel Assignment";
	public static final String ASSIGNMENT_CANCELLED_SUCCESSFULLY = "Assignment Cancelled Sucessfully";
	public static final String STANDARD = "STANDARD";
	public static final String CUSTOM_ASSIGNMENTS = "Custom Assignments";
	public static final String SELECT_CUSTOM_ASSIGNMENT = "Select Custom Assignment";
	public static final String SCHEDULE_TYPE_IN_TABLE = "Schedule Type in grid";
	public static final String STANDARD_ASSIGNMENTS = "Standard Assignments";
	public static final String SELECT_STANDARD_ASSIGNMENT = "Select Standard Assignment";
	public static final String SELECT_FIRST_STANDARD_ASSIGNMENT = "Select First Standard Assignment";
	public static final String ACTION_DROPDOWN = "Action Dropdown";
	public static final String CANCEL_ASSIGNMENT_READ_ONLY = "Cancel Assignment read only";
	public static final String STRING_EMPTY = "";
	public static final String OK_BUTTON = "Ok Button";
	public static final String YES_BUTTON = "Yes Button";
	public static final String STANDARD_FLAT_FEE_SCHEDULE_ADMIN_FEE = "Standard Flat Feeschedule - Admin Fee";
	public static final String ENABLE = "enable";
	public static final String DISABLE = "disable";
	public static final String PROGRESSIVE_TIER_STRUCTURE = "Progressive Tier Structure";
	public static final String CLONE_ICON = "Clone";
	public static final String NEW_SCHEDULE_CLONED_FROM_MS_STANDARD_NEW = "New Schedule (cloned From SWS MS Standard New)";
	public static final String SCHEDULE_NAME_HEPERLINK = "Schedule Name Heperlink";
	public static final String CLOSE_ICON = "Close Icon";
	public static final String EDIT_ICON = "Edit Icon";
	public static final String FEE_PERCENTAGE_VALUE = "Fee Rate value";
	public static final String MAN = "MAN";
	public static final String MAS = "MAS";
	public static final String SWM = "SWM";
	public static final String ENTITY_TYPE_DROPDOWN = "Entity Type Dropdown";
	public static final String SCHEDULE_MANAGEMENT = "Schedule management";
	public static final String REP_ASSIGNMENT = "Rep Assignment";
	public static final String AUM_BY_PROGRAM = "AUM by Program Report";
	public static final String SWS_HYBRID_MANAGER_ACCESS_NETWORK_STANDARD_20BPS = "SWS Hybrid Manager Access Network Standard 20bps";
	public static final String SWS_HYBRID_MANAGER_ACCESS_SELECT_STANDARD_20BPS = "SWS Hybrid Manager Access Select Standard 20bps";
	public static final String SWS_HYBRID_SWMII_STANDARD_15BPS = "SWS Hybrid SWM II Standard 15bps";
	public static final String SWS_FEE_SCHEDULE_REPORT = "SWS Fee Schedule Report";
	public static final String SCHEDULE_ASSIGNMENT_LIST = "Schedule Assignment list";
	public static final String EXISTING_SCHEDULE_ASSIGNMENT_LIST = "Existing Schedule Assignment List";
	public static final String INACTIVE_STATUS = "Inactive";
	public static final String ASSIGNMENT_STATUS = "Assignment Status";
	public static final String MODIFY_ASSIGNMENT_OPTION_DISABLED = "Modify Assignment Option Disabled";
	public static final String SELECTALL_CHECKBOX = "Select All Checkbox";
	public static final String RIA_CUSTODY_PLATFORM = "RIA CUSTODY PLATFORM";
	public static final String RIA_CUSTODY_PLATFORM_FEE = "RIA Custody Platform Fee";
	public static final String RIA_CUSTODY_PLATFORM_MANAGE_SCHEDULE_HEADER = "RIA CUSTODY PLATFORM - RIA Custody Platform Fee : Manage Schedule";
	public static final String IFAHYB_SWM_STANDARD_LINK = "IFA/Hybrid SWMII Standard 5bps schedule";
	public static final String IFA_HYBRID_RIA_ENTITY_TYPE = "IFA/Hybrid RIA";
	String strProgramFeeManagementHeaderXpath;
	String strProgramTypeDropDownXpath;
	String strFeeComponentDropDownXpath;
	String strNextButtonWithDisableXpath;
	String strMMCLinkXpath;
	String strProgramTypeOptionsXpath;
	String strFeeComponentOptionsXpath;
	String strNextButtonXpath;
	String strExportButtonXpath;
	String strREPAUMManageScheduleHeaderXpath;
	String strManageScheduleTabActiveXpath;
	String strRepAssignmentTrackingTabXpath;
	String strSwitchtoActiveStandardAssignmentslinkXpath;
	String strSearchButtonXpath;
	String strResetButtonXpath;
	String strAllTableHeadersXpath;
	String strLPLSWSManageScheduleHeaderXpath;
	String strHomeButtonXpath;
	String strSelectPlatformOptionsXpath;
	String strSelectPlatformDropdownXpath;
	String strStandardScheduleHeaderXpath;
	String strStandardScheduledataXpath;
	String strMSStandardScheduleLinkXpath;
	String strMWPStandardScheduleLinkXpath;
	String strSAM2StandardScheduleLinkXpath;
	String strSelectScheduleOptionsXpath;
	String strSelectScheduleDropdownXpath;
	String strCreateNewScheduleButtonXpath;
	String strNewScheduleHeaderXpath;
	String strTierStructureHeaderXpath;
	String strNewSchedulePlatformDropdownOptionsXpath;
	String strNewSchedulePlatformDropdownXpath;
	String strNewScheduleDisabledPlatformNameXpath;
	String strNewScheduleScheduleTypeOptionsXpath;
	String strNewScheduleScheduleTypeDropdownXpath;
	String strNewScheduleScheduleNameXpath;
	String strNewScheduleFeePercentage1TextboxXpath;
	String strNewScheduleAddTierButtonXpath;
	String strNewScheduleMinimumAUM2TextBoxXpath;
	String strNewScheduleFeePercentage2TextboxXpath;
	String strNewScheduleMinimumAUM3TextBoxXpath;
	String strNewScheduleFeePercentage3TextboxXpath;
	String strNewScheduleSaveButtonXpath;
	String strOtherScheduleDeleteActionButton1Xpath;
	String strOtherScheduleRadioButton1Xpath;
	String strDeleteButtonXpath;
	String strErrorMessageAlertXpath;
	String strCreateNewAssignmentButtonXpath;
	String strNewAssignmentWindowXpath;
	String strNewAssignmentSearchDropdownXpath;
	String strNewAssignmentSearchDropdownOptionsXpath;
	String strNewAssignmentSearchREPTextBoxXpath;
	String strNewAssignmentSubmitButtonXpath;
	String strCustomAssignmentRepTextBoxXpath;
	String strCustomAssignmentSearchTextboxXpath;
	String strCustomAssignmentAllTableHeaderXpath;
	String strActiveStandardAssignmentRepTextBoxXpath;
	String strNewAssignmentScheduleDropdownXpath;
	String strNewAssignmentScheduleDropdownOptionsXpath;
	String strNewAssignmentCancelButtonXpath;
	String strRportsTabXpath;
	String strReportsTypeDropDownXpath;
	String strReportsTypeDropDownOptionXpath;
	String strExportButtonDisabledXpath;
	String strExportButtonEnabledXpath;
	String strSearchInReportsTabButtonXpath;
	String strResetInReportsTabButtonXpath;
	String strRepAssignReportSearchOptionsXpath;
	String strRepAssignReportDateSearchOptionsXpath;
	String strAdminFeeReportSearchOptionsXpath;
	String strRepAumAdminReportSearchOptionsXpath;
	String strRepAumAdminReportDateSearchOptionsXpath;
	String strBulkUploadsearchXpath;
	String strAumByProgramSearchOptionsXpath;
	String strScheduledTypesOptionUnderReportsTabXpath;
	String strScheduledTypesUnderReportsTabXpath;
	String strRepAUMStandardDataXpath;
	String strRepAUMStandardScheduleLinkXpath;
	String strStandardFlatAdminFeeDataXpath;
	String strScheduleTypeDropDownUnderRepAssignXpath;
	String strScheduleTypeDropDownOptionsUnderRepAssignXpath;
	String strAssignmnetDropDownOptionUnderRepAssignXpath;
	String strAssignmnetDropDownOptionsUnderRepAssignXpath;
	String strNewScheduleMinimumAUMDisabledXpath;
	String strREPAUMTradeAdminFeeManageScheduleHeaderXpath;
	String strSearchFirmXpath;
	String strStartDateXpath;
	String strEndDateXpath;
	String strPlatformDropdownXpath;
	String strPlatformDropdownOptionsXpath;
	String strScheduleNameDropDownXpath;
	String strScheduleNameDropdownOptionsXpath;
	String strNotesXpath;
	String strSubmitButtonXpath;
	String strNewlyAddedAssignmentSelectXpath;
	String strCancelAssignmentDropDownXpath;
	String strNewlyAddedAssignmentXpath;
	String strAssignmentTypeDropdownXpath;
	String strAssignmentTypeDropdownOptionsXpath;
	String strScheduleTypeInGridXpath;
	String strSelectFirstRecordInGridXpath;
	String strActionDropdownXpath;
	String strCancelAssignmentDisabledOptionXpath;
	String strFlatTypeRadioButtonOptionXpath;
	String strMasterAccountReportHeaderXpath;
	String strHistoricalSearchFieldsXpath;
	String strHistoricalViewReportButtonXpath;
	String strCheckWithDivTextXpath;
	String strNewScheduleFeePercentageTextboxXpath;
	String strDisplaySelectedFeeTypeOptionXpath;
	String strFlatTypeRadioButtonOptionSelectXpath;
	String strLPLSWSorSWSFeeReportSearchOptionsXpath;
	String strLPLSWSorSWSFeeReportDateSearchOptionsXpath;
	String strLPLSWSorSWSFeeAllTableHeaderXpath;
	String strAUMByProgramAllTableHeaderXpath;
	String strTableHeaderXpath;
	String strReportArrowButtonXpath;
	String strPeriodEndDateXpath;
	String strSWSFeeTypeHeaderXpath;
	String strGenerateButtonXpath;
	String strBeginDateXpath;
	String strBeginDatecheckboxXpath;
	String strStandardFlatFeescheduleTradeFeeScheduleXpath;
	String strStandardFlatFeescheduleTradeFeeFlatFeeHeaderXpath;
	String strRepAUMStandardTierStructureHeaderXpath;
	String strMSStandardScheduleTierStructureHeaderXpath;
	String strMWPStandardScheduleTierStructureHeaderXpath;
	String strSAM2StandardScheduleTierStructureHeaderXpath;
	String strSWSFeeScheduleAllTableHeaderXpath;
	String strSumbitButtonDisabledXpath;
	String strSumbitButtonEnabledXpath;
	String strStartAndEndDateXpath;
	String strOkButtonXpath;
	String strYesButtonXpath;
	String strStandardFlatFeeScheduleAdminFeeXpath;
	String strSumbitButtonEnabledInUpdateXpath;
	String strSumbitButtonDisabledInUpdateXpath;
	String strNotesInUpdateXpath;
	String strEndDateinUpdateXpath;
	String strRequestStatusDropdownXpath;
	String strScheduleTypeXpath;
	String strProgressiveTierStructureHeaderXpath;
	String strMSStandardScheduleCloneIconXpath;
	String strMSStandardCloneHeaderXpath;
	String strScheduleNameHyperLinkXpath;
	String strFeePercentageTextboxXpath;
	String strCloseIconXpath;
	String strReportDropDownXpath;
	String strSummaryReportOptionXpath;
	String strMSStandard23bpsScheduleLinkXpath;
	String strMSStandard23bpsScheduleHeaderXpath;
	String strMWPStandard23bpsScheduleLinkXpath;
	String strMWPStandard23bpsScheduleHeaderXpath;
	String strSAMIIStandard23bpsScheduleLinkXpath;
	String strSAMIIStandard23bpsScheduleHeaderXpath;
	String strTieredSchedulenameHypelinkXpath;
	String strFlatCloneScheduleValueXpath;
	String strTieredCloneScheduleValueXpath;
	String strCancelInCloneSchedulePopupXpath;
	String strEditIconXpath;
	String strCopyScheduleIconXpath;
	String strEntityTypeDropDownInScheduleXpath;
	String strEntityTypeDropDownInAssignmentXpath;
	String strEntityTypeDropDownOptionInScheduleXpath;
	String strEntityTypeDropDownOptionInAssignmentXpath;
	String strOtherScheduleDeleteActionButtonXpath;
	String strSWSHybridManagerAccessNetworkStandard20bpsLinkXpath;
	String strSWSHybridManagerAccessSelectStandard20bpsLinkXpath;
	String strSWSHybridSWMIIStandard15bpsLinkXpath;
	String strSWSHybridManagerAccessNetworkStandard20bpsScheduleHeaderXpath;
	String strSWSHybridManagerAccessSelectStandard20bpsScheduleHeaderXpath;
	String strSWSHybridSWMIIStandard15bpsHeaderXpath;
	String strStandardScheduleCloneIconXpath;
	String strEntityTypeDropDownOptionInAumByProgramXpath;
	String strEntityTypeDropDownOptionInFirmAssignmentXpath;
	String strEntityTypeDropDownInAumProgramXpath;
	String strEntityTypeDropDownInFirmAssignmentXpath;
	String strFirmAssignmentReportTableHeaderXpath;
	String strEntityTypeDropDownOptionInSWSFeeScheduletXpath;
	String strPlatformTypeHeaderInAssignmentXpath;
	String strPlatformTypeHeaderInExistingAssignmentXpath;
	String strScheduleNameHyperLinkInRepAssignmentXpath;
	String strAssignmentStatusDropdownXpath;
	String strSelectAllCheckboxXpath;
	String strModifyAssignmentOptionDisabledXpath;
	String strSwsFeeScheduleReportXpath;
	String strRIACUSTODYPLATFORMManageScheduleHeaderXpath;
	String strIFAHybridSWMIIStandard5bpsScheduleLinkXpath;
	String strEntityTypeStandardScheduleXpath;
	String strEntityTypeCustomScheduleXpath;

	public ProgramFeeManagement(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strProgramFeeManagementHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				PROGRAM_FEE_MANAGEMENT_HEADER);
	}

	/**
	 * This method is used to check The Availability of Pricing Model Dropdown Field
	 * Options
	 * 
	 * @param pricingModelTypes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean verifyTheAvailabilityofPricingModelDropdownFieldOptions(DataTable pricingModelTypes) {
		boolean blnResult = false;
		List<Map<String, String>> filters = pricingModelTypes.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofPricingModelTypes(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the Availability of Pricing Model Type
	 * 
	 * @param pricingModelType
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean verifytheAvailabilityofPricingModelTypes(String pricingModelType) {
		return isElementPresentUsingXpath(getFormattedLocator(strProgramTypeOptionsXpath, pricingModelType),
				pricingModelType);
	}

	/**
	 * This method is used to check select REP AUM in the Pricing Model Dropdown
	 * List
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */

	public boolean selectREPAUMinthePricingModelDropdownList() {
		return selectValueFromDropdownUsingXpath(strProgramTypeDropDownXpath, REP_AUM, PRICING_MODEL_DROPDOWN);
	}

	/**
	 * This method is used to verify the Availability of Fee Component DropDown
	 * Field Options
	 * 
	 * @param feeComponentTypes
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean verifytheAvailabilityofFeeComponentDropDownFieldOptions(DataTable feeComponentTypes) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strFeeComponentDropDownXpath, FEE_COMPONENT_DROPDOWN);
		List<Map<String, String>> filters = feeComponentTypes.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofFeeComponentDropDownTypes(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the Availability of Fee Component DropDown Type
	 * 
	 * @param feeComponentType
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean verifytheAvailabilityofFeeComponentDropDownTypes(String feeComponentType) {
		return isElementPresentUsingXpath(getFormattedLocator(strFeeComponentOptionsXpath, feeComponentType),
				feeComponentType);
	}

	/**
	 * This method is used to verify The Availability of MMC link
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */

	public boolean verifyTheAvailabilityofMMClink() {
		return isElementPresentUsingXpath(strMMCLinkXpath, LPLCoreConstents.getInstance().LOWEST, MMC_LINK);
	}

	/**
	 * This method is used to check Next Button is Disable Before Selecting Fee
	 * Component Dropdown Field Option
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */

	public boolean checkIfNextButtonisDisabled() {
		return isElementPresentUsingXpath(strNextButtonWithDisableXpath, LPLCoreConstents.getInstance().LOWEST,
				NEXT_BUTTON_DISABLED);
	}

	/**
	 * This method is used to Select Admin Fee
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean iSelectAdminFee() {
		return selectValueFromDropdownUsingXpath(strFeeComponentDropDownXpath, ADMIN_FEE, FEE_COMPONENT_DROPDOWN);
	}

	/**
	 * This method is used to check whether Next Button Get Enable or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean iShouldSeeNextButtonGetEnable() {
		return isElementPresentUsingXpath(strNextButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				NEXT_BUTTON_ENABLED);
	}

	/**
	 * This method is used to Click on Next Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean iClickonNextButton() {
		return clickElementUsingXpath(strNextButtonXpath, NEXT_BUTTON);
	}

	/**
	 * This method is used to Click on Export Button under schedule Management Tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09-09-2020
	 */
	public boolean iclickonExportButton() {
		return clickElementUsingXpath(strExportButtonXpath, EXPORT_BUTTON_UNDER_SCHEDULE_MANAGEMENT_TAB);
	}

	/**
	 * This method is used to check Manage Schedule Page Load
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean iShouldLandOnREPAUMManageSchedulePage() {
		// Check for create new schedule button and then click
		waitTillVisibleUsingXpath(strCreateNewScheduleButtonXpath, LPLCoreConstents.getInstance().HIGHEST,
				CREATE_NEW_SCHEDULE_BUTTON);
		return isElementPresentUsingXpath(strREPAUMManageScheduleHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				REP_AUM_MANAGE_SCHEDULE_HEADER);
	}

	/**
	 * This method is used to check Schedule Management Tab Is selected by Default
	 * or Not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-18-2020
	 */
	public boolean iVerifyScheduleManagementTabIsSelectedbyDefault() {
		return isElementPresentUsingXpath(strManageScheduleTabActiveXpath, LPLCoreConstents.getInstance().LOWEST,
				MANAGE_SCHEDULE_TAB);
	}

	/**
	 * This method is used to click on Rep Assignment Tracking Tab
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-09-2020
	 */
	public boolean iclickonRepAssignmentTrackingTab() {
		return clickElementUsingXpath(strRepAssignmentTrackingTabXpath, REP_ASSIGNMENT_TRAKING);
	}

	/**
	 * This method is used to click on Switch to Active Standard Assignments link
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-09-2020
	 */
	public boolean iclickonSwitchtoActiveStandardhyperlink() {
		return clickElementUsingXpath(strSwitchtoActiveStandardAssignmentslinkXpath, SWITCH_TO_STANDARD_SCHEDULE);
	}

	/**
	 * This method is used to enter Rep ID/Name
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07/10/2020
	 */
	public boolean enterRepIDorName() {
		return enterTextUsingXpath(strActiveStandardAssignmentRepTextBoxXpath, testData.get("strRepText"),
				REP_NAME_TEXTBOX);
	}

	/**
	 * This method is used to Click On Search Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07/10/2020
	 */
	public boolean iClickOnSearchButtoninActiveStandardAssignmentspage() {
		return clickElementUsingXpath(strSearchButtonXpath, SEARCH_BUTTON);
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07/10/2020
	 */

	public boolean checkIfElementExistUsingTableHeaderText(String tableHeaderTextText) {
		return isElementPresentUsingXpath(getFormattedLocator(strAllTableHeadersXpath, tableHeaderTextText),
				tableHeaderTextText);
	}

	/**
	 * This method is used to verify the display of fields in search result in
	 * Active Standard Assignments
	 * 
	 * @param searchResultOptions
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07/10/2020
	 */
	public boolean verifyDisplayOfFieldsInSearchResultInactiveStandardAssignments(DataTable searchResultOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchResultOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to Click On Reset Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07/10/2020
	 */
	public boolean iClickOnResetButton() {
		return clickElementUsingXpath(strResetButtonXpath, RESET_BUTTON);
	}

	/**
	 * This method is used to select LPL SWS in the Pricing Model Dropdown or Not
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-08-2020
	 */
	public boolean selectLPLSWSinthePricingModelDropdownList() {
		refreshTheWebpage();
		return selectValueFromDropdownUsingXpath(strProgramTypeDropDownXpath, LPL_SWS, PRICING_MODEL_DROPDOWN);
	}

	/**
	 * This method is used to verify the Availability of Fee Component DropDown Type
	 * for LPL SWS
	 * 
	 * @param feeComponentType1
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-08-2020
	 */
	public boolean verifytheAvailabilityofFeeComponentDropDownFieldOptionsforLPLSWS(DataTable feeComponentTypes1) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strFeeComponentDropDownXpath, FEE_COMPONENT_DROPDOWN);
		List<Map<String, String>> filters = feeComponentTypes1.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofFeeComponentDropDownTypes(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to Select Premium Service Fee
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-08-2020
	 */
	public boolean iSelectPremiumServiceFee() {
		return selectValueFromDropdownUsingXpath(strFeeComponentDropDownXpath, SWS_SERVICE_FEE, FEE_COMPONENT_DROPDOWN);
	}

	/**
	 * This method is used to check LPL SWS - Manage Schedule Page Load
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-20-2020
	 */
	public boolean iShouldLandOnLPLSWSManageSchedulePage() {
		// Refresh the webpage once to fix some elements initial load issue happening
		refreshTheWebpage();
		return isElementPresentUsingXpath(strLPLSWSManageScheduleHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				LPL_SWS_MANAGE_SCHEDULE_HEADER);
	}

	/**
	 * This method is used to verify the default value selected for Select Platform
	 * Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-20-2020
	 */
	public boolean iVerifyDefaultValueSelectedForSelectPlatformDropdown() {
		return isElementPresentUsingXpath(strManageScheduleTabActiveXpath, LPLCoreConstents.getInstance().LOWEST,
				MANAGE_SCHEDULE_TAB);
	}

	/**
	 * This method is used to check The Availability of Select Platform Dropdown
	 * Field Options
	 * 
	 * @param selectPlatformLists
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-28-2020
	 */
	public boolean verifytheAvailabilityofSelectPlatformDropDownFieldOptions(DataTable selectPlatformLists) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strSelectPlatformDropdownXpath, SELECT_PLATFORM_DROPDOWN);
		List<Map<String, String>> filters = selectPlatformLists.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofPlatformList(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of Select Platform List Field
	 * Options
	 * 
	 * @param selectPlatformLists
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-28-2020
	 */
	public boolean verifytheAvailabilityofPlatformList(String selectplatformList) {
		return isElementPresentUsingXpath(getFormattedLocator(strSelectPlatformOptionsXpath, selectplatformList),
				selectplatformList);
	}

	/**
	 * This method is used to verify the default value for Select Platform Dropdown
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-04-2020
	 */
	public boolean verifyDefaultValueInSelectPlatformDropdown() {
		return isElementPresentUsingXpath(getFormattedLocator(strSelectPlatformDropdownXpath, ALL), ALL);
	}

	/**
	 * This method is used to check select MS in the Select Platform Dropdown List
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-04-2020
	 */
	public boolean selectMSinSelectPlatformDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectPlatformDropdownXpath, MS, MS);
	}

	/**
	 * This method is used to check select MWP in the Select Platform Dropdown List
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-04-2020
	 */
	public boolean selectMWPinSelectPlatformDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectPlatformDropdownXpath, MWP, MWP);
	}

	/**
	 * This method is used to check select SAM in the Select Platform Dropdown List
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-04-2020
	 */
	public boolean selectSAMinSelectPlatformDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectPlatformDropdownXpath, SAM, SAM);
	}

	/**
	 * This method is used to check column header name of schedules
	 * 
	 * @param tableHeaderText
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-05-2020
	 */
	public boolean checkIfElementsExistUsingTableHeaderText(String tableHeaderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strStandardScheduleHeaderXpath, tableHeaderText),
				tableHeaderText);
	}

	/**
	 * This method is used to check column header name of standard schedules
	 * 
	 * @param tableHeaderText
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-05-2020
	 */
	public boolean verifytheAvailabilityofcolumnsunderStansardSchedule(DataTable standardScheduleColumns) {
		boolean blnResult = false;
		List<Map<String, String>> filters = standardScheduleColumns.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementsExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check column header name of other schedules
	 * 
	 * @param tableHeaderText
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-05-2020
	 */
	public boolean verifytheAvailabilityofcolumnsunderOtherSchedules(DataTable otherSchedulesColumns) {
		boolean blnResult = false;
		List<Map<String, String>> filters = otherSchedulesColumns.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementsExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify The home button icon
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07-21-2020
	 */
	public boolean verifyThehomeButtonicondisplayed() {
		return isElementPresentUsingXpath(strHomeButtonXpath, LPLCoreConstents.getInstance().LOWEST, HOME_BUTTON);
	}

	/**
	 * This method is used to Click On Home Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 07/21/2020
	 */
	public boolean iclickonHomeButton() {
		return clickElementUsingXpath(strHomeButtonXpath, HOME_BUTTON);
	}

	/**
	 * This method is used to check data of standard schedules
	 * 
	 * @param standardScheduleData
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean verifytheAvailabilityofdataunderStandardSchedule(DataTable standardScheduleData) {
		boolean blnResult = false;
		List<Map<String, String>> filters = standardScheduleData.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkDataExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check data of standard schedules
	 * 
	 * @param scheduleData
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean checkDataExistUsingTableHeaderText(String scheduleData) {
		return isElementPresentUsingXpath(getFormattedLocator(strStandardScheduledataXpath, scheduleData),
				scheduleData);
	}

	/**
	 * This method is used to verify The Availability of MS Standard 23bps link
	 * under Standard Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean verifyTheAvailabilityofMSStandard23bpsLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strMSStandard23bpsScheduleLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				PREMIUM_MS_STANDARD_LINK);
	}

	/**
	 * This method is used to verify The Availability of SWS MWP Standard 23bps link
	 * under Standard Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean verifyTheAvailabilityofMWPStandard23bpsLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strMWPStandard23bpsScheduleLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				PREMIUM_MWP_STANDARD_LINK);
	}

	/**
	 * This method is used to verify The Availability of Premium SAM2 Schedule link
	 * under Standard Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean verifyTheAvailabilityofSAMIIStandard18bpsLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strSAMIIStandard23bpsScheduleLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				PREMIUM_SAM2_STANDARD_LINK);
	}

	/**
	 * This method is used to verify the availability of Select Schedule Dropdown
	 * field options
	 * 
	 * @param selectScheduleList
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean verifytheAvailabilityofSelectScheduleDropDownFieldOptions(DataTable selectScheduleList) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strSelectScheduleDropdownXpath, SELECT_SCHEDULE_DROPDOWN);
		List<Map<String, String>> filters = selectScheduleList.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofScheduleList(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of Select Schedule list
	 * 
	 * @param selectscheduleList
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean verifytheAvailabilityofScheduleList(String selectscheduleList) {
		return isElementPresentUsingXpath(getFormattedLocator(strSelectScheduleOptionsXpath, selectscheduleList),
				selectscheduleList);
	}

	/**
	 * This method is used to select CUSTOM schedule
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean selectCUSTOMinSelectScheduleDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectScheduleDropdownXpath, CUSTOM, CUSTOM);
	}

	/**
	 * This method is used to select ONBOARDING schedule
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean selectONBOARDINGinSelectScheduleDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectScheduleDropdownXpath, ONBOARDING, ONBOARDING);
	}

	/**
	 * This method is used to select MISCELLANEOUS schedule
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-06-2020
	 */
	public boolean selectMISCELLANEOUSinSelectScheduleDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectScheduleDropdownXpath, MISCELLANEOUS, MISCELLANEOUS);
	}

	/**
	 * This method is used to verify The Create New Schedule button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-10-2020
	 */
	public boolean verifyTheAvailabilityofCreateNewScheduleButton() {
		// Refresh the webpage since create new schedule button is not displayed due to
		// load issue.
		refreshTheWebpage();
		// Check for create new schedule button and then click
		waitTillVisibleUsingXpath(strCreateNewScheduleButtonXpath, LPLCoreConstents.getInstance().HIGHEST,
				CREATE_NEW_SCHEDULE_BUTTON);
		return isElementPresentUsingXpath(strCreateNewScheduleButtonXpath, LPLCoreConstents.getInstance().LOWEST,
				CREATE_NEW_SCHEDULE_BUTTON);
	}

	/**
	 * This method is used to Click On Create New Schedule Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/10/2020
	 */
	public boolean iclickonCreateNewScheduleButton() {
		// Refresh the webpage since create new schedule button is not displayed due to
		// load issue.
		refreshTheWebpage();
		// Check for create new schedule button and then click
		waitTillVisibleUsingXpath(strCreateNewScheduleButtonXpath, LPLCoreConstents.getInstance().HIGHEST,
				CREATE_NEW_SCHEDULE_BUTTON);
		return clickElementUsingXpath(strCreateNewScheduleButtonXpath, CREATE_NEW_SCHEDULE_BUTTON);
	}

	/**
	 * This method is used to verify the display of New Schedule window
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-11-2020
	 */
	public boolean verifyThedisplayofNewScheduleWindow() {
		return isElementPresentUsingXpath(strNewScheduleHeaderXpath, LPLCoreConstents.getInstance().HIGHEST,
				NEW_SCHEDULE_WINDOWN);
	}

	/**
	 * This method is used to verify the availability of columns under Tier
	 * Structure
	 * 
	 * @param tierStructureColumn
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/11/2020
	 */
	public boolean verifytheAvailabilityofcolumnsunderTierStructure(DataTable tierStructureColumn) {
		boolean blnResult = false;
		List<Map<String, String>> filters = tierStructureColumn.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementsExistUsingtierStructureTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/11/2020
	 */
	private boolean checkIfElementsExistUsingtierStructureTableHeaderText(String tierStructuretableHeaderText) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strTierStructureHeaderXpath, tierStructuretableHeaderText),
				tierStructuretableHeaderText);
	}

	/**
	 * This method is used to verify the availability of PLATFORM dropdown options
	 * in New Schedule window
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/11/2020
	 */
	public boolean verifytheAvailabilityofPLATFORMdropdownoptionsinNewSchedulewindow(DataTable selectPlatformList) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strNewSchedulePlatformDropdownXpath, PLATFORM_DROPDOWN);
		List<Map<String, String>> filters = selectPlatformList.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofPlatformListinNewScheduleWindow(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of PLATFORM list in New
	 * Schedule window
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/11/2020
	 */
	private boolean verifytheAvailabilityofPlatformListinNewScheduleWindow(String selectPlatformList) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strNewSchedulePlatformDropdownOptionsXpath, selectPlatformList),
				selectPlatformList);
	}

	/**
	 * This method is used to select MS Platofrm in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-11-2020
	 */
	public boolean selectMSinPLATFORMDropdownOptionsinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewSchedulePlatformDropdownXpath, MS, MS);
	}

	/**
	 * This method is used to select Mwp Platofrm in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-11-2020
	 */
	public boolean selectMWPinPLATFORMDropdownOptionsinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewSchedulePlatformDropdownXpath, MWP, MWP);
	}

	/**
	 * This method is used to select SAM Platofrm in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-11-2020
	 */
	public boolean selectSAMinPLATFORMDropdownOptionsinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewSchedulePlatformDropdownXpath, SAM, SAM);
	}

	/**
	 * This method is used to check MS1, MS2 is Disable in New Schedule window Radio
	 * button Option
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-12-2020
	 */
	public boolean checkIfPlatformNameisDisabledafterSelectingPlatform(DataTable platformNameList) {
		boolean blnResult = false;
		List<Map<String, String>> filters = platformNameList.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkPlatformNameRadioButtonDisabled(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check MS1, MS2 is Disable in New Schedule window Radio
	 * button Option
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-12-2020
	 */
	public boolean checkPlatformNameRadioButtonDisabled(String platformName) {
		return isElementPresentUsingXpath(getFormattedLocator(strNewScheduleDisabledPlatformNameXpath, platformName),
				platformName);

	}

	/**
	 * This method is used to verify the availability of SCHEDULE TYPE dropdown
	 * options in New Schedule window
	 * 
	 * @param scheduleTypeList
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/12/2020
	 */
	public boolean verifytheAvailabilityofSCHEDULETYPEdropdownoptionsinNewSchedulewindow(DataTable scheduleTypeList) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strNewScheduleScheduleTypeDropdownXpath, PLATFORM_DROPDOWN);
		List<Map<String, String>> filters = scheduleTypeList.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofScheduleTypeListinNewScheduleWindow(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of SCHEDULE TYPE List in New
	 * Schedule window
	 * 
	 * @param scheduleTypeList
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/12/2020
	 */
	private boolean verifytheAvailabilityofScheduleTypeListinNewScheduleWindow(String scheduleTypeList) {
		return isElementPresentUsingXpath(getFormattedLocator(strNewScheduleScheduleTypeOptionsXpath, scheduleTypeList),
				scheduleTypeList);
	}

	/**
	 * This method is used to select CUSTOM Schedule in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-12-2020
	 */
	public boolean selectCUSTOMScheduleTypeinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewScheduleScheduleTypeDropdownXpath, CUSTOM, CUSTOM);
	}

	/**
	 * This method is used to select ONBOARDING Schedule in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-12-2020
	 */
	public boolean selectONBOARDINGScheduleTypeinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewScheduleScheduleTypeDropdownXpath, ONBOARDING, ONBOARDING);
	}

	/**
	 * This method is used to select MISCELLANEOUS Schedule in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-12-2020
	 */
	public boolean selectMISCELLANEOUSScheduleTypeinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewScheduleScheduleTypeDropdownXpath, MISCELLANEOUS, MISCELLANEOUS);
	}

	/**
	 * This method is used to enter SCHEDULE NAME in NewSchedule window
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/13/2020
	 */
	public boolean enterSCHEDULENAME() {
		return enterTextUsingXpath(strNewScheduleScheduleNameXpath, testData.get("strScheduleName"),
				SCHEDULE_NAME_TEXTBOX);
	}

	/**
	 * This method is used to enter FEE PERCENTAGE in Tier1
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/13/2020
	 */
	public boolean enterFEEPERCENTAGEinTier1() {
		return enterTextUsingXpath(strNewScheduleFeePercentage1TextboxXpath, testData.get("strFeePercentage1"),
				FEE_PERCENTAGE);
	}

	/**
	 * This method is used to enter FEE PERCENTAGE
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 11/04/2020
	 */
	public boolean enterFeePercentage() {
		return enterTextUsingXpath(strNewScheduleFeePercentageTextboxXpath, testData.get("strFeePercentage"),
				FEE_PERCENTAGE);
	}

	/**
	 * This method is used to Click On +Add Tier Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/14/2020
	 */
	public boolean iclickonAddTierbutton() {
		return clickElementUsingXpath(strNewScheduleAddTierButtonXpath, ADD_TIER_BUTTON);
	}

	/**
	 * This method is used to Click On Save Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/14/2020
	 */
	public boolean iclickonSavebutton() {
		return clickElementUsingXpath(strNewScheduleSaveButtonXpath, SAVE_BUTTON);
	}

	/**
	 * This method is used to MINIMUM AUM in Tier 1
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/14/2020
	 */
	public boolean enterMINIMUMAUMinTier2() {
		return enterTextUsingXpath(strNewScheduleMinimumAUM2TextBoxXpath, testData.get("strMinimumAUM2"), MINIMUM_AUM);
	}

	/**
	 * This method is used to FEE PERCENTAGE in Tier 2
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/14/2020
	 */
	public boolean enterFEEPERCENTAGEinTier2() {
		return enterTextUsingXpath(strNewScheduleFeePercentage2TextboxXpath, testData.get("strFeePercentage2"),
				FEE_PERCENTAGE);
	}

	/**
	 * This method is used to MINIMUM AUM in Tier 3
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/14/2020
	 */
	public boolean enterMINIMUMAUMinTier3() {
		return enterTextUsingXpath(strNewScheduleMinimumAUM3TextBoxXpath, testData.get("strMinimumAUM3"), MINIMUM_AUM);
	}

	/**
	 * This method is used to FEE PERCENTAGE in Tier 3
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/14/2020
	 */
	public boolean enterFEEPERCENTAGEinTier3() {
		return enterTextUsingXpath(strNewScheduleFeePercentage3TextboxXpath, testData.get("strFeePercentage3"),
				FEE_PERCENTAGE);
	}

	/**
	 * This method is used to Click On Delete icon for created schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/17/2020
	 */
	public boolean iclickonDeleteiconforCreatedSchedule() {
		waitTillVisibleUsingXpath(strOtherScheduleDeleteActionButton1Xpath, LPLCoreConstents.getInstance().HIGHEST,
				DELETE_ACTION_BUTTON);
		return clickElementUsingXpath(strOtherScheduleDeleteActionButton1Xpath, DELETE_ACTION_BUTTON);
	}

	/**
	 * This method is used to Click On Delete Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/17/2020
	 */
	public boolean iclickonDeleteButton() {
		waitTillVisibleUsingXpath(strDeleteButtonXpath, LPLCoreConstents.getInstance().HIGHEST, DELETE);
		return clickElementUsingXpath(strDeleteButtonXpath, DELETE);
	}

	/**
	 * This method is used to Click On Radio button 1 under Other schedules
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/17/2020
	 */
	public boolean iclickonRadioButton1underOtherSchedules() {
		return clickElementUsingXpath(strOtherScheduleRadioButton1Xpath, SELECT_SCHEDULE);
	}

	/**
	 * This method is used to enter FEE PERCENTAGE in Tier2 greater that Tier1 value
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/18/2020
	 */
	public boolean enterFEEPERCENTAGEinTier2gretaerthanTier1value() {
		return enterTextUsingXpath(strNewScheduleFeePercentage2TextboxXpath,
				testData.get("strFeePercentage2GreaterThan1"), FEE_PERCENTAGE);
	}

	/**
	 * This method is used to verify the display of Error message alert
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/18/2020
	 */
	public boolean iVerifytheDisplayoferrormessagealert() {
		return isElementPresentUsingXpath(strErrorMessageAlertXpath, LPLCoreConstents.getInstance().LOWEST,
				ERROR_MESSAGE_ALERT);
	}

	/**
	 * This method is used to Click On Create New Assignment Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/19/2020
	 */
	public boolean iclickonCreateNewAssignmentButton() {
		return clickElementUsingXpath(strCreateNewAssignmentButtonXpath, CREATE_NEW_ASSIGNMENT_BUTTON);
	}

	/**
	 * This method is used to verify the display of New Assignment window
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/19/2020
	 */
	public boolean iVerifytheDisplayofNewAssignmentwindow() {
		return isElementPresentUsingXpath(strNewAssignmentWindowXpath, LPLCoreConstents.getInstance().LOWEST,
				NEW_ASSIGNMENT_WINDOW);
	}

	/**
	 * This method is verify availability of search dropdown options in New
	 * Assignment window
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/19/2020
	 */
	public boolean verifytheAvailabilityofSearchDropdownOptionsinNewAssignmentwindow(DataTable searchDropdownList) {
		boolean blnResult = false;
		blnResult = isElementPresentUsingXpath(strNewAssignmentSearchDropdownXpath, PLATFORM_DROPDOWN);
		List<Map<String, String>> filters = searchDropdownList.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofSearchDropdownListinNewAssignmentWindow(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is verify availability of search dropdown options in New
	 * Assignment window
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/19/2020
	 */
	private boolean verifytheAvailabilityofSearchDropdownListinNewAssignmentWindow(String searchDropdownList) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strNewAssignmentSearchDropdownOptionsXpath, searchDropdownList),
				searchDropdownList);
	}

	/**
	 * This method is used to enter RepID in Search Rep text box
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/19/2020
	 */
	public boolean enterRepIDinSearchREPTextbox() {
		return enterTextUsingXpath(strNewAssignmentSearchREPTextBoxXpath, testData.get("strSearchREP"), SEARCH_REP);
	}

	/**
	 * This method is used to Click On Submit Button
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/19/2020
	 */
	public boolean iclickonSubmitButtoninNewAssignmentwindow() {
		return clickElementUsingXpath(strNewAssignmentSubmitButtonXpath, SUBMIT_BUTTON);
	}

	/**
	 * This method is used to enter RepID in Custom Assignment Filter Criteria
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/20/2020
	 */
	public boolean enterRepIDinCustomAssignmentFilterCriteria() {
		return enterTextUsingXpath(strCustomAssignmentRepTextBoxXpath, testData.get("strSearchREP"), SEARCH_REP);
	}

	/**
	 * This method is used to Click On Search Button in Custom Assignments page
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/20/2020
	 */
	public boolean iClickOnSearchButtoninCustomAssignmentspage() {
		return clickElementUsingXpath(strCustomAssignmentSearchTextboxXpath, SEARCH_BUTTON);
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param tableHeaderTextText
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/20/2020
	 */
	public boolean checkIfCustomElementExistUsingTableHeaderText(String tableHeaderTextText) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strCustomAssignmentAllTableHeaderXpath, tableHeaderTextText), tableHeaderTextText);
	}

	/**
	 * This method is used to verify the display of fields in Search Result in
	 * Custom Assignments
	 * 
	 * @param searchResultOptions
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/20/2020
	 */
	public boolean verifyDisplayOfFieldsInSearchResultInCustomAssignments(DataTable searchResultOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchResultOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfCustomElementExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click on Report tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean clickOnReportsTab() {
		return clickElementUsingXpath(strRportsTabXpath, REPORT_BUTTON);
	}

	/**
	 * This method is used to check The Availability of view report dropdown field
	 * options Options
	 * 
	 * @param reportType
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */

	public boolean verifyTheAvailabilityofViewreportDropdownFieldoption(String reportType) {
		return isElementPresentUsingXpath(getFormattedLocator(strReportsTypeDropDownOptionXpath, reportType),
				LPLCoreConstents.getInstance().LOWEST, reportType + OPTIONS);
	}

	/**
	 * This method is used to check The Availability of view report dropdown field
	 * options Options
	 * 
	 * @param reportTypes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyTheAvailabilityofViewreportDropdownFieldoptions(DataTable reportTypes) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strReportsTypeDropDownXpath, VIEW_REPORT_DROPDOWN);
		List<Map<String, String>> filters = reportTypes.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyTheAvailabilityofViewreportDropdownFieldoption(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of Master Account List Table
	 * Column options Options
	 * 
	 * @param reportType
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 10-19-2020
	 */

	public boolean verifyTheAvailabilityofMasterAccountListTableColumn(String culumnHeaders) {
		return isElementPresentUsingXpath(getFormattedLocator(strMasterAccountReportHeaderXpath, culumnHeaders),
				LPLCoreConstents.getInstance().LOWEST, culumnHeaders + OPTIONS);
	}

	/**
	 * This method is used to verify the availability of Master Account List for
	 * Models report table column headers options Options
	 * 
	 * @param reportTypes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 10-19-2020
	 */
	public boolean verifyTheAvailabilityofMasterAccountListTableColumns(DataTable culumnHeaders) {
		boolean blnResult = false;
		List<Map<String, String>> filters = culumnHeaders.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyTheAvailabilityofMasterAccountListTableColumn(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		closeDriver();
		switchToFirstTab(browserActiveTabs);
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of Historical Billing Details
	 * Search Field Option options Options
	 * 
	 * @param reportTypes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 10-19-2020
	 */

	public boolean verifyTheAvailabilityofHistoricalBillingDetailsSearchFieldOption(String searchFieldOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strHistoricalSearchFieldsXpath, searchFieldOption),
				LPLCoreConstents.getInstance().HIGHEST, searchFieldOption + OPTIONS);
	}

	/**
	 * This method is used to verify the availability of of Historical Billing
	 * Details Search Field Options options Options
	 * 
	 * @param reportTypes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 10-19-2020
	 */
	public boolean verifyTheAvailabilityofHistoricalBillingDetailsSearchFieldOptions(DataTable searchFieldOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFieldOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyTheAvailabilityofHistoricalBillingDetailsSearchFieldOption(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		closeDriver();
		switchToFirstTab(browserActiveTabs);
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of Onboarding Period
	 * Termination Warnings Report Header
	 * 
	 * @param reportHeader
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 01-19-2021
	 */
	public boolean verifyOnboardingTerminationWarningsReportHeader(String reportHeader) {
		return isElementPresentUsingXpath(getFormattedLocator(strTableHeaderXpath, reportHeader),
				LPLCoreConstents.getInstance().HIGHEST, reportHeader + OPTIONS);
	}

	/**
	 * This method is used to verify the availability of Onboarding Period
	 * Termination Warnings Report Headers
	 * 
	 * @param reportHeaders
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 01-19-2021
	 */
	public boolean verifyOnboardingTerminationWarningsReportHeaders(DataTable reportHeaders) {
		boolean blnResult = false;
		List<Map<String, String>> filters = reportHeaders.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyOnboardingTerminationWarningsReportHeader(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		closeDriver();
		switchToFirstTab(browserActiveTabs);
		return blnResult;
	}

	/**
	 * This method is used to verify The Export button is disable or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean exportButtonIsDisable() {
		return isElementPresentUsingXpath(strExportButtonDisabledXpath, LPLCoreConstents.getInstance().LOWEST,
				EXPORT_BUTTON_DISABLE);
	}

	/**
	 * This method is used to verify The Export button is disable or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean masterAccountReportOpenedInNewTab() {
		boolean blnResult;
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		blnResult = isElementPresentUsingXpath(
				getFormattedLocator(strMasterAccountReportHeaderXpath, MASTER_ACCOUNT_MODEL_REPORT),
				LPLCoreConstents.getInstance().HIGHEST, MASTER_ACCOUNT_MODEL_REPORT);
		return blnResult;
	}

	/**
	 * This method is used to select report option parameter
	 * 
	 * @param selectReportType
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean selectReportOption(String selectReportType) {
		boolean blnResult = false;
		boolean blnClickDropDown = clickElementUsingXpath(strReportsTypeDropDownXpath, VIEW_REPORT_DROPDOWN);
		if (blnClickDropDown) {
			blnResult = clickElementUsingXpath(getFormattedLocator(strReportsTypeDropDownOptionXpath, selectReportType),
					selectReportType + OPTION);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the Export button got enabled or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean exportButtonIsEnabled() {
		return isElementPresentUsingXpath(strExportButtonEnabledXpath, LPLCoreConstents.getInstance().MEDIUM,
				EXPORT_BUTTON_ENABLE);
	}

	/**
	 * This method is used to check The Availability of date filter criteria fields
	 * under REP Assignment Report Options
	 * 
	 * @param filterCriteriaOption
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-24-2020
	 */
	public boolean verifyFilterCriteriaDateFieldunderREPAssignmentReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strRepAssignReportDateSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * REP Assignment Report Options
	 * 
	 * @param filterCriteriaOptions
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-24-2020
	 */
	public boolean verifyFilterCriteriaDateFieldsunderREPAssignmentReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaDateFieldunderREPAssignmentReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of Schedule Type DropDown
	 * Option under REP Assignment Report Options
	 * 
	 * @param dropDownOption
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-27-2020
	 */
	public boolean verifyFilterCriteriaOfScheduleTypeDropDownOptionunderREPAssignmentReport(String dropDownOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strScheduleTypeDropDownOptionsUnderRepAssignXpath, dropDownOption),
				LPLCoreConstents.getInstance().LOWEST, dropDownOption + OPTION);

	}

	/**
	 * This method is used to check The Availability of Schedule Type DropDown
	 * Options under REP Assignment Report Options
	 * 
	 * @param dropDownOptions
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-27-2020
	 */
	public boolean verifyFilterCriteriaOfScheduleTypeDropDownOptionsunderREPAssignmentReport(
			DataTable dropDownOptions) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strScheduleTypeDropDownUnderRepAssignXpath, SCHEDULE_TYPE_DROPDOWN);
		List<Map<String, String>> filters = dropDownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaOfScheduleTypeDropDownOptionunderREPAssignmentReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of Assignment Status Dropdown
	 * Option under REP Assignment Report Options
	 * 
	 * @param dropDownOption
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-27-2020
	 */
	public boolean verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionUnderREPAssignmentReport(
			String dropDownOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strAssignmnetDropDownOptionsUnderRepAssignXpath, dropDownOption),
				LPLCoreConstents.getInstance().LOWEST, dropDownOption + OPTION);

	}

	/**
	 * This method is used to check The Availability of Assignment Status Dropdown
	 * Options REP Assignment Report Options
	 * 
	 * @param dropDownOptions
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-27-2020
	 */
	public boolean verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionsUnderREPAssignmentReport(
			DataTable dropDownOptions) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strAssignmnetDropDownOptionUnderRepAssignXpath, ASSIGNMENT_STATUS_DROPDOWN);
		List<Map<String, String>> filters = dropDownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionUnderREPAssignmentReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * REP Assignment Report Options
	 * 
	 * @param filterCriteriaOption
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldunderREPAssignmentReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strRepAssignReportSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);

	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * REP Assignment Report Options
	 * 
	 * @param filterCriteriaOptions
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldsunderREPAssignmentReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldunderREPAssignmentReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click on Export button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean clickOnExportButtonUnderReportstab() {
		return clickElementUsingXpath(strExportButtonEnabledXpath, EXPORT_BUTTON);
	}

	/**
	 * This method is used to click click on Export dropdown and select report
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 02-15-2021
	 */
	public boolean clickOnExportDropDownAndSelectReportUnderReportstab() {
		clickElementUsingXpath(strSummaryReportOptionXpath, EXPORT_DROPDOWN);
		return clickElementUsingXpath(strSummaryReportOptionXpath, ADMIN_FEE_SUMMARY_REPORT);
	}

	/**
	 * This method is used to verify file downloaded successfully or not
	 * 
	 * @param downloadedReportType
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean checkIfReportDownloadedSuccessfully(String downloadedReportType) {
		// Wait till file downloads completes
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().HIGHEST);
		boolean blnResult;
		String actualReportname = STRING_EMPTY;
		if (downloadedReportType.equals(REP_ASSIGNMENT_REPORT))
			actualReportname = REP_ASSIGNMENT_REPORT_NAME;
		else if (downloadedReportType.equals(ADMIN_FEE_SCHEDULE_REPORTS))
			actualReportname = ADMIN_FEE_SCHEDULE_REPORTS_NAME;
		else if (downloadedReportType.equals(REP_AUM_ADMIN_FEE_REPORT))
			actualReportname = ADMIN_FEE_REPORT_NAME;
		else if (downloadedReportType.equals(BULK_UPLOAD_REPORT))
			actualReportname = BULK_UPLOAD_REPORT_NAME;
		else if (downloadedReportType.equals(AUM_BY_PROGRAM))
			actualReportname = REP_AUM_REPORT_BY_PROGRAM_NAME;
		else if (downloadedReportType.equals(FIRM_ASSIGNMENT_REPORT))
			actualReportname = FIRM_ASSIGNMENT_REPORT_NAME;
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		blnResult = checkIfFileDownloadedAndDeleted(LPLCoreConstents.getInstance().DefaultDownloadFolder,
				actualReportname);
		return blnResult;
	}

	/**
	 * This method is used to verify file downloaded successfully or not
	 *
	 * @author Abdul Hadi
	 * @since 09-09-2020
	 */
	public boolean checkIfReportExportedSuccessfully() {
		// Wait till file downloads completes under download folder, Added Hard coded
		// wait since windows taking more time to update the file in downloads folder ,
		// So hard coded wait beyond to HIGHEST CoreConstants
		LPLCoreSync.staticWait(500);
		return checkIfFileDownloadedAndDeleted(LPLCoreConstents.getInstance().DefaultDownloadFolder,
				SCHEDULE_LIST_REPORT_EXPORTED);
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * Admin fee schedule report Options
	 * 
	 * @param filterCriteriaOption
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldunderAdminfeeschedulereport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strAdminFeeReportSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * Admin fee schedule report Options
	 * 
	 * @param filterCriteriaOptions
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldsunderAdminfeeschedulereport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldunderAdminfeeschedulereport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The availability of filter criteria fields of
	 * different schedule type dropdown Options
	 * 
	 * @param scheduleType
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldofDifferentSceduleTypeDropdown(String scheduleType) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strScheduledTypesOptionUnderReportsTabXpath, scheduleType), scheduleType + OPTION);
	}

	/**
	 * This method is used to check The availability of filter criteria fields of
	 * different schedule type dropdown Options
	 * 
	 * @param scheduleTypes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldofDifferentSceduleTypesDropdown(DataTable scheduleTypes) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strScheduledTypesUnderReportsTabXpath, SCHEDULE_TYPE_IN_TABLE);
		List<Map<String, String>> filters = scheduleTypes.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldofDifferentSceduleTypeDropdown(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of Search button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean searchButtonDisplayed() {
		return isElementPresentUsingXpath(strSearchButtonXpath, LPLCoreConstents.getInstance().LOWEST, SEARCH_BUTTON);
	}

	/**
	 * This method is used to verify the availability of Reset button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean resetButtonDisplayed() {
		return isElementPresentUsingXpath(strResetButtonXpath, LPLCoreConstents.getInstance().LOWEST, RESET_BUTTON);
	}

	/**
	 * This method is used to verify the availability of filter criteria fields
	 * under Admin fee report
	 * 
	 * @param filterCriteriaOption
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldunderAdminfeeReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strRepAumAdminReportSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to verify the availability of filter criteria fields
	 * under Admin fee report
	 * 
	 * @param filterCriteriaOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldsunderAdminfeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldunderAdminfeeReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of filter criteria fields
	 * under Admin fee report
	 * 
	 * @param filterCriteriaOption
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-25-2020
	 */
	public boolean verifyFilterCriteriaDateFieldunderAdminfeeReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strRepAumAdminReportDateSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to verify the availability of filter criteria date fields
	 * under Admin fee report
	 * 
	 * @param filterCriteriaOptions
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-25-2020
	 */
	public boolean verifyFilterCriteriaDateFieldsunderAdminfeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaDateFieldunderAdminfeeReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of table headers Options
	 * 
	 * @param tableHeader
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyThetableHeader(String tableHeader) {
		return isElementPresentUsingXpath(getFormattedLocator(strBulkUploadsearchXpath, tableHeader),
				LPLCoreConstents.getInstance().LOWEST, tableHeader + OPTION);
	}

	/**
	 * This method is used to check The Availability of table headers Options
	 * 
	 * @param tableHeaders
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyThetableHeaders(DataTable tableHeaders) {
		boolean blnResult = false;
		List<Map<String, String>> filters = tableHeaders.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyThetableHeader(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of table headers Options of
	 * Admin fee report
	 * 
	 * @param tableHeaders
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 02-12-2021
	 */
	public boolean verifyThetableHeadersOfAdminFeeReport(DataTable tableHeaders) {
		boolean blnResult = false;
		List<Map<String, String>> filters = tableHeaders.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyThetableHeader(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * AUM - by Program report Options
	 * 
	 * @param filterCriteriaOption
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldunderAumByProgramReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strAumByProgramSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * AUM - by Program report Options
	 * 
	 * @param filterCriteriaOptions
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08-20-2020
	 */
	public boolean verifyFilterCriteriaFieldsunderAumByProgramReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldunderAumByProgramReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is verify availability of ScheduleName dropdown options in New
	 * Assignment window
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/21/2020
	 */
	public boolean verifytheAvailabilityofScheduleNameDropdownOptionsinNewAssignmentwindow(
			DataTable scheduleNameDropdownList) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strNewAssignmentScheduleDropdownXpath, SCHEDULE_NAME_DROPDOWN);
		List<Map<String, String>> filters = scheduleNameDropdownList.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofScheduleNameDropdownListinNewAssignmentWindow(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is verify availability of ScheduleName dropdown options in New
	 * Assignment window
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/21/2020
	 */
	private boolean verifytheAvailabilityofScheduleNameDropdownListinNewAssignmentWindow(
			String scheduleNameDropdownList) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strNewAssignmentScheduleDropdownOptionsXpath, scheduleNameDropdownList),
				scheduleNameDropdownList);
	}

	/**
	 * This method is used to click on Cancel Button in New Assignment window
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/21/2020
	 */
	public boolean iClickOnCancelbuttoninNewAssignmentwindow() {
		return clickElementUsingXpath(strNewAssignmentCancelButtonXpath, CANCEL_BUTTON);
	}

	/**
	 * This method is used to check data for REP AUM Standard
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/24/2020
	 */
	public boolean verifytheAvailabilityofREPAUMStandardDataunderStandardSchedule(DataTable standardScheduleData) {
		boolean blnResult = false;
		List<Map<String, String>> filters = standardScheduleData.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkREPAUMStandardDataExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check data for REP AUM Standard
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/24/2020
	 */
	private boolean checkREPAUMStandardDataExistUsingTableHeaderText(String scheduleData) {
		return isElementPresentUsingXpath(getFormattedLocator(strRepAUMStandardDataXpath, scheduleData), scheduleData);
	}

	/**
	 * This method is used to verify The Availability of Rep AUM Standard Schedule
	 * link under Standard Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-24-2020
	 */
	public boolean verifyTheAvailabilityofRepAUMStandardScheduleLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strRepAUMStandardScheduleLinkXpath, LPLCoreConstents.getInstance().LOWEST,
				REP_AUM_STANDARD_LINK);
	}

	/**
	 * This method is used to check data for Standard Flat Feeschedule - Admin Fee
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/24/2020
	 */
	public boolean verifyTheAvailabilityofStandardFlatFeescheduleAdminFeeData(DataTable standardScheduleData) {
		boolean blnResult = false;
		List<Map<String, String>> filters = standardScheduleData.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkStandardFlatFeescheduleAdminFeeDataExistUsingTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check data for Standard Flat Feeschedule - Admin Fee
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08/24/2020
	 */
	private boolean checkStandardFlatFeescheduleAdminFeeDataExistUsingTableHeaderText(String scheduleData) {
		return isElementPresentUsingXpath(getFormattedLocator(strStandardFlatAdminFeeDataXpath, scheduleData),
				scheduleData);
	}

	/**
	 * This method is used to verify Minimum AUM for Tier1 is disabled
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 08-26-2020
	 */

	public boolean verifyMinimumAUMforTier1isdisabled() {
		return isElementPresentUsingXpath(strNewScheduleMinimumAUMDisabledXpath, LPLCoreConstents.getInstance().LOWEST,
				MINIMUMAUM_TIER1_DISABLED);
	}

	/**
	 * This method is used to search for Firm and to select
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean verifyTheAvailabilityofPlatformDropdownOption(String dropDownOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strPlatformDropdownOptionsXpath, dropDownOption),
				dropDownOption);
	}

	/**
	 * This method is used to verify The Availability of Platform Dropdown field
	 * Options
	 * 
	 * @param DataTable
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean verifyTheAvailabilityofPlatformDropdownOptions(DataTable dropDownOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = dropDownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyTheAvailabilityofPlatformDropdownOption(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to enter Start date
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean enterStartdate() {
		clickElementUsingXpath(strStartDateXpath, START_DATE_ICON);
		waitTillVisibleUsingXpath(getFormattedLocator(strStartAndEndDateXpath, testData.get("StrStartAndEndDate")),
				LPLCoreConstents.getInstance().HIGHEST, START_DATE);
		return clickElementUsingXpath(getFormattedLocator(strStartAndEndDateXpath, testData.get("StrStartAndEndDate")),
				START_DATE);
	}

	/**
	 * This method is used to enter End date
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean enterEnddate() {
		clickElementUsingXpath(strEndDateXpath, END_DATE_ICON);
		waitTillVisibleUsingXpath(getFormattedLocator(strStartAndEndDateXpath, testData.get("StrStartAndEndDate")),
				LPLCoreConstents.getInstance().HIGHEST, END_DATE);
		return clickElementUsingXpath(getFormattedLocator(strStartAndEndDateXpath, testData.get("StrStartAndEndDate")),
				END_DATE);
	}

	/**
	 * This method is used to select Platform
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean selectPlatform() {
		waitTillVisibleUsingXpath(strPlatformDropdownXpath, LPLCoreConstents.getInstance().HIGHEST, PLATFORM_DROPDOWN);
		return selectValueFromDropdownUsingXpath(strPlatformDropdownXpath, testData.get("strPlatFormName"),
				PLATFORM_DROPDOWN);
	}

	/**
	 * This method is used to select Schedule name
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean selectSchedulename() {
		waitTillVisibleUsingXpath(strScheduleNameDropDownXpath, LPLCoreConstents.getInstance().HIGHEST,
				SCHEDULE_NAME_DROPDOWN);
		return selectValueFromDropdownUsingXpath(strScheduleNameDropDownXpath, testData.get("strScheduleName"),
				SCHEDULE_NAME_DROPDOWN);
	}

	/**
	 * This method is used to enter Note
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean enterNote() {
		return enterTextUsingXpath(strNotesXpath, AUTOMATION_TEST, ENTER_NOTES);
	}

	/**
	 * This method is used to click on Submit
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean clickonSubmit() {
		waitTillVisibleUsingXpath(strSubmitButtonXpath, LPLCoreConstents.getInstance().HIGHEST, SUBMIT_BUTTON);
		return clickElementUsingXpath(strSubmitButtonXpath, SUBMIT_BUTTON);
	}

	/**
	 * This method is used to check whether assignment created Successfully or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean assignmentCreatedSuccessfully() {
		waitTillVisibleUsingXpath(strNewlyAddedAssignmentXpath, LPLCoreConstents.getInstance().HIGHEST,
				ASSIGNMENT_CREATED_SUCCESSFULLY);
		return isElementPresentUsingXpath(strNewlyAddedAssignmentXpath, LPLCoreConstents.getInstance().LOWEST,
				ASSIGNMENT_CREATED_SUCCESSFULLY);
	}

	/**
	 * This method is used to select Newly Added Assignment
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean selectNewlyAddedAssignment() {
		return clickElementUsingXpath(strNewlyAddedAssignmentSelectXpath, NEWLY_ADDED_ASSIGNMENT_RECORD);
	}

	/**
	 * This method is used to choose Cancel Assignment Option
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean selectCancelAssignmentOption(String actionType) {
		return selectValueFromDropdownUsingXpath(strCancelAssignmentDropDownXpath, actionType,
				CANCEL_ASSIGNMENT_DROPDOWN);
	}

	/**
	 * This method is used to assignment Cancelled Successfully
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/17/2020
	 */
	public boolean assignmentCancelledSuccessfully() {
		return isElementNotPresentUsingXpath(strNewlyAddedAssignmentXpath);
	}

	/**
	 * This method is used to verify the availability of Select Assignment dropdown
	 * field options
	 * 
	 * @param dropDownOption
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public boolean verifyTheAvailabilityofSelectAssignmentdropdownFieldOption(String dropDownOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strAssignmentTypeDropdownOptionsXpath, dropDownOption),
				dropDownOption);
	}

	/**
	 * This method is used to verify the availability of Select Assignment dropdown
	 * field options
	 * 
	 * @param DataTable
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public boolean verifyTheAvailabilityofSelectAssignmentdropdownFieldOptions(DataTable dropDownOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = dropDownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyTheAvailabilityofSelectAssignmentdropdownFieldOption(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to select Custom Assignments option under Rep/Firm
	 * Assignment Tracking tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public void selectCustomAssignmentsOption() {
		selectValueFromDropdownUsingXpath(strAssignmentTypeDropdownXpath, CUSTOM_ASSIGNMENTS, SELECT_CUSTOM_ASSIGNMENT);
	}

	/**
	 * This method is used to Custom Assignments records
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public boolean customAssignmentsRecordsDisplayed() {
		boolean blnResult = true;
		List<WebElement> records = getWebElementsUsingXpath(strScheduleTypeInGridXpath, SCHEDULE_TYPE);
		for (int i = 0; i < records.size();) {
			String getColumnText = records.get(i).getText();
			if (!getColumnText.equals(CUSTOM) || !getColumnText.equals(ONBOARDING)
					|| !getColumnText.equals(MISCELLANEOUS)) {
				blnResult = false;
				break;
			}
		}
		return blnResult;
	}

	/**
	 * This method is used to select Standard Assignments option under Rep/Firm
	 * Assignment Tracking tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public void selectStandardAssignmentsoption() {
		selectValueFromDropdownUsingXpath(strAssignmentTypeDropdownXpath, STANDARD_ASSIGNMENTS,
				SELECT_STANDARD_ASSIGNMENT);
	}

	/**
	 * This method is used to Standard Assignments records
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public boolean standardAssignmentsRecordsDisplayed() {
		boolean blnResult = true;
		List<WebElement> records = getWebElementsUsingXpath(strScheduleTypeInGridXpath, SCHEDULE_TYPE);
		for (int i = 0; i < records.size(); i++) {
			String getColumnText = records.get(i).getText();
			if (!getColumnText.equals(STANDARD)) {
				blnResult = false;
				break;
			}
		}
		return blnResult;
	}

	/**
	 * This method is used to select first Standard Assignment record
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public boolean selectFirstStandardAssignmentRecord() {
		return clickElementUsingXpath(strSelectFirstRecordInGridXpath, SELECT_FIRST_STANDARD_ASSIGNMENT);
	}

	/**
	 * This method is used to click on Action dropdown
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public boolean clickonActionDropdown() {
		return clickElementUsingXpath(strActionDropdownXpath, ACTION_DROPDOWN);
	}

	/**
	 * This method is used to check whether all Action options are readonly
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/21/2020
	 */
	public boolean allActionOptionsAreReadonly() {
		return isElementPresentUsingXpath(strCancelAssignmentDisabledOptionXpath, LPLCoreConstents.getInstance().LOWEST,
				CANCEL_ASSIGNMENT_READ_ONLY);
	}

	/**
	 * This method is used to Select Trade Admin Fee
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 09-22-2020
	 */
	public boolean iSelectTradeAdminFee() {
		return selectValueFromDropdownUsingXpath(strFeeComponentDropDownXpath, TRADE_ADMIN_FEE, FEE_COMPONENT_DROPDOWN);
	}

	/**
	 * This method is used to check REP AUM - Trade Admin Fee: Manage Schedule Page
	 * Load
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 09-22-2020
	 */
	public boolean iShouldLandOnREPAUMTradeAdminFeeManageSchedulePage() {
		return isElementPresentUsingXpath(strREPAUMTradeAdminFeeManageScheduleHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, REP_AUM_TRADE_ADMIN_FEE_MANAGE_SCHEDULE_HEADER);
	}

	/**
	 * This method is used to verify the availability of Fee Type radio button
	 * option field options
	 * 
	 * @param feeTypeOption
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/23/2020
	 */
	public boolean verifyTheAvailabilityOfFeeTypeRadioButtonOption(String feeTypeOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strFlatTypeRadioButtonOptionXpath, feeTypeOption),
				feeTypeOption);
	}

	/**
	 * This method is used to verify the availability of Fee Type radio button
	 * options field options
	 * 
	 * @param DataTable
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/23/2020
	 */
	public boolean verifyTheAvailabilityOfFeeTypeRadioButtonOptions(DataTable dropDownOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = dropDownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyTheAvailabilityOfFeeTypeRadioButtonOption(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to Select Feetype
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/24/2020
	 */
	public boolean selectFeetype(String feeType) {
		String strFeeTypeRadioButtonOption = EMPTY_STRING;
		if (feeType.equals(PROGRESSIVE_TIERED))
			strFeeTypeRadioButtonOption = PROGRESSIVE_TIERED;
		else if (feeType.equals(FLAT))
			strFeeTypeRadioButtonOption = FLAT;
		return clickElementUsingXpath(
				getFormattedLocator(strFlatTypeRadioButtonOptionSelectXpath, strFeeTypeRadioButtonOption), feeType);
	}

	/**
	 * This method is used to check whether selected FeeType label displayed above
	 * to the TIER grid or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 11/13/2020
	 */
	public boolean selectedFeeTypeLabelDisplayed(String feeTypeLabel) {
		return isElementPresentUsingXpath(getFormattedLocator(strDisplaySelectedFeeTypeOptionXpath, feeTypeLabel),
				LPLCoreConstents.getInstance().LOWEST, feeTypeLabel);
	}

	/**
	 * This method is used to verify the availability of filter criteria fields
	 * under LPL SWS/SWS Fee fee report
	 * 
	 * @param filterCriteriaOptions
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-02-2020
	 */
	public boolean verifyFilterCriteriaFieldsunderLPLSWSorSWSFeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldunderLPLSWSorSWSfeeReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of filter criteria fields
	 * under LPL SWS/SWS fee report
	 * 
	 * @param filterCriteriaOption
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-02-2020
	 */
	public boolean verifyFilterCriteriaFieldunderLPLSWSorSWSfeeReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strLPLSWSorSWSFeeReportSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to verify the availability of filter criteria date fields
	 * under LPL SWS/SWS fee report
	 * 
	 * @param filterCriteriaOptions
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-02-2020
	 */
	public boolean verifyFilterCriteriaDateFieldsunderLPLSWSorSWSfeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaDateFieldunderLPLSWSorSWSfeeReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of filter criteria fields
	 * under LPL SWS/SWS fee report
	 * 
	 * @param filterCriteriaOption
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-02-2020
	 */
	public boolean verifyFilterCriteriaDateFieldunderLPLSWSorSWSfeeReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strLPLSWSorSWSFeeReportDateSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to verify the availability of Result Column Name under
	 * LPL SWS/SWS fee report
	 * 
	 * @param filterCriteriaOptions
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-02-2020
	 */
	public boolean verifyAvailabilityofResultColumnNameunderLPLSWSorSWSFeeReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyResultColumnNameunderLPLSWSorSWSfeeReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to verify the availability of Result Column Name under
	 * LPL SWS/SWS fee report
	 * 
	 * @param filterCriteriaOption
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-02-2020
	 */
	public boolean verifyResultColumnNameunderLPLSWSorSWSfeeReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strLPLSWSorSWSFeeAllTableHeaderXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * Firm Assignment Report Options
	 * 
	 * @param filterCriteriaOptions
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-04-2020
	 */
	public boolean verifyFilterCriteriaFieldsunderFirmAssignmentReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldunderFirmAssignmentReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * Firm Assignment Report Options
	 * 
	 * @param filterCriteriaOption
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-04-2020
	 */
	public boolean verifyFilterCriteriaFieldunderFirmAssignmentReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strRepAssignReportSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);

	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * Firm Assignment Report Options
	 * 
	 * @param filterCriteriaOptions
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-04-2020
	 */
	public boolean verifyFilterCriteriaDateFieldsunderFirmAssignmentReport(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaDateFieldunderFirmAssignmentReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of date filter criteria fields
	 * under Firm Assignment Report Options
	 * 
	 * @param filterCriteriaOption
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-04-2020
	 */
	public boolean verifyFilterCriteriaDateFieldunderFirmAssignmentReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strRepAssignReportDateSearchOptionsXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to check The Availability of Schedule Type DropDown
	 * Options under Firm Assignment Report Options
	 * 
	 * @param dropDownOptions
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-04-2020
	 */
	public boolean verifyFilterCriteriaOfScheduleTypeDropDownOptionsunderFirmAssignmentReport(
			DataTable dropDownOptions) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strScheduleTypeDropDownUnderRepAssignXpath, SCHEDULE_TYPE_DROPDOWN);
		List<Map<String, String>> filters = dropDownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaOfScheduleTypeDropDownOptionunderFirmAssignmentReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of Schedule Type DropDown
	 * Option under Firm Assignment Report Options
	 * 
	 * @param dropDownOption
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-04-2020
	 */
	public boolean verifyFilterCriteriaOfScheduleTypeDropDownOptionunderFirmAssignmentReport(String dropDownOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strScheduleTypeDropDownOptionsUnderRepAssignXpath, dropDownOption),
				LPLCoreConstents.getInstance().LOWEST, dropDownOption + OPTION);
	}

	/**
	 * This method is used to check The Availability of Assignment Status Dropdown
	 * Options Firm Assignment Report Options
	 * 
	 * @param dropDownOptions
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-04-2020
	 */
	public boolean verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionsUnderFirmAssignmentReport(
			DataTable dropDownOptions) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strAssignmnetDropDownOptionUnderRepAssignXpath, ASSIGNMENT_STATUS_DROPDOWN);
		List<Map<String, String>> filters = dropDownOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionUnderFirmAssignmentReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of Assignment Status Dropdown
	 * Option under Firm Assignment Report Options
	 * 
	 * @param dropDownOption
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-04-2020
	 */
	public boolean verifyFilterCriteriaOfSelectAssignmentStatusDropdownOptionUnderFirmAssignmentReport(
			String dropDownOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strAssignmnetDropDownOptionsUnderRepAssignXpath, dropDownOption),
				LPLCoreConstents.getInstance().LOWEST, dropDownOption + OPTION);
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * AUM - by Program report Options
	 * 
	 * @param filterCriteriaOptions
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-07-2020
	 */
	public boolean verifyAvailabilityOfAUMByProgramResultColumnHeaders(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldunderLPLSWSAumByProgramReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * AUM - by Program report Options
	 * 
	 * @param filterCriteriaOption
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-07-2020
	 */
	public boolean verifyFilterCriteriaFieldunderLPLSWSAumByProgramReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strAUMByProgramAllTableHeaderXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to click on the checkbox to enable Begin Date Input
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean clicktickBoxofBeginDate() {
		// for testing purpose the tickbox is clicked twice
		clickElementUsingXpath(strBeginDatecheckboxXpath, PERIOD_BEGIN_DATE_CHKBX_OPNHST);
		// The wait is given for testing purpose as the controls load but the page
		// becomes irresponsive
		LPLCoreSync.staticWait(2000);
		return clickElementUsingXpath(strBeginDatecheckboxXpath, PERIOD_BEGIN_DATE_CHKBX_OPNHST);
	}

	/**
	 * This method is used to provide Begin Date Input
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean provideBeginDate() {
		return enterTextUsingXpath(strBeginDateXpath, testData.get("strPeriodBeginDate"), PERIOD_BEGIN_DATE_OPNHST);
	}

	/**
	 * generate Report Button for Open hist Report This method is used to provide
	 * Begin Date Input
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean clickGenerateReportButtonOpen() {
		clickElementUsingXpath(strGenerateButtonXpath, GNRT_RPRT_BTTN_OPNHST);
		// The wait is given for testing purpose as the controls load but the page
		// becomes irresponsive
		LPLCoreSync.staticWait(5000);
		return clickElementUsingXpath(strGenerateButtonXpath, GNRT_RPRT_BTTN_OPNHST);
	}

	/**
	 * This method is used to validate SWS Fee Type Added in Header
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean validateSWSFeeTypeinHeader() {
		return isElementPresentUsingXpath(strSWSFeeTypeHeaderXpath, LPLCoreConstents.getInstance().HIGHEST,
				SWS_FEE_TYPE_HDR);
	}

	/**
	 * This method is used to provide End Date Input
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean provideEndDate() {
		waitTillVisibleUsingXpath(strPeriodEndDateXpath, LPLCoreConstents.getInstance().HIGHEST,
				PERIOD_END_DATE_OPNHST);
		clickElementUsingXpath(strPeriodEndDateXpath, PERIOD_END_DATE_OPNHST);
		return enterTextUsingXpath(strPeriodEndDateXpath, testData.get("strPeriodEndDate"), PERIOD_END_DATE_OPNHST);
	}

	/**
	 * This method is used to Click Report Grid Arrow
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean clickReportArrowButtonOpen() {
		waitTillVisibleUsingXpath(strReportArrowButtonXpath, LPLCoreConstents.getInstance().HIGHEST, RPRT_ARROW_OPNHST);
		return clickElementUsingXpath(strReportArrowButtonXpath, RPRT_ARROW_OPNHST);
	}

	/**
	 * This method is used to Validate the header
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean validateOpenHistoricalHeader(DataTable headerOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = headerOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingOpenHistTableHeaderText(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to validate individual header element
	 * 
	 * @return boolean
	 * @author abagchi
	 * @since 12/1/2020
	 */
	public boolean checkIfElementExistUsingOpenHistTableHeaderText(String tableHeaderTextText) {
		return isElementPresentUsingXpath(getFormattedLocator(strTableHeaderXpath, tableHeaderTextText),
				tableHeaderTextText);
	}

	/**
	 * This method is used to verify the availability of Standard Flat Fee schedule
	 * - Trade Fee under Schedule Name column
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/17/2020
	 */
	public boolean verifyAvailabilityOfStandardFlatFeeSchedueTradeFee() {
		return isElementPresentUsingXpath(strStandardFlatFeescheduleTradeFeeScheduleXpath,
				LPLCoreConstents.getInstance().LOWEST, STANDARD_FEE_SCHEDULE_TRADE_FEE_LINK);
	}

	/**
	 * This method is used to Click on Standard Flat Feeschedule - Trade Fee link
	 * under Schedule Name
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean clickonStandardFlatFeescheduleTradeFeeLinkUnderScheduleName() {
		return clickElementUsingXpath(strStandardFlatFeescheduleTradeFeeScheduleXpath,
				STANDARD_FEE_SCHEDULE_TRADE_FEE_LINK);
	}

	/**
	 * This method is used to verify the the Schedule popup name is displaying as
	 * Standard Flat Feeschedule - Trade Fee - Flat Fee
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/17/2020
	 */
	public boolean verifySchedulePopUpNameIsDisplayingAsStandardFlatFeeScheduleTradeFeeFlatFee() {
		return isElementPresentUsingXpath(strStandardFlatFeescheduleTradeFeeFlatFeeHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, STANDARD_FEE_SCHEDULE_TRADE_FEE_FLAT_FEE);
	}

	/**
	 * This method is used to Click on REP AUM Standard Schedule Name Column
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean clickonRepAUMStandardUnderScheduleNameColumn() {
		return clickElementUsingXpath(strRepAUMStandardScheduleLinkXpath, REP_AUM_STANDARD_LINK);
	}

	/**
	 * This method is used to verify verify that schedule popup name is displaying
	 * as Rep AUM Standard - Tier Structure
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean verifytheSchedulePopUpNameIsDisplayingAsRepAUMStandardTierStructure() {
		return isElementPresentUsingXpath(strRepAUMStandardTierStructureHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, REP_AUM_STANDARD_TIER_STRUCTURE);
	}

	/**
	 * This method is used to Click on SWS MS Standard 23bps Schedule Name Column
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean clickonMSStandard23bpsUnderScheduleNameColumn() {
		return clickElementUsingXpath(strMSStandard23bpsScheduleLinkXpath, PREMIUM_MS_STANDARD_LINK);
	}

	/**
	 * This method is used to verify verify that schedule popup name is displaying
	 * as SWS MS Standard - Tier Structure
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean verifyTheAvailabilityofMSStandard23bpsProgressiveScheduleLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strMSStandard23bpsScheduleHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				SWS_MS_STANDARD_TIER_STRUCTURE);
	}

	/**
	 * This method is used to Click on SWS MWP Standard 23bps Schedule Name Column
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean clickonMWPStandard23bpsUnderScheduleNameColumn() {
		return clickElementUsingXpath(strMWPStandard23bpsScheduleLinkXpath, PREMIUM_MWP_STANDARD_LINK);
	}

	/**
	 * This method is used to verify verify that schedule popup name is displaying
	 * as MWP Standard - Tier Structure
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean verifyTheAvailabilityofMWPStandardSchedule23bpsProgressiveLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strMWPStandard23bpsScheduleHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				SWS_MWP_STANDARD_TIER_STRUCTURE);
	}

	/**
	 * This method is used to Click on SAMII Standard 18bps Schedule Name Column
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean clickonSAMIIStandard18bpsUnderScheduleNameColumn() {
		return clickElementUsingXpath(strSAMIIStandard23bpsScheduleLinkXpath, PREMIUM_SAM2_STANDARD_LINK);
	}

	/**
	 * This method is used to verify verify that schedule popup name is displaying
	 * as SWS SAMII Standard 18bps - Progressive Tier Structure
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-17-2020
	 */
	public boolean verifyTheAvailabilityofSAMIIStandard18bpsProgressiveScheduleLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strSAMIIStandard23bpsScheduleHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, SWS_SAM2_STANDARD_TIER_STRUCTURE);
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * SWS Fee Schedule report Options
	 * 
	 * @param filterCriteriaOptions
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-18-2020
	 */
	public boolean verifyAvailabilityOfSWSFeeScheduleReportColumnHeader(DataTable filterCriteriaOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = filterCriteriaOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyFilterCriteriaFieldunderSWSFeeScheduleReport(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * SWS Fee Schedule report Options
	 * 
	 * @param filterCriteriaOption
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12-18-2020
	 */
	public boolean verifyFilterCriteriaFieldunderSWSFeeScheduleReport(String filterCriteriaOption) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strSWSFeeScheduleAllTableHeaderXpath, filterCriteriaOption),
				LPLCoreConstents.getInstance().LOWEST, filterCriteriaOption + OPTION);
	}

	/**
	 * This method is used to enter Firm in Search Firm text box
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12/24/2020
	 */
	public boolean iEnterFirminSearchFIRMTextbox() {
		return enterTextUsingXpath(strSearchFirmXpath, testData.get("strSearchFirm"), SEARCH_FIRM);
	}

	/**
	 * This method is used to verify Submit button current state in create
	 * assignment screen
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 12-24-2020
	 */
	public boolean iVerifySubmitButtonIsState(String buttonState) {
		boolean blnResult = false;
		if (buttonState.equals(ENABLED_TEXT))
			blnResult = isElementPresentUsingXpath(strSumbitButtonEnabledXpath, LPLCoreConstents.getInstance().HIGHEST,
					SUBMIT_BUTTON);
		else if (buttonState.equals(DISABLED_TEXT))
			blnResult = isElementPresentUsingXpath(strSumbitButtonDisabledXpath, LPLCoreConstents.getInstance().HIGHEST,
					SUBMIT_BUTTON);
		return blnResult;
	}

	/**
	 * This function is used to click on OK button
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 01/04/2021
	 **/
	public boolean clickOnOKbutton() {
		waitTillVisibleUsingXpath(strOkButtonXpath, LPLCoreConstents.getInstance().HIGHEST, OK_BUTTON);
		return clickElementUsingXpath(strOkButtonXpath, OK_BUTTON);
	}

	/**
	 * This function is used to click on Yes button in Assignment cancel pop up
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 01/04/2021
	 **/
	public boolean clickOnYesButtonInCancelPopUp() {
		waitTillVisibleUsingXpath(strYesButtonXpath, LPLCoreConstents.getInstance().HIGHEST, YES_BUTTON);
		return clickElementUsingXpath(strYesButtonXpath, YES_BUTTON);
	}

	/**
	 * This method is used to verify verify availability of Standard Flat
	 * Feeschedule - Admin Fee data under Custom Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 01-13-2021
	 */
	public boolean verifyStandardFlatFeeScheduleAdminFeeDisplayed() {
		return isElementPresentUsingXpath(strStandardFlatFeeScheduleAdminFeeXpath,
				LPLCoreConstents.getInstance().LOWEST, STANDARD_FLAT_FEE_SCHEDULE_ADMIN_FEE);
	}

	/**
	 * This method is used to verify Open Historical Billing Details report opened
	 * in new tab or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 01-19-2021
	 */
	public boolean historicalBillingDetailsReportOpenedInNewTab() {
		boolean blnResult;
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		blnResult = isElementPresentUsingXpath(strHistoricalViewReportButtonXpath,
				LPLCoreConstents.getInstance().HIGHEST, HISTORICAL_BILLING_DETAILS_REPORT);
		return blnResult;
	}

	/**
	 * This method is used to verify Onboarding Period Termination Warnings report
	 * opened in new tab or not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 01-19-2021
	 */
	public boolean onboardingPeriodTerminationWarningReportOpenedInNewTab() {
		browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		waitTillVisibleUsingXpath(
				getFormattedLocator(strCheckWithDivTextXpath, ONBOARDING_PERIOD_TERMINATION_WARNINGS_REPORT),
				LPLCoreConstents.getInstance().HIGHEST, ONBOARDING_PERIOD_TERMINATION_WARNINGS_REPORT);
		return isElementPresentUsingXpath(
				getFormattedLocator(strCheckWithDivTextXpath, ONBOARDING_PERIOD_TERMINATION_WARNINGS_REPORT),
				LPLCoreConstents.getInstance().HIGHEST, ONBOARDING_PERIOD_TERMINATION_WARNINGS_REPORT);
	}

	/**
	 * This method is used to select Onboarding in Schedule type drop down under
	 * Rep/Firm Assignment Tracking tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 01/21/2021
	 */
	public void selectOnboardingScheduleTypeOption(String optionToSelect) {
		selectValueFromDropdownUsingXpath(strScheduleTypeXpath, optionToSelect, optionToSelect);
	}

	/**
	 * This method is used to I select Approved in Request Status drop down under
	 * Rep/Firm Assignment Tracking tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 01/21/2021
	 */
	public void selectApprovedRequestStatusOption(String optionToSelect) {
		selectValueFromDropdownUsingXpath(strRequestStatusDropdownXpath, optionToSelect, optionToSelect);
	}

	/**
	 * This function is used to clear end date in change assignment screen
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 01/21/2021
	 **/
	public boolean clearEnddateInChangeAssignmentScreen() {
		waitTillVisibleUsingXpath(strEndDateinUpdateXpath, LPLCoreConstents.getInstance().HIGHEST, END_DATE);
		clearTextUsingXpath(strEndDateinUpdateXpath);
		return clickElementUsingXpath(strNotesInUpdateXpath, ENTER_NOTES);
	}

	/**
	 * This function is used to check Submit button enabled or disabled in change
	 * assignment screen
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 01/21/2021
	 **/
	public boolean checkSubmitButtonCurrentState(String buttonCurrentState) {
		boolean blnResult = false;
		if (buttonCurrentState.equals(ENABLE))
			blnResult = isElementPresentUsingXpath(strSumbitButtonEnabledInUpdateXpath,
					LPLCoreConstents.getInstance().HIGHEST, SUBMIT_BUTTON);
		else if (buttonCurrentState.equals(DISABLE))
			blnResult = isElementPresentUsingXpath(strSumbitButtonDisabledInUpdateXpath,
					LPLCoreConstents.getInstance().HIGHEST, SUBMIT_BUTTON);
		return blnResult;
	}

	/**
	 * This method is used to verify Progressive Tier Structure is displaying in
	 * popup name
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 02-10-2021
	 */
	public boolean verifythatProgressiveTierStructureisdisplayinginPopupName() {
		return isElementPresentUsingXpath(strProgressiveTierStructureHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				PROGRESSIVE_TIER_STRUCTURE);
	}

	/**
	 * This method is used to click on MS Standard Schedule Clone icon
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 02/10/2021
	 */
	public boolean iclickonMSStandardScheduleCloneicon() {
		waitTillVisibleUsingXpath(strMSStandardScheduleCloneIconXpath, LPLCoreConstents.getInstance().HIGHEST,
				CLONE_ICON);
		return clickElementUsingXpath(strMSStandardScheduleCloneIconXpath, CLONE_ICON);
	}

	/**
	 * This method is used to verify the display of MS Standard Schedule Clone popup
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 02-10-2021
	 */
	public boolean verifythedisplayofMSStandardScheduleClonePopup() {
		return isElementPresentUsingXpath(strMSStandardCloneHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				NEW_SCHEDULE_CLONED_FROM_MS_STANDARD_NEW);
	}

	/**
	 * This method is used to Click on newly added schedule name hyperlink
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 02-12-2021
	 */
	public boolean clickonScheduleNameHyperLink() {
		return clickElementUsingXpath(
				getFormattedLocator(strScheduleNameHyperLinkXpath, testData.get("strScheduleName")),
				SCHEDULE_NAME_HEPERLINK);
	}

	/**
	 * This method is used to verify the FEE PERCENTAGE value
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 02-12-2021
	 */
	public boolean valueIsinBpsInScheduleNameHyperLink(String feeType) {
		boolean blnResult = false;
		if (feeType.equals(FLAT))
			blnResult = isElementPresentUsingXpath(strFeePercentageTextboxXpath, LPLCoreConstents.getInstance().HIGHEST,
					FEE_PERCENTAGE_VALUE);
		else if (feeType.equals(TIERED))
			blnResult = isElementPresentUsingXpath(strTieredSchedulenameHypelinkXpath,
					LPLCoreConstents.getInstance().HIGHEST, FEE_PERCENTAGE_VALUE);
		else if (feeType.equals(PROGRESSIVE_TIERED))
			blnResult = isElementPresentUsingXpath(strTieredSchedulenameHypelinkXpath,
					LPLCoreConstents.getInstance().HIGHEST, FEE_PERCENTAGE_VALUE);
		return blnResult;
	}

	/**
	 * This method is used to verify the FEE PERCENTAGE value
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 02-12-2021
	 */
	public boolean valueIsinBpsInCopyAndEditSchedulePopUp(String feeType) {
		boolean blnResult = false;
		if (feeType.equals(FLAT))
			blnResult = isElementPresentUsingXpath(strFlatCloneScheduleValueXpath,
					LPLCoreConstents.getInstance().HIGHEST, FEE_PERCENTAGE_VALUE);
		else if (feeType.equals(TIERED))
			blnResult = isElementPresentUsingXpath(strTieredCloneScheduleValueXpath,
					LPLCoreConstents.getInstance().HIGHEST, FEE_PERCENTAGE_VALUE);
		else if (feeType.equals(PROGRESSIVE_TIERED))
			blnResult = isElementPresentUsingXpath(strTieredCloneScheduleValueXpath,
					LPLCoreConstents.getInstance().HIGHEST, FEE_PERCENTAGE_VALUE);
		return blnResult;
	}

	/**
	 * This method is used to click on close button icon
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 02-12-2021
	 */
	public boolean clickonCloseButtonIcon() {
		return clickElementUsingXpath(strCloseIconXpath, CLOSE_ICON);
	}

	/**
	 * This method is used to click on Copy schedule
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-02-2021
	 */
	public boolean clickonCopyScheduleIcon() {
		return clickElementUsingXpath(strCopyScheduleIconXpath, CLONE_ICON);
	}

	/**
	 * This method is used to click on Copy schedule
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-02-2021
	 */
	public boolean clickonCancel() {
		return clickElementUsingXpath(strCancelInCloneSchedulePopupXpath, CANCEL_BUTTON);
	}

	/**
	 * This method is used to click on Copy schedule
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-02-2021
	 */
	public boolean clickonEdit() {
		return clickElementUsingXpath(strEditIconXpath, EDIT_ICON);
	}

	/**
	 * This method is used to select MAN Platofrm in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-04-2021
	 */
	public boolean selectMANinPLATFORMDropdownOptionsinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewSchedulePlatformDropdownXpath, MAN, MAN);
	}

	/**
	 * This method is used to check The Availability of Entity Type Dropdown options
	 * Options
	 * 
	 * @param entityType
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-11-2021
	 */
	public boolean verifytheAvailabilityofEntityTypeDropDown(String entityType, String screenType) {
		switch (screenType.trim()) {
		case SCHEDULE_MANAGEMENT:
			return isElementPresentUsingXpath(
					getFormattedLocator(strEntityTypeDropDownOptionInScheduleXpath, entityType),
					LPLCoreConstents.getInstance().HIGHEST, entityType);
		case REP_ASSIGNMENT:
			return isElementPresentUsingXpath(
					getFormattedLocator(strEntityTypeDropDownOptionInAssignmentXpath, entityType),
					LPLCoreConstents.getInstance().HIGHEST, entityType);
		case AUM_BY_PROGRAM:
			return isElementPresentUsingXpath(
					getFormattedLocator(strEntityTypeDropDownOptionInAumByProgramXpath, entityType),
					LPLCoreConstents.getInstance().HIGHEST, entityType);
		case FIRM_ASSIGNMENT_REPORT:
			return isElementPresentUsingXpath(
					getFormattedLocator(strEntityTypeDropDownOptionInFirmAssignmentXpath, entityType),
					LPLCoreConstents.getInstance().HIGHEST, entityType);
		case SWS_FEE_SCHEDULE_REPORT:
			return isElementPresentUsingXpath(
					getFormattedLocator(strEntityTypeDropDownOptionInSWSFeeScheduletXpath, entityType),
					LPLCoreConstents.getInstance().HIGHEST, entityType);
		default:
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Validate if " + screenType + " screen displayed or not",
					"Proper " + screenType + " screen shoud be displayed",
					"Proper " + screenType + " screen is displayed", "Invalid [" + screenType + " screen] is passed");

		}
		return false;
	}

	/**
	 * This method is used to check The Availability of Entity Type Dropdown options
	 * Field Options
	 * 
	 * @param entityTypes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-11-2021
	 */
	public boolean verifytheAvailabilityofEntityTypeDropDownFieldOptions(DataTable entityTypes, String screenType) {
		boolean blnResult = false;
		List<Map<String, String>> filters = entityTypes.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofEntityTypeDropDown(filterName, screenType);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to select option in the Entity Type Dropdown List
	 * 
	 * @param optionToSelect
	 * @param screentype
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-11-2021
	 */
	public boolean selectOptionInEntityTypeDropdown(String optionToSelect, String screentype) {
		switch (screentype.trim()) {
		case SCHEDULE_MANAGEMENT:
			return selectValueFromDropdownUsingXpath(strEntityTypeDropDownInScheduleXpath, optionToSelect,
					ENTITY_TYPE_DROPDOWN);
		case REP_ASSIGNMENT:
			return selectValueFromDropdownUsingXpath(strEntityTypeDropDownInAssignmentXpath, optionToSelect,
					ENTITY_TYPE_DROPDOWN);
		case AUM_BY_PROGRAM:
			return selectValueFromDropdownUsingXpath(strEntityTypeDropDownInAumProgramXpath, optionToSelect,
					ENTITY_TYPE_DROPDOWN);
		case FIRM_ASSIGNMENT_REPORT:
			return selectValueFromDropdownUsingXpath(strEntityTypeDropDownInFirmAssignmentXpath, optionToSelect,
					ENTITY_TYPE_DROPDOWN);
		case SWS_FEE_SCHEDULE_REPORT:
			return selectValueFromDropdownUsingXpath(strEntityTypeDropDownInFirmAssignmentXpath, optionToSelect,
					ENTITY_TYPE_DROPDOWN);
			//strSwsFeeScheduleReportXpath
		default:
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Validate if " + screentype, "Proper " + screentype + " passed",
					"Proper " + screentype + " is passed", "Invalid [" + screentype + "] is passed");
		}
		return false;
	}

	/**
	 * This method is used to check The Availability of Entity Type Dropdown option
	 * Options
	 * 
	 * @param entityTypes
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 03-11-2021
	 */
	public boolean verifytheAvailabilityofEntityTypeDropDowninRepAssignmentScreen(String entityTypes) {
		return isElementPresentUsingXpath(
				getFormattedLocator(strEntityTypeDropDownOptionInAssignmentXpath, entityTypes), entityTypes);
	}

	/**
	 * This method is used to Click On Delete icon
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03/12/2021
	 */
	public boolean iclickonDeleteicon() {
		waitTillVisibleUsingXpath(strOtherScheduleDeleteActionButtonXpath, LPLCoreConstents.getInstance().HIGHEST,
				DELETE_ACTION_BUTTON);
		return clickElementUsingXpath(strOtherScheduleDeleteActionButtonXpath, DELETE_ACTION_BUTTON);
	}

	/**
	 * This method is used to select MAS Platform in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-12-2021
	 */
	public boolean selectMASinPLATFORMDropdownOptionsinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewSchedulePlatformDropdownXpath, MAS, MAS);
	}

	/**
	 * This method is used to select SWM Platform in New Schedule window
	 * 
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-12-2021
	 */
	public boolean selectSWMinPLATFORMDropdownOptionsinNewScheduleWindow() {
		return selectValueFromDropdownUsingXpath(strNewSchedulePlatformDropdownXpath, SWM, SWM);
	}

	/**
	 * This method is used to check select MAN in the Select Platform Dropdown List
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean selectMANinSelectPlatformDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectPlatformDropdownXpath, MAN, MAN);
	}

	/**
	 * This method is used to check select MAS in the Select Platform Dropdown List
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean selectMASinSelectPlatformDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectPlatformDropdownXpath, MAS, MAS);
	}

	/**
	 * This method is used to check select SWM in the Select Platform Dropdown List
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean selectSWMinSelectPlatformDropdownList() {
		return selectValueFromDropdownUsingXpath(strSelectPlatformDropdownXpath, SWM, SWM);
	}

	/**
	 * This method is used to verify The Availability of SWS Hybrid Manager Access
	 * Network Standard 20bps under Standard Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean verifyTheAvailabilityofSWSHybridManagerAccessNetworkStandard20bpsLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strSWSHybridManagerAccessNetworkStandard20bpsLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, SWS_HYBRID_MANAGER_ACCESS_NETWORK_STANDARD_20BPS);
	}

	/**
	 * This method is used to verify The Availability of SWS Hybrid Manager Access
	 * Select Standard 20bps under Standard Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean verifyTheAvailabilityofSWSHybridManagerAccessSelectStandard20bpsLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strSWSHybridManagerAccessSelectStandard20bpsLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, SWS_HYBRID_MANAGER_ACCESS_SELECT_STANDARD_20BPS);
	}

	/**
	 * This method is used to verify The Availability of SWS Hybrid SWM II Standard
	 * 15bps under Standard Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean verifyTheAvailabilityofSWSHybridSWSHybridSWMII15bpsLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strSWSHybridSWMIIStandard15bpsLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, SWS_HYBRID_SWMII_STANDARD_15BPS);
	}

	/**
	 * This method is used to Click on SWS Hybrid Manager Access Network Standard
	 * 20bps Schedule Name Column
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean clickonSWSHybridManagerAccessNetworkStandard20bpsLinkUnderScheduleNameColumn() {
		return clickElementUsingXpath(strSWSHybridManagerAccessNetworkStandard20bpsLinkXpath,
				SWS_HYBRID_MANAGER_ACCESS_NETWORK_STANDARD_20BPS);
	}

	/**
	 * This method is used to Click on SWS Hybrid Manager Access Select Standard
	 * 20bps Schedule Name Column
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean clickonSWSHybridManagerAccessSelectStandard20bpsLinkUnderScheduleNameColumn() {
		return clickElementUsingXpath(strSWSHybridManagerAccessSelectStandard20bpsLinkXpath,
				SWS_HYBRID_MANAGER_ACCESS_SELECT_STANDARD_20BPS);
	}

	/**
	 * This method is used to Click on SWS Hybrid SWM II Standard 15bps Schedule
	 * Name Column
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean clickonSWSHybridSWMIIStandard15bpsLinkUnderScheduleNameColumn() {
		return clickElementUsingXpath(strSWSHybridSWMIIStandard15bpsLinkXpath, SWS_HYBRID_SWMII_STANDARD_15BPS);
	}

	/**
	 * This method is used to verify verify that schedule popup name is displaying
	 * as SWS Hybrid Manager Access Network Standard 20bps - Tier Structure
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean verifyTheAvailabilityofSWSHybridManagerAccessNetworkStandard20bpsProgressiveScheduleLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strSWSHybridManagerAccessNetworkStandard20bpsScheduleHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, SWS_HYBRID_MANAGER_ACCESS_NETWORK_STANDARD_20BPS);
	}

	/**
	 * This method is used to verify verify that schedule popup name is displaying
	 * as SWS Hybrid Manager Access Select Standard 20bps - Tier Structure
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean verifyTheAvailabilityofSWSHybridManagerAccessSelectStandard20bpsProgressiveScheduleLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strSWSHybridManagerAccessSelectStandard20bpsScheduleHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, SWS_HYBRID_MANAGER_ACCESS_SELECT_STANDARD_20BPS);
	}

	/**
	 * This method is used to verify verify that schedule popup name is displaying
	 * as SWS Hybrid SWM II Standard 15bps - Progressive Tier Structure
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-15-2021
	 */
	public boolean verifyTheAvailabilityofSWSHybridSWMIIStandard15bpsProgressiveScheduleLinkunderStandardSchedule() {
		return isElementPresentUsingXpath(strSWSHybridSWMIIStandard15bpsHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, SWS_HYBRID_SWMII_STANDARD_15BPS);
	}

	/**
	 * This method is used to verify The Availability of clone icon under Standard
	 * Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 03-16-2021
	 */
	public boolean verifyTheAvailabilityofCloneIconunderStandardSchedule() {
		return isElementPresentUsingXpath(strStandardScheduleCloneIconXpath, LPLCoreConstents.getInstance().LOWEST,
				CLONE_ICON);
	}

	/**
	 * This method is used to verify Schedule name hyperlink under Rep/Firm
	 * Assignment Tracking tab Schedule
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 05-19-2021
	 */
	public boolean verifyScheduleNameHyperLink() {
		return isElementPresentUsingXpath(strScheduleNameHyperLinkInRepAssignmentXpath,
				LPLCoreConstents.getInstance().HIGHEST, SCHEDULE_NAME_HEPERLINK);
	}

	/**
	 * This method is used to check The Availability of filter criteria fields under
	 * AUM - by Program report Options
	 * 
	 * @param tableHeader
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 04-09-2021
	 */
	public boolean verifyAvailabilityOfFirmAssignmentReportColumnHeader(String tableHeader) {
		return isElementPresentUsingXpath(getFormattedLocator(strFirmAssignmentReportTableHeaderXpath, tableHeader),
				LPLCoreConstents.getInstance().LOWEST, tableHeader + OPTION);
	}

	/**
	 * This method is used to verify the Firm Assignment Report result column
	 * headers
	 * 
	 * @param tableHeaders
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 04-09-2021
	 */
	public boolean verifyAvailabilityOfFirmAssignmentReportColumnHeaders(DataTable tableHeaders) {
		boolean blnResult = false;
		List<Map<String, String>> filters = tableHeaders.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyAvailabilityOfFirmAssignmentReportColumnHeader(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to This method is used to verify the availability of new
	 * Platform field in Modify Assignment screen
	 * 
	 * @param screenType
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 04-22-2021
	 */
	public boolean verifyTheAvailabilityofPlatformField(String screenType) {
		switch (screenType.trim()) {
		case SCHEDULE_ASSIGNMENT_LIST:
			return isElementPresentUsingXpath(strPlatformTypeHeaderInAssignmentXpath, screenType);
		case EXISTING_SCHEDULE_ASSIGNMENT_LIST:
			return isElementPresentUsingXpath(strPlatformTypeHeaderInExistingAssignmentXpath, screenType);
		default:
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Validate the availability of new Platform field under" + screenType + " screen displayed or not",
					"Proper Platform field under" + screenType + " screen shoud be displayed",
					"Proper Platform field under" + screenType + " screen is displayed",
					"Invalid [" + screenType + " screen] is passed");
		}
		return false;
	}

	/**
	 * This method is used to select Inactive Assignment status option under
	 * Rep/Firm Assignment Tracking tab
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 05/21/2020
	 */
	public void selectInActiveAssignmentOption() {
		selectValueFromDropdownUsingXpath(strAssignmentStatusDropdownXpath, INACTIVE_STATUS, ASSIGNMENT_STATUS);
	}

	/**
	 * This method is used to verify the current state of Modify assignment option
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 05-21-2021
	 */

	public boolean verifyModifyAssignmentOptionDisabled() {
		clickElementUsingXpath(strActionDropdownXpath, ACTION_DROPDOWN);
		return isElementPresentUsingXpath(strModifyAssignmentOptionDisabledXpath, LPLCoreConstents.getInstance().LOWEST,
				MODIFY_ASSIGNMENT_OPTION_DISABLED);
	}

	/**
	 * This method is used to select All Assignment Checkbox
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 05-21-2021
	 */

	public boolean selectAllAssignmentCheckbox() {
		return clickElementUsingXpath(strSelectAllCheckboxXpath, SELECTALL_CHECKBOX);
	}

	/**
	 * This method is used to select RIA CUSTODY PLATFORM in the Pricing Model
	 * Dropdown or Not
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 06-18-2021
	 */
	public boolean selectRIACUSTODYPLATFORMinthePricingModelDropdownList() {
		refreshTheWebpage();
		return selectValueFromDropdownUsingXpath(strProgramTypeDropDownXpath, RIA_CUSTODY_PLATFORM,
				PRICING_MODEL_DROPDOWN);
	}

	/**
	 * This method is used to verify the Availability of Fee Component DropDown Type
	 * for RIA Custody Platform
	 * 
	 * @param feeComponentType1
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 06-18-2021
	 */
	public boolean verifytheAvailabilityofFeeComponentDropDownFieldOptionsforRIACustodyPlatform(
			DataTable feeComponentTypes1) {
		boolean blnResult = false;
		blnResult = clickElementUsingXpath(strFeeComponentDropDownXpath, FEE_COMPONENT_DROPDOWN);
		List<Map<String, String>> filters = feeComponentTypes1.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifytheAvailabilityofFeeComponentDropDownTypes(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to Select RIA Custody Platform Fee
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 06-18-2021
	 */
	public boolean iSelectRIACustodyPlatformFee() {
		return selectValueFromDropdownUsingXpath(strFeeComponentDropDownXpath, RIA_CUSTODY_PLATFORM_FEE,
				FEE_COMPONENT_DROPDOWN);
	}

	/**
	 * This method is used to check RIA CUSTODY PLATFORM - RIA Custody Platform Fee
	 * : Manage Schedule Page Load
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 06-18-2021
	 */
	public boolean iShouldLandOnRIACUSTODYPLATFORMManageSchedulePage() {
		// Check for create new schedule button and then click
		waitTillVisibleUsingXpath(strCreateNewScheduleButtonXpath, LPLCoreConstents.getInstance().HIGHEST,
				CREATE_NEW_SCHEDULE_BUTTON);
		return isElementPresentUsingXpath(strRIACUSTODYPLATFORMManageScheduleHeaderXpath,
				LPLCoreConstents.getInstance().LOWEST, RIA_CUSTODY_PLATFORM_MANAGE_SCHEDULE_HEADER);
	}

	public boolean verifytheavailabilityofIFAHybridSWMIIStandard5bpsunderScheduleNamecolumn() {
		return isElementPresentUsingXpath(strIFAHybridSWMIIStandard5bpsScheduleLinkXpath,
				LPLCoreConstents.getInstance().LOWEST, IFAHYB_SWM_STANDARD_LINK);
	}

	/**
	 * This method is used to verify IFA/Hybrid RIA Entity Type under Standard
	 * Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 06-24-2021
	 */
	public boolean verifyIFAorHybridRIAEntityTypeUnderStandardSchedule() {
		// Refresh the webpage since Standard Schedule is not displayed due to
		// load issue.
		refreshTheWebpage();
		return isElementPresentUsingXpath(strEntityTypeStandardScheduleXpath, LPLCoreConstents.getInstance().LOWEST,
				IFA_HYBRID_RIA_ENTITY_TYPE);
	}

	/**
	 * This method is used to verify IFA/Hybrid RIA Entity Type under Other Schedule
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 06-24-2021
	 */
	public boolean verifyIFAorHybridRIAEntityTypeUnderOtherSchedule() {
		return isElementPresentUsingXpath(strEntityTypeCustomScheduleXpath, LPLCoreConstents.getInstance().LOWEST,
				IFA_HYBRID_RIA_ENTITY_TYPE);
	}

	/**
	 * This method is used to verify Entity Type filter option is not present
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 06-24-2021
	 */
	public boolean verifyEntityTypeFilterOptionIsNotPresent() {
		return isElementPresentUsingXpath(strEntityTypeDropDownInScheduleXpath, LPLCoreConstents.getInstance().LOWEST,
				IFA_HYBRID_RIA_ENTITY_TYPE);
	}
}
