// Sample script to help you run tests through Cucumber using TestNG runner
package com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/resources/features/groupbilling.advfee/web",
    glue = "com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.steps",
    plugin = {
        "html:target/cucumber-html-report",
        "json:target/cucumber.json",
        "pretty:target/cucumber-pretty.txt",
        "usage:target/cucumber-usage.json",
        "junit:target/cucumber-results.xml",
        "com.lpl.qe.blackbird.listener.ConfigurationCucumberListener",
        "com.lpl.qe.blackbird.listener.CucumberLogger",
        "com.lpl.qe.blackbird.reporter.BlackbirdCucumberReporter"
    },
    monochrome = true,
    tags = "@Regression"
)
public class CucumberTestNGRunner_Regression extends AbstractTestNGCucumberTests {

}
