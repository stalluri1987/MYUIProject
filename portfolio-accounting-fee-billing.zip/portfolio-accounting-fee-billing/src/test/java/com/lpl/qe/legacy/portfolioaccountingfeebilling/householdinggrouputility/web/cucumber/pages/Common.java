package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import LPLCoreDriver.LPLCoreUtil;
import LPLCoreDriver.WebToolKit.Link;
import LPLCoreDriver.WebToolKit.SelectDropDown;
import LPLCoreDriver.WebToolKit.WebEdit;
import PageObjectLibrary.BNCommon;
import PageObjectLibrary.ClientManagement_AccountsTab;
import PageObjectLibrary.ClientManagement_Common;
import PageObjectLibrary.HomePage;
import PageObjectLibrary.IASTradingCommon;
import PageObjectLibrary.LoginPage;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> Common.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for Common</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * Common :
 * <p>
 * <br>
 * <b> Title: </b> AdminPortalCommon.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for Admin Portal Common</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AdminPortalCommon </br>
 * <br>
 * switchToNextWindow : This method is used to switch to the newly opened/second
 * window after closing the current window byLocator - To click on any By
 * locator</br>
 * <br>
 * click : This method is used for click on the web element and if unsuccessful
 * use JS click</br>
 * <br>
 * clickElementUsingXpath : This method is used for click on the web element
 * using xpath locator string</br>
 * <br>
 * clickElementUsingId : This method is used for click on the web element using
 * id locator string</br>
 * <br>
 * clickElementUsingCss : This method is used for click on the web element using
 * css locator string</br>
 * <br>
 * waitTillVisible : This method is used for wait for the web element(Max 10
 * secs) using By object to become visible</br>
 * <br>
 * waitTillVisibleUsingXpath : This method is used for wait for the web element
 * using xpath locator string to become visible</br>
 * <br>
 * waitTillVisibleUsingXpath : This method is used for wait for the web element
 * to be displayed using xpath locator string</br>
 * <br>
 * waitTillVisibleUsingId : This method is used for wait for the web element
 * using ID locator string to become visible</br>
 * <br>
 * waitTillVisibleUsingId : This method is used for wait for the web element to
 * be displayed using ID locator string</br>
 * <br>
 * waitTillVisibleUsingCss : This method is used for wait for the web element
 * using css locator string to become visible</br>
 * <br>
 * waitTillVisibleUsingCss : This method is used for wait for the web element to
 * be displayed using css locator string</br>
 * <br>
 * isElementPresent : This method is used for check if the web element is
 * present on the page in the given state(DISPLAYED, ENABLED,
 * DISPLAYEDANDENABLED)</br>
 * <br>
 * isElementPresentUsingXpath : This method is used for check if the web element
 * is present on the page using xpath locator and wait for 10 secs if not
 * available immediately</br>
 * <br>
 * isElementPresentUsingXpath : This method is used for check if the web element
 * is present on the page in the given state(DISPLAYED, ENABLED,
 * DISPLAYEDANDENABLED) using xpath locator</br>
 * <br>
 * isElementPresentUsingXpath : This method is used for check if the web element
 * is present on the page using xpath locator and wait for specified time if not
 * available immediately</br>
 * <br>
 * isElementPresentUsingId : This method is used for check if the web element is
 * present on the page using ID locator and wait for 10 secs if not available
 * immediately</br>
 * <br>
 * isElementPresentUsingId : This method is used for check if the web element is
 * present on the page using ID locator and wait for specified time if not
 * available immediately</br>
 * <br>
 * isElementEnabled : This method is used to check if the element is enabled. It
 * is considered as disabled if the disabled attribute is present with value
 * 'disabled'</br>
 * <br>
 * isElementPresentUsingId : This method is used for check if the web element is
 * present on the page in the given state(DISPLAYED, ENABLED,
 * DISPLAYEDANDENABLED) using ID locator</br>
 * <br>
 * isElementPresentUsingCss : This method is used for check if the web element
 * is present on the page using Css locator and wait for 10 secs if not
 * available immediately</br>
 * <br>
 * isElementPresentUsingCss : This method is used for check if the web element
 * is present on the page using Css locator and wait for specified time if not
 * available immediately</br>
 * <br>
 * isElementPresentUsingCss : This method is used for check if the web element
 * is present on the page in the given state(DISPLAYED, ENABLED,
 * DISPLAYEDANDENABLED) using Css locator</br>
 * <br>
 * getText : This method is used to retrieve text of the web element using
 * object of a WebElement</br>
 * <br>
 * getTextUsingXpath : This method is used to retrieve text from the WebElement
 * using xpath locator.</br>
 * <br>
 * getTextUsingId : This method is used to retrieve text from the WebElement
 * using ID locator.</br>
 * <br>
 * getTextUsingCss : This method is used to retrieve text from the WebElement
 * using Css locator.</br>
 * <br>
 * getTextForWebElementsUsingXpath : This method is used to retrieve text for
 * list of webelements using xpath of a WebElement</br>
 * <br>
 * getAttributeForWebElementsUsingXpath : This method is used to retrieve
 * specified attributes for list of webelements using xpath of a WebElement</br>
 * <br>
 * getTextForWebElementsUsingId : This method is used to retrieve text for list
 * of webelements using ID of a WebElement</br>
 * <br>
 * getTextForWebElementsUsingCss : This method is used to retrieve text for list
 * of webelements using Css of a WebElement</br>
 * <br>
 * getAttributeUsingXpath : This method is used to retrieve specified attribute
 * value from the WebElement using xpath locator.</br>
 * <br>
 * getAttributeForWebElement : This method is used to retrieve specified
 * attribute value from the WebElement using Weblement object.</br>
 * <br>
 * getAttributeUsingId : This method is used to retrieve specified attribute
 * value from the WebElement using ID locator.</br>
 * <br>
 * getAttributeUsingCss : This method is used to retrieve specified attribute
 * value from the WebElement using Css locator.</br>
 * <br>
 * getWebElement : This method returns WebElement object for given locator</br>
 * <br>
 * getWebElement : This method returns WebElement object for given locator.
 * Waits for specified time if element not found immediately</br>
 * <br>
 * getWebElementUsingXpath : This method returns WebElement object for given
 * xpath locator</br>
 * <br>
 * getWebElementUsingId : This method returns WebElement object for given ID
 * locator</br>
 * <br>
 * getWebElementUsingCss : This method returns WebElement object for given Css
 * locator</br>
 * <br>
 * getWebElements : This method is used to get list of webelements for the given
 * By object</br>
 * <br>
 * getWebElementsSizeUsingXpath : This method is used to get count of
 * webelements for the given xpath locator</br>
 * <br>
 * getWebElementsUsingXpath : This method is used to get list of webelements for
 * a given xpath locator</br>
 * <br>
 * getWebElementsUsingId : This method is used to get list of webelements for a
 * given id locator</br>
 * <br>
 * getWebElementsUsingCss : This method is used to get list of webelements for a
 * given Css locator</br>
 * <br>
 * getNumberOfWebElementsUsingXpath : This method is used to get number of
 * elements for given Xpath locator</br>
 * <br>
 * getNumberOfWebElementsUsingId : This method is used to get number of elements
 * for given ID locator</br>
 * <br>
 * getNumberOfWebElementsUsingCss : This method is used to get number of
 * elements for given locator</br>
 * <br>
 * enterText : This method is used to enter text using By object</br>
 * <br>
 * enterTextUsingXpath : This method is used to enter text using Xpath
 * locator</br>
 * <br>
 * enterTextUsingId : This method is used to enter text using ID locator</br>
 * <br>
 * enterTextUsingCss : This method is used to enter text using Css locator</br>
 * <br>
 * getFormattedLocator : This method is used to substitute the placeholders in
 * the given locator string with the given argument values</br>
 * <br>
 * isCheckBoxSelected : This method is used for check if the check box selected
 * on the page using Id locator</br>
 * <br>
 * checkIfCheckBoxSelected : This method is used for check if the check box
 * selected on the page using Id locator</br>
 * <br>
 * getWebElement : This method returns WebElement object for given By
 * object</br>
 * <br>
 * getCSSValueId : This method is used for getting value from the style tag</br>
 * <br>
 * getWebElementUsingXpath : This method returns WebElement object for given
 * locator string based on xpath</br>
 * <br>
 * isElementNotPresentUsingXpath : Function is used for check if the web element
 * is Not present on the page</br>
 * <br>
 * isElementNotPresentUsingXpath : Function is used for check if the web element
 * is Not present on the page for specified time</br>
 * <br>
 * isElementNotPresentUsingXpath : Function is used for check if the web element
 * is Not present on the page</br>
 * <br>
 * waitTillVisible : Function is used for wait for the max time specified to
 * check if the element is visible</br>
 * <br>
 * apply : Function is used for wait for the max time specified to check if the
 * element is visible</br>
 * <br>
 * setErrorMessage : This method is used to set the error message to strError
 * variable</br>
 * <br>
 * checkIfAllOptionsDisplayedUsingXpathSelector : This method checks the options
 * displayed or Not, As per the datatable options using dynamic xpath
 * locator</br>
 * <br>
 * validateOptions : This method is used to Validate the options are displayed
 * or not in Each tab expected options text value as well Actual value</br>
 * <br>
 * moveToElement : This method is used to move the mouse to the element
 * specified by the given xpath locator</br>
 * <br>
 * waitForPageLoading : This method is used to wait for page to load
 * completely.</br>
 * <br>
 * waitForProgressBarToDisappear : This method is used to wait for 'Loading.. '
 * progress bar to disappear</br>
 * <br>
 * waitTillInvisible : This method is used to wait for 'Loading.. ' progress bar
 * to disappear</br>
 * <br>
 * waitForPageLoading : This method is used to wait for page to load completely.
 * Max wait time is specified</br>
 * <br>
 * apply : This method is used to wait for page to load completely. Max wait
 * time is specified</br>
 * <br>
 * selectValueFromDropdownUsingXpath : This method is used to wait for page to
 * load completely. Max wait time is specified</br>
 * <br>
 * getAttributesUsingXpath : This method is used to retrieve text for list of
 * webelements using xpathof a WebElement</br>
 *
 * @author pmanohar
 * @since 06/27/2019
 *        </p>
 */

public class Common extends LPLCoreDriver {

	public static final String TEXT_ATTRIBUTE = "text";
	public static final String DISABLED = "disabled";
	public static final String EMPTY_STRING = "";
	public static final String PLACEHOLDER = "%s";
	public static final String ENABLED = "ENABLED";
	public static final String DISPLAYED = "DISPLAYED";
	public static final String SELECTED = "SELECTED";
	public static final String AND_IT_IS_SELECTED = " And it is selected";
	public static final String AND_IT_IS_NOT_SELECTED = " And it is not selected";
	public static final String FIELD = "field";
	public static final String SPACE = " ";
	public static final String LOCATOR = "Locator: ";
	public static final String FOR = "for";
	public static final String ELEMENT = "element";
	public static final String USER_CHECKS_FOR = "User checks for";
	public static final String ELEMENT_LOCATOR_TYPE = "element.locatorType:";
	public static final String USER_COULD_NOT_FIND_THE = "User could not find the";
	public static final String USER_SHOULD_FIND = "User should find";
	public static final String USER_FINDS_THE = "User finds the";
	public static final String FROM = " from ";
	public static final String DROPDOWN = " dropdown";
	public static final String STR_MODALIFRAME = "modaliframe";
	public static final String STR_FRAME = "Frame";
	public static final int TIMEOUT = 160;
	public static final String QA = "QA";
	public static final String PROD = "Prod";
	public static final String AXA_QA = "https://clientworkseqhqa.lpl.com/cw?adAuth=true";
	public static final String AXA_PROD = "https://clientworkseqh.lpl.com/cw?adAuth=true";
	static String strError = " ";
	public String strError1;
	public static final String SSO = "SSO";
	public static final String AXANONSSOPORTAL = "AXA Non SSO Portal";
	public static final String AXANONSSOPORTALQALINK = "AXA Non SSO Portal QA Link";
	public static final String AXANONSSOPORTALLOGIN = "AXA Non SSO Portal Login Button";
	public static final String COMPLETE = "complete";
	public static final String CHILD_WINDOW = "Child Window";

	WebDriver driver;
	static HomePage homePage;
	static LoginPage loginPage;
	static ClientManagement_Common cmCommon;
	static ClientManagement_AccountsTab cmAccountsTab;
	static IASTradingCommon iasTradingCmn;
	static BNCommon bncCommon;
	static LPLConfig ocfg;
	static WebEdit webEdit;
	static Random random;
	static LPLCoreUtil lplCoreUtil;
	/** XPath Property of AXA User Dropdown */
	String strAxaPortalSelectDropdownXpath;
	/** XPath Property of AXA Login button */
	String strAxaPortalLoginButtonXpath;
	/** XPath Property of AXA ClientWorks QA link */
	String strAxaPortalLPLClientWorksQALinkXpath;
	IASTradingCommon iasTradingCommon;
	LPLCoreConstents lplCoreConstents = LPLCoreConstents.getInstance();

	public Common(WebDriver driver) {
		// Initializing the driver
		this.driver = driver;
		// Initializing the Webedit class
		webEdit = new WebEdit();
		iasTradingCmn = new IASTradingCommon(driver);
		iasTradingCommon = new IASTradingCommon(driver);
	}

	/**
	 * This method is used to switch to the newly opened/second window after closing
	 * the current window
	 *
	 * @author Prabhakaran Manoharan
	 * @parameter maxTimeSeconds - Maximum time to wait for the Webelement byLocator
	 *            - To click on any By locator
	 * @since 13-Jan-2020
	 */
	public void switchToNextWindow() {
		Set<String> handles = driver.getWindowHandles();
		String firstWinHandle = driver.getWindowHandle();
		handles.remove(firstWinHandle);
		driver.close();
		String winHandle = handles.iterator().next();

		if (!winHandle.equals(firstWinHandle)) {
			// Storing handle of second window handle
			String secondWinHandle = winHandle;
			driver.switchTo().window(secondWinHandle);
		}
	}

	/**********************************************************************
	 * Click methods
	 **********************************************************************/
	/**
	 * clickOnElement: This method is used to click on any web element by using Java
	 * script executor click or a normal click.
	 *
	 * @return N/A
	 * @author Prabhakaran Manoharan
	 * @parameter maxTimeSeconds - Maximum time to wait for the Webelement byLocator
	 *            - To click on any By locator
	 * @since 13-Aug-2019
	 */
	private boolean clickOnElement(int maxTimeSecondsToWaitForElement, By byLocator, String elementName,
			String locatorType, String locator) {
		boolean blnResult = false;
		try {
			// wait for webelement
			WebElement webElement = LPLCoreUtil.waitForWebElement(maxTimeSecondsToWaitForElement, byLocator);
			// Click on webelement
			click(webElement);
			blnResult = true;
		} catch (Exception e) {
			// Failing the test as click action was not successful
			writeStepToReporter(testType.CLICK.name(), blnResult, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, e.getMessage());
		}
		return blnResult;
	}

	/**
	 * This method is used for click on the web element and if unsuccessful use JS
	 * click
	 *
	 * @param webElement
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public void click(WebElement webElement) {
		try {
			// Normal click on webelement
			webElement.click();
		} catch (Exception ex) {
			// Java Executor click on by locator
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(LPLCoreConstents.JSCLICK, webElement);
		}
	}
	
	/**
	 * This method is used for add text
	 *
	 * @param webElement
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public void enterText(String webElement) {
		
			// Java Executor click on by locator
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(LPLCoreConstents.JSCLICK, driver.findElement(By.xpath(webElement)));
			js.executeScript("arguments[0].value='1234';", driver.findElement(By.xpath(webElement)));
			//js.executeScript("document.getElementByXpath('//div[@class='udg-name-edit']').value='1234';", "");
			//js.executeScript(LPLCoreConstents.JSCLICK, webElement);
		
	}
	

	/**
	 * This method is used for click on the web element using xpath locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingXpath(String locator, String elementName) {
		// Clicking on element using xpath locator
		isElementPresentUsingXpath(locator, elementName);
		return clickOnElement(lplCoreConstents.BASE, By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for click on the web element using xpath locator string
	 * with maximum wait time of specified value
	 *
	 * @param locator
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return boolean
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingXpath(String locator, int maxWaitTimeInSeconds, String elementName) {
		// Clicking on element using xpath locator
		isElementPresentUsingXpath(locator, maxWaitTimeInSeconds, elementName);
		return clickOnElement(lplCoreConstents.UNIT, By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for click on the web element using id locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingId(String locator, String elementName) {
		// Clicking on element using ID locator
		return clickOnElement(lplCoreConstents.UNIT, By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for click on the web element using css locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingCss(String locator, String elementName) {
		// Clicking on element using CSS locator
		return clickOnElement(lplCoreConstents.UNIT, By.cssSelector(locator), elementName, LPLCoreConstents.CSS,
				locator);
	}

	/**********************************************************************
	 * Wait methods
	 **********************************************************************/

	/**
	 * This method is used for wait for the web element(Max 10 secs) using By object
	 * to become visible
	 *
	 * @param by
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisible(By by, String elementName, String locatorType, String locator) {
		// waiting for element for given By object
		boolean blnResult = LPLCoreSync.waitTillVisible(driver, by, lplCoreConstents.MEDIUM);
		if (!blnResult)
			// failing the test when element is not found
			writeStepToReporter(testType.WAITTILLVISIBLE.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					locatorType, locator, lplCoreConstents.BaseInMiliSec);
		// returning true when element is found
		return blnResult;
	}

	/**
	 * This method is used for wait for the web element(for specified time) using By
	 * object to become visible
	 *
	 * @param by
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisible(By by, int maxWaitTimeInSeconds, String elementName, String locatorType,
			String locator) {
		// waiting for element for given By object up to specified time if not
		// found immediately
		boolean blnResult = LPLCoreSync.waitTillVisible(driver, by, maxWaitTimeInSeconds);
		// Writing results of this step to the reporter
		writeStepToReporter(testType.WAITTILLVISIBLE.name(), blnResult, LPLCoreConstents.TRUE, elementName, locatorType,
				locator, maxWaitTimeInSeconds);
		return blnResult;
	}

	/**
	 * This method is used for wait for the web element using xpath locator string
	 * to become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingXpath(String locator, String elementName) {
		// waiting for element using Xpath locator
		return waitTillVisible(By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using xpath
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingXpath(String locator, int maxWaitTimeInSeconds, String elementName) {
		// waiting for element using Xpath locator up to specified time
		return waitTillVisible(By.xpath(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for wait for the web element using ID locator string to
	 * become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingId(String locator, String elementName) {
		// waiting for element using ID
		return waitTillVisible(By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using ID
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingId(String locator, int maxWaitTimeInSeconds, String elementName) {
		// waiting for element using Xpath locator up to specified time
		return waitTillVisible(By.id(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for wait for the web element using css locator string to
	 * become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingCss(String locator, String elementName) {
		// waiting for element using Css locator
		return waitTillVisible(By.cssSelector(locator), elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using css
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingCss(String locator, int maxWaitTimeInSeconds, String elementName) {
		// waiting for element using Css locator up to specified time
		return waitTillVisible(By.cssSelector(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.CSS,
				locator);
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED)
	 *
	 * @param locatorType
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresent(String elementState, String locatorType, String locator, String elementName) {
		// Retrieveing the Web element for given locator type and locator
		WebElement webElement = getWebElement(elementName, locatorType, locator);
		// return true is element is present else false
		return LPLCoreUtil.isElementPresent(elementState, webElement);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * xpath locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorXpath
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String locatorXpath, String elementName) {
		boolean blnResult = false;
		// Retrieving the Web element for given xpath locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			// Failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.XPATH, locatorXpath, EMPTY_STRING);
		// Returns true if element is found
		return blnResult;
	}

	public boolean isWebElementPresent(WebElement webElement, String elementName) {
		boolean blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			// Failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.XPATH, "", EMPTY_STRING);
		// Returns true if element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using xpath locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String elementState, String locator, String elementName) {
		// Checking for element on te page before checking for its state
		isElementPresentUsingXpath(locator, lplCoreConstents.MEDIUM, elementName);
		// Checking for element for given state using Xpath locator
		return isElementPresent(elementState, LPLCoreConstents.XPATH, locator, elementName);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * xpath locator and wait for specified time if not available immediately
	 *
	 * @param locatorXpath
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String locatorXpath, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement using xpath locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath, maxWaitTimeInSeconds);
		// Checking if element is present
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			// Failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.XPATH, locatorXpath, EMPTY_STRING);
		}
		return blnResult;
	}

	public boolean checkIfElementIsPresentUsingXpath(String locatorXpath) {
		return LPLCoreSync.waitTillVisible(driver, By.xpath(locatorXpath), lplCoreConstents.LOWEST);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * ID locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorId
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String locatorId, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement using ID locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		// Checking if element is present
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			// Failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.ID, locatorId, EMPTY_STRING);
		}
		// return true when element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * ID locator and wait for specified time if not available immediately
	 *
	 * @param locatorId
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String locatorId, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement for given ID locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId, maxWaitTimeInSeconds);
		// Checking if element is found
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			// failing the test if element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.ID, locatorId, EMPTY_STRING);
		}
		// return true if element is found
		return blnResult;
	}

	/**
	 * This method is used to check if the element is enabled. It is considered as
	 * disabled if the disabled attribute is present with value 'disabled'
	 *
	 * @param locatorXpath
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/14/2019
	 */
	public boolean isElementEnabled(String locatorXpath) {
		try {
			String attributeValue = Link.getLinkAttribute(driver.findElement(By.xpath(locatorXpath)), DISABLED);
			return (attributeValue == null);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using ID locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String elementState, String locator, String elementName) {
		// Checking if the element is present using the Id locator
		return isElementPresent(elementState, LPLCoreConstents.ID, locator, elementName);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * Css locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorCss
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String locatorCss, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement using Css locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		// Checking if the element is present
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			// Failing the test if the element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.CSS, locatorCss, EMPTY_STRING);
		// returns true if element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * Css locator and wait for specified time if not available immediately
	 *
	 * @param locatorCss
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String locatorCss, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		// Retrieving the webelement using Css locator and waits for specified
		// timime if element is not found immediately
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss, maxWaitTimeInSeconds);
		// Checking if the element is present
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			// Failing the test if the element is not found
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.CSS, locatorCss, EMPTY_STRING);
		// returns true if element is found
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using Css locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String elementState, String locator, String elementName) {
		// Checking for elementstate using Css
		return isElementPresent(elementState, LPLCoreConstents.CSS, locator, elementName);
	}

	/*************************************************
	 * Get text Methods
	 ******************************************************************/
	/**
	 * This method is used to retrieve the specified attribute of the web element
	 * using object of a WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @param attributeName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getAttribute(WebElement webElement, String elementName, String attributeName, String locatorType,
			String locator) {
		boolean blnResult = false;
		String text;
		// Retrieving the attribute value for the given element
		text = Link.getLinkAttribute(webElement, attributeName);
		if (text != null)
			blnResult = true;
		String test = attributeName.equalsIgnoreCase(TEXT_ATTRIBUTE) ? testType.GETTEXT.name()
				: testType.GETATTRIBUTE.name();
		if (!blnResult)
			// Failing the test if retrieved attribute value is null
			writeStepToReporter(test, blnResult, LPLCoreConstents.TRUE, elementName, locatorType, locator,
					attributeName);
		// returns the retrieved text
		return (text != null ? text : "");
	}

	/**
	 * This method is used to retrieve text of the web element using object of a
	 * WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getText(WebElement webElement, String elementName, String locatorType, String locator) {
		// returns the text attribute for the given webelement
		return getAttribute(webElement, elementName, TEXT_ATTRIBUTE, locatorType, locator).trim();
	}

	/**
	 * This method is used to retrieve text from the WebElement using xpath locator.
	 *
	 * @param locatorXpath the locator xpath
	 * @param elementName  the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingXpath(String locatorXpath, String elementName) {
		// retrieving the webelement using xpath locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		// retrieving the text attribute for the webelement
		return getText(webElement, elementName, LPLCoreConstents.XPATH, locatorXpath);
	}

	/**
	 * This method is used to retrieve text from the WebElement using ID locator.
	 *
	 * @param locatorId   the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingId(String locatorId, String elementName) {
		// Retrieving the webelement using ID locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		// Retrieving the text attribute of the given webelement using ID
		// locator
		return getText(webElement, elementName, LPLCoreConstents.ID, locatorId);
	}

	/**
	 * This method is used to retrieve text from the WebElement using Css locator.
	 *
	 * @param locatorCss  the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingCss(String locatorCss, String elementName) {
		// Retrieving the webelement using Css locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		// Retrieving the text attribute of the given webelement using Css
		// locator
		return getText(webElement, elementName, LPLCoreConstents.CSS, locatorCss);
	}

	/**
	 * This method is used to retrieve text for list of webelements using xpath of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingXpath(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		// Retrieving the list of webelements using Xpath locator
		List<WebElement> webElements = getWebElementsUsingXpath(locator, elementName);
		for (WebElement webElement : webElements)
			// Retrieving the list of value(text) for the given webelements
			// using Xpath locator
			values.add(getText(webElement, elementName, LPLCoreConstents.XPATH, locator));

		return values;
	}

	/**
	 * This method is used to retrieve specified attributes for list of webelements
	 * using xpath of a WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getAttributeForWebElementsUsingXpath(String locator, String attributeName, String elementName) {
		List<String> values = new ArrayList<>();
		// Retrieving the list of webelements using Xpath locator
		List<WebElement> webElements = getWebElementsUsingXpath(locator, elementName);
		for (WebElement webElement : webElements)
			// Retrieving the list of value(text) for the given webelements
			// using Xpath locator
			values.add(getAttributeForWebElement(webElement, attributeName, elementName));
		return values;
	}

	/**
	 * This method is used to retrieve text for list of webelements using ID of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingId(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		// Retrieving the list of webelements using ID locator
		List<WebElement> webElements = getWebElementsUsingId(locator, elementName);
		for (WebElement webElement : webElements)
			// Retrieving the list of value(text) for the given webelements
			// using ID locator
			values.add(getText(webElement, elementName, LPLCoreConstents.ID, locator));
		return values;
	}

	/**
	 * This method is used to retrieve text for list of webelements using Css of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingCss(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		// Retrieving the list of webelements using ID locator
		List<WebElement> webElements = getWebElementsUsingCss(locator, elementName);
		for (WebElement webElement : webElements)
			// Retrieving the list of value(text) for the given webelements
			// using ID locator
			values.add(getText(webElement, elementName, LPLCoreConstents.CSS, locator));
		return values;
	}

	/**
	 * This method is used to retrieve specified attribute value of the web element
	 * using object of a WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getAttributeValue(WebElement webElement, String attributeName, String elementName,
			String locatorType, String locator) {
		// Retrieving the value of the specified attribute for given locator
		// type and locator
		return getAttribute(webElement, elementName, attributeName, locatorType, locator).trim();
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using xpath locator.
	 *
	 * @param locatorXpath the locator xpath
	 * @param elementName  the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingXpath(String locatorXpath, String attributeName, String elementName) {
		// Retrieving the webelement using xpath locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		// Retrieving the value of the specified attribute for given xpath
		// locator
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.XPATH, locatorXpath);
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using Weblement object.
	 *
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeForWebElement(WebElement webElement, String attributeName, String elementName) {
		// Retrieving the value of the specified attribute for given xpath locator
		String text = Link.getLinkAttribute(webElement, attributeName);
		return text != null ? text : "";
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using ID locator.
	 *
	 * @param locatorId   the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingId(String locatorId, String attributeName, String elementName) {
		// Retrieving the webelement using ID locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		// Retrieving the value of the specified attribute for given ID locator
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.ID, locatorId);
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using Css locator.
	 *
	 * @param locatorCss  the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingCss(String locatorCss, String attributeName, String elementName) {
		// Retrieving the webelement using Css locator
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		// Retrieving the value of the specified attribute for given Css locator
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.CSS, locatorCss);
	}

	/**
	 * This method returns WebElement object for given locator
	 *
	 * @param elementName
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	private WebElement getWebElement(String elementName, String locatorType, String locator) {
		WebElement webElement = null;
		// Waiting the webelement using given locator type and locator
		webElement = LPLCoreSync.waitForWebElement(driver, locatorType, locator, lplCoreConstents.MEDIUM);
		if (webElement == null)
			// Failing the test if webelement is not found
			writeStepToReporter(testType.GETWEBELEMENT.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, EMPTY_STRING);
		// Returns Webelement if found
		return webElement;
	}

	/**
	 * This method returns WebElement object for given locator. Waits for specified
	 * time if element not found immediately
	 *
	 * @param elementName
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	private WebElement getWebElement(String elementName, String locatorType, String locator, int maxWaitTimeInSeconds) {
		WebElement webElement = null;
		// Waiting the webelement using given locator type and locator. Max wait
		// time is maxWaitTimeInSeconds
		webElement = LPLCoreSync.waitForWebElement(driver, locatorType, locator, maxWaitTimeInSeconds);
		if (webElement == null)
			// Failing the test if webelement is not found
			writeStepToReporter(testType.GETWEBELEMENT.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, EMPTY_STRING);
		// Returns Webelement if found
		return webElement;
	}

	/**
	 * This method returns WebElement object for given xpath locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingXpath(String locator, String elementName) {
		// Retrieves the web element using xpath locator
		return getWebElement(elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method returns WebElement object for given ID locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingId(String locator, String elementName) {
		// Retrieves the web element using Id locator
		return getWebElement(elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method returns WebElement object for given Css locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingCss(String locator, String elementName) {
		// Retrieves the web element using Css locator
		return getWebElement(elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used to get list of webelements for the given By object
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElements(By by, String elementName, String locatorType, String locator) {
		List<WebElement> webElementList = new ArrayList<>();
		try {
			// Waiting for weblements using By object
			webElementList = LPLCoreUtil.waitForListOfWebElements(lplCoreConstents.FAIR, by);
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			// Failing the test when exception occurs
			writeStepToReporter(testType.GETWEBELEMENTS.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, strError);
		}
		return webElementList;
	}

	/**
	 * This method is used to get count of webelements for the given xpath locator
	 *
	 * @param locator
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getWebElementsSizeUsingXpath(String locator) {
		int count = 0;
		try {
			count = driver.findElements(By.xpath(locator)).size();
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			return 0;
		}
		return count;
	}

	/**
	 * This method is used to get list of webelements for a given xpath locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingXpath(String locator, String elementName) {
		// Retrieving the list of webelements using Xpath locator
		return getWebElements(By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used to get list of webelements for a given id locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingId(String locator, String elementName) {
		// Retrieving the list of webelements using ID locator
		return getWebElements(By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used to get list of webelements for a given Css locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingCss(String locator, String elementName) {
		// Retrieving the list of webelements using Css locator
		return getWebElements(By.cssSelector(locator), elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used to get number of elements for given Xpath locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingXpath(String locator, String elementName) {
		// Retrieving the number of webelements using Xpath locator
		return getWebElementsUsingXpath(locator, elementName).size();
	}

	/**
	 * This method is used to get number of elements for given ID locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingId(String locator, String elementName) {
		// Retrieving the number of webelements using ID locator
		return getWebElementsUsingId(locator, elementName).size();
	}

	/**
	 * This method is used to get number of elements for given locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingCss(String locator, String elementName) {
		// Retrieving the number of webelements using Css locator
		return getWebElementsUsingCss(locator, elementName).size();
	}

	/**
	 * This method is used to clear text using By object
	 *
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean clearText(By by, String locatorType, String locator, String elementName) {
//         Clearing the existing text from text box
		boolean blnResult = webEdit.clearWebEditValue(driver, by);
		if (!blnResult)
			// Failing the test if the text is nto cleared successfully
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"User clears the text  for " + elementName + SPACE + FIELD,
					"User should be able to clear the text for " + elementName + SPACE + FIELD, "Text is cleared",
					"User could not clear the text for " + elementName + " field. Locator Type: " + locatorType + SPACE
							+ LOCATOR + locator + " " + webEdit.strError,
					true);
		return blnResult;
	}

	/**
	 * This method is used to enter text using By object
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterText(By by, String textToEnter, String locatorType, String locator, String elementName) {
		boolean blnResult = false;

		// Entering the text in the textbox
		blnResult = webEdit.setWebEditValue(driver, by, textToEnter);
		if (!blnResult)
			// Failing the test if the text is not entered successfully
			LPLCoreReporter
					.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
							"User enter the text " + textToEnter + SPACE + FOR + SPACE + elementName + SPACE + FIELD,
							"User should be able to enter the text "
									+ textToEnter + SPACE + FOR + SPACE + elementName + SPACE + FIELD,
							"Text is entered",
							"User could not enter the text " + textToEnter + SPACE + FOR + SPACE + elementName
									+ " field. Locator Type: " + locatorType + SPACE + LOCATOR + locator + " "
									+ webEdit.strError,
							true);
		return blnResult;
	}

	/**
	 * This method is used to enter text using Xpath locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingXpath(String locator, String textToEnter, String elementName) {
		// enter text in text box identified using xpath locator
		return enterText(By.xpath(locator), textToEnter, LPLCoreConstents.XPATH, locator, elementName);
	}

	/**
	 * This method is used to clear text using Xpath locator
	 *
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean clearTextUsingXpath(String locator, String elementName) {
		// enter text in text box identified using xpath locator
		return clearText(By.xpath(locator), LPLCoreConstents.XPATH, locator, elementName);
	}

	/**
	 * This method is used to enter text using ID locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingId(String locator, String textToEnter, String elementName) {
		// enter text in text box identified using Id locator
		return enterText(By.id(locator), textToEnter, LPLCoreConstents.ID, locator, elementName);
	}

	/**
	 * This method is used to enter text using Css locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingCss(String locator, String textToEnter, String elementName) {
		// enter text in text box identified using Css locator
		return enterText(By.cssSelector(locator), textToEnter, LPLCoreConstents.CSS, locator, elementName);
	}

	/**
	 * This method is used to substitute the placeholders in the given locator
	 * string with the given argument values
	 *
	 * @param locator
	 * @param arguments
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public String getFormattedLocator(String locator, String... arguments) {
		boolean blnResult = true;

		String formattedLocator = locator;
		// Retrieving the number of placeholders
		int numberOfPlaceholders = StringUtils.countMatches(locator, PLACEHOLDER);
		// Checking if the number of placeholders is equal to number of
		// arguments passed
		if (numberOfPlaceholders != arguments.length)
			blnResult = false;
		if (!blnResult)
			// Failing the test if number of placeholders is not equal to number
			// of arguments passed
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validating if the number of placeholders in locator string matches the number of arguments passed to replace them",
					"Number of placeholders in locator string should match the number of arguments passed to replace them",
					"Number of placeholders in locator string match with the number of arguments passed to replace them",
					"Number of placeholders in locator string does should match the number of arguments passed to replace them. Number of placeholders: "
							+ numberOfPlaceholders + ". Number of arguments passed: " + arguments.length
							+ ". Locator - " + locator + " Arguments - " + String.join(",", arguments),
					LPLCoreConstents.FALSE);

		for (int i = 0; i < arguments.length; i++) {
			// Replacing the placeholders with the arguments passed
			formattedLocator = formattedLocator.replaceFirst("%s", arguments[i]);
		}
		return formattedLocator;
	}

	/**
	 * This method is used to print the report log
	 *
	 * @param testType
	 * @param blnResult
	 * @param whatResultIsPassed
	 * @param elementName
	 * @param locatorType
	 * @param locator
	 * @author Prabhakaran Manoharan
	 * @since 08-27-2019
	 */
	public void writeStepToReporter(String testType, boolean blnResult, boolean whatResultIsPassed, String elementName,
			String locatorType, String locator, String errorMessage) {
		setErrorMessage(
				(!errorMessage.equals(EMPTY_STRING) || errorMessage == null) ? "Error: " + errorMessage : EMPTY_STRING);
		switch (testType.toUpperCase()) {

		case "COUNTOFWEBELEMENTS":
			// Report logger for getCountOfWebelements methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User retrieves the count of webelement for  " + elementName + SPACE + ELEMENT,
					"User should get the count of webelement " + elementName + SPACE + ELEMENT,
					"User get the count of webelement for " + elementName + SPACE + ELEMENT,
					"User could not retrieve the count of webelements for" + elementName + SPACE + ELEMENT_LOCATOR_TYPE
							+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
					LPLCoreConstents.FALSE);
			break;
		case "GETWEBELEMENT":
			// Report logger for getWebElement methods
			LPLCoreReporter
					.writeStepToReporter(blnResult, whatResultIsPassed,
							"User retrieves the webelement for  " + elementName + SPACE + ELEMENT,
							"User should find the webelement " + elementName + SPACE + ELEMENT,
							"User finds the webelement for " + elementName + SPACE + ELEMENT,
							"User could not retrieve the webelement for" + elementName + SPACE + ELEMENT_LOCATOR_TYPE
									+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
							LPLCoreConstents.FALSE);
			break;
		case "GETWEBELEMENTS":
			// Report logger for getWebElements methods
			LPLCoreReporter
					.writeStepToReporter(blnResult, whatResultIsPassed,
							"User retrieves the webelements for  " + elementName + SPACE + ELEMENT,
							"User should find the webelements " + elementName + SPACE + ELEMENT,
							"User finds the webelements for " + elementName + SPACE + ELEMENT,
							"User could not retrieve the webelements for " + elementName + SPACE + ELEMENT_LOCATOR_TYPE
									+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
							LPLCoreConstents.FALSE);
			break;
		case "ISELEMENTPRESENT":
			// Report logger for isElementPresent methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					USER_CHECKS_FOR + SPACE + elementName + SPACE + ELEMENT,
					USER_SHOULD_FIND + SPACE + elementName + SPACE + ELEMENT,
					USER_FINDS_THE + SPACE + elementName + SPACE + ELEMENT,
					USER_COULD_NOT_FIND_THE + SPACE + elementName + SPACE + ELEMENT + SPACE + ELEMENT_LOCATOR_TYPE
							+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
					LPLCoreConstents.FALSE);
			break;
		case "CLICK":
			// Report logger for Click methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User clicks on " + elementName + SPACE + ELEMENT,
					"User should be able to click the " + elementName + SPACE + ELEMENT,
					"User clicked the " + elementName + SPACE + ELEMENT,
					"User could not click the " + elementName + SPACE + ELEMENT_LOCATOR_TYPE + SPACE + locatorType
							+ SPACE + LOCATOR + locator + " " + strError,
					true);
			break;
		default:
			break;
		}
	}

	/**
	 * This method is used to print the report log
	 *
	 * @param testType
	 * @param blnResult
	 * @param whatResultIsPassed
	 * @param elementName
	 * @param locatorType
	 * @param locator
	 * @param maxWaitTimeInSeconds
	 * @author Prabhakaran Manoharan
	 * @since 08-27-2019
	 */
	public void writeStepToReporter(String testType, boolean blnResult, boolean whatResultIsPassed, String elementName,
			String locatorType, String locator, int maxWaitTimeInSeconds) {
		switch (testType.toUpperCase()) {
		case "WAITTILLVISIBLE":
			// Report logger for waitTillVisible methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User waits for " + elementName + " element. Max wait time is " + maxWaitTimeInSeconds + " secs",
					elementName + " element should appear", elementName + " is visible",
					elementName + " is not visible. Locator Type: " + locatorType + SPACE + LOCATOR + locator, true);
			break;
		case "WAITTILLINVISIBLE":
			// Report logger for waitTillInvisible methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User waits for " + elementName + " element to disappear. Max wait time is " + maxWaitTimeInSeconds
							+ " secs",
					elementName + " element should disappear", elementName + " element has disappeared",
					elementName + " is still visible. Locator Type: " + locatorType + SPACE + LOCATOR + locator, true);
			break;
		default:
			break;
		}
	}

	/**
	 * This method is used to print the report log
	 *
	 * @param testType
	 * @param blnResult
	 * @param whatResultIsPassed
	 * @param elementName
	 * @param locatorType
	 * @param locator
	 * @param attributeName
	 * @author Prabhakaran Manoharan
	 * @since 08-27-2019
	 */
	public void writeStepToReporter(String testType, boolean blnResult, boolean whatResultIsPassed, String elementName,
			String locatorType, String locator, String attributeName, String errorMessage) {
		setErrorMessage(
				(!errorMessage.equals(EMPTY_STRING) && errorMessage != null) ? "Error: " + errorMessage : EMPTY_STRING);
		switch (testType.toUpperCase()) {
		case "GETTEXT":
			// Report logger for getText methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User retrieves the text for the " + elementName + SPACE + ELEMENT,
					"Text should be retrieved for " + elementName + SPACE + ELEMENT,
					"Text is retrieved for " + elementName + SPACE + ELEMENT,
					"Text could not be retrieved for " + elementName + " element. Locator Type: " + locatorType
							+ ". Locator:" + locator + " " + strError,
					LPLCoreConstents.FALSE);
			break;
		case "GETATTRIBUTE":
			// Report logger for getAttribute methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User retrieves the " + attributeName + " attribute for the " + elementName + SPACE + ELEMENT,
					attributeName + " attribute should be retrieved for " + elementName + SPACE + ELEMENT,
					attributeName + " attribute is retrieved for " + elementName + SPACE + ELEMENT,
					attributeName + " attribute could not be retrieved for " + elementName + " element. Locator Type: "
							+ locatorType + ". Locator:" + locator + " " + strError,
					LPLCoreConstents.FALSE);
			break;
		default:
			break;
		}
	}

	/**
	 * This method contains list of constants for different checks performed on UI
	 * dusing webdriver
	 */
	public enum testType {
		// Constants for commonly used webdriver methods
		GETWEBELEMENT, GETWEBELEMENTS, ISELEMENTPRESENT, COUNTOFWEBELEMENTS, CLICK, GETTEXT, GETATTRIBUTE,
		WAITTILLVISIBLE, WAITTILLINVISIBLE
	}

	/**
	 * This method is used for check if the check box selected on the page using Id
	 * locator
	 *
	 * @param locatorId
	 * @param elementName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/08/2019
	 */
	public boolean isCheckBoxSelected(String locatorId, String elementName) {
		// Retrieving the weblement
		WebElement webElement = getWebElementUsingId(locatorId, elementName);
		// Checking if checkbox is selected
		return webElement.isSelected();
	}

	/**
	 * This method is used for check if the check box selected on the page using Id
	 * locator
	 *
	 * @param locatorId
	 * @param elementName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/08/2019
	 */
	public boolean checkIfCheckBoxSelected(String locatorId, String elementName) {
		// Check if check box is selected
		boolean blnResult = false;
		// Wait for webelement using ID locator
		LPLCoreSync.waitForWebElement(driver, LPLCoreConstents.ID, locatorId, lplCoreConstents.FAIR);
		// Retrieving the webelement using ID locator
		WebElement getElement = getWebElementUsingId(locatorId, elementName);
		// checking if checkbox is selected using ID locator
		blnResult = getElement.isSelected();
		if (blnResult) {
			// Passing the step if checkbox is selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"User checks for  " + elementName + AND_IT_IS_SELECTED,
					"User should find " + elementName + AND_IT_IS_SELECTED,
					"User finds the " + elementName + AND_IT_IS_SELECTED,
					"User could not find the " + elementName + SPACE + ELEMENT + strError, true);
		} else {
			// Failing the step if checkbox is not selected
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.FALSE,
					"User checks for  " + elementName + AND_IT_IS_NOT_SELECTED,
					"User should find " + elementName + AND_IT_IS_NOT_SELECTED,
					"User finds the " + elementName + AND_IT_IS_NOT_SELECTED,
					"User could not find the " + elementName + SPACE + ELEMENT + strError, false);
		}

		return blnResult;
	}

	/**
	 * This method returns WebElement object for given By object
	 *
	 * @param by
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElement(By by) {
		WebElement webElement = null;
		try {
			// Identify the webelement based on By object
			webElement = driver.findElement(by);
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the web element", "Web element should be retrieved", "Web element was retrieved",
					"Could not retreive the web element", true);
		}
		return webElement;
	}

	/**
	 * This method is used for getting value from the style tag
	 *
	 * @return String
	 * @author Pooja Navdeti
	 * @since 08/26/2019
	 */
	public String getCSSValueId(String elementId, String cssValue) {
		// Retrieving the Css value for the element
		return driver.findElement(By.id(elementId)).getCssValue(cssValue);
	}

	/**
	 * This method returns WebElement object for given locator string based on xpath
	 *
	 * @param locator
	 * @return By
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingXpath(String locator) {
		WebElement webElement = null;
		try {
			// Retrieving the webelement based on Xpath locator
			webElement = driver.findElement(By.xpath(locator));
		} catch (Exception e) {
			// Failing the test when exception occurs
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the web element", "Web element should be retrieved", "Web element was retrieved",
					"Could not retrieve the web element", true);
		}
		return webElement;
	}

	/**
	 * Function is used for check if the web element is Not present on the page
	 *
	 * @param locatorXpath
	 * @return boolean
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementNotPresentUsingXpath(String locatorXpath) {
		// Checking if the element is not present on the page
		return !LPLCoreSync.waitTillVisible(driver, By.xpath(locatorXpath), lplCoreConstents.LOWEST);
	}

	/**
	 * Function is used for check if the web element is Not present on the page for
	 * specified time
	 *
	 * @param locatorXpath
	 * @param intTimeOutInSeconds
	 * @return boolean
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public void isElementNotPresentUsingXpath(By locatorXpath, int intTimeOutInSeconds) {
		// Checking if the element is not present on the page
		(new WebDriverWait(driver, (long) intTimeOutInSeconds))
				.until(ExpectedConditions.invisibilityOfElementLocated(locatorXpath));
	}

	/**
	 * Function is used for check if the web element is Not present on the page
	 *
	 * @param locatorXpath
	 * @param maxTimeInSeconds
	 * @return boolean
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementNotPresentUsingXpath(String locatorXpath, int maxTimeInSeconds) {
		// Checking if the element is not present on the page
		return !LPLCoreSync.waitTillVisible(driver, By.xpath(locatorXpath), maxTimeInSeconds);
	}

	/**
	 * Function is used for wait for the max time specified to check if the element
	 * is visible
	 *
	 * @param webElement
	 * @param intTimeOutInSeconds
	 * @return boolean
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean waitTillVisible(WebElement webElement, final double intTimeOutInSeconds) {
		try {
			(new WebDriverWait(driver, (long) intTimeOutInSeconds)).until(new Function<WebDriver, Boolean>() {
				public Boolean apply(WebDriver driver) {
					boolean isElementDisplayed = false;
					StopWatch sw = new StopWatch();
					sw.start();
					try {
						while (!isElementDisplayed && sw.getTime() < (intTimeOutInSeconds * 1000)) {
							if (webElement.isDisplayed()) {
								isElementDisplayed = true;
							}
							break;
						}
					} catch (Exception var6) {
						setErrorMessage(var6.getMessage());
					}
					return isElementDisplayed;
				}
			});
			return true;
		} catch (Exception var4) {
			return false;
		}
	}

	/**
	 * This method is used to set the error message to strError variable
	 *
	 * @param errorMessage
	 * @author Prudhvi Raj M
	 * @since 08-28-2019
	 */
	public static void setErrorMessage(String errorMessage) {
		// Initializing the strError variable withh the exception/error message
		strError += errorMessage;
	}

	/**
	 * This method checks the options displayed or Not, As per the datatable options
	 * using dynamic xpath locator
	 *
	 * @param options
	 * @param xPathlocator
	 * @return void
	 * @author H Abdul Hadi
	 * @since 09-13-2019
	 */
	public void checkIfAllOptionsDisplayedUsingXpathSelector(DataTable options, String xPathlocator) {
		boolean blnResult = false;
		List<Map<String, String>> filters = options.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get("options");
			String getFomrattedXpath = String.format(xPathlocator, filterName);
			blnResult = isElementPresentUsingXpath(getFomrattedXpath, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"User should be able to see " + filterName, "User should be able to see " + filterName,
					"Successfully be able to see " + filterName, "Failed to see " + filterName + " : " + strError);
		}

	}

	/**
	 * This method is used to Validate the options are displayed or not in Each tab
	 *
	 * @param byLocator- taking xpath options and comparing to -strExpectedValues-
	 *                   expected options text value as well Actual value
	 * @return boolean true/false
	 * @author H Abdul Hadi.
	 * @version 1.0
	 * @since 09/13/2019
	 */
	public boolean validateOptions(By byLocator, String[] strExpectedValues) {
		boolean blnResult = false;
		try {
			List<WebElement> actualHeaderColumns = driver.findElements(byLocator);
			String[] strActualValues = new String[actualHeaderColumns.size()];
			int intVal = 0;
			for (WebElement webElement : actualHeaderColumns) {
				strActualValues[intVal] = Link.getLinkAttribute(webElement, "TEXT").trim();
				intVal++;
			}
			blnResult = Arrays.equals(strActualValues, strExpectedValues);
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			blnResult = false;
		}
		return blnResult;
	}

	/**
	 * This method is used to move the mouse to the element specified by the given
	 * xpath locator
	 *
	 * @param locatorXpath
	 * @param elementName
	 * @return boolean
	 * @author Prabhakaran
	 * @since 09/21/2019
	 */
	public boolean moveToElement(String locatorXpath, String elementName) {
		boolean blnResult = false;
		try {
			Actions actions = new Actions(driver);
			WebElement webElement = getWebElementUsingXpath(locatorXpath, elementName);
			actions.moveToElement(webElement).perform();
			blnResult = true;
		} catch (Exception e) {
			blnResult = false;
			setErrorMessage(e.getMessage());
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"User moves the mouse to " + elementName + ELEMENT,
					"User should be able to move to " + elementName + ELEMENT,
					"Successfully moved to " + elementName + ELEMENT,
					"Failed to move to " + elementName + " : " + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to wait for page to load completely.
	 *
	 * @return boolean
	 * @author Prabhakaran
	 * @since 09/21/2019
	 */
	public void waitForPageLoading() {
		waitForPageLoading(TIMEOUT);
		waitForProgressBarToDisappear();
	}

	/**
	 * This method is used to wait for 'Loading.. ' progress bar to disappear
	 *
	 * @return void
	 * @author Rahul Kumar Shaw
	 * @since 5/06/2020
	 */
	// Wait till the Progress Bar is disappeared
	public boolean waitForProgressBarToDisappear() {
		try {
			Wait<WebDriver> wait = new WebDriverWait(driver, TIMEOUT);
			wait.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(
					By.xpath("//*[@id='ngProgress-container' and not(contains(@style,'display: none;'))]"))));
			wait.until(
					ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.cssSelector(".pageLoading"))));
			wait.until(ExpectedConditions
					.invisibilityOfAllElements(driver.findElements(By.xpath("//div[@id='ngProgress-container']"))));
			wait.until(ExpectedConditions.invisibilityOfAllElements(
					driver.findElements(By.xpath("//i[@class='fa fa-spinner fa-spin text-center']"))));
			wait.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(
					By.xpath("//*[@id=\"messaging-view\"]/div/md-content/div/div[2]/md-progress-circular"))));
			wait.until(ExpectedConditions.invisibilityOfAllElements(
					driver.findElements(By.xpath("//i[@class='fa fa-spinner fa-spin fa-3x fa-fw']"))));
			return true;
		} catch (TimeoutException e) {
			setErrorMessage(e.getMessage());
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Validate page loads should completed within " + TIMEOUT + " seconds.",
					"Page loads should be completed ", "Page loads should be completed within " + TIMEOUT + " seconds.",
					"Failed to load page within " + TIMEOUT + " seconds.", true);
			return false;
		}
	}

	public void waitTillInvisible(String locator, int maxTimeInSeconds) {
		boolean isElementNotDisplayed = false;
		StopWatch sw = new StopWatch();
		sw.start();
		while (!isElementNotDisplayed && sw.getTime() < (long) (maxTimeInSeconds * 1000)) {
			isElementNotDisplayed = isElementNotPresentUsingXpath(locator);
		}
	}

	/**
	 * This method is used to wait for page to load completely. Max wait time is
	 * specified
	 *
	 * @param intMaxTime
	 * @return boolean
	 * @author Prabhakaran
	 * @since 09/21/2019
	 */

	public boolean waitForPageLoading(int intMaxTime) {
		try {
			(new WebDriverWait(this.driver, (long) intMaxTime)).until(new Function<WebDriver, Boolean>() {
				public Boolean apply(WebDriver driver) {
					return String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
							.equals(COMPLETE);
				}
			});
			return true;
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			return false;
		}
	}

	public boolean selectValueFromDropdownUsingXpath(String dropdownXpath, String valueToSelect, String elementName) {
		LPLCoreSync.staticWait(lplCoreConstents.LOW);
		SelectDropDown selectDropDown = new SelectDropDown(driver, By.xpath(dropdownXpath));
		boolean blnResult = selectDropDown.selectValueByVisibleText(valueToSelect);
		if (!blnResult) {
			setErrorMessage(selectDropDown.strError);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Select " + valueToSelect + FROM + elementName + DROPDOWN,
					valueToSelect + FROM + elementName + " dropdown should be selected",
					"Selected " + valueToSelect + FROM + elementName + DROPDOWN,
					"Failed to select to " + valueToSelect + FROM + elementName + " dropdown using locator["
							+ dropdownXpath + "]. Error: " + strError);
		}
		return blnResult;
	}

	public boolean selectValueFromDropdownUsingId(String dropdownId, String valueToSelect, String elementName) {
		LPLCoreSync.staticWait(lplCoreConstents.LOW);
		SelectDropDown selectDropDown = new SelectDropDown(driver, By.id(dropdownId));
		boolean blnResult = selectDropDown.selectValueByVisibleText(valueToSelect);
		if (!blnResult) {
			setErrorMessage(selectDropDown.strError);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Select " + valueToSelect + FROM + elementName + DROPDOWN,
					valueToSelect + FROM + elementName + " dropdown should be selected",
					"Selected " + valueToSelect + FROM + elementName + DROPDOWN, "Failed to select to " + valueToSelect
							+ FROM + elementName + " dropdown using locator[" + dropdownId + "]. Error: " + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to retrieve text for list of webelements using xpath* of
	 * a WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getAttributesUsingXpath(String locator, String attribute, String elementName) {
		List<String> values = new ArrayList<>();
		// Retrieving the list of webelements using Xpath locator
		List<WebElement> webElements = getWebElementsUsingXpath(locator, elementName);
		for (WebElement webElement : webElements)
			// Retrieving the list of value(text) for the given webelements// using Xpath
			// locator
			values.add(getAttribute(webElement, elementName, attribute, LPLCoreConstents.XPATH, locator));
		return values;
	}

	public void wait(int waitTimeInSeconds) {
		try {
			Thread.sleep((long) waitTimeInSeconds * 1000);
		} catch (InterruptedException e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Wait for " + waitTimeInSeconds + " seconds",
					"Program should wait for " + waitTimeInSeconds + "  seconds",
					"Program waited for " + waitTimeInSeconds + " seconds",
					"Exception occurred while waiting Error: " + e.getMessage());
			Thread.currentThread().interrupt();
		}
	}

	public String getStrError() {
		return strError;
	}

	public boolean isFormattedHeaderAsExpected(String testData, String eleXpath) {
		boolean blnResult = false;
		String uIData = getTextUsingXpath(eleXpath, testData);
		blnResult = (testData).equals(uIData);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate " + testData + " is displayed as expected", testData + " should be displayed as expected",
				testData + " is displayed as expected", "Failed To display " + testData + " as expected");
		return blnResult;
	}

	/**
	 * This method is used to get URL
	 *
	 * @param URL
	 * @return boolean
	 * @author Rahul Shaw
	 * @since 07-03-2020
	 */
	public String getAXAURL() {
		if (ocfg.getEnvironment().contains(QA))
			return AXA_QA;
		else if (ocfg.getEnvironment().contains(PROD))
			return AXA_PROD;
		return "";
	}

	/**
	 * This method is used to get URL
	 *
	 * @param URL
	 * @return boolean
	 * @author Rahul Shaw
	 * @since 07-03-2020
	 */
	public boolean loadURL(String url) {
		try {
			driver.get(url);
			waitForPageLoading();
			return true;
		} catch (Exception e) {
			setErrorMessage(e.toString());
			return false;
		}
	}

	/**
	 * This function is used to login to the AXA Non SSO Portal
	 *
	 * @author Chinmay
	 * @version 1.0
	 * @since 05/26/2020
	 * @return boolean
	 * @param String String DropdownValue -> Value to be selected in the Drop down,
	 *               Webdriver driver -> pass the Driver reference
	 * 
	 */

	public boolean AXA_Login(WebDriver driver, String dropDownValue) {
		boolean blnResult = false;
		try {
			waitTillVisibleUsingXpath(strAxaPortalSelectDropdownXpath, lplCoreConstents.BASE, AXANONSSOPORTAL);
			SelectDropDown dropdown = new SelectDropDown(driver, By.xpath(strAxaPortalSelectDropdownXpath));
			dropdown.selectDropDownByValue(dropDownValue);

			if (isElementPresentUsingXpath(ENABLED, strAxaPortalLoginButtonXpath, AXANONSSOPORTALLOGIN)) {
				clickElementUsingXpath(strAxaPortalLoginButtonXpath, AXANONSSOPORTALLOGIN);
				waitTillVisibleUsingXpath(strAxaPortalLPLClientWorksQALinkXpath, lplCoreConstents.HIGH,
						AXANONSSOPORTALQALINK);
				if (isElementPresentUsingXpath(ENABLED, strAxaPortalLPLClientWorksQALinkXpath, AXANONSSOPORTALQALINK)) {
					clickElementUsingXpath(strAxaPortalLPLClientWorksQALinkXpath, AXANONSSOPORTALQALINK);
				}
			}
			ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
			// switches to new tab
			driver.switchTo().window(tabs.get(1));
			// adding static wait as it redirects to Clientworks EQH from the EQH Portal
			LPLCoreSync.staticWait(lplCoreConstents.BaseInMiliSec);

			blnResult = true;
		} catch (NoSuchElementException ex) {
			blnResult = false;
			setErrorMessage(ex.getMessage());
		}
		return blnResult;
	}

	/**
	 * This method is used for switch to new window
	 *
	 * @author abanker
	 * @since 02/22/2021
	 */
	public boolean switchWindow(String windowType) {
		try {
			Set<String> strWindows = driver.getWindowHandles();
			// Using for each loop store the window value
			if (windowType.equalsIgnoreCase(CHILD_WINDOW)) {
				for (String eachWindow : strWindows) {
					// switch to window
					driver.switchTo().window(eachWindow);
				}
			} else {
				driver.switchTo().defaultContent();
			}

			return true;
		} catch (Exception ex) {
			setErrorMessage(ex.getMessage());
			return false;
		}
	}
	
	/**
	 * This method is used for return the page URL
	 *
	 * @author vparthas
	 * @since 7/27/2022
	 */
	public String getTheURL() {
		return driver.getCurrentUrl();
	}
}
