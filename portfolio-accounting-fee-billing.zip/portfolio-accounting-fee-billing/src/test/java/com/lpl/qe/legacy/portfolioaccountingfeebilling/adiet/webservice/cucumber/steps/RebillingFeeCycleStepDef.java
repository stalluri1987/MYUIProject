package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import java.io.IOException;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> RebillingFeeCycleStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for RebillingFeeCycle</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * RebillingFeeCycleStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class RebillingFeeCycleStepDef extends CommonStepDef {

	@Then("^I slect Fee Cylcle from Dropdown$")
	public void islectFeeCylclefromDropdown() {
		boolean blnResult = rebilling.iSelectFeeCycleInFileTypeDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select Precal in the Source dropdown list", "User should able to select Precal",
				"Successfully able to select Precal", "Failed to select Precal :" + Common.strError);
	}

	@When("^I click on Fee cycle Template$")
	public void iclickonFeecycleTemplate() {
		boolean blnResult = rebilling.iClickonFeeCycleSampleTemplateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Fee Cycle Sample Template link",
				"User should able to click Fee Cycle Sample Template link",
				"Successfully able to click Fee Cycle Sample Template link",
				"Failed to click Fee Cycle Sample Template link :" + Common.strError);
	}

	@Then("^I verify the Fee cycle Template is downoaded$")
	public void iverifytheTemplateisdownoaded() {
		boolean blnResult = rebilling.iShouldseeFeeCycleTemplateDownloadedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Fee Cycle Template downloading status",
				"User should be able to see Fee Cycle Template downloaded successfully",
				"Successfully able to see Fee Cycle Template downloaded successfully",
				"Failed to see Fee Cycle Template downloaded successfully : " + Common.strError);
	}

	@Then("^I enter data in the downloaded Fee cycle file$")
	public void ienterdatainthedownloadedfile() throws IOException {
		rebilling.iEnteredRequiredFeeCycleData();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Enter data in downloaded template file",
				"User should be able to Enter data in downloaded template file",
				"Successfully able to Enter data in downloaded template file",
				"Failed to Enter data in downloaded template file : " + Common.strError);
	}

	@When("^I click on Browse button on Fee Cycle screen$")
	public void iclickonBrowsebuttononFeeCycleScreen() {
		boolean blnResult = rebilling.iClickonFeeCycleBrowseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "click on Browse button",
				"User should able to click Browse button", "Successfully able to click Browse button",
				"Failed to click Browse button :" + Common.strError);
	}

	@When("^I selected the filled Fee Cycle sample downloaded template$")
	public void iselectedthefilledFeeCyclesampledownloadedtemplate() {
		boolean blnResult = rebilling.iSelectedFeeCycleDownloadedTemplate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select filled sample downloaded template",
				"User should able to Select filled sample downloaded template",
				"Successfully able to Select filled sample downloaded template",
				"Failed to Select filled sample downloaded template :" + Common.strError);
	}

	@Then("^I upload the Fee cycle file$")
	public void iuploadthefile() {
		boolean blnResult = rebilling.iClickOnFeeCycleUploadButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Upload button",
				"User should able to click Upload button", "Successfully able to click Upload button",
				"Failed to click Upload button :" + Common.strError);
	}

	@Then("^I verify the Fee file is uploaded successfully$")
	public void iverifytheFeefileisuploadedsuccessfully() {
		boolean blnResult = rebilling.iVerifyFeeFileUploadedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify file uploaded sucessfully or not",
				"User should able to see file uploaded successfully", "Successfully able to see file uploaded",
				"Failed to see file uploaded :" + Common.strError);
	}

	@Then("^I click on the Fee cycle check box$")
	public void iclickontheFeecyclecheckbox() {
		boolean blnResult = rebilling.iClickonFeeCycleChekBox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on check BOX in Fee cycle Page",
				"User should able to click Check Box", "Successfully able to click Check Box",
				"Failed to click Check Box :" + Common.strError);
	}

	@Then("^I click on Fee cycle Process button$")
	public void iclickonFeecycleProcessbutton() {
		boolean blnResult = rebilling.iClickonFeeCycleProcess();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Process button in Fee cycle Page", "User should able to click Process button",
				"Successfully able to click Process Button", "Failed to click ProcessButton :" + Common.strError);
	}

	@Then("^I wait for ten minutes to job run$")
	public void iwaitfortenminutestojobrun() {
		rebilling.waitForTenMinutes();
	}

	@When("^I select Fee cycle in source dropdown$")
	public void i_select_Fee_cycle_in_source_dropdown() {
		boolean blnResult = rebilling.iSelectFeecycleInSourceDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select Precal in the Source dropdown list", "User should able to select Precal",
				"Successfully able to select Precal", "Failed to select Precal :" + Common.strError);
	}

	@When("^I provide portfolio number in portfolio dropdown$")
	public void iselectusernamefromuserdropdown() {
		boolean blnResult = rebilling.enterFeePortfolioNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Test Portfolio number in Portflio TestBox", "User should able to enter Portfolio number",
				"Successfully able to Enter Portfolio", "Failed to enterPortfolio :" + Common.strError);
	}

	@Then("^I select all in USER$")
	public void selectUserFromUserDropdown() {
		boolean blnResult = rebilling.selectFeeUserFromUserDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select user in the User dropdown list",
				"User should able to select user from User dropdown",
				"Successfully able to select user from User dropdown",
				"Failed to select user from User dropdown :" + Common.strError);
	}

	@Then("^I verify the employee rebate$")
	public void iverifytheemployeerebate() {
		boolean blnResult = rebilling.iVerifyEMRebate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify employee Rebate",
				"User should able to Verify employee Rebate", "Employee Rebate is validated",
				"Failed to Validate EM Rebate :" + Common.strError);
	}

	@Then("^I verify the Premium Fee$")
	public void iverifythepremiumFee() {
		boolean blnResult = rebilling.iVerifyPremiumFee();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Premium Fee",
				"User should able to Verify Premium Fee", "Premium Fee is validated",
				"Failed to Validate Premium Fee :" + Common.strError);
	}

	@Then("^I delete the Fee cycle record$")
	public void ideletetheFeecyclerecord() {
		boolean blnResult = rebilling.clickOnDeleteIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete icon",
				"User should able to click Delete icon", "Successfully able to click Delete icon",
				"Failed to click Delete icon :" + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
