package com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.pages;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import LPLCoreDriver.LPLCoreUtil;
import LPLCoreDriver.WebToolKit.Link;
import LPLCoreDriver.WebToolKit.SelectDropDown;
import LPLCoreDriver.WebToolKit.WebEdit;

/**
 * <br>
 * <b> Title: </b> CaseAdminCommon.java</br>
 * <br>
 * <b> Description: </b> Utility methods for interacting with webpage
 * objects</br>
 * <br>
 * <b>Methods:</br>
 * </b> <br>
 * clickElementUsingXpath : Function is used for click on the web element using
 * xpath locator string</br>
 * <br>
 * waitTillVisible : Function is used for wait for the web element using xpath
 * locator string to become visible</br>
 * <br>
 * getWebElements : This method is used to get list of webelements for a given
 * locator</br>
 * <br>
 * clickElement : Function is used for click on the web element using By
 * object</br>
 * <br>
 * clickOnElement : This method is used to click on any web element by using
 * Java script executor click or a normal click</br>
 * <br>
 * isElementPresent : Function is used for check if the web element is present
 * on the page using xpath locator</br>
 * <br>
 * isElementPresent : Function is used for check if the web element is present
 * on the page using xpath locator and wait for specified time if not available
 * immediately</br>
 * <br>
 * isElementPresent : Function is used for check if the web element is present
 * on the page using By object and wait for specified time if not available
 * immediately</br>
 * <br>
 * getText : Function is used to retrieve text of the web element using By
 * object</br>
 * <br>
 * getText : Function is used to retrieve text of the web element using object
 * of a WebElement</br>
 * <br>
 * getText : Function is used to retrieve text from the WebElement using xpath
 * locator</br>
 * <br>
 * getText : Function is used to retrieve text for list of webelements using
 * objects of a WebElement</br>
 * <br>
 * getAttribute : Function is used to retrieve the specified attribute of the
 * web element using object of a WebElement</br>
 * <br>
 * getFormattedLocator : Function is used to substitute the plaeceholders in the
 * given locator string with the given</br>
 * <br>
 * getDropdownValues : This method returns all the available values from the
 * Select dropdown based on xpath</br>
 * <br>
 * getBy : This method returns By object for given locator string based on
 * xpath</br>
 * <br>
 * getByID : This method returns By object for given locator string based on
 * id</br>
 * <br>
 * getWebElement : This method returns WebElement object for given By
 * object</br>
 * <br>
 * getWebElementUsingXpath : This method returns WebElement object for given
 * locator string based on xpath</br>
 * <br>
 * getWebElementUsingId : This method returns WebElement object for given
 * locator string based on id</br>
 * <br>
 * getWebElementUsingCss :This method returns WebElement object for given
 * locator string based on CSS</br>
 * isFileDownloaded : This method checks if a file was downloaded and if so,
 * deletes it * <br>
 *
 * @author pmanohar
 * @since 07-05-2019
 */

public class Common extends LPLCoreDriver {

	public static final String TEXT_ATTRIBUTE = "text";
	public static final String EMPTY_STRING = "";
	public static final String PLACEHOLDER = "%s";
	public static final String ENABLED = "ENABLED";
	public static final String DISPLAYED = "DISPLAYED";
	public static final String SELECTED = "SELECTED";
	public static final String AND_IT_IS_SELECTED = " And it is selected";
	public static final String AND_IT_IS_NOT_SELECTED = " And it is not selected";
	public static final String FIELD = "field";
	public static final String SPACE = " ";
	public static final String LOCATOR = "Locator: ";
	public static final String FOR = "for";
	public static final String ELEMENT = "element";
	public static final String USER_CHECKS_FOR = "User checks for";
	public static final String ELEMENT_LOCATOR_TYPE = "element.locatorType:";
	public static final String USER_COULD_NOT_FIND_THE = "User could not find the";
	public static final String USER_SHOULD_FIND = "User should find";
	public static final String USER_FINDS_THE = "User finds the";
	public static final String DROP_DOWN_OBJECT_IS_NOT_DISPLAYED = "DropDown object is not displayed.";
	public static final String FROM = " from ";
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String USER_SHOULD_NOT_SEE = "User should not see ";
	public static final String COMPLETE = "complete";
	public static final String FONT_FAMILY = "font-family";
	public static final String ROBOTO = "roboto";
	public static final String SELECT = "Select ";
	public static final String DROPDOWN = " dropdown";
	public static final String USING_LOCATOR = "using locator[";
	public static final String ERROR = "]. Error: ";
	public static final String FAILED_TO_SELECT_TO = "failed to select to";
	public String strError = EMPTY_STRING;
	
	LPLCoreConstents lplCoreConstents = LPLCoreConstents.getInstance();
	WebEdit webEdit;
	LPLCoreUtil lplcoretil;

	public Common(WebDriver browserDriver) {
		// Initializing the driver
		this.driver = browserDriver;
		// Initializing the Webedit class
		webEdit = new WebEdit();
		lplcoretil = new LPLCoreUtil();
	}

	/**********************************************************************
	 * Click methods
	 **********************************************************************/
	/**
	 * clickOnElement: This method is used to click on any web element by using Java
	 * script executor click or a normal click.
	 *
	 * @return N/A
	 * @author Prabhakaran Manoharan
	 * @parameter maxTimeSeconds - Maximum time to wait for the Webelement byLocator
	 *            - To click on any By locator
	 * @since 13-Aug-2019
	 */
	private boolean clickOnElement(int maxTimeSecondsToWaitForElement, By byLocator, String elementName,
			String locatorType, String locator) {
		boolean blnResult = false;
		try {
			WebElement webElement = LPLCoreUtil.waitForWebElement(maxTimeSecondsToWaitForElement, byLocator);
			click(webElement);
			blnResult = true;
		} catch (Exception e) {
			writeStepToReporter(testType.CLICK.name(), blnResult, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, e.getMessage() == null ? "" : e.getMessage());
		}
		return blnResult;
	}

	/**
	 * This method is used for click on the web element and if unsuccessful use JS
	 * click
	 *
	 * @param webElement
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean click(WebElement webElement) {
		try {
			// Normal click on webelement
			webElement.click();
			return true;
		} catch (Exception ex) {
			// Java Executor click on by locator
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(LPLCoreConstents.JSCLICK, webElement);
			return false;
		}
	}

	/**
	 * This method is used for click on the web element using xpath locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingXpath(String locator, String elementName) {
		return clickOnElement(lplCoreConstents.UNIT, By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for click on the web element using xpath locator string
	 *
	 * @param locator
	 * @param waitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingXpath(String locator, int waitTimeInSeconds, String elementName) {
		return clickOnElement(waitTimeInSeconds, By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for click on the web element using id locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingId(String locator, String elementName) {
		return clickOnElement(lplCoreConstents.UNIT, By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for click on the web element using css locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean clickElementUsingCss(String locator, String elementName) {
		return clickOnElement(lplCoreConstents.UNIT, By.cssSelector(locator), elementName, LPLCoreConstents.CSS,
				locator);
	}

	/**********************************************************************
	 * Wait methods
	 **********************************************************************/

	/**
	 * This method is used for wait for the web element(Max 10 secs) using By object
	 * to become visible
	 *
	 * @param by
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisible(By by, String elementName, String locatorType, String locator) {
		boolean blnResult = LPLCoreSync.waitTillVisible(driver, by, lplCoreConstents.HIGHEST);
		if (!blnResult)
			writeStepToReporter(testType.WAITTILLVISIBLE.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					locatorType, locator, lplCoreConstents.BaseInMiliSec);
		return blnResult;
	}

	/**
	 * This method is used for wait for the web element(for specified time) using By
	 * object to become visible
	 *
	 * @param by
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisible(By by, int maxWaitTimeInSeconds, String elementName, String locatorType,
			String locator) {
		boolean blnResult = LPLCoreSync.waitTillVisible(driver, by, maxWaitTimeInSeconds);
		writeStepToReporter(testType.WAITTILLVISIBLE.name(), blnResult, LPLCoreConstents.TRUE, elementName, locatorType,
				locator, maxWaitTimeInSeconds);
		return blnResult;
	}

	/**
	 * This method is used for wait for the web element using xpath locator string
	 * to become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingXpath(String locator, String elementName) {
		return waitTillVisible(By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using xpath
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingXpath(String locator, int maxWaitTimeInSeconds, String elementName) {
		return waitTillVisible(By.xpath(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used for wait for the web element using ID locator string to
	 * become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingId(String locator, String elementName) {
		return waitTillVisible(By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using ID
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingId(String locator, int maxWaitTimeInSeconds, String elementName) {
		return waitTillVisible(By.id(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used for wait for the web element using css locator string to
	 * become visible
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingCss(String locator, String elementName) {
		return waitTillVisible(By.cssSelector(locator), elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used for wait for the web element to be displayed using css
	 * locator string
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2019
	 */
	public boolean waitTillVisibleUsingCss(String locator, int maxWaitTimeInSeconds, String elementName) {
		return waitTillVisible(By.cssSelector(locator), maxWaitTimeInSeconds, elementName, LPLCoreConstents.CSS,
				locator);
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED)
	 *
	 * @param locatorType
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresent(String elementState, String locatorType, String locator, String elementName) {
		WebElement webElement = getWebElement(elementName, locatorType, locator);
		return LPLCoreUtil.isElementPresent(elementState, webElement);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * xpath locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorXpath
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String locatorXpath, String elementName) {
		boolean blnResult = false;
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.XPATH, locatorXpath, EMPTY_STRING);
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using xpath locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String elementState, String locator, String elementName) {
		return isElementPresent(elementState, LPLCoreConstents.XPATH, locator, elementName);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * xpath locator and wait for specified time if not available immediately
	 *
	 * @param locatorXpath
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingXpath(String locatorXpath, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath, maxWaitTimeInSeconds);
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.XPATH, locatorXpath, EMPTY_STRING);
		}
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * ID locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorId
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String locatorId, String elementName) {
		boolean blnResult = false;
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.ID, locatorId, EMPTY_STRING);
		}
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * ID locator and wait for specified time if not available immediately
	 *
	 * @param locatorId
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String locatorId, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId, maxWaitTimeInSeconds);
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult) {
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.ID, locatorId, EMPTY_STRING);
		}
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using ID locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingId(String elementState, String locator, String elementName) {
		return isElementPresent(elementState, LPLCoreConstents.ID, locator, elementName);
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * Css locator and wait for 10 secs if not available immediately
	 *
	 * @param locatorCss
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String locatorCss, String elementName) {
		boolean blnResult = false;
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.CSS, locatorCss, EMPTY_STRING);
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page using
	 * Css locator and wait for specified time if not available immediately
	 *
	 * @param locatorCss
	 * @param maxWaitTimeInSeconds
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String locatorCss, int maxWaitTimeInSeconds, String elementName) {
		boolean blnResult = false;
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss, maxWaitTimeInSeconds);
		blnResult = LPLCoreUtil.isElementPresent(webElement);
		if (!blnResult)
			writeStepToReporter(testType.ISELEMENTPRESENT.name(), blnResult, LPLCoreConstents.TRUE, elementName,
					LPLCoreConstents.CSS, locatorCss, EMPTY_STRING);
		return blnResult;
	}

	/**
	 * This method is used for check if the web element is present on the page in
	 * the given state(DISPLAYED, ENABLED, DISPLAYEDANDENABLED) using Css locator
	 *
	 * @param elementState
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementPresentUsingCss(String elementState, String locator, String elementName) {
		return isElementPresent(elementState, LPLCoreConstents.CSS, locator, elementName);
	}

	/*************************************************
	 * Get text Methods
	 ******************************************************************/
	/**
	 * This method is used to retrieve the specified attribute of the web element
	 * using object of a WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @param attributeName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getAttribute(WebElement webElement, String elementName, String attributeName, String locatorType,
			String locator) {
		boolean blnResult = false;
		String text;
		text = Link.getLinkAttribute(webElement, attributeName);
		if (text != null)
			blnResult = true;
		String test = attributeName.equalsIgnoreCase(TEXT_ATTRIBUTE) ? testType.GETTEXT.name()
				: testType.GETATTRIBUTE.name();
		if (!blnResult)
			writeStepToReporter(test, blnResult, LPLCoreConstents.TRUE, elementName, locatorType, locator,
					attributeName);
		return (text != null ? text : "");
	}

	/**
	 * This method is used to retrieve text of the web element using object of a
	 * WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getText(WebElement webElement, String elementName, String locatorType, String locator) {
		return getAttribute(webElement, elementName, TEXT_ATTRIBUTE, locatorType, locator).trim();
	}

	/**
	 * This method is used to retrieve text from the WebElement using xpath locator.
	 *
	 * @param locatorXpath the locator xpath
	 * @param elementName  the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingXpath(String locatorXpath, String elementName) {
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		return getText(webElement, elementName, LPLCoreConstents.XPATH, locatorXpath);
	}

	/**
	 * This method is used to retrieve text from the WebElement using ID locator.
	 *
	 * @param locatorId   the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingId(String locatorId, String elementName) {
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		return getText(webElement, elementName, LPLCoreConstents.ID, locatorId);
	}

	/**
	 * This method is used to retrieve text from the WebElement using Css locator.
	 *
	 * @param locatorCss  the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getTextUsingCss(String locatorCss, String elementName) {
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		return getText(webElement, elementName, LPLCoreConstents.CSS, locatorCss);
	}

	/**
	 * This method is used to retrieve text for list of webelements using xpath of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingXpath(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		List<WebElement> webElements = getWebElementsUsingXpath(locator, elementName);
		for (WebElement webElement : webElements)
			values.add(getText(webElement, elementName, LPLCoreConstents.XPATH, locator));
		return values;
	}

	/**
	 * This method is used to retrieve text for list of webelements using ID of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingId(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		List<WebElement> webElements = getWebElementsUsingId(locator, elementName);
		for (WebElement webElement : webElements)
			values.add(getText(webElement, elementName, LPLCoreConstents.ID, locator));
		return values;
	}

	/**
	 * This method is used to retrieve text for list of webelements using Css of a
	 * WebElement
	 *
	 * @param locator
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<String> getTextForWebElementsUsingCss(String locator, String elementName) {
		List<String> values = new ArrayList<>();
		List<WebElement> webElements = getWebElementsUsingCss(locator, elementName);
		for (WebElement webElement : webElements)
			values.add(getText(webElement, elementName, LPLCoreConstents.CSS, locator));
		return values;
	}

	/**
	 * This method is used to retrieve specified attribute value of the web element
	 * using object of a WebElement
	 *
	 * @param webElement
	 * @param elementName
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	private String getAttributeValue(WebElement webElement, String attributeName, String elementName,
			String locatorType, String locator) {
		return getAttribute(webElement, elementName, attributeName, locatorType, locator).trim();
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using xpath locator.
	 *
	 * @param locatorXpath the locator xpath
	 * @param elementName  the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingXpath(String locatorXpath, String attributeName, String elementName) {
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorXpath);
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.XPATH, locatorXpath);
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using ID locator.
	 *
	 * @param locatorId   the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingId(String locatorId, String attributeName, String elementName) {
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.ID, locatorId);
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.ID, locatorId);
	}

	/**
	 * This method is used to retrieve specified attribute value from the WebElement
	 * using Css locator.
	 *
	 * @param locatorCss  the locator xpath
	 * @param elementName the element name
	 * @return the text
	 * @author aswain
	 * @since 7-22-2019
	 */
	public String getAttributeUsingCss(String locatorCss, String attributeName, String elementName) {
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.CSS, locatorCss);
		return getAttributeValue(webElement, attributeName, elementName, LPLCoreConstents.CSS, locatorCss);
	}

	/**
	 * This method returns WebElement object for given locator
	 *
	 * @param elementName
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	private WebElement getWebElement(String elementName, String locatorType, String locator) {
		WebElement webElement = null;
		webElement = LPLCoreSync.waitForWebElement(driver, locatorType, locator, lplCoreConstents.BaseInMiliSec);
		if (webElement == null)
			writeStepToReporter(testType.GETWEBELEMENT.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, EMPTY_STRING);
		return webElement;
	}

	/**
	 * This method returns WebElement object for given locator. Waits for specified
	 * time if element not found immediately
	 *
	 * @param elementName
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	private WebElement getWebElement(String elementName, String locatorType, String locator, int maxWaitTimeInSeconds) {
		WebElement webElement = null;
		webElement = LPLCoreSync.waitForWebElement(driver, locatorType, locator, maxWaitTimeInSeconds);
		if (webElement == null)
			writeStepToReporter(testType.GETWEBELEMENT.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, EMPTY_STRING);
		return webElement;
	}

	/**
	 * This method returns WebElement object for given xpath locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingXpath(String locator, String elementName) {
		return getWebElement(elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method returns WebElement object for given ID locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingId(String locator, String elementName) {
		return getWebElement(elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method returns WebElement object for given Css locator
	 *
	 * @param locator
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingCss(String locator, String elementName) {
		return getWebElement(elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used to get list of webelements for the given By object
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElements(By by, String elementName, String locatorType, String locator) {
		List<WebElement> webElementList = new ArrayList<>();
		try {
			webElementList = LPLCoreUtil.waitForListOfWebElements(lplCoreConstents.FAIR, by);
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			writeStepToReporter(testType.GETWEBELEMENTS.name(), false, LPLCoreConstents.TRUE, elementName, locatorType,
					locator, strError);
		}
		return webElementList;
	}

	/**
	 * This method is used to get list of webelements for a given xpath locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingXpath(String locator, String elementName) {
		return getWebElements(By.xpath(locator), elementName, LPLCoreConstents.XPATH, locator);
	}

	/**
	 * This method is used to get list of webelements for a given id locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingId(String locator, String elementName) {
		return getWebElements(By.id(locator), elementName, LPLCoreConstents.ID, locator);
	}

	/**
	 * This method is used to get list of webelements for a given Css locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public List<WebElement> getWebElementsUsingCss(String locator, String elementName) {
		return getWebElements(By.cssSelector(locator), elementName, LPLCoreConstents.CSS, locator);
	}

	/**
	 * This method is used to get number of elements for given Xpath locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingXpath(String locator, String elementName) {
		return getWebElementsUsingXpath(locator, elementName).size();
	}

	/**
	 * This method is used to get number of elements for given ID locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingId(String locator, String elementName) {
		return getWebElementsUsingId(locator, elementName).size();
	}

	/**
	 * This method is used to get number of elements for given locator
	 *
	 * @param locator
	 * @param elementName
	 * @return void
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public int getNumberOfWebElementsUsingCss(String locator, String elementName) {
		return getWebElementsUsingCss(locator, elementName).size();
	}

	/**
	 * This method is used to enter text using By object
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterText(By by, String textToEnter, String locatorType, String locator, String elementName) {
		boolean blnResult = false;
		// Clearing the existing text from text box
		blnResult = webEdit.clearWebEditValue(driver, by);
		if (!blnResult)
			// Failing the test if the text is nto cleared successfully
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"User clears the text  for " + elementName + SPACE + FIELD,
					"User should be able to clear the text for " + elementName + SPACE + FIELD, "Text is cleared",
					"User could not clear the text for " + elementName + " field. Locator Type: " + locatorType + SPACE
							+ LOCATOR + locator + " " + webEdit.strError,
					true);
		// Entering the text in the textbox
		blnResult = webEdit.setWebEditValue(driver, by, textToEnter);
		if (!blnResult)
			// Failing the test if the text is not entered successfully
			LPLCoreReporter
					.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
							"User enter the text " + textToEnter + SPACE + FOR + SPACE + elementName + SPACE + FIELD,
							"User should be able to enter the text "+ textToEnter + SPACE + FOR + SPACE + elementName + SPACE + FIELD,"Text is entered",
							"User could not enter the text " + textToEnter + SPACE + FOR + SPACE + elementName
									+ " field. Locator Type: " + locatorType + SPACE + LOCATOR + locator + " "
									+ webEdit.strError,true);
		return blnResult;
	}

	/**
	 * This method is used to enter text using Xpath locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingXpath(String locator, String textToEnter, String elementName) {
		return enterText(By.xpath(locator), textToEnter, LPLCoreConstents.XPATH, locator, elementName);
	}

	/**
	 * This method is used to enter text using ID locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingId(String locator, String textToEnter, String elementName) {
		return enterText(By.id(locator), textToEnter, LPLCoreConstents.ID, locator, elementName);
	}

	/**
	 * This method is used to enter text using Css locator
	 *
	 * @param textToEnter
	 * @param elementName
	 * @return Boolean
	 * @author Prateek Mehta
	 * @since 08/06/2019
	 */
	public boolean enterTextUsingCss(String locator, String textToEnter, String elementName) {
		return enterText(By.cssSelector(locator), textToEnter, LPLCoreConstents.CSS, locator, elementName);
	}

	/**
	 * This method is used to substitute the placeholders in the given locator
	 * string with the given argument values
	 *
	 * @param locator
	 * @param arguments
	 * @return String
	 * @author Prabhakaran Manoharan
	 * @since 7/15/2018
	 */
	public String getFormattedLocator(String locator, String... arguments) {
		boolean blnResult = true;
		String formattedLocator = locator;
		// Retrieving the number of placeholders
		int numberOfPlaceholders = StringUtils.countMatches(locator, PLACEHOLDER);
		// Checking if the number of placeholders is equal to number of arguments passed
		if (numberOfPlaceholders != arguments.length)
			blnResult = false;
		if (!blnResult)
			// Failing the test if number of placeholders is not equal to number of
			// arguments passed
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validating if the number of placeholders in locator string matches the number of arguments passed to replace them",
					"Number of placeholders in locator string should match the number of arguments passed to replace them",
					"Number of placeholders in locator string match with the number of arguments passed to replace them",
					"Number of placeholders in locator string does should match the number of arguments passed to replace them. Number of placeholders: "
							+ numberOfPlaceholders + ". Number of arguments passed: " + arguments.length
							+ ". Locator - " + locator + " Arguments - " + String.join(",", arguments),
					LPLCoreConstents.FALSE);
		for (int i = 0; i < arguments.length; i++) {
			// Replacing the placeholders with the arguments passed
			formattedLocator = formattedLocator.replaceFirst("%s", arguments[i]);
		}
		return formattedLocator;
	}

	/**
	 * This method is used to print the report log
	 *
	 * @param testType
	 * @param blnResult
	 * @param whatResultIsPassed
	 * @param elementName
	 * @param locatorType
	 * @param locator
	 * @author Prabhakaran Manoharan
	 * @since 08-27-2019
	 */
	public void writeStepToReporter(String testType, boolean blnResult, boolean whatResultIsPassed, String elementName,
			String locatorType, String locator, String errorMessage) {
		setErrorMessage(!errorMessage.equals(EMPTY_STRING) ? "Error: " + errorMessage : EMPTY_STRING);
		switch (testType.toUpperCase()) {
		case "GETWEBELEMENT":
			// Report logger for getWebElement methods
			LPLCoreReporter
					.writeStepToReporter(blnResult, whatResultIsPassed,
							"User retrieves the webelement for  " + elementName + SPACE + ELEMENT,
							"User should find the webelement " + elementName + SPACE + ELEMENT,
							"User finds the webelement for " + elementName + SPACE + ELEMENT,
							"User could not retrieve the webelement for" + elementName + SPACE + ELEMENT_LOCATOR_TYPE
									+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
							LPLCoreConstents.FALSE);
			break;
		case "GETWEBELEMENTS":
			// Report logger for getWebElements methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
							"User retrieves the webelements for  " + elementName + SPACE + ELEMENT,
							"User should find the webelements " + elementName + SPACE + ELEMENT,
							"User finds the webelements for " + elementName + SPACE + ELEMENT,
							"User could not retrieve the webelements for " + elementName + SPACE + ELEMENT_LOCATOR_TYPE
									+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
							LPLCoreConstents.FALSE);
			break;
		case "ISELEMENTPRESENT":
			// Report logger for isElementPresent methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					USER_CHECKS_FOR + SPACE + elementName + SPACE + ELEMENT,
					USER_SHOULD_FIND + SPACE + elementName + SPACE + ELEMENT,
					USER_FINDS_THE + SPACE + elementName + SPACE + ELEMENT,
					USER_COULD_NOT_FIND_THE + SPACE + elementName + SPACE + ELEMENT + SPACE + ELEMENT_LOCATOR_TYPE
							+ SPACE + locatorType + SPACE + LOCATOR + locator + " " + strError,
					LPLCoreConstents.FALSE);
			break;
		case "CLICK":
			// Report logger for Click methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User clicks on " + elementName + SPACE + ELEMENT,
					"User should be able to click the " + elementName + SPACE + ELEMENT,
					"User clicked the " + elementName + SPACE + ELEMENT,
					"User could not click the " + elementName + SPACE + ELEMENT_LOCATOR_TYPE + SPACE + locatorType
							+ SPACE + LOCATOR + locator + " " + strError,
					true);
			break;
		default:
			break;
		}
	}

	/**
	 * This method is used to print the report log
	 *
	 * @param testType
	 * @param blnResult
	 * @param whatResultIsPassed
	 * @param elementName
	 * @param locatorType
	 * @param locator
	 * @param maxWaitTimeInSeconds
	 * @author Prabhakaran Manoharan
	 * @since 08-27-2019
	 */
	public void writeStepToReporter(String testType, boolean blnResult, boolean whatResultIsPassed, String elementName,
			String locatorType, String locator, int maxWaitTimeInSeconds) {
		switch (testType.toUpperCase()) {
		case "WAITTILLVISIBLE":
			// Report logger for waitTillVisible methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User waits for " + elementName + " element. Max wait time is " + maxWaitTimeInSeconds + " secs",
					elementName + " element should appear", elementName + " is visible",
					elementName + " is not visible. Locator Type: " + locatorType + SPACE + LOCATOR + locator, true);
			break;
		case "WAITTILLINVISIBLE":
			// Report logger for waitTillInvisible methods
			LPLCoreReporter.writeStepToReporter(blnResult, whatResultIsPassed,
					"User waits for " + elementName + " element to disappear. Max wait time is " + maxWaitTimeInSeconds + " secs",
					elementName + " element should disappear", elementName + " element has disappeared",
					elementName + " is still visible. Locator Type: " + locatorType + SPACE + LOCATOR + locator, true);
			break;
		default:
			break;
		}
	}

	/**
	 * This method contains list of constants for different checks performed on UI
	 * dusing webdriver
	 */
	public enum testType {
		// Constants for commonly used webdriver methods
		GETWEBELEMENT, GETWEBELEMENTS, ISELEMENTPRESENT, CLICK, GETTEXT, GETATTRIBUTE, WAITTILLVISIBLE,
		WAITTILLINVISIBLE
	}

	/**
	 * This method is used for check if the check box selected on the page using Id
	 * locator
	 *
	 * @param locatorId
	 * @param elementName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/08/2019
	 */
	public boolean isCheckBoxSelected(String locatorId, String elementName) {
		WebElement webElement = getWebElementUsingId(locatorId, elementName);
		return webElement.isSelected();
	}

	/**
	 * This method is used for check if the check box selected on the page using Id
	 * locator
	 *
	 * @param locatorId
	 * @param elementName
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 08/08/2019
	 */
	public boolean checkIfCheckBoxSelected(String locatorId, String elementName) {
		boolean blnResult = false;
		LPLCoreSync.waitForWebElement(driver, LPLCoreConstents.ID, locatorId, lplCoreConstents.FAIRINMILLISEC);
		WebElement getElement = getWebElementUsingId(locatorId, elementName);
		blnResult = getElement.isSelected();
		if (blnResult) {
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_CHECKS_FOR + SPACE + elementName + AND_IT_IS_SELECTED,
					USER_SHOULD_FIND + SPACE + elementName + AND_IT_IS_SELECTED,
					USER_FINDS_THE + SPACE + elementName + AND_IT_IS_SELECTED,
					USER_COULD_NOT_FIND_THE + elementName + SPACE + ELEMENT + strError, true);
		} else {
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.FALSE,
					USER_CHECKS_FOR + SPACE + elementName + AND_IT_IS_NOT_SELECTED,
					USER_SHOULD_FIND + SPACE + elementName + AND_IT_IS_NOT_SELECTED,
					USER_FINDS_THE + SPACE + elementName + AND_IT_IS_NOT_SELECTED,
					USER_COULD_NOT_FIND_THE + SPACE + elementName + SPACE + ELEMENT + strError, false);
		}
		return blnResult;
	}

	/**
	 * This method returns WebElement object for given By object
	 *
	 * @param by
	 * @return WebElement
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElement(By by) {
		WebElement webElement = null;
		try {
			// Identify the webelement based on By object
			webElement = driver.findElement(by);
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the web element", "Web element should be retrieved", "Web element was retrieved",
					"Could not retreive the web element", true);
		}
		return webElement;
	}

	/**
	 * This method is used for getting value from the style tag
	 *
	 * @return String
	 * @author Pooja Navdeti
	 * @since 08/26/2019
	 */
	public String getCSSValueId(String elementId, String cssValue) {
		return driver.findElement(By.id(elementId)).getCssValue(cssValue);
	}

	/**
	 * This method returns WebElement object for given locator string based on xpath
	 *
	 * @param locator
	 * @return By
	 * @author Prabhakaran Manoharan
	 * @since 07-16-2019
	 */
	public WebElement getWebElementUsingXpath(String locator) {
		WebElement webElement = null;
		try {
			webElement = driver.findElement(By.xpath(locator));
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
					"Retrieving the web element", "Web element should be retrieved", "Web element was retrieved",
					"Could not retrieve the web element", true);
		}
		return webElement;
	}

	/**
	 * Function is used for check if the web element is Not present on the page
	 *
	 * @param locatorXpath
	 * @return boolean
	 * @author Prabhakaran Manoharan
	 * @since 8/11/2018
	 */
	public boolean isElementNotPresentUsingXpath(String locatorXpath) {
		return !LPLCoreSync.waitTillVisible(driver, By.xpath(locatorXpath), lplCoreConstents.MEDIUM);
	}

	/**
	 * This method is used to set the error message to strError variable
	 *
	 * @param errorMessage
	 * @author Prudhvi Raj M
	 * @since 08-28-2019
	 */
	private void setErrorMessage(String errorMessage) {
		// Initializing the strError variable with the exception/error message
		strError += errorMessage;
	}

	/**
	 * This method is used to select the dropdown value by text using xpath
	 *
	 * @param dropdownXpath
	 * @param valueToSelect
	 * @param elementName
	 * @return boolean
	 * @author H Abdul Hadi
	 * @since 07-03-2020
	 */
	public boolean selectValueFromDropdownUsingXpath(String dropdownXpath, String valueToSelect, String elementName) {
		SelectDropDown selectDropDown = new SelectDropDown(driver, By.xpath(dropdownXpath));
		boolean blnResult = selectDropDown.selectValueByVisibleText(valueToSelect);
		if (!blnResult) {
			setErrorMessage(selectDropDown.strError);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					SELECT + valueToSelect + FROM + elementName + DROPDOWN,
					valueToSelect + FROM + elementName + DROPDOWN + SELECT,
					SELECT + valueToSelect + FROM + elementName + DROPDOWN, FAILED_TO_SELECT_TO + valueToSelect + FROM
							+ elementName + DROPDOWN + USING_LOCATOR + dropdownXpath + ERROR + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to select the dropdown value by text using Id
	 *
	 * @param dropdownXpath
	 * @param valueToSelect
	 * @param elementName
	 * @return boolean
	 * @author H Abdul Hadi
	 * @since 07-03-2020
	 */
	public boolean selectValueFromDropdownUsingId(String dropdownId, String valueToSelect, String elementName) {
		SelectDropDown selectDropDown = new SelectDropDown(driver, By.id(dropdownId));
		boolean blnResult = selectDropDown.selectValueByVisibleText(valueToSelect);
		if (!blnResult) {
			setErrorMessage(selectDropDown.strError);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					SELECT + valueToSelect + FROM + elementName + DROPDOWN,
					valueToSelect + FROM + elementName + DROPDOWN + SELECT,
					SELECT + valueToSelect + FROM + elementName + DROPDOWN, FAILED_TO_SELECT_TO + valueToSelect + FROM
							+ elementName + DROPDOWN + USING_LOCATOR + dropdownId + ERROR + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to wait for page to load completely.
	 *
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2019
	 */
	public void waitForPageLoading() {
		waitForPageLoading(lplCoreConstents.HIGHINMILLISEC);
		waitForProgressBarToDisappear();
	}

	/**
	 * This method is used to wait for page to load completely. Max wait time is
	 * specified
	 *
	 * @param intMaxTime
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2020
	 */
	public boolean waitForPageLoading(int intMaxTime) {
		try {
			(new WebDriverWait(this.driver, (long) intMaxTime)).until(new Function<WebDriver, Boolean>() {
				public Boolean apply(WebDriver driver) {
					return String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
							.equals(COMPLETE);
				}
			});
			return true;
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			return false;
		}
	}

	/**
	 * This method is used to wait for 'Loading.. ' progress bar to disappear
	 *
	 * @return void
	 * @author Abdul Hadi
	 * @since 07/14/2020
	 */
	public void waitForProgressBarToDisappear() {
		String loadingBarLocator = "//*[@id='ngProgress-container' and not(contains(@style,'display: none;'))]";
		boolean isProgressBarDisplayed = LPLCoreSync.waitTillVisible(driver, By.xpath(loadingBarLocator),
				lplCoreConstents.LOW);
		if (isProgressBarDisplayed)
			isElementNotPresentUsingXpath(By.xpath(loadingBarLocator), lplCoreConstents.HIGHEST);
		boolean isPageLoadingCircleDisplayed = LPLCoreSync.waitTillVisible(driver, By.cssSelector(".pageLoading"),
				lplCoreConstents.LOW);
		if (isPageLoadingCircleDisplayed)
			isElementNotPresentUsingXpath(By.cssSelector(loadingBarLocator), lplCoreConstents.HIGHEST);
	}

	/**
	 * Function is used for check if the web element is Not present on the page for
	 * specified time
	 *
	 * @param locatorXpath
	 * @param intTimeOutInSeconds
	 * @return boolean
	 * @author Abdul Hadi
	 * @since 07/14/2020
	 */
	public void isElementNotPresentUsingXpath(By locatorXpath, int intTimeOutInSeconds) {
		(new WebDriverWait(driver, (long) intTimeOutInSeconds))
				.until(ExpectedConditions.invisibilityOfElementLocated(locatorXpath));
	}

	/**
	 * Function is used for check if the web element is enabled or not on the page
	 *
	 * @param locatorID
	 * @param elementName
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 */
	public boolean isElementEnabled(String locatorId, int maxWaitTimeInSeconds, String elementName) {
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorId);
		return webElement.isEnabled();
	}

	/**
	 * This function is used to verify element is disabled or not.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 **/
	public boolean isElementDisabled(String xpath, int maxWaitTimeInSeconds, String element) {
		return !isElementEnabled(xpath, maxWaitTimeInSeconds, element);
	}

	/**
	 * Function is used for check if the web element is displayed on the page
	 *
	 * @param locatorID
	 * @param elementName
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/10/2020
	 */
	public boolean isElementDisplayed(String locatorId, int maxWaitTimeInSeconds, String elementName) {
		WebElement webElement = getWebElement(elementName, LPLCoreConstents.XPATH, locatorId);
		return webElement.isDisplayed();
	}

	/**
	 * This method is used to check if the element is disabled
	 * 
	 * @param xpath
	 * @param element
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 09/04/2020
	 **/
	public boolean isElementNotDisplayed(String xpath, int maxWaitTimeInSeconds, String element) {
		return !isElementDisplayed(xpath, maxWaitTimeInSeconds, element);
	}

	/**
	 * This function is used to verify font used for messages.
	 *
	 * @return boolean
	 * @author Krishna Vakalapudi
	 * @since 08/15/2020
	 **/
	public boolean fontRobotUsed(String locatorId, String elementName) {
		boolean blnResult = false;
		WebElement text = getWebElementUsingXpath(locatorId);
		String fontFamily = text.getCssValue(FONT_FAMILY);
		fontFamily = fontFamily.toLowerCase();
		if (fontFamily.contains(ROBOTO)) {
			blnResult = true;
		} else {
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Verify that User able to see text font is Roboto",
					"User should be able to see text font is Roboto", "User able to see text font is Roboto",
					"Font is not Roboto but " + fontFamily + strError);
		}
		return blnResult;
	}
}
