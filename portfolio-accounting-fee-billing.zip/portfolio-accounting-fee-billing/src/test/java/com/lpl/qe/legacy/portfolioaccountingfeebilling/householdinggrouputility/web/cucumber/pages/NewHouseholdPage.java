package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreUtil;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> NewHouseholdPage.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for NewHouseholdPage</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * NewHouseholdPage : </br>
 * <br>
 * isPageDisplayed : This method is used to check if new household page is
 * loaded</br>
 * <br>
 * String : This method is used to return the placeholder for the client search
 * box</br>
 * <br>
 * enterSearchTextInClientPrimarySearchBox : This method is used to enter the
 * text in Client search text box</br>
 * <br>
 * getSearchResultsForClientsPrimary : This method is used to return the another
 * search results for client name search * </br>
 * <br>
 * enterSearchTextInOtherClientPrimarySearchBox : This method is used to enter
 * the other text in Client search text box </br>
 * <br>
 * getSearchResultsForClientPrimary : This method is used to return the search
 * results for client name search</br>
 * <br>
 * clickEditGroupNameButton : This method is used to click on Edit Group Client
 * Name </br>
 * <br>
 * clearEditGroupName : This method is used to clear and Edit Group Client Name
 * </br>
 * <br>
 * getClientPrimaryNameFromSearchResult : This method is used to return the one
 * of the client name from the client name search results</br>
 * <br>
 * getClientsPrimaryNameFromSearchResult : This method is used to return the one
 * of the client name from the other </br>
 * <br>
 * selectClientPrimary : This method is used to select one of the client name
 * from the client name search results</br>
 * <br>
 * isTileDisplayed : This method is used to check if the tile is displayed for
 * the given client name</br>
 * <br>
 * clickCloseButton: This method is used to click on close button in create
 * Household page </br>
 * <br>
 * clickYesButton : This method is used to verify close button warnning popup
 * Yes button clicked</br>
 * <br>
 * clickNoButton : This method is used to verify close button warnning popup No
 * button clicked</br>
 * <br>
 * verifyCameoutFromCreateHouseholdSetUpPage :This method is used to verify came
 * out from create Household set up page after click on Yes button </br>
 * <br>
 * capitalizeString : This method is used to capitalize the string(Pascal
 * Case)</br>
 * <br>
 * <br>
 * clearAndEnterCombinedStatementName : This method is used to clear and Edit
 * Combined Statement Name </br>
 * clickDeleteClientButton : This method is used to delete the client </br>
 * <br>
 * viewBlanktile : This method is used to view the blank tile after delete the
 * client </br>
 * <br>
 * clickCreateHouseholdButton : This method is used to return the placeholder
 * for the Create HouseHold Group </br>
 * <br>
 * VerifyHouseholdGroupCreated : This method is used to return the confirmation
 * for the HouseHold Group Created successfully</br>
 * <br>
 * clickXCloseIcon : This method is used to click the x close button on
 * confirmation banner button </br>
 * <br>
 * verifyWarnningPopup : This method is used to verify close button warnning
 * popup in create Household setup page </br>
 * <br>
 * verifyStreamlineTooltip : This method is used to verify the Household Group
 * confirmation page Tool tip </br>
 *
 * <br>
 * verifyStreamlineTooltipText : This method is used to verify the Household
 * Group confirmation page Why Streamline ? Tool tip Text</br>
 * <br>
 * clickOnCloseButton : This method is used to click on close button on
 * Household Group confirmation page </br>
 * <br>
 * clickDeleteButton : This method is used to delete the client in the HouseHold
 * setup page</br>
 * <br>
 * isTooltipDisplayed: This method is used to validate Primary client Tooltip
 * </br>
 * <br>
 * isTooltipContentDisplayed : This method is used to validate Primary client
 * Tooltip content </br>
 * <br>
 * clickContentChevron : This method is used to click on content chevron on
 * Household confirmation page</br>
 * verifyPopUp : This method is used to verify close button popup in Household
 * confirmation page</br>
 * <br>
 * <br>
 * strEditHouseholdGroupXpath : This method is used to edit the household group
 * </br>
 * verifyRecommendedNextStep : This method is used to verify the Household Group
 * confirmation page Recommended Next Step Streamline Household Capabilities
 * </br>
 * <br>
 * clickCombinedStatement : This method is used to click on Combined Statement
 * streamline </br>
 * <br>
 * isHHPageDisplayed: This method is used to select the Household from create
 * group dropdown </br>
 * <br>
 * clickOnPrimaryRadioButton : This method is used to click on Primary Radio
 * button to select the client as primary </br>
 * <br>
 * verifyHouseholdCombinedStatement : This method is used to verify the
 * Household Group confirmation page Recommended Next Step Streamline Household
 * Capabilities as Household Combined Statement </br>
 * <br>
 * clickStreamlineBillingButton : This method is used to set up the
 * StreamlineBilling for Household Group </br>
 * <br>
 * clickFlatFeeTypeButton : This method is used to select the StreamlineBilling
 * Fee Type Flat Fee </br>
 * <br>
 * enterFlatFeeValue : This method is used to enter the Flat Fee Value </br>
 * <br>
 * clickFlatFeeValue : This method is used to select the Flat Fee Value </br>
 * <br>
 * clickDoneButton : This method is used to click the Done button </br>
 * <br>
 * VerifyBillingReviewHeader : This method is used to view the Billing Review
 * page </br>
 * <br>
 * clickOnEditStreamlineBillingPencilIcon : This method is used to click on
 * Streamline Billing Edit pencil icon </br>
 * <br>
 * clickBillingEditDetails : This method is used to edit the Billing page </br>
 * <br>
 * clickProgressiveTieredFeeTypeButton : This method is used to select the
 * StreamlineBilling Fee Type Flat Fee </br>
 * <br>
 * clickViewLetterCombineStatementButton : This method is used to click on view
 * Letter of combined statement </br>
 * <br>
 * selectAdditionalSchedule : This method is used to select the Progressive
 * Tiered additional Schedule from </br>
 * <br>
 * clickBillingEditSubmitChangesButton : This method is used to click on Edit
 * billing submit changes button </br>
 * <br>
 * clickCreateHouseHoldBillingSetUpButton : This method is used to create
 * household Billing setup button </br>
 * <br>
 * VerifyHouseholdGroupBillingCreated : This method is used to return the
 * Billing setup confirmation for the </br>
 * <br>
 * clickReviewButton : This method is used to click on review button in edit
 * household group page</br>
 * clickSubmitChangesButton : This method is used to click on Submit Changes
 * button in edit review household group page </br>
 * <br>
 * verifyEditBillingDetailsPage : This method is used to verify the edit billing
 * details page </br>
 * <br>
 * verifyBillingUpdatedConfirmationPage : This method is used to verify Edit
 * billing confirmation page </br>
 * <br>
 * enterGroupname : This method is used to enter group name in group listing
 * Page </br>
 * <br>
 * clickHHGroupName : This method is used to click on hyperlinked groupname in
 * group listing Page </br>
 * <br>
 * isDashboardPageDisplayed : This method is used to view Household dashboard
 * Page </br>
 * <br>
 * VOTgraphDisplayed : This method is used to validate VOT graph </br>
 * <br>
 * VOTgraphaxisDisplayed : This method is used to validate VOT graph axis data
 * </br>
 * <br>
 * clickEditHHsummarybutton : This method is used to click on edit household
 * summary button </br>
 * <br>
 * EditHouseholdPageDisplayed : This method is used to view edit household Page
 * </br>
 * <br>
 * AccounttileDisplayed : This method is used to validate Account tile </br>
 * <br>
 * AccounttilefieldVisible : This method is used to validate Account tile fields
 * </br>
 * <br>
 * clickEditcombinedstatementbutton : This method is used to click on Edit
 * combined statement button in household dashboard Page </br>
 * <br>
 * EditcombinedstatementPageDisplayed : This method is used to view Edit
 * combined statement Page after clicking edit combined statement icon in
 * dashboard Page </br>
 * <br>
 * clickEditbillingratebutton : This method is used to click on billing rate
 * icon in the dashboard Page </br>
 * <br>
 * EditbillingPageDisplayed : This method is used to validate edit billing page
 * after clicking billing rate icon in the dashboard page </br>
 * <br>
 * clickshowfulldetailshyperlink : This method is used to click on show full
 * details hyperlink </br>
 * <br>
 * hidefulldetailshyperlinkDisplayed : This method is used to view hide full
 * details hyperlink </br>
 * <br>
 * assetallocationbreakdownPanelDisplayed : This method is used to check asset
 * allocation breakdown Panel is displayed </br>
 * <br>
 * clickshidefulldetailshyperlink : This method is used to click on hide full
 * details hyperlink </br>
 * <br>
 * notessectionDisplayed : This method is used to check Notes Section is
 * displayed </br>
 * <br>
 * addnotehyperlinkDisplayed : This method is used to Validate Add Note
 * hyperlink is displayed </br>
 * <br>
 * clickaddnotehyperlink : This method is used to click on add note hyperlink
 * </br>
 * <br>
 * newnotewindowDisplayed : This method is used to Validate New Note Window is
 * displayed </br>
 * <br>
 * enternotefields : This method is used to enter the Title and Text of note
 * </br>
 * <br>
 * selectnotetype : This method is used to Select Note Type </br>
 * <br>
 * clicknotesavebutton : This method is used to click on save note Button </br>
 * <br>
 * createdNoteDisplayed : This method is used to Validate Created Note is
 * displayed </br>
 * <br>
 * PositionBalancesUpdateFrequencyDisplayed : This method is used to check
 * selected Position Balances Update Frequency hyperlink is displayed </br>
 * <br>
 * defaultIntradayUpdatedBalancesoptionDisplayed : This method is used to check
 * default Intraday Updated Balances option is displayed </br>
 * <br>
 * clickupdatefrequencydropdownbutton : This method is used to click on Position
 * Balances Update Frequency dropdown Button </br>
 * <br>
 * clickpreviousMarketCloseoption : This method is used to click on default
 * Previous Market Close option </br>
 * <br>
 * clickintradaydropdownoption : This method is used to click on Intraday
 * Updated Balances option </br>
 * <br>
 * clickintradayupdatedbalancesoption : This method is used to click on Intraday
 * Updated Balances option </br>
 * <br>
 * clickpreviousmarketplacedropdownoption : This method is used to click on
 * Previous Market Close option from dropdown </br>
 * <br>
 * clickCreateaNewCombinedStatementforClientbutton : This method is used to
 * click on Create a New Combined Statement for Client button </br>
 * <br>
 * tiletoselectprimaryaccountDisplayed : This method is used to check if tile to
 * select primary account is displayed after clicking on Create a New Combined
 * Statement for Client button </br>
 * <br>
 * clickclientname : This method is used to select client names from search
 * results in Edit Household Page </br>
 * <br>
 * summarynamewithrepid : This method is used to validate household summary name
 * with repid in dashboard Page </br>
 * <br>
 * primaryclientcontactinformation : This method is used to validate primary
 * client information in the summary section of the dashboard Page </br>
 * <br>
 * householdclientsection : This method is used to validate household client
 * section in the dashboard Page </br>
 * <br>
 * primaryclienthouseholdsection : This method is used to validate primary
 * client tile in the household client section of the dashboard Page </br>
 * <br>
 * <br>
 * expandbillingratechevron : This method is used to expand Billing rate chevron
 * </br>
 * <br>
 * collapsebillingratechevron : This method is used to collapse Billing rate
 * chevron </br>
 * <br>
 * validatebanksweepmessage : This method is used to validate bank sweep message
 * in the confirmation page </br>
 * <br>
 * seehouseholdcapabilitiessection : This method is used to validate household
 * capabilities section in the dashboard Page </br>
 * <br>
 * clickcreateanewcombinedstatement : This method is used to click on Create a
 * New Combined Statement for Client in C/S Edit Modal </br>
 * <br>
 * seereviewprimayaccountinformation : This method is used to validate review
 * primary account information in C/S edit modal </br>
 * <br>
 * seenextbutton : This method is used to validate next button in C/S edit modal
 * </br>
 * <br>
 * noaccounteligiblemessage : This method is used to validate no account
 * eligible message for each capability </br>
 * <br>
 * seeredcolourdeletebillingtracker : This method is used to validate red colour
 * delete billing tracker </br>
 * <br>
 * seebillingsummary : This method is used to validate billing summary in the
 * confirmation Page <\br> <br>
 * seeAddClienttoanExistingStatementbutton : This method is used to validate Add
 * Client to an Existing Statement button in selected state <\br> <br>
 * clickContentsChevronCSeditmodal : This method is used to click on contents
 * Chevron in combined statement edit modal<\br> <br>
 * clickeditCSclosemodalbutton : This method is used to click on close modal
 * option in CS edit modal page<\br> <br>
 * clickyesbuttonCSclosemodal : This method is used to click on yes button
 * present in edit CS close modal popup <\br> <br>
 * seesubgroupcombinedstatementswithheader : This method is used to validate sub
 * group combined statement header along with sub group combined statements<\br>
 * <br>
 * seesubgroupcombinedstatementsinprogressstatus : This method is used to
 * validate sub group combined statements INPROGRESS status </br>
 * 
 * @author pmanohar/dshukla
 * @param <waittillvisibleusingxpath>
 * @since 06/04/lplCoreConstents.HIGHlplCoreConstents.HIGH
 *        </p>
 */

public class NewHouseholdPage extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 872;
	Map<String, HashMap<String, String>> pageObjectMap;
	String strClientPrimarySearchTextboxXpath;
	String strPageHeaderXpath;
	String strGroupSearchTextboxXpath;
	String strGroupSearchTextboxSearchXpath;
	String strClientsPrimarySearchTextboxXpath;
	String strPrimaryClientSearchResultsXpath;
	String strContextMenuDropdownXpath;
	String strDeleteHouseholdBtnXpath;
	String strContextMenuDeleteXpath;
	String strReturnCMGroupsBtnXpath;
	String strCombineStatementEditBtnXpath;
	String strEditCombineStatementNameXpath;
	String strPrimaryClientsSearchResultsXpath;
	String strClientNameInTileXpath;
	String strPrimaryRadioButtonXpath;
	String strEditBillingDetailsXpath;
	String strReviewButtonXpath;
	String strSubmitChangesButtonXpath;
	String strDeleteBtnXpath;
	String strEditGroupNameBtnXpath;
	String strClearGroupNameXpath;
	String strEditGroupNameXpath;
	String strViewLetterCombinedStatementXpath;
	String strBlankTileXpath;
	String strCreateBtnXpath;
	String strToolTipPrimaryClientXpath;
	String strToolTipPrimaryClientContentXpath;
	String strConfirmationMsgXpath;
	String strStreamlineToolTipXpath;
	String strStreamlineBillingXpath;
	String strDoneButtonXpath;
	String strBillingReviewHeaderXpath;
	String strCreateGroupNameXpath;
	String strCreateGroupNameValueXpath;
	String strEditBillingNameiConXpath;
	String strEditBillingNameXpath;
	String strEditDetailsButtonXpath;
	String strProgressiveTieredXpath;
	String strAdditionalScheduleXpath;
	String strAdditionalScheduleValueXpath;
	String strSearchBoxXpath;
	String strCloseXIconXpath;
	String strStreamlineToolTipTextAXpath;
	String strclosebuttonXpath;
	String strCloseXButtonXpath;
	String strConfirmationCloseXButtonXpath;
	String strWarnningPopupXpath;
	String strNoButtonXpath;
	String strYesButtonXpath;
	String strComeoutFromCreateHHPageXpath;
	String strEditBillingConfirmationPageXpath;
	String strEditHHPageXpath;
	String strCloseButtonPopUpXpath;
	String strRecommendedNextStepXpath;
	String strCombinedStatementXpath;
	String strCombinedStatementLinkXpath;
	String strContentChevronXpath;
	String strEditHouseholdGroupXpath;
	String strClientSearchTextboxXPATH;
	//String strClientSearchButtonXpath;
	String strClientSearchCheckBoxXPATH;
	String strContextMenuGroupXPATH;
	String strContextMenuEditHouseholdGroupXPATH;
	String strActionButtonXPATH;
	String strPrimaryClientSearchTextboxXPATH;
	String strPopupboxXPATH;
	String strPopupboxTextXPATH;
	String strOKButtonpopupboxXPATH;
	String strConfirmationPageXpath;
	String strChangesNotSavedPopupXPATH;
	String strGoBackButtonXPATH;
	String strProceedToCloseButtonXpath;
	String strPleaseSelectPrimaryClientTextXPATH;
	String strNoResultFoundTextXPATH;
	String strRemoveClientBtnXPATH;
	String strFormsToolTipXPATH;
	String strFormsToolTipContentsXPATH;
	String strBillingFormBtnFormsPanelXPATH;
	String strFormsContentWhenOutstandingDocGridPresentXPATH;
	String strPrepareFormForSignBtnFormsPanelXPATH;
	String strFormReadyToSignPanelXPATH;
	String strActivationIndicatorInFormReadyToSignXPATH;
	String strFormReadytoSignLabelXPATH;
	String strFormReadytoSignWhenOutstandingDocGridPresentXPATH;
	String strBillingFormBtnFormReadytoSignXPATH;
	String strDropDownFormReadytoSignXPATH;
	String strPrepareFormForSignBtnFormReadytoSignXPATH;
	String strclickGroupsTabxpath;
	String strenterGroupnamexpath;
	String strGroupsearchbuttonxpath;
	String strBillingRateXpath;
	String strsubheadernamexpath;
	String strSubheadereditbuttonxpath;
	String strBillingRateOpenAllXpath;
	String strAdvisoryFeeXpath;
	String strclickGroupnameXpath;
	String strclickHHGroupnamexpath;
	String strNavEditHHpagexpath;
	String strEditbillingpagexpath;
	String strEditBillingDetailsBannerXPATH;
	String strEditBtnEditBillingBannerXPATH;
	String strDeleteBtnEditBillingBannerXPATH;
	String strProceedToDeleteButtonXPATH;
	String strDoneDeletingButtonXPATH;
	String strBillingDeletionConfirmationMsgXPATH;
	String strGoBackBtnDeleteBannerXPATH;
	String strAccountSummaryPageXpath;
	String strClickClientNamexpath;
	String strClientSummaryPageXpath;
	String strBackLinkXpath;
	String strValidateBackLinkXpath;
	String strBankSweepTileXpath;
	String strNoBankSweepEditIconXpath;
	String strBillingContentsChevronXpath;
	String strValidateOpenAllXpath;
	String strClickOpenAllXpath;
	String strBillingPanelXpath;
	String strValidateCloseAllXpath;
	String strClickCloseAllXpath;
	String strBillingPanelClosedXpath;
	String strFlatRateDecimalDashboardXPATH;
	String strFlatRateDecimalXPATH;
	String strFlatRateDecimalReviewXPATH;
	String strClientContextMenuXpath;
	String strClickDeleteHHxpath;
	String strDeleteHouseholdPageXpath;
	String strHHBannerTitlexpath;
	String strDeleteHHLabelXpath;
	String strCancelAndReturnXpath;
	String strClickDeleteHHbuttonXpath;
	String strDeleteHHpopupXpath;
	String strClickReturnClientMgmtXpath;
	String strhouseholdaccountsxpath;
	String strNoCombinedStatementTileXpath;
	String strDoneDeletingXpath;
	String strProceedToDeleteXpath;
	String strClickDeleteCombinedStatementXpath;
	String strCombinedCollapsedContentsPanelXpath;
	String strValidateCombinedContentsCollpsedXpath;
	String strCombinedAccountsCollapsedXpath;
	String strClickCombinedAccountsCollapsedXpath;
	String strClickCombinedExpandAccountsXpath;
	String strValidateCombinedAccountsChevronXpath;
	String strValidateCombinedAccountDetailsXpath;
	String strClickCombinedExpandContentsXpath;
	String strPreselectClientNameXpath;
	String strErrorMessageXpath;
	String strEditBtnEditCombinedStmtBannerXPATH;
	String strOutsideBusinessAccountXpath;	
//	String titleNewCombinedStatementSubgroupPageXpath;
	String strTrackerCombinedStatementName;
	String strHeadingCombinedStatementName;
	String strPrimaryClientSearchResult;
	String strSetupCombinedStatementSubgroupXpath;
	String strNewCSdropdownMenuXpath;
	String strNewCombinedStatementNameXpath;
	String strCreateaNewCSforClientXpath;
	String strselectprimaryaccounttileXpath;
	String strclientnameselectxpath;
	String strAccountPanelTitleXpath;
	String strsummarynameXpath;
	String strhhrepidXpath;
	String strprimaryclientcontactinfoXpath;
	String strhouseholdclientsectionXpath;
	String strprimaryclienthhsectionXpath;
	String strbillingrateexpandchevronXpath;
	String strbillingcollapseratechevronXpath;
	String strbanksweepmessageXpath;
	String strClickEditHHPencilIconXpath;
	String strChevronBillingRateSection;
	String strClientNameBillingRateSection;
	String strNextBillingDate;
	String strUpComingFee;
	String strPaidFromColumn;
	String strAdvisoryFeesColumn;
	String strclickOnCancelWithoutAddingClient;
	String selectNoFromPrompt;
	String strCSEditModalClickCloseButtonXpath;
	String selectYesFromPrompt;
	String strhouseholdcapabilitiessectionXpath;
	String strNoOfclientsReviewHHPageXpath;
	String strNoOfAccountsForEachClientLocXpath;
	String strClickAccountChevronXpath;
	String strShowMoreXpath;
	String strContentsChevronXpath;
	String strcreateanewcombinedstatementXpath;
	String strprimaryaccountinformationXpath;
	String strNextButtonXpath;
	String strNoAccountEligibleMessageXpath;
	String strNoAccountEligibleMessageBankSweepXpath;
	String strPrimaryClientSearchResultsListXpath;
	String strReviewBillingAccountChevronXpath;
	String strReviewBillingAccountDetailsXpath;
	String strReviewBillingShowMoreButtonXpath;
	String strreddeletebillingtrackerXpath;
	String strEditHHAccountChevronXpath;
	String strEditHHContentsChevronXpath;
	String strEditHHAccountDetailsXpath;
	String strNoOfClientsXpath;
	String strNoOfAccountsContentsPanelXpath;
	String strNoOfClientsContentXpath;
	String strAccountValueContentsPanelXpath;
	String strNoOfAccountEachClientXpath;
	String strAccountValueEachClientXpath;
	String strbillingsummaryXpath;
	String strsubgroupcombinedstatementinprogressstatusXpath;
	String strCSSubmitChangesXpath;
	String strfeeratevalueXpath;
	String strtotalassetvalueXpath;
	String strbillablevalueXpath;
	String strESTAnnualfeesXpath;
	String strYTDfeesXpath;
	String strPrimaryClientExistXpath;
	String strBillingUpdatedXpath;
	String strBillingNameXpath;
	String strAlertMsgBillingXpath;
	String strNoOfColumnsBillingSummaryXpath;
	String strBillingColumnNameXpath;
	String strAccountNameXpath;
	String strAccountClassXpath;
	String strAccountNumberXpath;
	String strContentPanelXpath;
	String strAccountPanelXpath;
	String strcsedithhcontentchevronXpath;
	String strcontentclientnameXpath;
	String strClientTitleXpath;
	String strAccountsTitleXpath;
	String strValueTitleXpath;
	String strClickReviewContentsXpath;
	String strClientReviewTitleXpath;
	String strValueReviewTitleXpath;
	String strAccountsReviewTitleXpath;
	String strShowFullDetailsLinkXpath;
	String strTotalGroupValueXpath;
	String strRevenueYTDXpath;
	String strCashandEquivalentPctXpath;
	String strRevenueLast1yrXpath;
	String strclientsandaccountdetailschevronXpath;
	String strclienttileinformationXpath;
	String strclientsaccountXpath;
	String strclientaccountchevronXpath;
	String strclientaccountnameXpath;
	String strprogramnameXpath;
	String strclientaccountnumberXpath;
	String strtotalaccountvalueXpath;
	String strNoOfClientsReviewHHXpath;
	String StrEditHHGroupNamePencilIconXpath;
	String strErrorMsgHHNameExceedingLimitXpath;
	String strNoOfSecuritiesXpath;
	String strMarketValueForSecuritiesXpath;
	String strCSsubgroupJumpToDetailsXpath;
	String strCSaccountsxpath;
	String strCSshowmorebuttonxpath;
	String strHHNameSummaryPanelConfPageXpath;
	String strRepIDSummaryPanelConfPageXpath;
	String strContentsLabelSummaryPanelConfPageXpath;
	String strActiveStatusSummaryPanelConfPageXpath;
	String strCombinedStatementOptionalXpath;
	String strCombinedStatementLinkConfPageXpath;
	String strsubgroupcombinedstatementstilesXpath;
	String strsubgroupcombinedstatementsectionXpath;
	String strcombinedstatementbannerxpath;
	String strcombinedstatementgreenbannertextXpath;
	String strcrossbuttoncombinedstatementbannerxpath;
	String strContentChevronBillingSecConfPageXpath;
	String strContentChevronBillingSecConfPageExpandedXpath;
	String strAccChevronBillingSecConfPageNotExpandedXpath;
	String strAccChevronBillingSecConfPageXpath;
	String strAccChevronBillingSecConfPageExpandedXpath;
	String strContentChevronBillingSecConfPageCollapsedXpath;
	String  strclientacountchevronxpath;
    String  strCSAccountnameXpath;
    String strCSAccountclassXpath;
    String strCSAccountnumberXpath;
    String  strCStotalaccountvalueXpath;
	String strclickCashAccountGroupnameXpath; 
	String strBalancesAndInvestmentsXpath;
	String houseHoldName;
	String strHouseholdValueXpath;
	String strPrimaryClientValueXpath;
	String  strsubgroupcstileXpath;
	String strRemoveClientButtonXpath;
    String strselectedremovalclientxpath;
	String strHouseholdNameCreatePageXpath;
	String strCombinedStatementsubgroupDashboardXpath;
	String strCombinedStatementSingleDashboardXpath;
	String strClickCSOverlayModalNextButtonXpath;
	String strSeeClientAccountNumberXpath;
	String strHouseholdCapabilityTrackerXpath;
	String strInprogressXpath;
	String strHouseholdNameInTrackerXpath;
	String strCapabilityTrackerChevronXpath;
	String strBankSweepTitleInTrackerXpath;
	String strBanksweepNameXpath;
	String strEditChangeTileXpath;
	String strReviewChangeTileXpath;
	String strHouseholdBannerXpath;
	String strSummaryBannerFieldsXpath;
	String strReviewHouseholdButtonXpath;
	String strClientSearchEditHouseholdXpath;
	String strPrimaryClientSearchResultsEditHouseholdXpath;
	String strDeleteEditingButtonCombinedStatementXpath;
	String strSubmitHouseholdButtonXpath;
	String strRemovedClientToolTipXpath;
	String strRemoveClientToolTipLinkXpath;
	String strBanksweepContentsChevronXpath;
	String strcloseHouseholdButtonXpath;
	String strAlphaNumericErrorMessageXpath;
	String strExceedinGroupNameErrorMessageXpath;
	String strBlankErrorMessageXpath;
	String strClientTabXpath;
	String strClientNameClientTabXpath;
	String strClientSearchButtonXpath;
	String strEditOptionXpath;
	String strMoveButtonXpath;
	String strSelectAccountsToMOvePageTitleXpath;
	String strNoAccountEligibleMessageCombinedStmtXpath;
	String strNoAccountEligibleMessageBillingXpath;
	String strCapabilityTrackerClientVerbiageXpath;
	String strCapabilityTrackerRemoveClientTextTitlexpath;
	String strCapabilityTrackerRemoveClientTextxpath;
	String strExpandedChevronXpath;
	String strAddedClientCapabilitiesXpath;
	String strAccountTabXpath;
	String strAccountContextMenuXpath;
	String strHouseholdCreatedSuccessXpath;
	String strHouseholdNameXpath;
	String strRepIDXpath;
	String strActiveTextXpath;
	String strStreamlineToolTipText1Xpath;
	String strStreamlineToolTipText2Xpath;
	String strInvestmentManagementTileXpath;
	String strBanmSweepTileConfPageXpath;
	String strContentChevronBankSweepXpath;
	String strUndoButtonOnTrackerXpath;
	String strClientTileXpath;
	String strClientAccChevronReviewPageXpath;
	String strDefault5AccountReviewPageXpath;
	String strClientsScrollbarXpath;
	String strConfirmationPageForNewXpath;


	public static final String FIELDS = "Fields";
	public static final String HOUSEHOLD = "Household";
	public static final String BILLING = "Billing";
	public static final String PRIMARY_CLIENT = "Primary Client";
	public static final String ACCOUNT_CHEVRON = "account Chevron";
	public static final String SHOWFULLDETAILS = "Show Full Detail Link on Household dashboard page";
	public static final String FLAT = "Flat";
	public static final String FLAT_RATE = "FLAT RATE";
	public static final String FLOATING_POINT = "0.0";
	public static final String CHILD_WINDOW = "Child Window";
	public static final String TRACKER_TITLE = " HOUSEHOLD";
	public static final String DELETE_BANNER_TITLE = "DELETE ";
	public static final String ERROR_MSG_FOR_HOUSEHOLD_SPECIALCHARACTERS = "Only alpha-numeric characters are allowed.";
	public static final String FOR_ERROR_MSG_FOR_HOUSEHOLD_EXCEEDING_CHAR = "You have reached the max number of characters.";
	public static final String ERROR_MSG_FOR_BLANK_HOUSEHOLD = "Household Name is required.";
	public static final String MOVE_ACCOUNTS_PAGE_TITLE = "Select Accounts to Move";
	public static final String CLIENT_REMOVED_TRACKER_TEXT = "removed from the";
	public static final String STREAMLINE_TOOL_TIP_TEXT1 = "Streamlining your household can provide you the flexibility and the holistic view you need to effectively manage your clients and their assets.";
	public static final String STREAMLINE_TOOL_TIP_TEXT2 = "You can streamline your management by adding capabilities detailed on this page which can help provide the efficiencies you need in evaluating your clients’ portfolios.";
	
	public NewHouseholdPage(WebDriver driver) {
		super(driver);
		lplCoreUtil = new LPLCoreUtil();
		/** Fetching page objects from FARM */
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		checkForLocatorTypeAndInitializeFields(pageObjectMap, this.getClass().getDeclaredFields(), PAGE_IDENTIFIER);
	}

	/**
	 * This method is used to check if new household page is loaded
	 *
	 * @return boolean
	 * @author pmanohar
	 */
	public boolean isPageDisplayed() {
		driver.switchTo().frame("iframe-modal-frame");
		return isElementPresentUsingXpath(strPageHeaderXpath, lplCoreConstents.HIGH, "New Household Page Header");

	}
	
	/**
	 * This method is used to check if new household page is loaded
	 *
	 * @return boolean
	 * @author pmanohar
	 */
	public boolean isHHPageDisplayed() {
		
		return isElementPresentUsingXpath(strPageHeaderXpath, lplCoreConstents.HIGH, "New Household Page Header");

	}

	/**
	 * This method is used to return the placehMap<String, HashMap<String, String>> pageObjectMap;older for the client search box
	 *
	 * @return String
	 * @author pmanohar
	 */
	public String getPlaceholderForSearchBox() {
		return getAttributeUsingXpath(strClientPrimarySearchTextboxXpath, "placeholder",
				"Search Text for  Primary Client");

	}

	/**
	 * This method is used to enter the text in Client search text box
	 *
	 * @param text - Search text
	 * @return boolean
	 * @author pmanohar
	 */
	public boolean enterSearchTextInClientPrimarySearchBox(String text) {
		clickElementUsingXpath(strClientPrimarySearchTextboxXpath, 120, "Search Text for Client Primary");
		return enterTextUsingXpath(strClientPrimarySearchTextboxXpath, text, "Search Text for Client Primary");
	}
	
	/**
	 * This method is used to click on selected client in Edit household page
	 *
	 * @param text - Search text
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnClientToSelect() {
		return clickElementUsingXpath(strClientSearchEditHouseholdXpath, 120, "Click on the client name");
		//return enterTextUsingXpath(strClientPrimarySearchTextboxXpath, text, "Search Text for Client Primary");
	}

	/**
	 * This method is used to enter the text in Client search text box
	 *
	 * @param text - Search text
	 * @return boolean
	 * @author pmanohar
	 */
	public boolean enterSearchTextInGroupSearchBox(String strText) {
		enterTextUsingXpath(strGroupSearchTextboxXpath, strText, "Search Text for Group");
		return clickElementUsingXpath(strGroupSearchTextboxSearchXpath, "Search Text for Group");
	}

	/**
	 * This method is used to enter the other text in Client search text box
	 *
	 * @param text - Search text
	 * @return boolean
	 * @author dshukla
	 */
	public boolean enterSearchTextInOtherClientPrimarySearchBox(String text2) {
		return enterTextUsingXpath(strClientsPrimarySearchTextboxXpath, text2,
				"Search Text for Another Client Primary");
	}

	/**
	 * This method is used to return the search results for client name search
	 *
	 * @return List<String>
	 * @author pmanohar
	 */
	public List<String> getSearchResultsForClientPrimary() {
		isElementPresentUsingXpath(strPrimaryClientSearchResultsXpath, lplCoreConstents.HIGH,
				"Primary Client Search Results");
		return getTextForWebElementsUsingXpath(strPrimaryClientSearchResultsXpath, " Primary Client Search Results");
	}
	
	/**
	 * This method is used to return the search results for client name search
	 *
	 * @return List<String>
	 * @author vparthas
	 */
	public List<String> getSearchResultsForNewClientPrimary() {
		wait(5);
		isElementPresentUsingXpath(strPrimaryClientSearchResultsEditHouseholdXpath, lplCoreConstents.HIGH,
		"Primary Client Search Results"); 
		return getTextForWebElementsUsingXpath(strPrimaryClientSearchResultsEditHouseholdXpath, " Primary Client Search Results");
	}
	
	/**
	 * This method is used to return the search results for client name search
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeHouseholdCapabilitiesConfPage() {
		return isElementPresentUsingXpath(strCombinedStatementLinkXpath, lplCoreConstents.HIGH,"Combined statement tile")&&
				isElementPresentUsingXpath(strStreamlineBillingXpath, lplCoreConstents.HIGH,"Billing tile")&&
				isElementPresentUsingXpath(strInvestmentManagementTileXpath, lplCoreConstents.HIGH,"Investment Management tile");
		
	}
	
	/**
	 * This method is used to verify Bank Sweep tile in confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeBankSweepTileConfPage() {
		return isElementPresentUsingXpath(strBanmSweepTileConfPageXpath, lplCoreConstents.HIGH,"Combined statement tile");
		
	}
	
	/**
	 * This method is used to click on create household
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickCreateHouseholdButton() {

		return clickElementUsingXpath(strCreateBtnXpath, "CreateHouseHold Button");
	}

	/**
	 * This method is used to return the another search results for client name
	 * search
	 *
	 * @return List<String>
	 * @author dshukla
	 */
	public List<String> getSearchResultsForClientsPrimary() {
		isElementPresentUsingXpath(strPrimaryClientsSearchResultsXpath, lplCoreConstents.HIGHEST,
				"Client Primary Search Results");
		return getTextForWebElementsUsingXpath(strPrimaryClientsSearchResultsXpath,
				"select the client from Search Results");
	}

	/**
	 * This method is used to return the one of the client name from the client name
	 * search results
	 *
	 * @return String
	 * @author pmanohar
	 */
	public String getClientPrimaryNameFromSearchResult() {
		return getTextUsingXpath(strPrimaryClientSearchResultsXpath, "Primary client Search Result");

	}

	/**
	 * This method is used to return the one of the client name from the other
	 * client name search results
	 *
	 * @return String
	 * @author dshukla
	 */
	public String getClientsPrimaryNameFromSearchResult() {
		return getTextUsingXpath(strPrimaryClientsSearchResultsXpath, "Other Primary Client Search Result");
	}

	public void getBrowserClosed() {
		driver.close();

	}

	/**
	 * This method is used to select one of the client name from the client name
	 * search results
	 *
	 * @return boolean
	 * @author pmanohar
	 */
	public boolean selectClientPrimary() {
		return clickElementUsingXpath(strPrimaryClientSearchResultsXpath, "Client Primary Search Result");
	}


	public boolean clickGroupContextMenuDropdown() {
		return iasTradingCmn.performContextOrActionDropdown("Delete", "", "", By.xpath(strContextMenuDeleteXpath));
	}

	/**
	 * This method is used to click on Delete this household button
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickDeleteHousehold() {
		driver.switchTo().frame("iframe-modal-frame");
		clickElementUsingXpath(strDeleteHouseholdBtnXpath, lplCoreConstents.HIGH, "Click on Group Context Dropdown");
		return clickElementUsingXpath(strReturnCMGroupsBtnXpath, "Click on Group Context Dropdown");

	}

	/**
	 * This method is used to select one of the client name from the client name
	 * search results
	 *
	 * @return boolean
	 * @author pmanohar
	 */
	public boolean selectClientsPrimary() {
		return clickElementUsingXpath(strPrimaryClientsSearchResultsXpath, "Client Primary Search Result");
	}

	/**
	 * This method is used to check if the tile is displayed for the given client
	 * name
	 *
	 * @return boolean
	 * @author pmanohar
	 */
	public boolean isTileDisplayed(String clientName) {
		String[] nameParts = clientName.split(" ");
		String formattedClientName = capitalizeString(nameParts[0]) + "  " + capitalizeString(nameParts[1]);
		return isElementPresentUsingXpath(getFormattedLocator(strClientNameInTileXpath, formattedClientName),
				"Client Name Tile");
	}

	/**
	 * This method is used to edit the household group
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean clickOnEditHouseholdIcon() {

		isElementPresentUsingXpath(strEditHouseholdGroupXpath, "Edit household group");
		return clickElementUsingXpath(strEditHouseholdGroupXpath, "Click on edit household group");
	}

	/**
	 * This method is used to click on Primary Radio button to select the client as
	 * primary
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean clickOnPrimaryRadioButton() {
		return clickElementUsingXpath(strPrimaryRadioButtonXpath.replace("xxx", testData.get("firstName")), lplCoreConstents.HIGH,
				"Primary Radio Button clicked");
	}

	

	/**
	 * This method is used to verify the edit billing details page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyEditBillingDetailsPage() {
		return isElementPresentUsingXpath(strEditBillingDetailsXpath, lplCoreConstents.HIGH,
				"Edit Billing Details page");

	}

	/**
	 * This method is used to click on close button in create Household setup page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickCloseButton() {
		return clickElementUsingXpath(strCloseXButtonXpath, "Close Button in Household create page");
	}

	/**
	 * This method is used to click on close button in create Household setup page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickConfirmationCloseButton() {
		return clickElementUsingXpath(strConfirmationCloseXButtonXpath, "Close Button in Household create page");
	}

	/**
	 * This method is used to verify close button warnning popup in create Household
	 * setup page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyWarningPopup() {
		return isElementPresentUsingXpath(strWarnningPopupXpath, lplCoreConstents.HIGH, "Close button warning pop up");
	}

	/**
	 * This method is used to verify close button warning pop up No button clicked
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickNoButton() {
		return clickElementUsingXpath(strNoButtonXpath, "No Button clicked");
	}

	/**
	 * This method is used to verify close button warning pop up Yes button clicked
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickYesButton() {
		return clickElementUsingXpath(strYesButtonXpath, "Yes Button clicked");
	}

	/**
	 * This method is used to click on review button in edit household group page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickReviewButton() {
		return clickElementUsingXpath(strReviewButtonXpath, lplCoreConstents.HIGH, "Review Button clicked");
	}

	/**
	 * This method is used to click on Submit Changes button in edit review
	 * household group page
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean clickSubmitChangesButton() {
		return clickElementUsingXpath(strSubmitChangesButtonXpath, lplCoreConstents.HIGHEST, "Review Button clicked");
	}

	/**
	 * This method is used to verify came out from create Household set up page
	 * after click on Yes button
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyCameoutFromCreateHouseholdSetUpPage() {
		return isElementPresentUsingXpath(strComeoutFromCreateHHPageXpath, lplCoreConstents.HIGH,
				"Come out from create household setup page");
	}

	/**
	 * This method is used to verify Edit billing confirmation page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyBillingUpdatedConfirmationPage() {
		return isElementPresentUsingXpath(strEditBillingConfirmationPageXpath, lplCoreConstents.HIGH,
				"Edit Billing confirmation page");
	}

	/**
	 * This method is used to verify Edit details tile for editing the Household
	 * existing page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyEditHouseholdPageTile() {
		return isElementPresentUsingXpath(strEditHHPageXpath, lplCoreConstents.HIGH, "Edit details page");
	}

	/**
	 * This method is used to capitalize the string(Pascal Case)
	 *
	 * @return boolean
	 * @author pmanohar
	 */
	public String capitalizeString(String text) {

		return text.toLowerCase().substring(0, 1).toUpperCase() + text.toLowerCase().substring(1);
	}

	/**
	 * This method is used to delete the client
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickDeleteButton() {
		return clickElementUsingXpath(strDeleteBtnXpath.replace("xxx", testData.get("firstName")), lplCoreConstents.HIGH, "Delete Client");
	}

	/**
	 * This method is used to click on Edit Group Client Name
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickEditGroupNameButton() {

		return clickElementUsingXpath(strEditGroupNameBtnXpath, "Edit Group Client Name");
	}

	/**
	 * This method is used to click on view Letter of combined statement
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickViewLetterCombineStatement() {
		return clickElementUsingXpath(strViewLetterCombinedStatementXpath, "View Letter combined statement");
	}

	/**
	 * This method is used to clear and Edit Group Client Name
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clearAndEnterGroupName(String groupName) {
		//clearTextUsingXpath(strEditGroupNameXpath, "Group Name");
		return enterTextUsingXpath(strEditGroupNameXpath, groupName, "Group Name");
	}
	
	/**
	 * This method is used to clear group name
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clearHouseholdName() {
		return clearTextUsingXpath(strEditGroupNameXpath, "Group Name");
	}

	/**
	 * This method is used to view the blank tile after delete the client
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean viewBlanktile() {
		return isElementPresentUsingXpath(strBlankTileXpath, "Blank tile after delete the client");

	}

	
	
	/**
	 * This method is used to click the x close button on confirmation banner button
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickXCloseIcon() {
		return clickElementUsingXpath(strCloseXIconXpath, "Click on x Close icon");
	}

	/**
	 * This method is used to click on content chevron on Household confirmation
	 * page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickContentChevron() {
		return clickElementUsingXpath(strContentChevronXpath, "Click on content chevron ");
	}
	
	/**
	 * This method is used to click on content chevron on Household Bank sweep confirmation
	 * page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickContentChevronBankSweep() {
		return clickElementUsingXpath(strContentChevronBankSweepXpath, "Click on content chevron ");
	}

	/**
	 * This method is used to verify the Household Group confirmation page Tool tip
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean verifyStreamlineTooltip() {
		return isElementPresentUsingXpath(strStreamlineToolTipXpath, lplCoreConstents.HIGH,
				"Confirmation page Why Streamline Tool Tip");
	}
	
	/**
	 * This method is used to verify the household created success message
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean seeHouseholdSuccessMsgConfPage() {
		return isElementPresentUsingXpath(strHouseholdCreatedSuccessXpath, lplCoreConstents.HIGH, "Confirmation page success message");
	}
	
	/**
	 * This method is used to verify household contents in confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean seeHouseholdDetailsConfPage() {
		return isElementPresentUsingXpath(strHouseholdNameXpath, lplCoreConstents.HIGH, "Confirmation page success message") &&
				isElementPresentUsingXpath(strRepIDXpath, lplCoreConstents.HIGH, "Confirmation page success message") &&
				isElementPresentUsingXpath(strActiveTextXpath, lplCoreConstents.HIGH, "Confirmation page success message");
	}

	/**
	 * This method is used to verify the Household Group confirmation page Why
	 * Streamline ? Tool tip Text
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyStreamlineTooltipText() {
		return getTextUsingXpath(strStreamlineToolTipText1Xpath, "Edit HH Combined Statement Static Text").equals(STREAMLINE_TOOL_TIP_TEXT1) &&
				getTextUsingXpath(strStreamlineToolTipText2Xpath, "Edit HH Combined Statement Static Text").equals(STREAMLINE_TOOL_TIP_TEXT2);
	}

	/**
	 * This method is used to verify the Household Group confirmation page
	 * Recommended Next Step Streamline Household Capabilities
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyRecommendedNextStep() {
		return isElementPresentUsingXpath(strRecommendedNextStepXpath, lplCoreConstents.HIGH,
				"Confirmation page Recommended Next Step Streamline Household Capabilities");

	}

	/**
	 * This method is used to verify the Household Group confirmation page
	 * Recommended Next Step Streamline Household Capabilities as Household Combined
	 * Statement
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyHouseholdCombinedStatement() {
		return isElementPresentUsingXpath(strCombinedStatementXpath, lplCoreConstents.HIGH,
				"Confirmation page Recommended Next Step :Streamline Household Capabilities");

	}

	/**
	 * This method is used to click on close button on Household Group confirmation
	 * page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickOnCloseButton() {
		return clickElementUsingXpath(strclosebuttonXpath, "Confirmation page close button");
	}

	/**
	 * This method is used to verify close button popup in Household confirmation
	 * page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyPopUp() {
		return isElementPresentUsingXpath(strCloseButtonPopUpXpath, lplCoreConstents.HIGH, "Close button popup");
	}

	/**
	 * This method is used to create the client in the HouseHold setup page
	 * successfully
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean verifyHouseholdGroupCreated() {

		return isElementPresentUsingXpath(strConfirmationMsgXpath, lplCoreConstents.HIGH, "Confirmation page");
	}


	/**
	 * This method is used to select the StreamlineBilling Fee Type Flat Fee
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickProgressiveTieredFeeTypeButton() {

		return clickElementUsingXpath(strProgressiveTieredXpath, "Fee Type Flat Fee selected");
	}

	/**
	 * This method is used to select the Progressive Tiered additional Schedule from
	 * dropdown
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean selectAdditionalSchedule(String additionalschedulename) {
		clickElementUsingXpath(strAdditionalScheduleXpath, "AdditionalSchedule dropdown");
		return clickElementUsingXpath(getFormattedLocator(strAdditionalScheduleValueXpath, additionalschedulename),
				"Additional Schedule dropdown Value");

	}

	/**
	 * This method is used to validate Primary client Tooltip
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean isTooltipDisplayed() {
		return isElementPresentUsingXpath(strToolTipPrimaryClientXpath, lplCoreConstents.HIGH,
				"Primary Client Tool Tip");
	}

	/**
	 * This method is used to validate Primary client tool tip content
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean isTooltipContentDisplayed() {
		return isElementPresentUsingXpath(strToolTipPrimaryClientContentXpath, lplCoreConstents.HIGH,
				"Primary Client Tool Tip content");
	}


	/**
	 * This method is used to view the Billing Review page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyBillingReviewHeader() {
		return isElementPresentUsingXpath(strBillingReviewHeaderXpath, lplCoreConstents.HIGHEST, "Billing Review page");
	}

	/**
	 * This method is used to select the Household from create group dropdown
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean isHouseholdPageDisplayed() {
		clickElementUsingXpath(strCreateGroupNameXpath, lplCoreConstents.HIGHEST, "Create Group dropdown");
		return clickElementUsingXpath(strCreateGroupNameValueXpath, lplCoreConstents.HIGHEST,
				"Create Group dropdown Value select as Household");
	}

	/**
	 * This method is used to edit the Billing page
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickBillingEditDetails() {

		return clickElementUsingXpath(strEditDetailsButtonXpath, "Edit Details button clicked");

	}


	/**
	 * This method is used to return the CW supportview page
	 *
	 * @return boolean
	 * @author dshukla
	 *
	 *         public boolean selectSupportView() { return
	 *         homePage.performCWSupportView("RepID", strRepIDXpath);
	 *
	 *         }
	 */

	/**
	 * This method is used to wait for the frame to be available and switch to it
	 * based on the frame id/ name
	 * 
	 * @param frameId
	 * @return boolean
	 * @author aswain
	 * @since 08/13/2020
	 */
	public boolean switchToFrame(String frameId) {
		// Waiting 30 seconds for an element to be present on the page, checking
		// for its presence once every 5 seconds.
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		return wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameId)) != null;
	}

	/**
	 * This method is used to verify the Pop-up Box
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyPopupbox() {
		return isElementPresentUsingXpath(strPopupboxXPATH, lplCoreConstents.HIGH, "Pop-up Box validation");
	}

	/**
	 * This method is used to verify the Text present in Pop-up Box
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyPopupboxText() {

		return isElementPresentUsingXpath(strPopupboxTextXPATH, lplCoreConstents.HIGH,
				"Validation of Text present in Pop-up Box");

	}

	/**
	 * This method is used to click on OK button in pop up box
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickOKButtonPopupbox() {
		return clickElementUsingXpath(strOKButtonpopupboxXPATH, "OK button clicked in Pop-up Box");
	}

	/**
	 * Method to Validate the Streamline/Confirmation Page
	 * 
	 * @author prchavan
	 * @return boolean
	 */
	public boolean validateConfirmationPage() {
		
		return isElementPresentUsingXpath(strConfirmationPageForNewXpath, lplCoreConstents.HIGH,
				"Validate Confirmation Page");
	}

	/**
	 * This method is used to verify close button changes not saved popup in edit
	 * Household page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyChangesNotSavedPopup() {
		return isElementPresentUsingXpath(strChangesNotSavedPopupXPATH, lplCoreConstents.HIGH,
				"Close button changes not saved pop up");
	}

	/**
	 * This method is used to verify close button changes not saved pop up Go Back
	 * button clicked
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickGoBackButton() {
		return clickElementUsingXpath(strGoBackButtonXPATH, "GO BACK Button clicked");
	}

	/**
	 * This method is used to verify close button changes not saved pop up Proceed
	 * to Close button clicked
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickProceedToCloseButton() {
		return clickElementUsingXpath(strProceedToCloseButtonXpath, "PROCEED TO CLOSE Button clicked");
	}

	/**
	 * This method is used to verify error message when no primary client is
	 * selected
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyPleaseSelectPrimaryClientText() {
		return isElementPresentUsingXpath(strPleaseSelectPrimaryClientTextXPATH, lplCoreConstents.HIGH,
				"Validation of Please select a primary client. error message");
	}

	/**
	 * This method is used to verify message when client search term returns no
	 * result
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyNoResultFoundText() {
		return isElementPresentUsingXpath(strNoResultFoundTextXPATH, lplCoreConstents.HIGH,
				"Validation of No results found. message");
	}

	/**
	 * This method is used to remove the client
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickRemoveClientButton() {
		return clickElementUsingXpath(strRemoveClientBtnXPATH.replace("xxx", testData.get("firstName")), "Remove Client");
	}

	/**
	 * This method is used to validate Forms Tooltip
	 * 
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean isFormsTooltipDisplayed() {
		return isElementPresentUsingXpath(strFormsToolTipXPATH, lplCoreConstents.HIGH, "Forms Tool Tip");
	}

	/**
	 * This method is used to validate Forms tool tip content
	 * 
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean isFormstipContentDisplayed() {
		return isElementPresentUsingXpath(strFormsToolTipContentsXPATH, lplCoreConstents.HIGH,
				"Forms Tool Tip content");
	}

	/**
	 * This method is used to click on Billing Form PDF button available in Forms
	 * Tooltip
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickBillingFormPDFBtnFormsTooltip() {
		return clickElementUsingXpath(strBillingFormBtnFormsPanelXPATH,
				"Billing Form PDF button available in Forms Tooltip");
	}

	/**
	 * This method is used to validate Forms tool tip content when there is an
	 * outstanding DocGrid billing form(s) request for the group
	 * 
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean isFormsContentWhenOutstandingDocGridPresent() {
		return isElementPresentUsingXpath(strFormsContentWhenOutstandingDocGridPresentXPATH, lplCoreConstents.HIGH,
				"Forms Tool Tip content when there is an outstanding DocGrid billing form request for the group");
	}

	/**
	 * This method is used to view PREPARE FORM FOR SIGNATURE button is available in
	 * right side of Forms panel
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean isPrepareFormForSignatureButton() {
		return isElementPresentUsingXpath(strPrepareFormForSignBtnFormsPanelXPATH, "PREPARE FORM FOR SIGNATURE button");
	}

	/**
	 * This method is used to click on PREPARE FORM FOR SIGNATURE button available
	 * in right side of Forms panel
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickPrepareFormForSignatureButton() {
		return clickElementUsingXpath(strPrepareFormForSignBtnFormsPanelXPATH, "PREPARE FORM FOR SIGNATURE button");
	}

	/**
	 * This method is used to validate Form Ready to Sign panel
	 * 
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean isFormReadyToSignPanelDisplayed() {
		return isElementPresentUsingXpath(strFormReadyToSignPanelXPATH, lplCoreConstents.HIGH,
				"Form Ready to Sign panel");
	}

	/**
	 * This method is used to validate !ACTIVATION REQUIRES FORMS indicator in Form
	 * Ready to Sign panel
	 * 
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean isActivationIndicatorInFormReadyToSign() {
		return isElementPresentUsingXpath(strActivationIndicatorInFormReadyToSignXPATH, lplCoreConstents.HIGH,
				"!ACTIVATION REQUIRES FORMS indicator in Form Ready to Sign panel");
	}

	/**
	 * This method is used to validate Form Ready to Sign Label
	 * 
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean isFormReadytoSignLabel() {
		return isElementPresentUsingXpath(strFormReadytoSignLabelXPATH, lplCoreConstents.HIGH,
				"Form Ready to Sign Label");
	}

	/**
	 * This method is used to validate Form Ready to Sign when there is an
	 * outstanding DocGrid billing form(s) request for the group
	 * 
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean isFormReadytoSignWhenOutstandingDocGridPresent() {
		return isElementPresentUsingXpath(strFormReadytoSignWhenOutstandingDocGridPresentXPATH, lplCoreConstents.HIGH,
				"Form Ready to Sign content when there is an outstanding DocGrid billing form request for the group");
	}

	/**
	 * This method is used to click on Billing Form PDF button available in Form
	 * Ready to Sign Panel
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickBillingFormPDFBtnFormReadytoSign() {
		return clickElementUsingXpath(strBillingFormBtnFormReadytoSignXPATH,
				"Billing Form PDF button available in Form Ready to Sign Panel");
	}

	/**
	 * This method is used to click on drop down available in bottom side of
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickDropDownFormReadytoSign() {
		return clickElementUsingXpath(strDropDownFormReadytoSignXPATH, "Drop Down");
	}

	/**
	 * This method is used to click on drop down value available in bottom side of
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickDropDownValueFormReadytoSign() {
		return clickElementUsingXpath("//div[contains(text(),'CAG')]", "Drop down value");
	}

	/**
	 * This method is used to click on PREPARE FORM FOR SIGNATURE button available
	 * in bottom side of Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickPrepareFormForSignatureBtnForm() {
		return clickElementUsingXpath(strPrepareFormForSignBtnFormReadytoSignXPATH,
				"PREPARE FORM FOR SIGNATURE button at bottom side of Streamline/Confirmation page");
	}

	public static String getClientName(String filePath) {
		try {
			FileInputStream file = new FileInputStream(new File(filePath));
			@SuppressWarnings("resource")
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			Sheet sheet = workbook.getSheet("Account Context");
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row nextRow = rowIterator.next();
				int rowNum = nextRow.getRowNum();
				if (rowNum > 0)
					return nextRow.getCell(0).getStringCellValue();
			}
		} catch (IOException e) {
			setErrorMessage("Exception Occurred");
		}
		return "";
	}

	/**
	 * This method is used to click on Billing Rate Contents Panel on Dashboard
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickBillingRateContentsPanel() {
		return clickElementUsingXpath(strBillingContentsChevronXpath, "Billing Rate Contents Panel is clicked");
	}

	/**
	 * This method is used to check "Open All" hyperlink is displayed in Billing
	 * Rate Section on Dashboard
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isOpenAllHyperlinkDisplayed() {
		return isElementPresentUsingXpath(strValidateOpenAllXpath, lplCoreConstents.HIGH,
				"Open All Hyperlink is displayed");
		// a[@class='ng-tns-c113-0'][contains(text(),'Open all')]
	}

	/**
	 * This method is used to click on Open All Hyperlink in Billing Rate Tile on
	 * Dashboard
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickOpenAllHyperlink() {
		return clickElementUsingXpath(strClickOpenAllXpath, "Open All Hyperlink is clicked");
	}

	/**
	 * This method is used to check "Close All" hyperlink is displayed in Billing
	 * Rate Section on Dashboard
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isCloseAllHyperlinkDisplayed() {
		return isElementPresentUsingXpath(strValidateCloseAllXpath, lplCoreConstents.HIGH,
				"Close All Hyperlink is displayed");

	}

	/**
	 * This method is used to click on Clients Tab
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickClientsTab() {
		return clickElementUsingXpath(strClientTabXpath, "Clients Tab is clicked");
	}
	
	/**
	 * This method is used to click on Clients Tab
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickAccountsTab() {
		return clickElementUsingXpath(strAccountTabXpath, "Clients Tab is clicked");
	}

	/**
	 * This method is used to select Client Name hyperlink in Billing Capability
	 * Tile
	 *
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean ClientNameHyperlinkSelected() {
		String clientName = testData.get("clientName");
		return clickElementUsingXpath(strClickClientNamexpath.replace("xxx", clientName),
				"Household Client Name is clicked");

	}

	/**
	 * This method is used to validate Client Summary page is displayed
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isClientSummaryPageDisplayed() {
		return isElementPresentUsingXpath(strClientSummaryPageXpath, lplCoreConstents.HIGH,
				"Clients Summary page displayed");
	}


	/**
	 * This method is used to validate Account Summary page is displayed
	 * 
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isAccountSummaryPageDisplayed() {
		boolean blnResult = false;
		
		try {
			for (String newWindowHandle : driver.getWindowHandles()) {
				driver.switchTo().window(newWindowHandle);
				//wait(3);
				//isElementPresentUsingXpath(strAccountSummaryPageXpath, lplCoreConstents.HIGH,"Account Summary page displayed");
				//System.out.println(blnResult);
				blnResult = true;
				//System.out.println(blnResult);
			}
		} catch (NoSuchElementException e) {

			blnResult = false;
		}
		return blnResult; 
	}

	/**
	 * This method is used to validate Bank Sweep Capability Tile is displayed on
	 * Dashboard
	 * 
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isBankSweepDisplayed() {
		return isElementPresentUsingXpath(strBankSweepTileXpath, "Bank Sweep Tile displayed");
	}

	/**
	 * This method is used to validate Edit Pencil Icon is displayed on Bank Sweep
	 * 
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isEditPencilIconisplayed() {
		return isElementNotPresentUsingXpath(strNoBankSweepEditIconXpath);
	}

	/**
	 * This method is used to check Back Link is present on Household Dashboard
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isDashboardBackLinkDisplayed() {
		boolean blnResult = false;
		blnResult = isElementPresentUsingXpath(strBackLinkXpath, lplCoreConstents.HIGH,
				"Household Dashboard Back Link Arrow");
		if (blnResult)
			blnResult = isElementPresentUsingXpath(strValidateBackLinkXpath, lplCoreConstents.HIGH,
					"Household Dashboard Back Link");
		return blnResult;
	}

	/**
	 * This method is used to click on Back link on Household Dashboard
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickBackLink() {
		return clickElementUsingXpath(("//a[@class='backLink']"), "Household Dashboard back link is clicked");

	}

	/**
	 * This method is used to check User is on Groups Grid of Clientworks
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isGroupsGridDisplayed() {
		return isElementPresentUsingXpath("//div[@class='ng-scope']//span[1]//span[1]", lplCoreConstents.HIGH,
				"Groups Grid Page of Clientworks");
	}

	/**
	 * This method is used to check The advisory fee details panel is opened for all
	 * client�s after clicking on Open All link in Billing Tile on Dashboard
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isPanelOpen() {
		return isElementPresent(DISPLAYED, "XPATH", strBillingPanelXpath, "Account panel not displayed");
	}

	/**
	 * This method is used to click on Close All link in Billing Tile on Dashboard
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickCloseAllLink() {
		return clickElementUsingXpath(strClickCloseAllXpath, lplCoreConstents.HIGH,
				"Close All link in Billing Capability Tile on Dashboard is clicked");
	}

	/**
	 * This method is used to check The advisory fee details panel is closed for all
	 * client�s after clicking on Close All link in Billing Tile on Dashboard
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isPanelClosed() {
		//wait(2);
		return isElementPresent(DISPLAYED, "XPATH", strValidateOpenAllXpath, "Account panel not displayed");
	}

	/**
	 * This method is used to click on Groups Tab
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickGroupsTab() {
		return clickElementUsingXpath(strclickGroupsTabxpath, "Group Tab is clicked");
	}

	/**
	 * This method is used to enter the Groupname
	 *
	 * @return boolean
	 * @param�Enter Groupname Value
	 * @author awaeza
	 */

	public boolean enterGroupname(String groupName) {
		return enterTextUsingXpath(strenterGroupnamexpath, groupName, "Enter Group Name");
	}

	/**
	 * This method is used to click on Search button
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clicksearch() {
		return clickElementUsingXpath(strGroupsearchbuttonxpath, "Search Button is clicked");
	}

	/**
	 * This method is used to view billing rate
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean verifybillingrate() {
		return isElementPresentUsingXpath(strBillingRateXpath, "Billing Rate is available");
	}

	/**
	 * This method is used to open all billing rate content chevron
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyopenallchevroncontent() {
		return clickElementUsingXpath(strBillingRateOpenAllXpath, "Billing Rate Open All content chevron clicked");
	}

	/**
	 * This method is used to verify the advisory fee for client billing
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyadvisoryfee() {
		return isElementPresentUsingXpath(strAdvisoryFeeXpath, "Billing Advisory Fee is available");

	}

	/**
	 * This method is used to click on Household Group name
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickHHGroupName() {
		String groupID = testData.get("groupID");
		wait(5);
		return clickElementUsingXpath(strclickHHGroupnamexpath.replace("xxx", groupID),
				"Household Group name is clicked");

	}

	/**
	 * This method is used to click on HH Group name
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickGroupName() {
		return clickElementUsingXpath(strclickGroupnameXpath, "Household Group name is clicked");
	}


	/**
	 * This method is used to check if Edit household page is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean EditHouseholdPageDisplayed() {

		return isElementPresentUsingXpath(strNavEditHHpagexpath, lplCoreConstents.HIGH,
				"Edit Household Page Displayed");

	}


	


	/**
	 * This method is used to check Household Accounts is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 * 
	 */

	public boolean householdaccountsDisplayed() {
		return isElementPresentUsingXpath(strhouseholdaccountsxpath, lplCoreConstents.HIGH,
				"Household accounts is Displayed");

	}

	/**
	 * This method is used to validate household accounts columns
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean householdaccountscolumns(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
	}

	

//	/**
//	 * This method is used to check edit combined statement alert message options
//	 * are displayed
//	 *
//	 * @return boolean
//	 * @author awaeza
//	 */
//	public boolean editCombinedStatementalertoptionsDisplayed() {
//
//		String streditCombinedStatementalerttextxpath = "//div[contains(text(),'Do you want ')]";
//		if (isElementPresentUsingXpath(streditCombinedStatementalerttextxpath, lplCoreConstents.HIGH,
//				"Edit combined statement alert message Displayed")) {
//			String streditCombinedStatementalerteditoptionxpath = "//button[text()=' Edit ']";
//			if (isElementPresentUsingXpath(streditCombinedStatementalerteditoptionxpath, lplCoreConstents.HIGH,
//					"Edit combined statement alert popup edit option Displayed")) {
//				String streditCombinedStatementalertdeleteoptionxpath = "//button[contains(text(),' Delete ')]";
//				isElementPresentUsingXpath(streditCombinedStatementalertdeleteoptionxpath, lplCoreConstents.HIGH,
//						"Edit combined statement alert popup delete option Displayed");
//			}
//		}
//		return true;
//
//	}

//	/**
//	 * This method is used to click on delete option from edit combined statement
//	 * alert popup
//	 *
//	 * @return boolean
//	 * @author awaeza
//	 */
//	public boolean clickdeleteoptioneditcombinestatement() {
//
//		String strdeleteoptioneditCSxpath = "//button[contains(text(),' Delete ')]";
//		return clickElementUsingXpath(strdeleteoptioneditCSxpath,
//				"Delete option is clicked from edit combined statement alert popup");
//	}

//	/**
//	 * This method is used to check delete combined statement alert popup is
//	 * displayed
//	 *
//	 * @return boolean
//	 * @author awaeza
//	 */
//	public boolean deleteCombinedStatementalertpopupDisplayed() {
//
//		String strdeleteCStalertpopupxpath = "//div[@class='modal-body text-center']";
//		return isElementPresentUsingXpath(strdeleteCStalertpopupxpath, lplCoreConstents.HIGH,
//				"Delete combined statement alert popup Displayed");
//
//	}

//	/**
//	 * This method is used to check delete combined statement alert message text is
//	 * displayed
//	 *
//	 * @return boolean
//	 * @author awaeza
//	 */
//	public boolean deleteCombinedStatementalerttextDisplayed() {
//
//		String strdeleteCSalerttextxpath = "//p[contains(text(),'Are you sure ')]";
//		return isElementPresentUsingXpath(strdeleteCSalerttextxpath, lplCoreConstents.HIGH,
//				"Delete combined statement alert message Displayed");
//
//	}

//	/**
//	 * This method is used to check delete combined statement alert message options
//	 * are displayed
//	 *
//	 * @return boolean
//	 * @author awaeza
//	 */
//	public boolean deleteCombinedStatementalertoptionsDisplayed() {
//
//		String strdeleteCSalerttextxpath = "//p[contains(text(),'Are you sure ')]";
//		if (isElementPresentUsingXpath(strdeleteCSalerttextxpath, lplCoreConstents.HIGH,
//				"Delete combined statement alert message Displayed")) {
//			String strdeleteCSalertproceedtodeleteoptionxpath = "//button[contains(text(),'PROCEED TO DELETE')]";
//			if (isElementPresentUsingXpath(strdeleteCSalertproceedtodeleteoptionxpath, lplCoreConstents.HIGH,
//					"delete combined statement alert popup PROCEED TO DELETE option Displayed")) {
//				String strdeleteCSalertgobackoptionxpath = "//button[contains(text(),'GO BACK')]";
//				isElementPresentUsingXpath(strdeleteCSalertgobackoptionxpath, lplCoreConstents.HIGH,
//						"delete combined statement alert popup GO BACK option Displayed");
//			}
//		}
//		return true;
//
//	}

	/**
	 * This method is used to click on proceed to delete option from delete combined
	 * statement alert popup
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickproceedtodeleteoptiondeletecombinestatement() {

		String strproceedtodeleteoptiondeleteCSxpath = "//button[contains(text(),'PROCEED TO DELETE')]";
		return clickElementUsingXpath(strproceedtodeleteoptiondeleteCSxpath,
				"PROCEED TO DELETE option is clicked from delete combined statement alert popup");
	}

	/**
	 * This method is used to check delete editing button is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean deleteeditingbuttonCombinedstatementDisplayed() {

		//String strDeleteEditingButtonCombinedStatementXpath = "//button[@title='DELETE EDITING']";
		return isElementPresentUsingXpath(strDeleteEditingButtonCombinedStatementXpath, lplCoreConstents.HIGH,
				"DELETE EDITING button is Displayed");

	}

	/**
	 * This method is used to click on edit button in banner
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickediteditingbuttoncombinestatement() {

		return clickElementUsingXpath(strEditBtnEditCombinedStmtBannerXPATH, "EDIT option is clicked");
	}

	/**
	 * This method is used to click on delete editing button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickdeleteeditingbuttoncombinestatement() {

		//String strdeleteeditingbuttonCSxpath = "//button[@title='DELETE EDITING']";
		return clickElementUsingXpath(strDeleteEditingButtonCombinedStatementXpath, "DELETE EDITING option is clicked");
	}


	/**
	 * This method is used to check if Billing details page is displayed
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean billingDetailsPageDisplayed() {
		return isElementPresentUsingXpath(strEditbillingpagexpath, lplCoreConstents.HIGH,
				"Billing details Page Displayed");

	}

	/**
	 * This method is used to check if Banner is displayed in Billing details page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean bannerinBillingDetailsDisplayed() {
		return isElementPresentUsingXpath(strEditBillingDetailsBannerXPATH, "Banner in Billing details Page Displayed");

	}

	/**
	 * This method is used to check if Edit and Delete button in Banner is displayed
	 * in Billing details page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean editAndDeleteinbannerDisplayed() {
		return isElementPresentUsingXpath(strEditBtnEditBillingBannerXPATH, "Edit button in Banner")
				&& isElementPresentUsingXpath(strDeleteBtnEditBillingBannerXPATH, "Delete button in Banner");

	}

	/**
	 * This method is used to click on Edit Button in Banner
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickEditbuttoninBanner() {
		return clickElementUsingXpath(strEditBtnEditBillingBannerXPATH, "Edit button in Banner is clicked");
	}

	/**
	 * This method is used to click on Done Editing button
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean clickDoneEditingButton() {
		return clickElementUsingXpath(strDoneButtonXpath, lplCoreConstents.HIGHEST, "Done Editing button clicked");

	}

	/**
	 * This method is used to click on Delete button present in Banner in Billing
	 * details Page
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean clickDeletebuttoninBanner() {
		return clickElementUsingXpath(strDeleteBtnEditBillingBannerXPATH, "Delete button in Banner is clicked");

	}

	/**
	 * This method is used to check if Delete Billing Pop-up message
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean deleteBillingPopup() {
		return isElementPresentUsingXpath(strPopupboxTextXPATH, "Delete Billing Pop-up message is displayed");

	}

	/**
	 * This method is used to check if Proceed to Delete and Go Back button in
	 * Delete Billing Pop-up
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean proceedtoDeleteandGoBackbtninPopupDisplayed() {
		return isElementPresentUsingXpath(strNoButtonXpath, "Go Back button in Pop-up")
				&& isElementPresentUsingXpath(strProceedToDeleteButtonXPATH, "Proceed to Delete button in Pop-up");

	}

	/**
	 * This method is used to click on Go Back button present in Delete Billing
	 * Pop-up
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean clickGoBackbuttoninPopup() {
		return clickElementUsingXpath(strGoBackBtnDeleteBannerXPATH, "Go Back button in Pop-up is clicked");

	}

	/**
	 * This method is used to click on Proceed to Delete button present in Delete
	 * Billing Pop-up
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean clickProceedtoDeletebuttoninPopup() {
		return clickElementUsingXpath(strProceedToDeleteButtonXPATH, "Proceed to Delete button in Pop-up is clicked");

	}

	/**
	 * This method is used to click the Done Deleting button
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean clickDoneDeletingButton() {
		return clickElementUsingXpath(strDoneDeletingButtonXPATH, "Done Deleting button clicked");

	}

	/**
	 * This method is used to verify Delete billing confirmation page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyDeleteBillingUpdatedConfirmationPage() {
		return isElementPresentUsingXpath(strBillingDeletionConfirmationMsgXPATH, lplCoreConstents.HIGH,
				"Delete Billing confirmation page");
	}

	/**
	 * This method is used to verify Streamline Billing in confirmation page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyHouseholdStreamlineBilling() {
		return isElementPresentUsingXpath(strStreamlineBillingXpath, lplCoreConstents.HIGH,
				"Streamline Billing confirmation page");
	}

	/**
	 * This method is used to click on Jump To Details link on Dashboard
	 *
	 * @return boolean
	 * @author vsharm
	 */
	public boolean clickJumpToDetails() {
		return clickElementUsingXpath("//button[@class=\"btn btn-link btn-sm jump-details\"]",
				"Jump To Details link is clicked");
	}

	/**
	 * This method is used to click on remove client button based on client name
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickHouseholdRemoveClientButton() {

		
return clickElementUsingXpath(strRemoveClientButtonXpath.replace("xxx", testData.get("firstName")),
				"remove client  button is clicked");
	}

	/**
	 * This method is used to click on review household button
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickReviewHouseholdButton() {
		wait(3);
		return clickElementUsingXpath(strReviewHouseholdButtonXpath, "review household button is clicked");

	}

	/**
	 * This method is used to click on submit household button
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickSubmitHouseholdButton() {
		
		return clickElementUsingXpath(strSubmitHouseholdButtonXpath, "submit changes button is clicked");

	}

	/**
	 * This method is used to check removed client tool tip displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean removedClientToolTipDisplayed() {
		
		return isElementPresentUsingXpath(strRemovedClientToolTipXpath, lplCoreConstents.HIGH,
				"removed client tool tip displayed");
	}

	/**
	 * This method is used to click on removed client tool tip verbiage
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickRemoveToolTipVerbiage() {
		
		return clickElementUsingXpath(strRemoveClientToolTipLinkXpath,
				"here link in removed client tile verbiage is clicked");

	}

	/**
	 * This method is used to check Capabilities Section is present on Dashboard
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean capabilitiesSectionDisplayed() {
		return isElementPresent(DISPLAYED, "XPATH", strBankSweepTileXpath, "Capabilities Section is displayed");
	}

	

	/**
	 * This method is used to Validate Static Text on Edit Household Combined
	 * Statement Details page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateEditHHCombinedStatementStaticText() {
		String strHHCombinedStatemnetStaticTextxpath = "//p[@title = 'primary note']";
		String str1 = getTextUsingXpath(strHHCombinedStatemnetStaticTextxpath,
				"Edit HH Combined Statement Static Text");
		String str2 = "Please note that the address associated with the primary account you select will be the mailing address for this combined statement. You may choose any eligible account from the household’s primary client. Note: Only eligible accounts are displayed.";
		System.out.println(str1);
		System.out.println(str2);
		return (str1.equalsIgnoreCase(str2));
	}


	/**
	 * This method is used to verify Flat Rate in Dashboard Page
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean validateFlatRateinDasboardPage() {
		String str1 = getTextUsingXpath(strFlatRateDecimalDashboardXPATH, "Flat Rate value");
		String str2 = testData.get("flatFee").concat("%");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to verify Flat Rate in Edit Billing Details Page
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean validateFlatRateinEditBillingDetailsPage() {
		String str1 = getTextUsingXpath(strFlatRateDecimalXPATH, "Flat Rate value");
		String str2 = testData.get("flatFee").concat("%");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to verify Flat Rate in Review Billing Details Page
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean validateFlatRateinReviewBillingDetailsPage() {
		String str1 = getTextUsingXpath(strFlatRateDecimalReviewXPATH, "Flat Rate value");
		String str2 = testData.get("flatFee").concat("%");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to verify Flat Rate in Streamline Confirmation Page
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean validateFlatRateinStreamlineConfirmationPage() {
		String str1 = getTextUsingXpath(strFlatRateDecimalXPATH, "Flat Rate value");
		String str2 = testData.get("flatFee").concat("%");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to click on edit button present in the edit combined
	 * statement alert message
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickeditHHcombinedstatementbutton() {

		String streditCombinedStatementalerteditoptionxpath = "//button[text()=' Edit ']";
		return clickElementUsingXpath(streditCombinedStatementalerteditoptionxpath,
				"edit button present in edit combined statement alert message is clicked");

	}

	/**
	 * This method is used to click on radio button present in the edit combined
	 * statement alert message
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean clickeditHHcombinedstatementradiobutton() {
		String accountnumber = testData.get("accountnumber");
		String streditcombinedstatementradiobutton = "(//*[contains(text(),'xxx')])[1]//..//..//..//..//../td/input";
		return clickElementUsingXpath(streditcombinedstatementradiobutton.replace("xxx", accountnumber),
				"edit combined statement radio button is clicked");
	}


	/**
	 * This method is used to click on Delete option in context menu
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickDeleteOption() {
		return clickElementUsingXpath(strClickDeleteHHxpath, "Delete option in Client Context menu is clicked");
	}

	/**
	 * This method is used to verify Delete Household Details page is displayed
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean deleteHouseholdPageDisplayed() {
		return isElementPresentUsingXpath(strDeleteHouseholdPageXpath, lplCoreConstents.HIGH,
				"Household Details page is Displayed");

	}

	/**
	 * This method is used to Validate Delete Household page Banner
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean deleteHHBannerTitleDisplayed() {
		String str1 = getTextUsingXpath(strHHBannerTitlexpath, "Delete Household Banner Title Text");
	//String str2 = testData.get("BannerTitle");
		return (str1.equalsIgnoreCase(DELETE_BANNER_TITLE+testData.get("Groupname").toUpperCase()));
	}

	/**
	 * This method is used to Validate Delete Household label displayed
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean deleteHHLabelDisplayed() {
		return isElementPresentUsingXpath(strDeleteHHLabelXpath, lplCoreConstents.HIGH,
				"Delete household Label displayed");
	}

	/**
	 * This method is used to Validate Cancel And Return Button Displayed on Delete
	 * Household label displayed
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean cancelAndReturnButtonDisplayed() {
		return isElementPresentUsingXpath(strCancelAndReturnXpath, lplCoreConstents.HIGH,
				"Delete household page title displayed");
	}

	/**
	 * This method is used to click on Delete button
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickDeleteHHButton() {
		return clickElementUsingXpath(strClickDeleteHHbuttonXpath, "Delete button is clicked");
	}

	/**
	 * This method is used to Validate Pop-Up window is Displayed on Delete
	 * Household label displayed
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean DeleteHHPopUpDisplayed() {
		return isElementPresentUsingXpath(strDeleteHHpopupXpath, lplCoreConstents.HIGH, "Pop-Up window is displayed");
	}

	/**
	 * This method is used to click on Return Client Management Button
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickReturnClientManagementButton() {
		return clickElementUsingXpath(strClickReturnClientMgmtXpath, "Return on client management is clicked");
	}

	/**
	 * This method is used to check if Back Hyperlink in Edit Billing details page
	 * is displayed
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyCancelReturntoDashboardHyperlinkinBillingDetails() {
		return isElementPresentUsingXpath("//*[@class='cancel-link']", lplCoreConstents.HIGH,
				"Cancel & Return to Dashboard Hyperlink in Edit Billing details Page Displayed");

	}

	/**
	 * This method is used to click on Back Hyperlink in Edit Billing details page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickCancelReturntoDashboardHyperlinkinBillingDetails() {
		return clickElementUsingXpath("//*[@class='cancel-link']", lplCoreConstents.HIGH,
				"Cancel & Return to Dashboard Hyperlink in Edit Billing details Page Displayed");
	}


	/**
	 * This method is used to click on Cancel & Return to Dashboard Hyperlink in
	 * Edit Combined Statement page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickCancelReturntoDashboardHyperlinkinCominedStmt() {
		return clickElementUsingXpath("//*[@class='backbtn']", lplCoreConstents.HIGH,"Cancel & Return to Dashboard hyperlink is displayed");
	}


	

	/**
	 * This method is used to enter the Client name
	 * 
	 * @param�Enter Client name Value
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean enterPreselectClientname(String clientName) {
		return enterTextUsingXpath(strClientNameClientTabXpath, clientName, "Enter Client Name");
	}

	/**
	 * This method is used to click on client context menu Clients Tab
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickClientsContextMenu() {
		return clickElementUsingXpath(strClientContextMenuXpath, "Client Context menu is clicked");
	}
	
	/**
	 * This method is used to click on client context menu Clients Tab
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickAccountsContextMenu() {
		return clickElementUsingXpath(strAccountContextMenuXpath, "Client Context menu is clicked");
	}

	/**
	 * This method is used to click on search button on clients tab
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean clickClientsPageSearchButton() {

		return clickElementUsingXpath(strClientSearchButtonXpath,
				"Search button on clients tab is clicked");

	}

	/**
	 * This method is used to click on groups option in client context menu on
	 * clients tab
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickGroupsOption() {
		wait(30);
		//return clickElementUsingXpath("(//ul[@id='context-menu']/li)[3]//span[text()='Group']","Groups Option in Client context menu is clicked");
		return clickElementUsingXpath("//span[text()='Group']",
				"Groups Option in Client context menu is clicked");
	}

	/**
	 * This method is used to click on Create New Household sub menu in client
	 * context menu
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickCreateNewHousehold() {
		return clickElementUsingXpath("((//ul[@id='context-menu']/li)[3]/ul/li)[1]", lplCoreConstents.HIGH,
				"Create New Household sub-menu is clicked");
	}
	
	

	/**
	 * This method is used to check if Client Name is Preselected on New Household
	 * Page
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean preselectedClientNameDisplayed() {
		String clientName = testData.get("EnterclientName");
		System.out.println(strPreselectClientNameXpath.replace("xxx", clientName));
		return isElementPresent(DISPLAYED, "XPATH", strPreselectClientNameXpath.replace("xxx", clientName),
				"Capabilities Section is displayed");
	}
	
	/**
	 * This method is used to validate Account Panel Chevron on Combined Statement
	 * Capability Tile
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateAccountPanelChevron() {
		return isElementPresent(DISPLAYED, "XPATH",
				"//div[@title='HOUSEHOLD COMBINED STATEMENT']//i[@class='fa fa-chevron-right text-info null']",
				"Page expands to show list of account details");
	}


	/**
	 * This method is used to click on Accounts Panel chevron to collapse in
	 * combined statement capability tile
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickAccountPanelCollapseChevron() {
		return clickElementUsingXpath(
				"//div[@title='HOUSEHOLD COMBINED STATEMENT']//i[@class='fa fa-chevron-right text-info fa-rotate-90']",
				"Accounts panel chevron is clicked");
	}

	/**
	 * This method is used to validate Account details are not visible after
	 * collapsing accounts chevron
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean accountPanelCollapsed() {
		return isElementNotPresentUsingXpath(
				"//div[@title='HOUSEHOLD COMBINED STATEMENT']//div[@class='dx-scrollview-content']");
	}

	/**
	 * This method is used to validate list of accounts for all clients is not
	 * visible after collapsing contents chevron
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean contentsPanelCollapsed() {
		return isElementNotPresentUsingXpath("//div[@title='HOUSEHOLD COMBINED STATEMENT']//div[@class='card-body']");
	}

	/**
	 * This method is used to click on Accounts Panel chevron to collapse in
	 * combined statement capability tile
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickContentsPanelCollapsedChevron() {
		return clickElementUsingXpath(
				"//div[@title='HOUSEHOLD COMBINED STATEMENT']//i[@class='fa fa-chevron-right text-info fa-rotate-90']",
				"Accounts panel chevron is clicked");
	}

	/**
	 * This method is used to click on Delete option on Edit Combined Statement page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickDeleteCombinedStatement() {
		return clickElementUsingXpath(strClickDeleteCombinedStatementXpath,
				"DELETE option on Edit Combined Statement page is clicked");
	}

	/**
	 * This method is used to click on Proceed To Delete Edit Combined Statement
	 * page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickProceedToDeleteCombinedStatement() {
		return clickElementUsingXpath(strProceedToDeleteXpath,
				"Proceed To Delete option Edit Combined Statement is clicked");
	}

	/**
	 * This method is used to click on Done Deleting button on Edit Combined
	 * Statement page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickDoneDeletingCombinedStatement() {
		return clickElementUsingXpath(strDoneDeletingXpath, "Done Deleting button is clicked");
	}

	/**
	 * This method is used to validate Combined Statement Tile not present after
	 * Deleting Combined Statement capability
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateNoCombinedStatementTile() {
		return isElementNotPresentUsingXpath(strNoCombinedStatementTileXpath);
	}

	
	/**
	 * This method is used to validate Combined Statement Tile not present after
	 * Deleting Combined Statement capability
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateEstAnnualFeeNotDisplayed() {
		return isElementNotPresentUsingXpath("strEstAnnualFeeNotDisplayedXpath");
	}

	/**
	 * This method is used to click on Combined Statement Contents panel
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickReviewCombinedStatementExpandContentsPanel() {
		return clickElementUsingXpath(strClickCombinedExpandContentsXpath,
				"Combined Statement contents panel chevron is clicked");
	}

	/**
	 * This method is used to validate Account Panel Chevron on Combined Statement
	 * Capability Tile
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateReviewCombinedStatementAccountDetails() {
		return isElementPresent(DISPLAYED, "XPATH", strValidateCombinedAccountDetailsXpath,
				"Page expands to show list of account details");
	}

	/**
	 * This method is used to validate Account Details are displayed on Combined
	 * Statement tile
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateReviewCombinedStatementAccountPanelChevron() {
		return isElementPresent(DISPLAYED, "XPATH", strValidateCombinedAccountsChevronXpath,
				"Page expands to show list of account details");
	}

	/**
	 * This method is used to click on Accounts Panel chevron to expand in combined
	 * statement capability tile
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickReviewCombinedStatementAccountPanelExpandChevron() {
		return clickElementUsingXpath(strClickCombinedExpandAccountsXpath, "Accounts panel chevron is clicked");
	}

	/**
	 * This method is used to click on Accounts Panel chevron to collapse in
	 * combined statement capability tile
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickReviewCombinedStatementAccountPanelCollapseChevron() {
		return clickElementUsingXpath(strClickCombinedAccountsCollapsedXpath, "Accounts panel chevron is clicked");
	}

	/**
	 * This method is used to validate Account details are not visible after
	 * collapsing accounts chevron on Review Combined Statement Page
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateAccountPanelCollapsed() {
		return isElementNotPresentUsingXpath(strCombinedAccountsCollapsedXpath);
	}

	/**
	 * This method is used to validate list of accounts for all clients is not
	 * visible after collapsing contents chevron
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean validateContentsPanelCollapsed() {
		return isElementNotPresentUsingXpath(strValidateCombinedContentsCollpsedXpath);
	}

	/**
	 * This method is used to click on Contents Panel chevron to collapse on Review
	 * Combined Statement Page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickReviewCombinedStatementContentsPanelCollapsedChevron() {
		return clickElementUsingXpath(strCombinedCollapsedContentsPanelXpath, "Accounts panel chevron is clicked");
	}


	/**
	 * This method is used to Validate error message on New Household page when
	 * accounts are already present in Bank Sweep
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateBankSweepErrorMessage() {
		String str1 = getTextUsingXpath(strErrorMessageXpath, "Error message text");
		String str2 = testData.get("ErrorText");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to validate Billing Rate section is displayed in
	 * dashboard
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean billingratesectionDisplayed() {
		String strbillingratesectionxpath = "//*[text()=' BILLING RATE ']";
		return isElementPresentUsingXpath(strbillingratesectionxpath, lplCoreConstents.HIGH,
				"Billing Rate section is displayed in dashboard");

	}

	
	/**
	 * This method is used to validate billing tile is displayed in Billing Rate
	 * section of dashbaord
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean billingratetileDisplayed() {
		String strbillingratetilexpath = "//*[text()=' BILLING RATE ']//..";
		return isElementPresentUsingXpath(strbillingratetilexpath, lplCoreConstents.HIGH,
				"Billing Rate tile is displayed in Billing rate  section of dashboard");

	}

	/**
	 * This method is used to validate View Payout Schedule hyperlink in Billing
	 * Rate tile of dashbaord
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean viewPayoutSchedulehyperlinkDisplayed() {
		String strviewPayoutSchedulehyperlinkxpath = "//*[@class='btn-col btn btn-link btn-sm payout-sched-link']";
		return isElementPresentUsingXpath(strviewPayoutSchedulehyperlinkxpath, lplCoreConstents.HIGH,
				"View Payout Schedule hyperlink is displayed in Billing rate  section of dashboard");

	}

	/**
	 * This method is used to validate SCHEDULE name is displayed in Billing Rate
	 * tile of dashbaord
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean schedulenameDisplayed() {
		String strschedulenamexpath = "//*[text()='SCHEDULE']//../div[@class='summary-value']";
		return isElementPresentUsingXpath(strschedulenamexpath, lplCoreConstents.HIGH,
				"SCHEDULE name is displayed in Billing Rate tile of dashbaord");

	}

	/**
	 * This method is used to get text of SCHEDULE fee type in Billing Rate tile of
	 * dashboard
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public String schedulenamegettext() {
		String strschedulenamexpath = "//*[text()='SCHEDULE']//../div[@class='summary-value']";
		return getTextUsingXpath(strschedulenamexpath, "SCHEDULE fee type text");
	}

	/**
	 * This method is used to get text of fee rate type in Billing Rate tile of
	 * dashboard
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public String feeratetypegettext() {
		String strfeeratetypexpath = "//*[contains(text(),'RATE') and @class='summary-header']";
		return getTextUsingXpath(strfeeratetypexpath, "fee rate type text");
	}

	/**
	 * This method is used to validate Flat fee SCHEDULE type
	 *
	 * @return boolean
	 * @author awaeza
	 */

	public boolean flatfeeScheduleType() {
		String scheduleType = schedulenamegettext();
		if (scheduleType.equalsIgnoreCase(FLAT)) {
			String flatfeeSCHEDULEtypexpath = "//div[@class='summary-value' and contains(text(),'Flat')]";
			isElementPresentUsingXpath(flatfeeSCHEDULEtypexpath, lplCoreConstents.HIGH, "SCHEDULE fee type is flat");
		}
		return true;
	}

	/**
	 * This method is used to validate flat fee rate displayed in Billing rate tile
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean flatbillingrateDisplayed() {
		String feerate = feeratetypegettext();
		if (feerate.equalsIgnoreCase(FLAT_RATE)) {
			String flatbillingratexpath = "//div[@class='summary-header' and contains(text(),'FLAT RATE')]";
			isElementPresentUsingXpath(flatbillingratexpath, lplCoreConstents.HIGH, "Billing Rate is flat");
		}
		return true;
	}

	/**
	 * This method is used to validate Blended rate displayed in Billing rate tile
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean blendedbillingrateDisplayed() {
		String blendedbillingratexpath = "//div[@class='summary-header' and contains(text(),'BLENDED RATE')]";
		return isElementPresentUsingXpath(blendedbillingratexpath, lplCoreConstents.HIGH, "Blended rate is displayed");

	}

	/**
	 * This method is used to validate Billing Rate Tile Fields
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean billingratetilefields(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
	}

	/**
	 * This method is used to click on Edit Button in Combined Statement Banner
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clickEditbuttoninCombinedStmtBanner() {
		return clickElementUsingXpath(strEditBtnEditCombinedStmtBannerXPATH,
				"Edit button in Combined Statement Banner is clicked");
	}

	/**
	 * This method is used to verify CURRENT INVESTMENT MANAGEMENT sub-header under
	 * Recommended Next Step
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyCurrentInvestmentManagementSubHeader() {
		return isElementPresentUsingXpath("//*[text()=' CURRENT INVESTMENT MANAGEMENT ']", lplCoreConstents.HIGH,
				"CURRENT INVESTMENT MANAGEMENT sub-header under Recommended Next Step");
	}

	/**
	 * This method is used to verify No current Investment management verbiage under
	 * CURRENT INVESTMENT MANAGEMENT sub-header
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyNoCurrentInvestmentManagementVerbiage() {
		return isElementPresentUsingXpath("//*[text()=' No current Investment management ']", lplCoreConstents.HIGH,
				"No current Investment management verbiage under CURRENT INVESTMENT MANAGEMENT sub-header");
	}

	/**
	 * This method is used to verify Investment Management sub-header with OPTIONAL
	 * gray-shaded box
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyInvestmentManagementSubHeader() {
		return isElementPresentUsingXpath("//*[text()=' Investment Management ']", lplCoreConstents.HIGH,
				"Investment Management sub-header")
				&& isElementPresentUsingXpath("//div[5]//div[2]/h2/span[contains(text(),'Optional')]",
						lplCoreConstents.HIGH, "OPTIONAL gray-shaded box");
	}

	/**
	 * This method is used to verify Requires Billing hyperlink not active for
	 * selection
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyRequiresBillingHyperlink() {
		return isElementPresentUsingXpath("//*[text()=' Requires Billing ']", lplCoreConstents.HIGH,
				"Requires Billing hyperlink not active for selection");
	}

	/**
	 * This method is used to verify Streamline Investment Management hyperlink
	 * under Recommended Step
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyStreamlineInvestmentManagementHyperlink() {
		return isElementPresentUsingXpath("//button[@title='Streamline Investment Management']", lplCoreConstents.HIGH,
				"Streamline Investment Management hyperlink under Recommended Step");
	}

	/**
	 * This method is used to click on Streamline Investment Management hyperlink
	 * under Recommended Step
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean clickStreamlineInvestmentManagementHyperlink() {
		return clickElementUsingXpath("//button[@title='Streamline Investment Management']", lplCoreConstents.HIGH,
				"Streamline Investment Management hyperlink under Recommended Step");
	}

	/**
	 * This method is used to verify Household Investment Management Details Page
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyHouseholdInvestmentManagementDetails() {
		return isElementPresentUsingXpath("//*[text()=' Household Investment Management Details ']",
				lplCoreConstents.HIGH, "Household Investment Management Details Page");
	}

	/**
	 * This method is used to verify Investment Management Name is same as Household
	 * Name
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean validateInvestmentManagementName() {
		String str1 = getTextUsingXpath("//*[@title='Investment Management Name' and @class='capability-static']",
				"Investment Management Name");
		return (str1.contains(testData.get("HHName")));
	}

	/**
	 * This method is used to verify Investment Management label is added to
	 * Investment Management Name
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean validateInvestmentManagementLabel() {
		String str1 = getTextUsingXpath("//*[@title='Investment Management Name' and @class='capability-static']",
				"Investment Management Name");
		return (str1.endsWith("INVESTMENT MANAGEMENT"));
	}

	/**
	 * This method is used to click on Edit icon of Investment Management Name
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean clickEditIconInvestmentManagementName() {
		return clickElementUsingXpath("//button//*[@title='Edit Investment Management Name']", lplCoreConstents.HIGH,
				"Click on Edit Icon of Investment Management Name");
	}

	/**
	 * This method is used to clear and Edit Investment Management Name
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean clearAndEnterInvestmentManagementName(String investmentMgmtName) {
		clearTextUsingXpath("//input[@title='Edit Investment Management Name']", "Investment Management Name");
		return enterTextUsingXpath("//input[@title='Edit Investment Management Name']", investmentMgmtName,
				"Investment Management Name");
	}

	/**
	 * This method is used to verify Error message when Investment Management Name
	 * is more than 50 characters
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyErrorMsgInvestmentManagementMorethanFiftyChars() {
		return isElementPresentUsingXpath("//*[text()='You have reached the max number of characters.']",
				lplCoreConstents.HIGH, "Investment Management Name is more than 50 characters");
	}

	/**
	 * This method is used to verify Error message when Investment Management Name
	 * contains special characters
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyErrorMsgInvestmentManagementSpecialChars() {
		return isElementPresentUsingXpath("//*[text()='Only alpha-numeric characters are allowed.']",
				lplCoreConstents.HIGH, "Investment Management Name contains characters");
	}

	/**
	 * This method is used to verify Edited Investment Management Name
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyEditedInvestmentManagementName() {
		return clickElementUsingXpath("//*[@class='capability-title']", "Click on page") && isElementPresentUsingXpath(
				"//*[@title='Investment Management Name']", "Edited Investment Management Name");
	}

	/**
	 * This method is used to validate Outside Business Account Not Present on Edit
	 * Combined Statement Details Page
	 * 
	 * 
	 * @return boolean
	 * @author vsharma
	 */

	public boolean verifyOutsideBusinessAccountNotPresent() {
		return isElementNotPresentUsingXpath(strOutsideBusinessAccountXpath);

	}

	/**
	 * This method is used to validate Capability tracker in Edit Household Page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean householdCapabilityTrackerDisplayed() {
		return isElementPresentUsingXpath(strHouseholdCapabilityTrackerXpath, lplCoreConstents.HIGH,
				"Household Capability tacker is displayed");

	}

	

	/**
	 * This method is used to validate summary changes sub header of household
	 * Capability tracker in Edit Household Page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean summarychangessubheader() {
		String summarychangessubheaderxpath = "//p[text()=' Summary of changes ']";
		return isElementPresentUsingXpath(summarychangessubheaderxpath, lplCoreConstents.HIGH,
				"Household Capability summary changes sub header is displayed");

	}

	/**
	 * This method is used to validate removed client verbiage of household
	 * Capability tracker in Edit Household Page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	
	public boolean capabilitytrackerremovedclientverbiage() {
		return isElementPresentUsingXpath(strCapabilityTrackerClientVerbiageXpath,
				lplCoreConstents.HIGH, "Household Capability removed  client verbiage is displayed");

	}

	/**
	 * This method is used to validate removed client household Capability tracker
	 * tiles in Edit Household Page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean capabilitytrackerremovedclienttiles() {
		String clientname = testData.get("firstName");
		System.out.println("output = "+getTextUsingXpath(strCapabilityTrackerRemoveClientTextxpath.replace("xxx", clientname), "Capability Tracker Title"));
		return (isElementPresentUsingXpath(strCapabilityTrackerRemoveClientTextTitlexpath.replace("xxx", clientname),
				lplCoreConstents.HIGH, "Household Capability removed  client tiles are displayed")
				&& getTextUsingXpath(strCapabilityTrackerRemoveClientTextxpath.replace("xxx", clientname), "Capability Tracker Title").contains(CLIENT_REMOVED_TRACKER_TEXT));
	}

	/**
	 * This method is used to expand household Capability tracker chevron
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean expnadHHcapabilityracker() {
		String strHHcapabilitytrackerexpandchevronxpath = "//*[@class='card-title collapsible-title']//*[@class='fa fa-chevron-up pull-right collapse show']";
		return clickElementUsingXpath(strHHcapabilitytrackerexpandchevronxpath,
				"Household Capability tracker is expanded");
	}
	
	/**
	 * This method is used to expand household Capability tracker chevron
	 * 
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnUndoButton() {
		return clickElementUsingXpath(strUndoButtonOnTrackerXpath.replace("xxx", testData.get("firstName")),"Undo button clicked in the Capability tracker");
	}

	/**
	 * This method is used to collapse household Capability tracker chevron
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean collapseHHcapabilityracker() {
		String strHHcapabilitytrackercollapsechevronxpath = "//*[@class='fa fa-chevron-down pull-right collapse show']";
		return clickElementUsingXpath(strHHcapabilitytrackercollapsechevronxpath,
				"Household Capability tracker is collapsed");
	}

	

	/**
	 * This method is used to verify household capabilities tracker with existing
	 * Bank Sweep capability on billing details page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyHouseholdCapabilitiesTrackerinBilling() {
		return isElementPresentUsingXpath("//app-capability-tracker//*[@class='card-body']", lplCoreConstents.HIGH,
				"Household capabilities tracker on the review billing details page")
				&& isElementPresentUsingXpath("//app-capability-tracker//div/h3/i[2]", lplCoreConstents.HIGH,
						"An expansion chevron is displayed to the right of the household name")
				&& isElementPresentUsingXpath("//*[@class='existing-capability capability']", lplCoreConstents.HIGH,
						"Bank Sweep Capability on the review billing details page");

	}


	/**
	 * This method is used to verify Existing Combined Statement Capability on
	 * billing details page
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean verifyExistingCombinedStmtCapabilityinBilling() {
		return isElementPresentUsingXpath("//div[2]/section/div/section[2]//*[@class='existing-capability capability']",
				lplCoreConstents.HIGH, "Existing Combined Statement Capability in Billing Page");
	}
	
	/**
	 * This method is to verify removed account is added back when click on undo button
	 *
	 * @return boolean
	 * @author prchavan
	 */

	public boolean seeRemovedAccountAddedBack() {
		return isElementPresentUsingXpath(strClientTileXpath.replace("xxx", testData.get("firstName")),
				lplCoreConstents.HIGH, "Existing Combined Statement Capability in Billing Page");
	}

	/**
	 * This method is used to validate static verbiage 'IN PROGRESS' on capability
	 * Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayStaticInProgressVerbiage() {
		return isElementPresentUsingXpath(strInprogressXpath, lplCoreConstents.HIGH,
				"Household Capability tacker static verbiage is displayed");

	}

	/**
	 * This method is used to verify Capability Tracker Title is same as Household
	 * Name
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCapabilityTrackerTitle() {
		String[] clientName = testData.get("firstName").split(" ");
		return (getTextUsingXpath(strHouseholdNameInTrackerXpath, "Capability Tracker Title").equalsIgnoreCase(clientName[1]+TRACKER_TITLE));
	}

	/**
	 * This method is used to validate Capability Tracker chevron
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCapabilityTrackerChevron() {
		return isElementPresentUsingXpath(strCapabilityTrackerChevronXpath,
				lplCoreConstents.HIGH, "Household Capability tacker chevron is displayed");

	}

	/**
	 * This method is used to validate Bank Sweep Title in Capability Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCapabilityTrackerBankSweepTitle() {
		return isElementPresentUsingXpath(strBankSweepTitleInTrackerXpath, lplCoreConstents.HIGH,
				"Household Capability tacker chevron is displayed");

	}

	/**
	 * This method is used to validate Bank Sweep Name in Capability Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCapabilityTrackerBankSweepName() {
		return isElementPresentUsingXpath(strBanksweepNameXpath, lplCoreConstents.HIGH, "Bank Sweep title displayed");
	}


	/**
	 * This method is used to select client names from search results in Edit
	 * Household Page
	 * 
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickclientname() {
		String clientname = testData.get("clientname");
		return clickElementUsingXpath(strclientnameselectxpath.replace("xxx", clientname), "added  client sucessfully");
	}

	/**
	 * This method is used to validate added client verbaige in Household capability
	 * tracker
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean addedclientverbaige() {
		return isElementPresentUsingXpath(strCapabilityTrackerClientVerbiageXpath, lplCoreConstents.HIGH,
				"Added client verbaige displayed in household capability tracker");

	}

	/**
	 * This Methods handles multiple windows
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean windowHandles() {
		boolean blnResult = false;
		clickElementUsingXpath("//button[@class='btn billing-form-btn']", "Household Capability tracker is collapsed");
		try {
			for (String newWindowHandle : driver.getWindowHandles()) {
				driver.switchTo().window(newWindowHandle);
				blnResult = true;
			}
		} catch (NoSuchElementException e) {

			blnResult = false;
		}
		return blnResult;
	}

	/**
	 * This method is used to validate if PDF is displayed on new window
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean billingPDFDisplayed() {
		return switchWindow(CHILD_WINDOW);
		//waitForPageLoading();
	//	return isElementPresentUsingXpath("*[type='application/x-google-chrome-pdf']", lplCoreConstents.HIGH, "Primary Client Tool Tip");
		//return isElementPresentUsingXpath("//html[@class='focus-outline-visible']", lplCoreConstents.HIGH, "Primary Client Tool Tip");
	}

	/**
	 * This method is used to validate added client capabilities tile information in
	 * Household capability tracker
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean addedclientcapabilities() {
		String clientname = testData.get("firstName");
		//String strAddedClientCapabilitiesXpath = "//*[@class='tracker-body no-border collapse show']//*[text()='xxx']//..//parent::div";
		return isElementPresentUsingXpath(strAddedClientCapabilitiesXpath.replace("xxx", clientname),
				lplCoreConstents.HIGH, "Added client verbaige displayed in household capability tracker");
	}

	/**
	 * This method is used to validate expanded chevron for added or removed client
	 * in Household capability tracker
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean expandedchevronHHtracker() {
		//String strExpandedChevronXpath = "//i[@class='fa fa-chevron-down client-tile-chevron collapse show']";
		return isElementPresentUsingXpath(strExpandedChevronXpath, lplCoreConstents.HIGH,
				"Exapnded chevron is displayed beside clientname");

	}

	/**
	 * This method is used to validate Billable Value column in Billing Summary
	 * banner
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyBillableValuecolumninBillingSummary() {
		return isElementPresentUsingXpath("//*[@class='summary-header'][text()='BILLABLE VALUE']",
				lplCoreConstents.HIGH, "Billable Value column in Billing Summary banner");
	}

	/**
	 * This method is used to validate Billable Value column in client/account
	 * details for group billing
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyBillableValuecolumninClientAccountDetails() {
		return isElementPresentUsingXpath("//th[7][text()=' BILLABLE VALUE ']", lplCoreConstents.HIGH,
				"Billable Value column in client/account details for group billing");
	}

	/**
	 * This method is used to validate Status column in client/account details for
	 * group billing
	 * 
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyStatuscolumninClientAccountDetails() {
		return isElementPresentUsingXpath("//th[10][text()=' STATUS ']", lplCoreConstents.HIGH,
				"Status column in client/account details for group billing");
	}

	/**
	 * This method is used to validate dashBoard Sub header
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean subheader() {
		String strsubheaderxpath = "//*[@class='summary-wrapper']";
		return isElementPresentUsingXpath(strsubheaderxpath, lplCoreConstents.HIGH,
				"Sub header is displayed in DashBoard Page");
	}

	/**
	 * This method is used to validate sub header menu fields
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean subheadermenufieldVisible(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
	}

	/**
	 * This method is used to validate sub header name with edit button
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean subheadernamewitheditbutton() {
		
		return (isElementPresentUsingXpath(strsubheadernamexpath, lplCoreConstents.HIGH,
				"Sub header name is displayed in DashBoard Page")&&isElementPresentUsingXpath(strSubheadereditbuttonxpath, lplCoreConstents.HIGH,
						"Sub header edit button is displayed in DashBoard Page"));
	}

	/**
	 * This method is used to verify side to side navigation tab on Edit HH page
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean isSideToSideNavigationTabDisplayed() {
		return isElementPresentUsingXpath(strEditChangeTileXpath, lplCoreConstents.HIGH, "Details Tab")
				&& isElementPresentUsingXpath(strReviewChangeTileXpath, lplCoreConstents.HIGH, "Details Tab");
	}

	/**
	 * This method is used to validate household client name on Edit HH page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateHouseholdClientName() {
		return isElementPresentUsingXpath(strHouseholdNameCreatePageXpath, lplCoreConstents.HIGH,
				"Household Client name displayed on Edit Household Page");
	}

	/**
	 * This method is used to validate summary banner on Edit HH page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateEditHouseholdSummaryBanner() {
		return isElementPresentUsingXpath(strHouseholdBannerXpath, lplCoreConstents.HIGH,
				"Household Summary Banner on Edit Household Page displayed");
	}

	/**
	 * This method is used to validate summary banner fields in Edit Household Page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displaySummaryBannerFields(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator(strSummaryBannerFieldsXpath, field), field);

	}

	/**
	 * This method is used to validate alphanumeric group name error message
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean alphaNumericGroupNameErrorMessage() {
		return (getTextUsingXpath(strAlphaNumericErrorMessageXpath,
				"Alphanumeric group name error message displayed").equalsIgnoreCase(ERROR_MSG_FOR_HOUSEHOLD_SPECIALCHARACTERS));

	}

	/**
	 * This method is used to validate exceeding characters group name error message
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean exceedinGroupNameErrorMessage() {
		return (getTextUsingXpath(strExceedinGroupNameErrorMessageXpath,
				"Exceeding character group name error message displayed").equalsIgnoreCase(FOR_ERROR_MSG_FOR_HOUSEHOLD_EXCEEDING_CHAR));

	}

	/**
	 * This method is used to validate blank group name error message
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean blankgroupnameerrormessage() {
		return (getTextUsingXpath(strBlankErrorMessageXpath, "Blank group name error message displayed").equalsIgnoreCase(ERROR_MSG_FOR_BLANK_HOUSEHOLD));

	}

	/**
	 * This method is used to clear group name
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean blankgroupname() {
		return clearTextUsingXpath(strEditGroupNameXpath, "Group Name");

	}

	

	/**
	 * This method is used to clear Group Combined statement Name
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clearCombinedstatementName() {
		clearTextUsingXpath(strEditCombineStatementNameXpath, "Combined Statement Name");
		driver.findElement(By.xpath(strEditCombineStatementNameXpath)).sendKeys(Keys.TAB);
		return true;
	}

	/**
	 * This method is used to Validate Show x more clients hyperlink on dashboard if
	 * household has more than 5 clients
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean dashboardShowMoreClientsHyperlink() {
		return isElementPresentUsingXpath("//span[contains (text(), 'more Clients')]", lplCoreConstents.HIGH,
				"show more clients hyperlink Displayed");

	}

	/**
	 * This method is used to click on show x more clients hyperlink on dashboard
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickDashboardShowMoreClientsHyperlink() {
		return clickElementUsingXpath("//span[contains (text(), 'more Clients')]", "show more x clients is clicked");

	}

	/**
	 * This method is used to Validate Show x more clients hyperlink changes to Hide
	 * x more clients on dashboard if household has more than 5 clients
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean DisplayedHideClientsHyperlink() {
		return isElementPresentUsingXpath("//span[contains (text(),'Hide')]", lplCoreConstents.HIGH,
				"hide more clients hyperlink Displayed");

	}

	/**
	 * This method is used to click on back button on Edit Household Details Page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickEditHouseholdPageBackButton() {
		return clickElementUsingXpath("//a[@title='Back']", "Back button on Edit Household Details page is clicked");
	}

	/**
	 * This method is used to Validate back button on Edit Household Details Page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayedEditHouseholdPageBackButton() {
		return isElementPresentUsingXpath("//a[@title='Back']", lplCoreConstents.HIGH,
				"Back button on Edit Household Details page is Displayed");
	}

	/**
	 * This method is used to click on Household Group Context menu
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickHouseholdGroupContextMenu() {
		return clickElementUsingXpath("//i[@class='fa fa-chevron-right close-control master-detail-toggle']",
				"Back button on Edit Household Details page is clicked");
	}

	/**
	 * This method is used to click on Edit Household Group option in client Context
	 * menu
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickEditHouseholdOption() {
		waitTillVisibleUsingXpath("((//ul[@id='context-menu']/li)[3]/ul/li)[1]", "Edit Household");
		return clickElementUsingXpath("((//ul[@id='context-menu']/li)[3]/ul/li)[1]",
				"Edit Household sub-menu is clicked");
	}

	/**
	 * This method is used to click on group member context menu on groups Tab
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickGroupMemberContextMenu() {
		return clickElementUsingXpath("(//div[@class='context-menu-cell'])[2]/div/div/button", "Group Member Context menu is clicked");
	}


	/**
	 * This method is used to select primary account for combined statement sub
	 * Group
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickprimaryaccountCSsubgroup() {
		String straddress = testData.get("Address");
		String strprimaryaccountCSsubgroupxpath = "//*[contains(text(),'xxx')]//../td[1]/input";
		return clickElementUsingXpath(strprimaryaccountCSsubgroupxpath.replace("xxx", straddress),
				"Primary account for combined statement sub Group is selected");
	}

	/**
	 * This method is used to clear client name
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clearClientName() {
		return clearTextUsingXpath(strClientPrimarySearchTextboxXpath, "client Name");

	}

	/**
	 * This method is used to wait until entered client name is selected
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public void waitTillClientSelected() {
		waitForPageLoading();
	}

	/**
	 * This method is used to select one of the client name from the client name
	 * list using Keyboard keys search results
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public void selectClientNameUsingKeys() {
		waitForPageLoading();
		wait(3);
		clickElementUsingXpath(strPrimaryClientSearchResultsListXpath, "Select client name");
	}

	

	/**
	 * This method is used to click on Set up Combined Statement Subgroup(s)
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickSetupsCombinedStatementSubgroup() {
		return clickElementUsingXpath(strSetupCombinedStatementSubgroupXpath,
				"For A Combined Statement Subgroup(s) is clicked");
	}


	/**
	 * This method is used to click on Move for mentioned client
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnMove(String clientName) {
		String strMoveButtonXpath = "//div[@class='row card-body']/div//div[@title='" + clientName
				+ "']/../../div[5]/div/button";
		return clickElementUsingXpath(strMoveButtonXpath, "Move is clicked for mentioned client");
	}

	/**
	 * This method is used to click on New Combined Statement for mentioned client
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnNewCombinedStatement(String clientName) {
		String strNewCombinedStatementXpath = "//div[@class='row card-body']/div//div[@title='" + clientName
				+ "']/../../div[5]/div/div/div";
		return clickElementUsingXpath(strNewCombinedStatementXpath,
				"New Combined Statement is clicked for mentioned client");
	}

	/**
	 * This method is used to click on dropdown menu for new C/S
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickNewCSdropdownMenu() {
		return clickElementUsingXpath(strNewCSdropdownMenuXpath,
				"New Combined Statement is clicked for mentioned client");
	}

	/**
	 * This method is used to verify text displayed in combined statement overlay
	 * modal page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyTextOverlayPageStmt() {
		String noOfStatemntsXpath = "//div[@class='card cs-group-m card-bg']/app-summary-combined-statement";
		int numberOfStatements = getWebElementsSizeUsingXpath(noOfStatemntsXpath);
		String str1 = getTextUsingXpath(
				"//section[@class='row cs-client-modal']/div//h3[@class='subgroup-count-title']",
				"No of existing combined statement");
		String str2;
		if(numberOfStatements==1) {
			 str2 = "This household currently has " + numberOfStatements + " combined statement.";
		}else {
			 str2 = "This household currently has " + numberOfStatements + " combined statements.";
		}
		
		System.out.println(str1);
		System.out.println(str2);
		return (str1.equals(str2));
	}

	/**
	 * This method is used to verify text displayed in combined statement overlay
	 * modal page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyOverlayPageText() {
		String chooseStatemntTextXpath = "//section[@class='row cs-client-modal']/div//h2[@class='gray-hue text-uppercase title mb-0']";
		String str1 = getTextUsingXpath(chooseStatemntTextXpath, "Text");
		String str2 = "HOW WOULD YOU LIKE TO ADD THIS CLIENT TO COMBINED STATEMENTS FOR THIS HOUSEHOLD?";
		return (str1.equals(str2));
	}

	/**
	 * This method is used to verify text displayed in combined statement overlay
	 * modal page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean OverlayPageSelectCSText() {
		String selectCombinedStatementTitleXpath = "//div[@class='select-title']";
		String str1 = getTextUsingXpath(selectCombinedStatementTitleXpath, "Select Combined Statement");
		String str2 = "Select which combined statement you want to add this client to:";
		return (str1.equals(str2));
	}

	/**
	 * This method is used to verify whether the Add Client to an Existing Statement
	 * button is displayed
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyAddClientToAnExistingStatementText() {
		String addClientToAnExistingStatementXpath = "//div[@class='combine-statement col card selected']/h3";
		String str1 = getTextUsingXpath(addClientToAnExistingStatementXpath,
				"Add Client to an Existing Statement button");
		String str2 = "Add Client to an Existing Statement";
		System.out.println(str1);
		System.out.println(str2);
		return (str1.equals(str2));
	}

	/**
	 * This method is used to verify whether the Add Client to an Existing Statement
	 * button is enabled by default
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean addClientToAnExistingStatementIsSelected() {
		String addClientToAnExistingStatementXpath = "//div[@class='card cs-group-m card-bg']/*/div";
		return isElementPresentUsingXpath("ENABLED", addClientToAnExistingStatementXpath, "Add client");
	}

	/**
	 * This method is used to verify whether the Add Client to an Existing Statement
	 * button is enabled by default
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyCreateANewCSForClient() {
		String createANewCSForClientXpath = "//div[@class='combine-statement col card']/h3";
		String str1 = getTextUsingXpath(createANewCSForClientXpath,
				"Create a New Combined Statement for Client button");
		String str2 = "Create a New Combined Statement for Client";
		return (str1.equals(str2));
	}

	/**
	 * This method is used to click on desired combined statement in Overlay page
	 * for Combined statement
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectDesiredCombinedStatement() {
		return clickElementUsingXpath(
				"//div[@class='cs-group-m']/app-summary-combined-statement//div[@title='HOUSEHOLD COMBINED STATEMENT']/section/div/div//h2[@title='BIRD HOUSEHOLD COMBINED STATEMENT']",
				"Select desired combined statement for new client");
	}

	/**
	 * This method is used to click on NEXT button in Overlay page for Combined
	 * statement
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean overlayPage_NextButton() {
		return clickElementUsingXpath(strClickCSOverlayModalNextButtonXpath, "Next button on CS overlay moday clicked");
	}
	/**
	 * This method is used to see Edit Household page is disaplyed statement
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeEditHHPage_ClickingNext() {
		String editHHPageTitle = "//nav[@class='navbar-fixed-top sub-header']/div/h2";
		String str1 = getTextUsingXpath(editHHPageTitle, "Edit Household page title");
		String str2 = "Edit " + testData.get("Groupname").toUpperCase();
		return (str1.equalsIgnoreCase(str2));
	}


	/**
	 * This method is used to click on Create a New Combined Statement for Client
	 * button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickCreateaNewCombinedStatementforClientbutton() {
		return clickElementUsingXpath(strCreateaNewCSforClientXpath,
				"Create a New Combined Statement for Client button is clicked");
	}

	/**
	 * This method is used to check if tile to select primary account is displayed
	 * after clicking Create a New Combined Statement for Client button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean tiletoselectprimaryaccountDisplayed() {
		return isElementPresentUsingXpath(strselectprimaryaccounttileXpath, lplCoreConstents.HIGH,
				"tile to select primary account Displayed");

	}


	

	/**
	 * This method is to click on COMPELETE DETAILS FOR 1 COMBINED STATEMENT
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnCompleteDetailsFor1CombinedStatement() {
		return clickElementUsingXpath("//button[@title='Create Combined Statement Subgroup Button Label']",
				"Click on the COMPELETE DETAILS FOR 1 COMBINED STATEMENT");
	}

	/**
	 * This method is used to verify the user is landed in Review Combined Statement
	 * Subgroup(s) Details page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateReviewCSSubgroupDetailsPage() {
		String reviewCSPageXpath = "//h2[@title='page titledetail']";
		String str1 = getTextUsingXpath(reviewCSPageXpath, "Review Combined Statement Subgroup(s) Details page");
		String str2 = "Review Combined Statement Subgroup(s) Details";
		return (str1.equals(str2));
	}


	/**
	 * This method is used to validate account panel title as Accounts on Set Up
	 * Combined Statement page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateAccountsPanelTitle_CSSetUpCSpage() {
		String str1 = getTextUsingXpath(strAccountPanelTitleXpath, "Account is displayed as panel title");
		String str2 = testData.get("accountPanelTitle");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to validate household summary name with repid in
	 * dashboard Page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean summarynamewithrepid() {
		return isElementPresentUsingXpath(strsummarynameXpath, "Household summary name is displayed in dashboard Page")
				&& isElementPresentUsingXpath(strhhrepidXpath, "Repid is displayed in household summary banner of dashboard");
	}

	/**
	 * This method is used to validate primary client information in the summary
	 * section of the dashboard Page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean primaryclientcontactinformation() {
		return isElementPresentUsingXpath(strprimaryclientcontactinfoXpath,
				"Primary client information is displayed in household summary section of the dashboard Page");

	}

	/**
	 * This method is used to validate household client section in the dashboard
	 * Page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean householdclientsection() {
		return isElementPresentUsingXpath(strhouseholdclientsectionXpath,
				"household client  section is displayed in the dashboard page");
	}

	/**
	 * This method is used to validate primary client tile in the household client
	 * section of the dashboard Page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean primaryclienthouseholdsection() {
		return isElementPresentUsingXpath(strprimaryclienthhsectionXpath,
				"household primary client tile is displayed in the household client section of the dashboard page");
	}

	/**
	 * This method is used to expand Billing rate chevron
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean expandbillingratechevron() {
		return clickElementUsingXpath(strbillingrateexpandchevronXpath, "billing rate chevron is clicked");

	}

	/**
	 * This method is used to collapse Billing rate chevron
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean collapsebillingratechevron() {
		return clickElementUsingXpath(strbillingcollapseratechevronXpath, "billing rate chevron is clicked");

	}

	/**
	 * This method is used to validate bank sweep message in the confirmation page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean validateBankSweepMessage() {
		return isElementPresentUsingXpath(strbanksweepmessageXpath,
				"Bank sweep  message is displayed in the confirmation Page");
	}

	/**
	 * This method is used to click on Edit HH pencil icon Streamline/Confirmation
	 * page
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickEditHHPencilIcon() {
		wait(10);
		return clickElementUsingXpath(strClickEditHHPencilIconXpath, "Edit HH pencil icon clicked");
	}


	/**
	 * This method is used to click on chevron under clinet in Billing rate section
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickBillingRateContentChevron() {
		strChevronBillingRateSection = "//div[@class='col capability-tile-padding']//strong[text()=' BILLING RATE ']/../section/div/div[3]/div/button/I\r\n";
		return clickElementUsingXpath(strChevronBillingRateSection, "Chevron under Billing Rate section");
	}

	/**
	 * This method is used to click on client name chevron under billing rate
	 * section
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickClientNameUnderBillingRateChevron() {
		strClientNameBillingRateSection = "//tr[@class='mat-row cdk-row account-element-row ng-tns-c114-0 ng-star-inserted']/td/button/i";
		return clickElementUsingXpath(strClientNameBillingRateSection, "Chevron under Billing Rate section");
	}

	/**
	 * This method is used to validate column name under client under Billing rate
	 * section
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateNextBillingDateColumn() {
		strNextBillingDate = "//tr[@class='mat-row cdk-row account-detail-row ng-tns-c114-0 ng-star-inserted']/td/div/table/thead/tr/th[1]";
		String str1 = getTextUsingXpath(strNextBillingDate, "NEXT BILLING DATE");
		String str2 = testData.get("nameColumn1");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to validate column name under client under Billing rate
	 * section
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateUpcomingFeeColumn() {
		strUpComingFee = "//tr[@class='mat-row cdk-row account-detail-row ng-tns-c114-0 ng-star-inserted']/td/div/table/thead/tr/th[2]";
		String str1 = getTextUsingXpath(strUpComingFee, "EST. UPCOMING FEE");
		String str2 = testData.get("nameColumn2");
		return str1.equalsIgnoreCase(str2);

	}

	/**
	 * This method is used to validate column name under client under Billing rate
	 * section
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validatePaidFromColumn() {
		strPaidFromColumn = "//tr[@class='mat-row cdk-row account-detail-row ng-tns-c114-0 ng-star-inserted']/td/div/table/thead/tr//th[text()='PAID FROM']";
		String str1 = getTextUsingXpath(strPaidFromColumn, "PAID FROM");
		String str2 = testData.get("nameColumn3");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to validate column name under client under Billing rate
	 * section
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateAdvisoryFeesColumn() {
		strAdvisoryFeesColumn = "//tr[@class='mat-row cdk-row account-detail-row ng-tns-c114-0 ng-star-inserted']/td/div/table/thead/tr//th[text()=' ADVISORY FEES FROM THIS ACCOUNT YTD ']";
		String str1 = getTextUsingXpath(strAdvisoryFeesColumn, "ADVISORY FEES FROM THIS ACCOUNT YTD");
		String str2 = testData.get("nameColumn4");
		return (str1.equalsIgnoreCase(str2));
	}


	/**
	 * This method is used to click on Cancel without adding client button
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnCancelWithoutAddingClient() {
		strclickOnCancelWithoutAddingClient = "//div[@class='modal-footer modal-footer-m']/a";
		return clickElementUsingXpath(strclickOnCancelWithoutAddingClient, "Click on cancel without adding client");
	}


	/**
	 * This method is used to click on No on the prompt in Overlay page for combined
	 * statement
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnNoInPromtToCancel() {
		return clickElementUsingXpath("//div[@class='yes-no-buttons']/button[2]", "Alert Box 'No'");
	}


	/**
	 * This method is used to click on Yes on the prompt in Overlay page for
	 * combined statement
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnYesInPromtToCancel() {
		return clickElementUsingXpath("//div[@class='yes-no-buttons']/button[1]", "Alert Box 'Yes'");
	}

	/**
	 * This method is used to validate household capabilities section in the
	 * dashboard Page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seehouseholdcapabilitiessection() {
		return isElementPresentUsingXpath(strhouseholdcapabilitiessectionXpath,
				"Household Capabilities section is displayed in the dashboard Page");

	}

	/**
	 * This method is used to click on Content chevron in Review household page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnContentsReviewHHPage() {
		return clickElementUsingXpath(strContentsChevronXpath, "Click on Content chevron in Review household page");
	}

	/**
	 * This method is used to verify text displayed in combined statement overlay
	 * modal page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyShowMoreButton() {
		boolean result = false;
		int numberOfClients = getWebElementsSizeUsingXpath(strNoOfclientsReviewHHPageXpath);

		for (int i = 1; i <= numberOfClients; i++) {
			String noOfAccountsForEachClient = getTextUsingXpath(
					strNoOfAccountsForEachClientLocXpath.replace("x", Integer.toString(i)),
					"No of accounts for each client");
			System.out.println("acc = "+noOfAccountsForEachClient);

			if (Integer.parseInt(noOfAccountsForEachClient) > 5) {
				clickElementUsingXpath(strClickAccountChevronXpath.replace("x", Integer.toString(i)),
						"Click on Account chevron for selected client");
				result = isElementPresentUsingXpath(strShowMoreXpath.replace("z", Integer.toString(i)),
						"Household Capabilities section is displayed in the dashboard Page");
			/*	String str1 = getTextUsingXpath(strShowMoreXpath.replace("z", Integer.toString(i)), "Show More");
				String str2 = testData.get("verifyText");
				System.out.println(str1);
				System.out.println(str2);
				result = (str1.equalsIgnoreCase(str2)); */
			} else {
				 continue;
			}
		}
		return result;
	}

	/**
	 * This method is used to click on Create a New Combined Statement for Client in
	 * C/S Edit Modal
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickcreateanewcombinedstatement() {
		return clickElementUsingXpath(strcreateanewcombinedstatementXpath,
				"Click on Create a New Combined Statement for Client button");

	}

	/**
	 * This method is used to validate review primary account information in C/S
	 * edit modal
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seereviewprimayaccountinformation() {
		return isElementPresentUsingXpath(strprimaryaccountinformationXpath,
				"Primary account information is displayed in the review C/S edit modal");

	}

	/**
	 * This method is used to validate no account eligible message for each
	 * capability
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean noAccountEligibleMessage() {
		if (isElementPresentUsingXpath(strNoAccountEligibleMessageXpath,
				"No account eligible message for each capability message is displayed")&&
				isElementPresentUsingXpath(strNoAccountEligibleMessageBankSweepXpath,
						"No account eligible message for each capability message is displayed")&&
				isElementPresentUsingXpath(strNoAccountEligibleMessageCombinedStmtXpath,
								"No account eligible message for each capability message is displayed")&&
				isElementPresentUsingXpath(strNoAccountEligibleMessageBillingXpath,
						"No account eligible message for each capability message is displayed")) {
			
			return true;
		}else {
			return false;
		}	
		
	}

	/**
	 * This method is used to validate red colour delete billing tracker
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeredcolourdeletebillingtracker() {
		return (isElementPresentUsingXpath(strreddeletebillingtrackerXpath, "Red colour billing tracker is displayed"));

	}

	/**
	 * This method is used to click on Accounts Chevron on Review Billing page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickAccountsChevron_ReviewBillingPage() {
		return clickElementUsingXpath(strReviewBillingAccountChevronXpath,
				"Click on accounts chevron on Review Billing page");
	}

	/**
	 * This method is used to validate account details on Review Billing page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateAccountDetails_ReviewBillingPage() {
		return isElementPresentUsingXpath(strReviewBillingAccountDetailsXpath,
				"Displayed account details under accounts chevron on Review Billing page");
	}

	/**
	 * This method is used to click on Show more button on Review Billing page if no
	 * of accounts is more than 5
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickShowMoreButton_ReviewBillingPage() {
		try {
			String noOfAccountsForEachClient = getTextUsingXpath(strReviewBillingAccountChevronXpath,
					"No of accounts for each client");
			String[] parts = noOfAccountsForEachClient.split(" ");
			String value = parts[0];
			int a = Integer.parseInt(value);
			return (a > 5) ? clickElementUsingXpath(strReviewBillingShowMoreButtonXpath, "Click on show more button")
					: LPLCoreConstents.FALSE;
		} catch (NumberFormatException ex) {
			setErrorMessage("Invalid string in argumment");
			return false;
		}
	}

	/**
	 * This method is used to click on contents Chevron on Edit HH page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickContentsChevron_EditHHPage() {
		return clickElementUsingXpath(strEditHHContentsChevronXpath, "Click on contents chevron on Edit HH page");
	}

	/**
	 * This method is used to click on Accounts Chevron on Edit HH page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickAccountsChevron_EditHHPage() {
		return clickElementUsingXpath(strEditHHAccountChevronXpath, "Click on accounts chevron on Edit HH page");
	}

	/**
	 * This method is used to validate account details block on Edit HH page
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean validateAccountsDetails_EditHHPage() {
		return clickElementUsingXpath(strEditHHAccountDetailsXpath, "Displayed account details on Edit HH page");
	}

	/**
	 * This method is used to validate total number of accounts In New Household
	 * Combined statement details page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateNoOfAcctsInNewHouseholdCSPage() {
		int noOfClients = getWebElementsSizeUsingXpath(strNoOfClientsXpath);
		int total = 0;
		for (int i = 1; i <= noOfClients; i++) {
			String value = getTextUsingXpath(strNoOfAccountEachClientXpath.replace("x", Integer.toString(i)),
					"Account value for each client").trim();
			System.out.println(Integer.parseInt(value));
			total = total + Integer.parseInt(value);
		}
		String str1;
		if(total==1) {
			str1 = Integer.toString(total) + " ACCT |";
		}else {
			str1 = Integer.toString(total) + " ACCTS |";
		}
		//String str1 = Integer.toString(total) + " ACCTS |";
		String str2 = getTextUsingXpath(strNoOfAccountsContentsPanelXpath, "Total value of the account in Contents panel");
		System.out.println(str1);
		System.out.println(str2);
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to validate total account value In New Household Combined
	 * statement details page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean validateNoOfClientsInNewHouseholdCSPage() {
		int noOfClients = getWebElementsSizeUsingXpath(strNoOfClientsXpath);
		String str1;
		if(noOfClients==1) {
			str1 = getWebElementsSizeUsingXpath(strNoOfClientsXpath) + " CLIENT";
		}else {
			str1 = getWebElementsSizeUsingXpath(strNoOfClientsXpath) + " CLIENTS";
		}
		String str2 = getTextUsingXpath(strNoOfClientsContentXpath, "Number of clients displayed in contents panel")
				.trim();
		System.out.println(str1);
		System.out.println(str2);
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to validate total account value In New Household Combined
	 * statement details page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean totalAccountValueInNewHouseholdCSPage() {
	/*	float total = 0f;
		int noOfClients = getWebElementsSizeUsingXpath(strNoOfClientsXpath);
		for (int i = 1; i <= noOfClients; i++) {
			System.out.println(getTextUsingXpath(strAccountValueEachClientXpath.replace("xx", Integer.toString(i)), "Account value for each client"));
			String value = getTextUsingXpath(strAccountValueEachClientXpath.replace("xx", Integer.toString(i)),
					"Account value for each client").substring(1);
			System.out.println(value);
			total = total + Float.parseFloat(value);
			total = (float) (Math.round(total * 100.0) / 100.0);
		}
		String str1 = "$" + total;
		String str2 = getTextUsingXpath(strAccountValueContentsPanelXpath, "Total value of the account in Contents panel");
		System.out.println(str1);
		System.out.println(str2);
		return (str1.equalsIgnoreCase(str2)); */
		return isElementPresentUsingXpath(strAccountValueContentsPanelXpath, "Billing Summary is displayed in the confirmation Page");
	}

	/**
	 * This method is used to validate billing summary in the confirmation Page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seebillingsummary() {
		return isElementPresentUsingXpath(strbillingsummaryXpath,
				"Billing Summary is displayed in the confirmation Page");

	}

	/**
	 * This method is used to click on Edit Group Client Name
	 *
	 * @return boolean
	 * @author nandlal sharma
	 */
	public boolean validateElementNotVisisble() {
		return isElementNotPresentUsingXpath(strEditGroupNameBtnXpath, 10);
	}


	

	/**
	 * This method is used to click on yes button present in edit CS close modal
	 * popup
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickCSSubmitChanges() {
		return clickElementUsingXpath(strCSSubmitChangesXpath,
				"Click on SUMIT CHANGES button in Review Combined Statement Subgroup(s) Details page");
	}

	/**
	 * This method is used to validate sub group combined statements INPROGRESS
	 * status
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seesubgroupcombinedstatementsinprogressstatus() {
		return isElementPresentUsingXpath(strsubgroupcombinedstatementinprogressstatusXpath,
				"Sub group combined statement INPROGRESS status is displayed");

	}

	/**
	 * This method is used to validate fee rate value in billing rate section of the
	 * dashboard page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seefeeratevalue() {
		return isElementPresentUsingXpath(strfeeratevalueXpath,
				"Fee rate value is displayed in the billing rate section of the dashboard page");

	}

	/**
	 * This method is used to validate total asset value in billing rate section of
	 * the dashboard page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seetotalassetvalue() {
		return isElementPresentUsingXpath(strtotalassetvalueXpath,
				"Total Asset value is displayed in the billing rate section of the dashboard page");

	}

	/**
	 * This method is used to validate billable value in billing rate section of the
	 * dashboard page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seebillablevalue() {
		return isElementPresentUsingXpath(strbillablevalueXpath,
				"Billable value is displayed in the billing rate section of the dashboard page");
	}

	/**
	 * This method is used to validate EST Annual fees along with YTD fees in
	 * billing rate section of the dashboard page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seebillingratefeesvalues() {
		return isElementPresentUsingXpath(strESTAnnualfeesXpath,
				"EST Annual fees is displayed in the billing rate section of the dashboard page")
				&& isElementPresentUsingXpath(strYTDfeesXpath,
						"YTD fees is displayed in the billing rate section of the dashboard page");
	}

	/**
	 * This method is used to check for primary client
	 * 
	 * @return boolean
	 * @author pabdeo
	 */
	public boolean verifyPrimaryClientListedFirst() {
		return isElementPresentUsingXpath(strPrimaryClientExistXpath.replace("xxx", testData.get("primaryClientName")), PRIMARY_CLIENT);
	}

	/**
	 * This method is used to enter the last name in Client search text box
	 *
	 * @param text - Search text
	 * @return boolean
	 * @author pabdeo
	 */
	public boolean enterLastName(String text) {
		clickElementUsingXpath(strClientPrimarySearchTextboxXpath, 120, "Search Text for Client Primary");
		return enterTextUsingXpath(strClientPrimarySearchTextboxXpath, text, "Search Text for Client Primary");
	}

	/**
	 * This method is used to verify billing updated message in confirmation page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeBillingSetupUpdatedMsgInConfPage() {
		String str1 = getTextUsingXpath(strBillingUpdatedXpath, "Billing cpability updated successfully");
		String str2 = testData.get("groupName") + testData.get("verifyText");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to verify household billing name in confirmation page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyHouseholdBillingName() {
		String str1 = getTextUsingXpath(strBillingNameXpath, "Billing cpability name");
		String str2 = testData.get("groupName") + testData.get("verifyText1");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to verify alert message in billing section in
	 * confirmation page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyBillingAlertMessage() {
		String str1 = getTextUsingXpath(strAlertMsgBillingXpath, "Billing cpability name");
		String str2 = testData.get("alertText");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to verify column name in billing section in confirmation
	 * page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyColumnNameInBillingSection() {
		int noOfColumns = getWebElementsSizeUsingXpath(strNoOfColumnsBillingSummaryXpath);
		boolean result = false;
		for (int i = 1; i <= noOfColumns; i++) {
			if (i == 1) {
				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
						"SCHEDULE column");
				String str2 = testData.get("columnName1");
				return str1.equalsIgnoreCase(str2);
			} else if (i == 2) {
				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
						"FLAT RATE column");
				String str2 = testData.get("columnName2");
				return str1.equalsIgnoreCase(str2);
			} else if (i == 3) {
				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
						"TOTAL ASSETS column");
				String str2 = testData.get("columnName3");
				return str1.equalsIgnoreCase(str2);
			} else if (i == 4) {
				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
						"EST. ANNUAL FEE column");
				String str2 = testData.get("columnName4");
				return str1.equalsIgnoreCase(str2);
			} else if (i == 5) {
				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
						"FEE FROM column");
				String str2 = testData.get("columnName5");
				return str1.equalsIgnoreCase(str2);
			}
		}
		return result;

	}

	/**
	 * This method is used to check if account details are displayed
	 *
	 * @return boolean
	 * @author skoul
	 */
	public boolean isAccountDetailsDisplayed() {
		return isElementPresentUsingXpath(strAccountNameXpath, "Account Name")
				&& isElementPresentUsingXpath(strAccountClassXpath, "Account Class")
				&& isElementPresentUsingXpath(strAccountNumberXpath, "Account Number");
	}

	/**
	 * This method is used to click on Content Panel chevron on billing page
	 *
	 * @return boolean
	 * @author skoul
	 */
	public boolean clickContentPanelChevron() {
		return clickElementUsingXpath(strContentPanelXpath, "Content panel chevron is clicked");
	}

	/**
	 * This method is used to click on Account Panel chevron on billing page
	 *
	 * @return boolean
	 * @author skoul
	 */
	public boolean clickAccountChevron() {
		return clickElementUsingXpath(strAccountPanelXpath, "Accpunt panel chevron is clicked");
	}

	/**
	 * This method is used to click on Content Panel chevron in combined statement
	 * section of edit details page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickcontentchevronCSeditHHpage() {
		return clickElementUsingXpath(strcsedithhcontentchevronXpath, "Content panel chevron is clicked");
	}

	/**
	 * This method is used to check removed client name is not present in content
	 * information
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean removedclientnotDisplayed() {
		return isElementNotPresentUsingXpath(strcontentclientnameXpath.replace("xxx", testData.get("firstName")));
	}

	/**
	 * This method is used to click on enabled next button in CS edit modal
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickenablednextbutton() {
		wait(3);
		return clickElementUsingXpath(strNextButtonXpath, "Enabled next button is clicked");
	}
	
	/**
	 * This method is used to validate next button in C/S edit modal
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeNextButton() {
		return isElementPresentUsingXpath(strNextButtonXpath, "Next button is displayed in the review C/S edit modal");

	}

	/**
	 * This method is used to check added client information in the Content Panel
	 * combined statement section of edit details page
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean isCScontentclientinformationDisplayed() {
		return isElementPresentUsingXpath(strcontentclientnameXpath.replace("xxx", testData.get("firstName")),
				"Client Name is displayed in content information");

	}

	/**
	 * This method is used to check if account details are displayed
	 *
	 * @return boolean
	 * @author skoul
	 */
	public boolean verifyTitleBanner() {
		return isElementPresentUsingXpath(strClientTitleXpath, "Client")
				&& isElementPresentUsingXpath(strAccountsTitleXpath, "Accounts")
				&& isElementPresentUsingXpath(strValueTitleXpath, "Value");

	}

	/**
	 * This method is used to click on Review Changes Contents panel
	 *
	 * @return boolean
	 * @author hnayak
	 */
	public boolean clickReviewChangesContentsPanel() {
		return clickElementUsingXpath(strClickReviewContentsXpath, "Review Changes contents panel chevron is clicked");
	}

	/**
	 * This method is used to check if client details are displayed
	 *
	 * @return boolean
	 * @author hnayak
	 */
	public boolean verifyClientBannerDisplay() {
		return isElementPresentUsingXpath(strClientReviewTitleXpath, "Client")
				&& isElementPresentUsingXpath(strAccountsReviewTitleXpath, "Accounts")
				&& isElementPresentUsingXpath(strValueReviewTitleXpath, "Value");

	}

	/**
	 * This method is used to click on account chevron
	 *
	 * @return boolean
	 * @author pabdeo
	 */
	public boolean clickonAccountChevron() {
		return clickElementUsingXpath(strClientAccChevronReviewPageXpath.replace("xxx", testData.get("firstName")), ACCOUNT_CHEVRON);
	}

	/**
	 * This method is used to verify by default 5 accounts displayed
	 *
	 * @return boolean
	 * @author pabdeo
	 */
	public boolean strClickAccountxpath() {
		int count = getWebElementsSizeUsingXpath(strDefault5AccountReviewPageXpath.replace("xxx", testData.get("firstName")));
		return (count == 5);
	}

	/**
	 * This method is used to click on clients and account details chevron
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickonclientsandaccountdetailschevron() {
		//return clickElementUsingXpath(strclientsandaccountdetailschevronXpath.replace("xxx", testData.get("clientname")),"client and account details chevron is clicked");
		return clickElementUsingXpath(strclientsandaccountdetailschevronXpath, "client and account details chevron is clicked");
	}

	/**
	 * This method is used to check if client tiles are displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean verifyclienttileinformation() {
		return isElementPresentUsingXpath(strclienttileinformationXpath.replace("xxx", testData.get("clientname")),
				"Client tile information is displyed");
	}

	/**
	 * This method is used to click on accounts chevron present under clients and
	 * account details
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickonclientsaccountschevron() {
		return clickElementUsingXpath(strclientaccountchevronXpath.replace("xxx", testData.get("clientname")),
				"Accounts  chevron under client and account details chevron is clicked");
	}

	/**
	 * This method is used to check if clients account detail information are
	 * displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean verifyclientaccountsinformation() {
		//return isElementPresentUsingXpath(strclientsaccountXpath.replace("xxx", testData.get("clientname")),"Clients accounts information is displyed");
		return isElementPresentUsingXpath(strclientsaccountXpath, "Clients accounts information is displyed");
	}

	/**
	 * This method is used to validate Account values are displayed in descending
	 * order statement details page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean checkAccountsInDescendingOrder() {
		List<Float> clientValueList = new ArrayList<>();
		int flag = 0;
		int noOfClientsReviewHH = getWebElementsSizeUsingXpath(strNoOfClientsReviewHHXpath);
		for (int i = 1; i <= noOfClientsReviewHH; i++) {
			waitForPageLoading();
			click(driver.findElement(
					By.xpath("//app-content[@title='household']//div[@class='content-panel']/div/section/div[" + i
							+ "]/div/div/div/div[1]/div/button/i")));
			int noOfAccountsEachClient = Integer.parseInt(
					getTextUsingXpath("//app-content[@title='household']//div[@class='content-panel']/div/section/div["
							+ i + "]/div/section/div/div[2]/div", "Get no. of accounts for each client"));
			if (noOfAccountsEachClient - 1 > 5) {
				for (int n = 1; n <= noOfAccountsEachClient / 5; n++) {
					clickElementUsingXpath(strShowMoreXpath.replace("z", Integer.toString(i)), "Show More");
				}
				noOfAccountsEachClient = Integer.parseInt(getTextUsingXpath(
						"//app-content[@title='household']//div[@class='content-panel']/div/section/div[" + i
								+ "]/div/section/div/div[2]/div",
						"Get no. of accounts for each client after clicking ShowMore"));
			}
			for (int j = 1; j <= noOfAccountsEachClient; j++) {
				String value = getTextUsingXpath(
						"//app-content[@title='household']//div[@class='content-panel']/div/section/div[" + i
								+ "]/div/div/div/div[2]/div/dx-list/div/div/div/div[2]/div[" + j + "]/div/div/div[4]",
						"Account value for each client").substring(1);
				if (value.contains("K") && value.contains("$")) {
					value = value.substring(1);
					String[] val = value.split("K");
					clientValueList.add(Float.parseFloat(val[0]) * 1000);
				} else if (value.contains("M") && value.contains("$")) {
					value = value.substring(1);
					String[] val = value.split("M");
					clientValueList.add(Float.parseFloat(val[0]) * 1000000);
				} else if (value.contains("K")) {
					String[] val = value.split("K");
					clientValueList.add(Float.parseFloat(val[0]) * 1000);
				} else if (value.contains("M")) {
					String[] val = value.split("M");
					clientValueList.add(Float.parseFloat(val[0]) * 1000000);
				} else {
					clientValueList.add(Float.parseFloat(value));
				}
			}

			List<Float> clientValueListActual = new ArrayList<>();
			for (int s = 0; s < clientValueList.size(); s++) {
				if (!Float.toString(clientValueList.get(s)).equalsIgnoreCase(FLOATING_POINT)) {
					clientValueListActual.add(clientValueList.get(s));
				} else {
					break;
				}
			}

			List<Float> clientValueListExpt = clientValueListActual.stream().sorted(Comparator.reverseOrder())
					.collect(Collectors.toList());
			if (clientValueListExpt.equals(clientValueListActual)) {
				flag = 1;
			} else {
				flag = 0;
				break;
			}
			clientValueList.clear();
			clientValueListActual.clear();
			clientValueListExpt.clear();
		}
		return flag == 1 ? LPLCoreConstents.TRUE : LPLCoreConstents.FALSE;
	}

	/**
	 * This method is used to click on Show Full Details Link
	 *
	 * @return boolean
	 * @author hnayak
	 */
	public boolean clickonShowFullDetails() {
		return clickElementUsingXpath(strShowFullDetailsLinkXpath, SHOWFULLDETAILS);
	}

	/**
	 * This method is used to click on Show Full Details Link
	 *
	 * @return boolean
	 * @author hnayak
	 */
	public boolean verifySummaryColumn() {
		return isElementPresentUsingXpath(strTotalGroupValueXpath, "TotalGroupValue")
				&& isElementPresentUsingXpath(strCashandEquivalentPctXpath, "Cash$EquivalentPct")
				&& isElementPresentUsingXpath(strRevenueYTDXpath, "RevenueYTD")
				&& isElementPresentUsingXpath(strRevenueLast1yrXpath, "RevenueLast1yr");
	}

	/**
	 * This method is used to check if Account name is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean verifyclientaccountname() {
		return isElementPresentUsingXpath(strclientaccountnameXpath, "Accounts name is displayed");

	}

	/**
	 * This method is used to check if Program name is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean verifyprogramname() {
		return isElementPresentUsingXpath(strprogramnameXpath,"Program name is displyed");

	}

	/**
	 * This method is used to check if Account number is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean verifyclientaccountnumber() {
		return isElementPresentUsingXpath(strclientaccountnumberXpath,"Account Number is displyed");

	}

	/**
	 * This method is used to check if Total account value is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean verifytotalaccountvalue() {
		return isElementPresentUsingXpath(strtotalaccountvalueXpath,"Total account value is displyed");
	}

	/**
	 * This method is used to click on Edit Group name pencil icon in Edit household
	 * page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickonEditHHGroupNamePencilIcon() {
		return clickElementUsingXpath(StrEditHHGroupNamePencilIconXpath,
				"Edit Household group name in Edit household page is clicked");
	}

	/**
	 * This method is used to enter the text in Household group name in Edit
	 * household page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean enterHouseholdNameExceeding40Char() {
		clearTextUsingXpath(strEditGroupNameXpath, "Clear Group Name");
		return enterTextUsingXpath(strEditGroupNameXpath, testData.get("GroupNameExceeding40Char"),
				"Enter Group Name Exceeding 40 characters");
	}

	/**
	 * This method is used to verify Error message when household group name
	 * exceeding 40 characters
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyErrorMsgForHHGroupNameExceeding40Char() {
		String str1 = getTextUsingXpath(strErrorMsgHHNameExceedingLimitXpath,
				"Error message when household group name exceeding 40 characters");
		String str2 = testData.get("errorMessage");
		return (str1.equalsIgnoreCase(str2));
	}

	/**
	 * This method is used to verify Market value for securities in dollars
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyMarketValueForSecuritiesInDollars() {
		int noOfSecurities = getWebElementsSizeUsingXpath(strNoOfSecuritiesXpath);
		int flag = 0;
		for (int i = 1; i <= noOfSecurities; i++) {
			String str1 = getTextUsingXpath(strMarketValueForSecuritiesXpath.replace("x", Integer.toString(i)),
					"Market value for securities");
			if (str1.contains("$")) {
				flag = 1;
			} else {
				flag = 0;
				break;
			}
		}
		return (flag == 1);
	}

	/**
	 * This method is used to validate Active Label on CS Subgroup Tile on Dashboard
	 * 
	 * @return boolean
	 * @author vsharma
	 */
	public boolean verifyDashboardCombinedStatamentSubgroupTile_JumpToDetails() {
		return isElementPresentUsingXpath(strCSsubgroupJumpToDetailsXpath, "CS Subgroup Active Label on Dashboard");
	}

	/**
	 * This method is used to validate CS Subgroup summary banner fields on
	 * Dashboard
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCSSummaryBannerFields_dashboard(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
	}

	

	
	/**
	 * This method is used to check 5 defaults accounts with show more button in
	 * combined statement section
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean verifydefaultaccountswithshowmorebutton() {
		String numberOfDefaultAccounts = testData.get("numberOfDefaultAccounts");
		int i = getNumberOfWebElementsUsingXpath(strCSaccountsxpath, "five default accounts are displayed");
		return ((Integer.toString(i)).equalsIgnoreCase(numberOfDefaultAccounts)) ? isElementPresentUsingXpath(
				strCSshowmorebuttonxpath.replace("xxx", testData.get("clientname")), "Show more button is displayed")
				: LPLCoreConstents.FALSE;
	}

	/**
	 * This method is used to click on Show more button in combined statement
	 * section
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickonCSshowmorebutton() {
		String str1 = testData.get("clientname");
		return clickElementUsingXpath(strCSshowmorebuttonxpath.replace("xxx", str1),
				"show  more button in combined statement section is clicked");
	}

	/**
	 * This method is used to check show more button is not displayed with remaining
	 * accounts in the combined statement section
	 *
	 * @return boolean
	 * 
	 * @author awaeza
	 */
	public boolean verifyremainingaccountswithnoshowmorebutton() {
		int i = getNumberOfWebElementsUsingXpath(strCSaccountsxpath,
				"remaining accounts are displayed with no show more button");
		return (i > 5)
				? isElementNotPresentUsingXpath(strCSshowmorebuttonxpath.replace("xxx", testData.get("clientname")))
				: LPLCoreConstents.FALSE;
	}

	/**
	 * This method is used to verify household name in the summary panel in
	 * confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyHouseholsNameSummaryPanel() {

		return isElementPresentUsingXpath(strHHNameSummaryPanelConfPageXpath,
				"Household name in summary panel confirmation page");

	}

	/**
	 * This method is used to verify Rep ID information in the summary panel in
	 * confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyRepIDSummaryPanel() {

		return isElementPresentUsingXpath(strRepIDSummaryPanelConfPageXpath,
				"Rep ID information in summary panel confirmation page");

	}

	/**
	 * This method is used to verify CONTENTS label in the summary panel in
	 * confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyContentsLabelSummaryPanel() {

		return isElementPresentUsingXpath(strContentsLabelSummaryPanelConfPageXpath,
				"CONTENTS label in summary panel confirmation page");

	}

	/**
	 * This method is used to verify CONTENTS label in the summary panel in
	 * confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyActiveStatusLabelSummaryPanel() {
		if (isElementPresentUsingXpath(strActiveStatusSummaryPanelConfPageXpath,
				"CONTENTS label in summary panel confirmation page")) {
			String color = driver.findElement(By.xpath("//div[@class='header-wrapper col-12']/h3/span[3]"))
					.getCssValue("background-color");
			return color.equalsIgnoreCase(testData.get("RGBAcolorCode"));
		}
		return false;
	}

	/**
	 * This method is used to select the Request Id from dropdown
	 *
	 * @return boolean
	 * @author abanker
	 */

	public boolean selectRequestId() {
		clickElementUsingXpath("//*[@class='dx-dropdowneditor-icon']", lplCoreConstents.HIGHEST,
				"Click on Request ID Dropdown");
		return clickElementUsingXpath("//*[contains(text(),'CAG')]", lplCoreConstents.HIGHEST,
				"Select request ID from Dropdown");
	}

	

	/**
	 * This method is used to Check element displayed
	 *
	 * @return boolean
	 * @author abanker
	 */

	public boolean CheckElementDisplayed() {
		switchWindow(CHILD_WINDOW);
		waitForPageLoading();
		return isElementPresentUsingXpath("//*[text()='Documents for Group Billing']", lplCoreConstents.VERYHIGH,
				"DocGrid page");
	}

	/**
	 * This method is used to verify combined statement optional is displayed or not
	 * in confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyCSOptionalText() {
		System.out.println(getTextUsingXpath(strCombinedStatementOptionalXpath, "Combined statement optional text"));
		return getTextUsingXpath(strCombinedStatementOptionalXpath, "Combined statement optional text")
				.equalsIgnoreCase(testData.get("CSOptionalText"));

	}

	/**
	 * This method is used to verify combined statement optional is displayed or not
	 * in confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyCSLinkInConfPage() {
		return getTextUsingXpath(strCombinedStatementLinkConfPageXpath, "Combined statement optional text")
				.equalsIgnoreCase(testData.get("combinedStatementText"));
	}

	/**
	 * This method is to validate whether all details for Education/Retirement goals
	 * are displayed
	 *
	 * @param DataTable values provided in scenario level
	 * @return boolean
	 * @author Rahul Shaw
	 * @since 07/16/2020
	 */
	public boolean isTableDetailsDisplayed(DataTable value, String strValue) {
		boolean blnResult = false;
		List<Map<String, String>> labels = value.asMaps(String.class, String.class);

		for (Map<String, String> data : labels) {
			// getting the required Label name
			String labelName = data.get(FIELDS);
			// validating if the required field label is displayed
			blnResult = checkLabelPresent(strValue, labelName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate user is able to view  " + labelName, "User should be able to view " + labelName,
					"User is able to view " + labelName, "Failed to view " + labelName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click on save note Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean checkLabelPresent(String strValue, String labelName) {
		if (strValue.equalsIgnoreCase(HOUSEHOLD))
			return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", labelName), labelName);
		else if (strValue.equalsIgnoreCase(BILLING))
			return isElementPresentUsingXpath(getFormattedLocator(
					"//*[contains(text(),'Household Capabilities')]/following-sibling::section//*[contains(text(),'BILLING RATE')]/..//th[contains(text(),'%s')]",
					labelName), labelName);
		return false;
	}

	/**
	 * This method is used to click on save note Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean expandBillingRateMenu() {
		clickElementUsingXpath(
				"//*[contains(text(),'Household Capabilities')]/following-sibling::section//*[contains(text(),'BILLING RATE')]/..//button[@title='click to expand accounts list']",
				"");
		return clickElementUsingXpath(
				"//*[contains(text(),'Household Capabilities')]/following-sibling::section//*[contains(text(),'BILLING RATE')]/..//button[@title='click to expand']",
				"");
	}

	/**
	 * This method is used to click on save note Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickOnShowFullDetailsButton() {
		return clickElementUsingXpath("//button/small[contains(text(),'Show Full Details')]", "");
	}

	/**
	 * This method is used to click on save note Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean isMarketValuesOfSecuritiesDisplayed() {
		return isElementPresentUsingXpath("//h2[contains(text(),'Market Value of Securities')]",
				"Market Value Of Securities");
	}

	/**
	 * This method is used to click on save note Button
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean closeBrowser() {
		boolean blnResult = false;
		try {
			driver.close();
			blnResult = true;
		} catch (Exception e) {
			setErrorMessage(e.getMessage());
			blnResult = false;
		}
		return blnResult;
	}

	/**
	 * This method is used to validate sub group combined statement section in
	 * dashboard page
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean validatesubgroupcombinedstatementsection() {
		return isElementPresentUsingXpath(strsubgroupcombinedstatementsectionXpath,
				"sub group combined statement section is displayed");

	}

	/**
	 * This method is used to validate sub group combined statement section tiles
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean validatesubgroupcombinedstatementstiles() {
		int i = getWebElementsSizeUsingXpath(strsubgroupcombinedstatementstilesXpath);
		return (i > 0);
	}

	/**
	 * This method is used to validate combined statement green banner with text
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean validatecombinedstatementgreenbannerwithtext() {
		return isElementPresentUsingXpath(strcombinedstatementbannerxpath,
				"combined statement green banner is displayed")
				&& isElementPresentUsingXpath(strcombinedstatementgreenbannertextXpath,
						"combined statement green banner text is displayed");

	}

	/**
	 * This method is used to validate cross close button in combined statement
	 * banner
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean validatecrossbuttoncombinedstatementbanner() {
		return isElementPresentUsingXpath(strcrossbuttoncombinedstatementbannerxpath,
				"cross button in combined statement green banner is displayed");

	}
	
	/**
	 * This method is used to click on contents chevron in billing section from 
	 * confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickContentChevronBillingSecCongPage() {
		return clickElementUsingXpath(strContentChevronBillingSecConfPageXpath, "Click on contents chevron in billing section from confirmation page");
	}
	
	/**
	 * This method is used to verify Contents chevron is expanded billing section from 
	 * confirmation page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyContentsPanelExpandedForBillingSecInConfPage() {
		return isElementPresentUsingXpath(strContentChevronBillingSecConfPageExpandedXpath,
				"contents chevron in billing section from confirmation page is expanded");

	}
	
	/**
	 * This method is used to verify Accounts chevron is not expanded in billing section from 
	 * confirmation page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyAccountsPanelNotExpandedBillingSectionConfPage() {
		return isElementPresentUsingXpath(strAccChevronBillingSecConfPageNotExpandedXpath,
				"Accounts chevron in billing section from confirmation page is not expanded");

	}
	
	/**
	 * This method is used to click on Accounts chevron in billing section from 
	 * confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickAccChevronBillingSecConfPage() {
		return clickElementUsingXpath(strAccChevronBillingSecConfPageXpath, "Click on contents chevron in billing section from confirmation page");
	}
	
	/**
	 * This method is used to verify Accounts chevron is expanded in billing section from 
	 * confirmation page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyAccountsPanelExpandedBillingSectionConfPage() {
		return isElementPresentUsingXpath(strAccChevronBillingSecConfPageExpandedXpath,
				"Accounts chevron in billing section from confirmation page is not expanded");

	}
	
	/**
	 * This method is used to verify Accounts chevron is expanded in billing section from 
	 * confirmation page
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyContentChevronCollapseBillingSectionConfPage() {
		return isElementPresentUsingXpath(strContentChevronBillingSecConfPageCollapsedXpath,
				"Accounts chevron in billing section from confirmation page is not expanded");

	}
	
	/**
	 * This method is used to click on client account chevron under  client name
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean clickclientaccountchevron() {
		
		//return clickElementUsingXpath(strclientacountchevronxpath.replace("xxx",testData.get(CLIENTNAME)), "client account chevron is clicked");
		return clickElementUsingXpath(strclientacountchevronxpath.replace("xxx",testData.get("clientName")), "client account chevron is clicked");
	}
	
	/**
	 * This method is used to click on House Holding Group for Cash Account section check
	 *
	 * @return boolean
	 * @author akale
	 */
	public boolean clickCashAccountGroupName() {
		return clickElementUsingXpath(strclickCashAccountGroupnameXpath, "Household Group name for Cash Account is clicked");
	}
	
	
	/**
	 * This method is used to check for the Balances and Investments link on House Holding Group page  
	 *
	 * @return boolean
	 * @author akale
	 */

	public boolean verifyBalancesAndInvestments() {
		return isElementPresentUsingXpath(strBalancesAndInvestmentsXpath, "Balances And Investments is available");
	}
	

	/**
	 * This method is used to click on Show all contents link from House Holding Group page
	 *
	 * @return boolean
	 * @author akale
	 */
	public boolean clickShowFullDetailsLink() {
		return clickElementUsingXpath(strShowFullDetailsLinkXpath, "Click on the Show Full Details Button");
	}
	
	
	
	/**
	 * This method to check for the fields in Cash Accounts Fields 
	 *
	 * @return boolean
	 * @author akale
	 */
	public boolean cashaccountsfieldsVisible(String field) {
		// This method is used to validate where the STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
	}
	
	
	/**
	 * Click on client account content chevron
	 *
	 * @return boolean
	 * @author amrita
	 */
	public boolean clickClientAccountExpandArrow() {

		return clickElementUsingXpath(strBanksweepContentsChevronXpath,
				"Click on client account content chevron ");
	}

	/**
	 * Deletes the already created household from the streamline page
	 *
	 * @return boolean
	 * @author amrita
	 */
	public boolean deleteHousehold(String text) {
		// User closes the window to delete the household
		//isElementPresentUsingXpath(strPrimaryClientSearchResultsXpath, lplCoreConstents.HIGH, "Primary Client Search Results");
		//String strcloseHouseholdButton = testData.get("strcloseButton");
		//clickElementUsingXpath(strcloseHouseholdButtonXpath, "Close Household Button");
		houseHoldName = text;
		
		String strLink = getFormattedLocator("//a[text()= '%s']", houseHoldName);

		enterTextUsingXpath(strGroupSearchTextboxXpath, houseHoldName, "Search Text for Group");
		clickElementUsingXpath(strGroupSearchTextboxSearchXpath, "Search Text for Group");

		moveToElement(strLink, "Group Name");
		clickElementUsingXpath(getFormattedLocator("//a[text()= '%s']/..//button", houseHoldName), "");

		System.out.println("For Delete click");
		clickElementUsingXpath("//button[contains(text(),'Delete')]", "Delete button");

		// waitForPageLoading();
		// clickGroupContextMenuDropdown();
		// return true;

		driver.switchTo().frame("iframe-modal-frame");
		String strDeleteHousehold = "//button[@title='Confirm delete Household']";
		clickElementUsingXpath(strDeleteHousehold, "Delete This HouseHold button");
		return isElementPresentUsingXpath(strDeleteHousehold, lplCoreConstents.HIGH, "Validate Click Operation");

	}
	
	/**
	 * Create new household 
	 *
	 * @return boolean
	 * @author amrita
	 */
	public boolean createNewHousehold(String text) {
		// User clicks on primary text box and enters the primary client name
		clickElementUsingXpath(strClientPrimarySearchTextboxXpath, 120, "Search Text for Client Primary");
		enterTextUsingXpath(strClientPrimarySearchTextboxXpath, text, "Search Text for Client Primary");
		wait(5);
		isElementPresentUsingXpath(strPrimaryClientSearchResultsXpath, lplCoreConstents.HIGH,
				"Primary Client Search Results");

		// Selected primary client and it is used for creating new household
		clickElementUsingXpath(strPrimaryClientSearchResultsXpath, "Client Primary Search Result");
		wait(3);
		clickElementUsingXpath(strCreateBtnXpath, "CreateHouseHold Button");
		waitForPageLoading();

		isElementPresentUsingXpath(strConfirmationPageXpath, lplCoreConstents.HIGH, "Validate Confirmation Page");
		System.out.println(getTextUsingXpath("//h2[@class='card-title household-name']", " "));
		houseHoldName = getTextUsingXpath("//h2[@class='card-title household-name']", " ");
		return houseHoldName != null;
	}
	

	/**
	 * This method is used to ensure two decimal places for household value in create household page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean iSeeTwoDecimalplaceForHouseholdValueCreateHouseholdPage() {
		String householdValue = getTextUsingXpath(strHouseholdValueXpath, "household value");
		String[] decimalValue = householdValue.split("\\.");
		return(decimalValue[1].trim().length()==2);
	}
	
	/**
	 * This method is used to ensure two decimal places for household value in create household page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean iSeeTwoDecimalplaceForClientValueInCreateHouseholdPage() {
		String householdValue = getTextUsingXpath(strPrimaryClientValueXpath, "Primary client value");
		String[] decimalValue = householdValue.split("\\.");
		System.out.println(decimalValue[1]);
		return(decimalValue[1].trim().length()==2);
	}

	/**
	 * This method is used to validate sub group combined statement tile is  not present in 
	 * edit  household  page
	 * 
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean subgroupcombinedstatementtilenotdisplayed() {
		
		
		return isElementNotPresentUsingXpath(strsubgroupcstileXpath.replace("xxx",testData.get("subGroupCombinedStatementName")));
	}
	
	
	
	/**
	 * This method is used to verify Hosuehold name is not blank in Create household page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean isHouseholdNameNotBlankCreateHouseholdPage() {
		return (getTextUsingXpath(strHouseholdNameCreatePageXpath, "New Household").length()!=0);
	}

	
	/**
	 * This method is used to validate select client for removal in household group 
	 * 
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeselectedremovalclientinhhgroup() {
		
	return isElementPresentUsingXpath(strselectedremovalclientxpath.replace("xxx",testData.get("primaryClientName")), lplCoreConstents.HIGH, "selected  client for removal is  Displayed ");
	
	}
	
	/**
	 * This method is used to validate "x" number in client account chevron 
	 * 
	 * 
	 * @return boolean
	 * @author awaeza
	 */
	public boolean seeClientAccountsNumber() {
		
	isElementPresentUsingXpath(strSeeClientAccountNumberXpath.replace("xxx",testData.get("ClientName")), lplCoreConstents.HIGH, "Client Account chevron is Displayed");
	return (getTextUsingXpath(strSeeClientAccountNumberXpath.replace("xxx",testData.get("ClientName")),"X number in Account chevron")).startsWith(testData.get("Accountnumber"));
	
	}
	
	/**
	 * This method is used to click on Move account option in client tab
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnMoveAccountOption() {
		clickElementUsingXpath(strEditOptionXpath, "Click on Edit option");
		return clickElementUsingXpath(strMoveButtonXpath, "Move Button option is clicked");
	}
	
	/**
	 * This method is used to verify whether the user is on Select Accounts to Move page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeSelectAccountsToMovePage() {
		return (getTextUsingXpath(strSelectAccountsToMOvePageTitleXpath, "Select Accounts to Move page title").equalsIgnoreCase(MOVE_ACCOUNTS_PAGE_TITLE));
	}
	
	/**
	 * This method is used to verify whether the user is on Select Accounts to Move page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyClientsScrollBarDashboardPage() {
		return isElementPresentUsingXpath(strClientsScrollbarXpath, lplCoreConstents.HIGH, "Client scroll bar");
	}
	
	
	
}


