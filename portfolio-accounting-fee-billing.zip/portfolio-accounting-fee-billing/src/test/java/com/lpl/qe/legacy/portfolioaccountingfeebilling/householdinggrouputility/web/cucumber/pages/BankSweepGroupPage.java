package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreUtil;

public class BankSweepGroupPage extends Common implements ILocatorInitialize{
	static final int PAGE_IDENTIFIER = 872;
	String strBSSummaryPageXpath;
	String strTopBannerGroupNameXpath;
	String strTopBannerRepIDXpath;
	String strTopBannerValueXpath;
	String strTopBannerAccXpath;
	String strDisplayEditButtonDashboardXpath;
	String strDisplayEditButtonSummaryXpath;
	String strEditGroupPageTitleXpath;
	String strRelatedGroupsSectionXpath;
	String strRelatedGroupContentXpath;
	String strClickRelatedGroupLinkXpath;
	String strRelatedGroupNameXpath;
	String strBSReviewButtonXpath;
	String strBSReviewPageXpath;
	String strBSGroupNameXpath;
	String strGroupContentsTextReviewPageXpath;
	String strAccountsTileXpath;
	String strRemoveMemeberBSGroupXpath;
	String strGroupUpdateSuccessMsgXpath;
	String strConvertTwoPointZeroHeaderXpath;
    String strConvertTwoPointZeroContentXpath;
    String strConvertTwoPointZeroClickHereXpath;
    String strNewHouseholdSetupPageXpath;
    String strFirstPrimarybuttonXpath;
    String strConvertTwoPointZeroContent1Xpath;
	
	Map<String, HashMap<String, String>> pageObjectMap;
	public BankSweepGroupPage(WebDriver driver) {
		super(driver);
		lplCoreUtil = new LPLCoreUtil();
		/** Fetching page objects from FARM */
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		checkForLocatorTypeAndInitializeFields(pageObjectMap, this.getClass().getDeclaredFields(), PAGE_IDENTIFIER);
	}
	
	
	/**
	 * This method is see the Bank Sweep summary page
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean seeBankSweepSummaryPage() {
		return isElementPresentUsingXpath(strBSSummaryPageXpath.replaceAll("xxx", testData.get("groupName")), lplCoreConstents.HIGH,
				"Bank sweep group summary page");
	}
	
	/**
	 * This method is see the Bank Sweep summary page top banner
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean seeTopBannerSummaryPage() {
		return (isElementPresentUsingXpath(strTopBannerGroupNameXpath.replaceAll("xxx", testData.get("groupName")), lplCoreConstents.HIGH,"Bank sweep group summary page") && 
				isElementPresentUsingXpath(strTopBannerRepIDXpath, lplCoreConstents.HIGH,"Bank sweep group summary page") &&
				getTextUsingXpath(strTopBannerValueXpath, "Bank sweep group summary page").equals("VALUE") &&
				getTextUsingXpath(strTopBannerAccXpath, "Bank sweep group summary page").equals("ACCTS"));
				
	}
	
	/**
	 * This method is see the Bank Sweep summary section header
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean seeSummarySectionHeader() {
		String text = getTextUsingXpath(strTopBannerGroupNameXpath.replaceAll("xxx", testData.get("groupName")), "Bank sweep group summary page");
		return text.endsWith("ICA");
		
				
	}
	
	/**
     * This method is see account details in summary page
     *
     * @return boolean
     * @author sethupar
     */

     public boolean displayAccountDetailsInSummaryPage(String field) {
         return isElementPresentUsingXpath(getFormattedLocator("//*[@class='client-tiles-wrapper']//preceding-sibling::*[contains(text(),'%s')]", field), field);
}
     /**
     * This method is edit button displayed in both dashboard and summary page
     *
     * @return boolean
     * @author sethupar
     */
     public boolean displayEditbuttonInDashboardAndSummaryPage() {
         return isElementPresentUsingXpath(strDisplayEditButtonDashboardXpath,"verify Edit button displayed in Dashboard page")
         && isElementPresentUsingXpath(strDisplayEditButtonSummaryXpath,"verify Edit button displayed in Summary page");
                                      
     
     }
     /**
     * This method is clicking the edit button in summary page
     *
     * @return boolean
     * @author sethupar
     */
     public boolean clickEditButtonInSummaryPage() {
           return clickElementUsingXpath(strDisplayEditButtonSummaryXpath, "Click on edit button from summary page");
     }
     /**
     * This method is see account details in edit page
     *
     * @return boolean
     * @author sethupar
     */
     public boolean displayDetailsInEditPage(String field) {
      // This method is used to validate whether STO Team field is visible
                   return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
}
     /**
     * This method is see page title in edit page
     *
     * @return boolean
     * @author sethupar
     */
     public boolean verifyPageTitleInEditPage() {
           return isElementPresentUsingXpath(strEditGroupPageTitleXpath,"verify the page title in Edit page" );
                         

}
     
     /**
      * This method is to see the Related group section
      *
      * @return boolean
      * @author vparthas
      */
      public boolean verifyRelatedGroupsSection() {
            return isElementPresentUsingXpath(strRelatedGroupsSectionXpath,"verify the page title in Edit page" );
                          

 }
      
      /**
       * This method is to click on Household under Related group section
       *
       * @return boolean
       * @author vparthas
       */
       public boolean clickOnRelatedGroupsHousehold() {
    	   boolean result = false;
    	   int noOfRelatedGroups = getWebElementsSizeUsingXpath(strRelatedGroupContentXpath);
    	   System.out.println(noOfRelatedGroups);
    	   for(int i=1;i<=noOfRelatedGroups;i++) {
    		   String text = getTextUsingXpath(strRelatedGroupNameXpath.replace("z", Integer.toString(i)), "Bank sweep group summary page");
    		   System.out.println(text);
    		   if(text.endsWith("Household")) {
    			   System.out.println(strClickRelatedGroupLinkXpath.replace("z", Integer.toString(i)));
    			   clickElementUsingXpath(strClickRelatedGroupLinkXpath.replace("z", Integer.toString(i)), "Click on edit button from summary page");
    			   result = true;
    			  return result;
    		   }
    		   System.out.println("end FOR loop");
    	   }
            return result; 
  }
       
       /**
        * This method is to click on User Defined group under Related group section
        *
        * @return boolean
        * @author vparthas
        */
        public boolean clickOnRelatedGroupsUserDefined() {
     	   boolean result = false;
     	   int noOfRelatedGroups = getWebElementsSizeUsingXpath(strRelatedGroupContentXpath);
     	  // System.out.println(noOfRelatedGroups);
     	   for(int i=1;i<=noOfRelatedGroups;i++) {
     		   String text = getTextUsingXpath(strRelatedGroupNameXpath.replace("z", Integer.toString(i)), "Bank sweep group summary page");
     		 // System.out.println(text);
     		   if(text.endsWith("Defined")) {
     			//   System.out.println(strClickRelatedGroupLinkXpath.replace("z", Integer.toString(i)));
     			   clickElementUsingXpath(strClickRelatedGroupLinkXpath.replace("z", Integer.toString(i)), "Click on edit button from summary page");
     			   result = true;
     			  return result;
     		   }
     		   //System.out.println("end FOR loop");
     	   }
             return result; 
   }
        
        /**
         * This method is to click on BS Review button
         *
         * @return boolean
         * @author vparthas
         */
         public boolean clickOnBSReviewButton() {
               return clickElementUsingXpath(strBSReviewButtonXpath, "Click on Review button in Edit BS page");
         }
         
         /**
          * This method is to see the BS review page
          *
          * @return boolean
          * @author vparthas
          */
          public boolean seeReviewBSPage() {
                return isElementPresentUsingXpath(strBSReviewPageXpath.replace("xxx", testData.get("groupName")), "Review BS page");
          }
          
          /**
           * This method is to see the BS review page
           *
           * @return boolean
           * @author vparthas
           */
           public boolean verifyReviewBSPageContents() {
                 return getTextUsingXpath(strBSGroupNameXpath, "Bank sweep group summary page").equalsIgnoreCase(testData.get("groupName")) &&
                		 isElementPresentUsingXpath(strGroupContentsTextReviewPageXpath, "Review BS page") && 
                		 isElementPresentUsingXpath(strAccountsTileXpath, "Review BS page");
           }
           
           /**
            * This method is to see the BS review page
            *
            * @return boolean
            * @author vparthas
            */
            public boolean seeRemoveMemberButton() {
                  return isElementPresentUsingXpath(strRemoveMemeberBSGroupXpath, "Edit BS page");
            }
           
            
            /**
        	 * This method is used to click on Save Changes button in Add to Groups page
        	 *
        	 * @return boolean
        	 * @author vparthas
        	 */
        	public boolean seeGroupUpdateMessage() {
        		return clickElementUsingXpath(strGroupUpdateSuccessMsgXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
        	}
        	
        	/**
             * This method is verify the content under Convert to 2.0 section
             *
             * @return boolean
             * @author sethupar
             */

             public boolean seeConvertToTwoPointZeroSection() {
            	 wait(5);
                return isElementPresentUsingXpath(strConvertTwoPointZeroHeaderXpath, "Edit BS page") 
                		&& isElementPresentUsingXpath(strConvertTwoPointZeroContentXpath, "Edit BS page") 
                		&& isElementPresentUsingXpath(strConvertTwoPointZeroContent1Xpath, "Edit BS page");
          }
             
             /**
             * This method is click the CLICK HERE hyperlink in Convert to 2.0 section
             *
             * @return boolean
             * @author sethupar
             */
             public boolean ClickHereHyperLinkInConvertToTwoPointZeroSection() {
                    return clickElementUsingXpath(strConvertTwoPointZeroClickHereXpath, lplCoreConstents.HIGH,
                    		"Click on Click Here hyperlink in Convert to 2.0 Section");
             }
             /**
              * This method is verify It is displayed New Household setup page
              *
              * @return boolean
              * @author sethupar
              */
             public boolean verifyNewHouseholdSetupPage() {
             switchToNextWindow();
                 return isElementPresentUsingXpath(strNewHouseholdSetupPageXpath, "New Household Setup Page");
           }

/**
       * This method is used to click the first primary radio button
       *
       * @return boolean
       * @author sethupar
       */
       public boolean clickfirstPrimarybutton() {
             return clickElementUsingXpath(strFirstPrimarybuttonXpath, "Enabled next button is clicked");
       }
       

 /**
 * This method is to verify the verbiage under the convert to 2.0 section
 *
 * @return boolean
 * @author sethupar
 */    
 public boolean seeVerbiageUnderConvertTwoPointZeroSection() {
        return isElementPresentUsingXpath("//span[text()=' Select the related household and choose to convert the BS group to a BS capability of the household ']", "Verify Client selection field Placeholder Name");
 }




}
