package com.lpl.qe.portfolioaccountingfeebilling.householdingCAG.web;

import java.awt.AWTException;

import org.testng.annotations.Test;

import com.dataprovider.DataProviderClass;
import com.dataprovider.DataProviderFactory;
import com.dataprovider.REQUEST_TYPE;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.annotations.NeedsDriver;
import com.lpl.qe.blackbird.clientworks.web.utils.LoginUtility;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.portfolioaccountingfeebilling.householding.constants.HouseholdDashboardEnum;
import com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject.EditHouseholdData;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.CommonUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.HouseholdCreateUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.HouseholdDashbaordUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.HouseholdEditUtility;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.LoginLogoutUtility;

public class ValidateHouseholdDashbaordPage {
	private static final String SHEET_NAME = "EditHouseholdData";
	private static final String EXCEL_FILE = "src/test/resources/testdata/HouseholdGroupExcel.xlsx";
	@NeedsDriver
	@DataProviderFactory(requestType = REQUEST_TYPE.POJO, fileName = EXCEL_FILE, sheetName = SHEET_NAME, range = "3-3")
	@Test(dataProvider = "UniversalRowProvider", dataProviderClass = DataProviderClass.class)
	
	public void validateHouseholdDashbaord(EditHouseholdData editHHData)
			throws InterruptedException, AWTException{
		CommonUtility clientworksCommonUtility = BasePage.initialize(DriverFactory.getDriver(), CommonUtility.class);
		HouseholdCreateUtility householdCreateUtility = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreateUtility.class);
		HouseholdEditUtility householdEditUtility = BasePage.initialize(DriverFactory.getDriver(), HouseholdEditUtility.class);
		HouseholdDashbaordUtility dashboardPageUtility = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashbaordUtility.class);
		LoginLogoutUtility.loginToCW();
		LoginUtility.userLogin(editHHData.getUserName(), editHHData.getPassword());
		clientworksCommonUtility.clickOnGroupsTab();
		clientworksCommonUtility.enterHouseholdNameToSearch(editHHData.getGroupName());
		clientworksCommonUtility.clickSearchHouseholdButton();
		clientworksCommonUtility.clickOnHouseholdName(editHHData.getGroupID());
		clientworksCommonUtility.isHouseholdDashbaordPageDisplayed();
	/*	dashboardPageUtility.clickBackToGroupsLink();
		clientworksCommonUtility.isGroupsTabDisplayed();
		clientworksCommonUtility.enterHouseholdNameToSearch(editHHData.getGroupName());
		clientworksCommonUtility.clickSearchHouseholdButton();
		clientworksCommonUtility.clickOnHouseholdName(editHHData.getGroupID());
		clientworksCommonUtility.isHouseholdDashbaordPageDisplayed();
		dashboardPageUtility.isInvestmentsTabDisplayed();
		dashboardPageUtility.isOrdersTabDisplayed();
		dashboardPageUtility.isActivityTabDisplayed();
		dashboardPageUtility.isRequestsTabDisplayed();
		dashboardPageUtility.isDocumentsTabDisplayed();
		dashboardPageUtility.isSummaryTabDisplayed();
		clientworksCommonUtility.isHouseholdDashbaordPageDisplayed();
		dashboardPageUtility.isBalancesAndInvestmentSectionDisplayed();
		dashboardPageUtility.verifyHouseholdSummaryTile(); 
		dashboardPageUtility.clickShowDetailsLinkAndVerifyColumnName(HouseholdDashboardEnum.BALANDINVHIDECOLUMN1.toString(),
				HouseholdDashboardEnum.BALANDINVHIDECOLUMN2.toString(), HouseholdDashboardEnum.BALANDINVHIDECOLUMN3.toString());
		dashboardPageUtility.clickHideDetailsLinkAndVerifyColumnName();
		dashboardPageUtility.verifyJumpToDetailsLink(); */
		dashboardPageUtility.verifyScrollBarForClientsSection();
		dashboardPageUtility.enterAndValidateNoteSection(editHHData.getNoteTitle(), editHHData.getNoteText(), editHHData.getNoteType());
		dashboardPageUtility.seeNoteCreated();
		dashboardPageUtility.validateDeleteAndPopUpNoteSection();
		dashboardPageUtility.verifyNoteIsDeleted();
		dashboardPageUtility.updateFrequencyDropdown(HouseholdDashboardEnum.PREVIOUSMARKETCLOSE.toString(), 
				HouseholdDashboardEnum.INTRADAYBALANCESUPDATE.toString());
		LoginLogoutUtility.closeBrowser();
	}

}
