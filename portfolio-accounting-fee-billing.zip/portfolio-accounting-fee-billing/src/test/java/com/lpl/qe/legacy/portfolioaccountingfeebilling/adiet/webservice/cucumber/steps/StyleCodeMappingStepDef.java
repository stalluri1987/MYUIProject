package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> StyleCodeMappingStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for StyleCodeMapping</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * StyleCodeMappingStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class StyleCodeMappingStepDef extends CommonStepDef {

	@Then("^I should land on Fiserv-unmapped page$")
	public void iShouldlandonFiservunMappedPage() {
		boolean blnResult = styleCodeMapping.iShouldlandonFiservunMappedPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Fiserv-unmapped page",
				"User should be able to see Fiserv-unmapped page", "Successfully able to see Fiserv-unmapped pagen",
				"Failed to see Fiserv-unmapped page : " + Common.strError);
	}

	@Then("^I verify the availability of Fiserv-unmapped sleeve details options$")
	public void iVerifytheAvailabilityofFiservUnmappedSleeveDetailsOptions(DataTable sleeveDetailsOption) {
		boolean blnResult = styleCodeMapping
				.iVerifytheAvailabilityofFiservUnmappedSleeveDetailsOptions(sleeveDetailsOption);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of File Type drop down options",
				"User should be able to see all File Type drop down options",
				"Successfully able to see all File Type drop down options",
				"Failed to see all File Type drop down options : " + Common.strError);
	}

	@When("^I choose (.+) tab$")
	public void chooseMappedTab(String selectTab) {
		boolean blnResult = styleCodeMapping.chooseTab(selectTab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Choose " + selectTab + " tab",
				"User should be able to choose " + selectTab + " tab",
				"Successfully able to choose " + selectTab + " tab",
				"Failed to choose " + selectTab + " tab : " + Common.strError);
	}

	@When("^I select Fiserv Unmapped tab$")
	public void selectFiservUnmappedTab(String selectTab) {
		boolean blnResult = styleCodeMapping.selectFiservUnmappedTab(selectTab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Choose " + selectTab + " tab",
				"User should be able to choose " + selectTab + " tab",
				"Successfully able to choose " + selectTab + " tab",
				"Failed to choose " + selectTab + " tab : " + Common.strError);
	}

	@Then("^I verify the availability of search fields under mapped tab$")
	public void verifyAvailabilityOfSearchFieldsUnderMappedTab(DataTable searchFields) {
		boolean blnResult = styleCodeMapping.verifyAvailabilityOfSearchFieldsUnderMappedTab(searchFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search fields under mapped tab",
				"User should be able to see all search fields under mapped tab",
				"Successfully able to see all search fields under mapped tab",
				"Failed to see all search fields under mapped tab : " + Common.strError);
	}

	@Then("^I should see Search button$")
	public void searchButtonDisplayed() {
		boolean blnResult = styleCodeMapping.searchButtonDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availablity of Search button",
				"User should be able to see Search Button", "Successfully able to see Search Button",
				"Failed to see Search Button : " + Common.strError);
	}

	@Then("^I verify the availability of grid headers under mapped tab$")
	public void verifyAvailabilityOfGridHeadersUnderMappedTab(DataTable gridHeaders) {
		boolean blnResult = styleCodeMapping.iVerifytheAvailabilityofFiservUnmappedSleeveDetailsOptions(gridHeaders);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of grid headers under mapped tab",
				"User should be able to see all grid headers under mapped tab",
				"Successfully able to see all grid headers under mapped tab",
				"Failed to see all grid headers under mapped tab : " + Common.strError);
	}

	@Then("^I should see Edit Manager Style link displayed in the grid$")
	public void editManagerStylelinkDisplayedUnderGrid() {
		boolean blnResult = styleCodeMapping.editManagerStylelinkDisplayedUnderGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Edit Manager Style link",
				"User should be able to see Edit Manager Style link",
				"Successfully able to see Edit Manager Style link",
				"Failed to see Edit Manager Style link : " + Common.strError);
	}

	@Then("^I validate Vestmark-unmapped page is displayed by default$")
	public void iValidateVestmarkunMappedPageDisplayedByDefault() {
		boolean blnResult = styleCodeMapping.iShouldlandonVestmarkUnMappedPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Vestmark-unmapped page",
				"User should be able to see Vestmark-unmapped page", "Successfully able to see Vestmark-unmapped page",
				"Failed to see Vestmark-unmapped page : " + Common.strError);
	}

	@Then("^I verify the availability of Vestmark-unmapped sleeve details options$")
	public void iVerifytheAvailabilityofVestmarkUnmappedSleeveDetailsOptions(DataTable sleeveDetailsOption) {
		boolean blnResult = styleCodeMapping
				.iVerifytheAvailabilityofVestmarkUnmappedSleeveDetailsOptions(sleeveDetailsOption);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Vestmark-unmapped sleeve details options",
				"User should be able to see Vestmark-unmapped sleeve details options",
				"Successfully able to see Vestmark-unmapped sleeve details options",
				"Failed to see Vestmark-unmapped sleeve details options : " + Common.strError);
	}

	@When("^I click on the Add Manager Style link$")
	public void iClickOnAddManagerStyleLink() {
		boolean blnResult = styleCodeMapping.iClickonVestmarkAddManagerStyleLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Add Manager Style link",
				"User should able to click Add Manager Style link", "Successfully able to click Add Manager Style link",
				"Failed to click Add Manager Style link :" + Common.strError);
	}

	@When("^I click on the Add Manager Style link in Fiserv tab$")
	public void iClickOnAddManagerStyleLinkInFiservTab() {
		boolean blnResult = styleCodeMapping.iClickonFiservAddManagerStyleLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Add Manager Style link",
				"User should able to click Add Manager Style link", "Successfully able to click Add Manager Style link",
				"Failed to click Add Manager Style link :" + Common.strError);
	}

	@Then("^I verify Sleeve Mapping pop up is displayed$")
	public void iVerifySleeveMappingPopUpIsDisplayed() {
		boolean blnResult = styleCodeMapping.sleeveMappingPopupVestmarkDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Sleeve Mapping pop up is displayed", "User should able to see Sleeve Mapping pop up",
				"Successfully able to see Sleeve Mapping pop up",
				"Failed to see Sleeve Mapping pop up :" + Common.strError);
	}

	@Then("^I verify the Sleeve Tag is displayed in pop up$")
	public void iVerifytheSleeveTagIsDisplayedInPopUp() {
		boolean blnResult = styleCodeMapping.sleeveTagVestmarkSleeveMappingPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Sleeve Tag in pop up", "User should be able to see Sleeve Tag in pop up",
				"Successfully able to see Sleeve Tag in pop up",
				"Failed to see Sleeve Tag in pop up : " + Common.strError);
	}

	@Then("^I verify the Model Name is displayed in pop up$")
	public void iVerifytheModelNamegIsDisplayedInPopUp() {
		boolean blnResult = styleCodeMapping.modelNameVestmarkSleeveMappingPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Model Name in pop up", "User should be able to see Model Name in pop up",
				"Successfully able to see Model Name in pop up",
				"Failed to see Model Name in pop up : " + Common.strError);
	}

	@Then("^I verify the Program is displayed in pop up$")
	public void iVerifytheProgramIsDisplayedInPopUp() {
		boolean blnResult = styleCodeMapping.programVestmarkSleeveMappingPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Program in pop up", "User should be able to see Program in pop up",
				"Successfully able to see Program in pop up", "Failed to see Program in pop up : " + Common.strError);
	}

	@Then("^I verify the Model Style Code - RIA field is present in pop up$")
	public void iVerifytheModelStyleCodeRIAIsDisplayedInPopUp() {
		boolean blnResult = styleCodeMapping.modelStyleCodeRIAVestmarkSleeveMappingPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Model Style Code - RIA field in pop up",
				"User should be able to see Model Style Code - RIA field in pop up",
				"Successfully able to see Model Style Code - RIA field in pop up",
				"Failed to see Model Style Code - RIA field in pop up : " + Common.strError);
	}

	@Then("^I verify the Model Style Code - LPL Corp is present in pop up$")
	public void iVerifytheModelStyleCodeLPLCorpIsDisplayedInPopUp() {
		boolean blnResult = styleCodeMapping.modelStyleCodeLPLCorpVestmarkSleeveMappingPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Model Style Code - LPL Corp in pop up",
				"User should be able to see Model Style Code - LPL Corp in pop up",
				"Successfully able to see Model Style Code - LPL Corp in pop up",
				"Failed to see Model Style Code - LPL Corp in pop up : " + Common.strError);
	}

	@Then("^I verify the Sleeve details displayed in the grid$")
	public void iVerifyTheSleeveDetailsDisplayedInGrid(DataTable sleeveDetailsOption) {
		boolean blnResult = styleCodeMapping.sleeveTagMappingPopUp(sleeveDetailsOption);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Vestmark details in grid",
				"User should be able to see Vestmark details in grid",
				"Successfully able to see Vestmark details in grid",
				"Failed to see Vestmark details in grid : " + Common.strError);
	}

	@Then("^I choose the Mapped tab$")
	public void chooseMappedTab() {
		boolean blnResult = styleCodeMapping.ClickOnMappedTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Mapped tab",
				"User should able to click on Mapped tab", "Successfully able to click on Mapped tab",
				"Failed to click on Mapped tab :" + Common.strError);
	}

	@Then("^I choose the Edit Manager Style link$")
	public void chooseTheEditManagerStylelink() {
		boolean blnResult = styleCodeMapping.ClickonEditManagerStyleLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Edit Manager Style link",
				"User should able to click Edit Manager Style link",
				"Successfully able to click Edit Manager Style link",
				"Failed to click Edit Manager Style link :" + Common.strError);
	}

	@Then("^I verify the Model Style Code - RIA - ERISA is present in pop up$")
	public void verifyTheModelStyleCodeRIAERISAIsPresentInPopUp() {
		boolean blnResult = styleCodeMapping.modelStyleCodeRIAERISASleeveMappingPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Model Style Code - RIA - ERISA in pop up",
				"User should be able to see Model Style Code - RIA - ERISA in pop up",
				"Successfully able to see Model Style Code - RIA - ERISA in pop up",
				"Failed to see Model Style Code - RIA - ERISA in pop up : " + Common.strError);
	}

	@Then("^I verify the Model Style Code - LPL Corp ERISA is present in pop up$")
	public void verifyTheModelStyleCodeLPLCorpERISAIsPresentInPopUp() {
		boolean blnResult = styleCodeMapping.modelStyleCodeLPLCorpERISASleeveMappingPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of Model Style Code - LPL Corp ERISA in pop up",
				"User should be able to see Model Style Code - LPL Corp ERISA in pop up",
				"Successfully able to see Model Style Code - LPL Corp ERISA in pop up",
				"Failed to see Model Style Code - LPL Corp ERISA in pop up : " + Common.strError);
	}

	@When("^I clear Model Style Code - RIA - ERISA field$")
	public void clearModelStyleCodeRIAERISAField() {
		boolean blnResult = styleCodeMapping.clearModelStyleCodeRIAERISAField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Clear Model Style Code - RIA - ERISA field",
				"User should be able to clear Model Style Code - RIA - ERISA field",
				"Successfully able to clear Model Style Code - RIA - ERISA field",
				"Failed to clear Model Style Code - RIA - ERISA field : " + Common.strError);
	}

	@Then("^I enter ERISA RIA Style Code in the Model Style Code - RIA - ERISA field$")
	public void enterERISARIAStyleCodeInTheModelStyleCodeRIAERISAfield() {
		boolean blnResult = styleCodeMapping.enterRIAERISAStyleCode();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter RIA - ERISA Style Code",
				"User should be able to enter RIA - ERISA Style Code",
				"Successfully able to enter RIA - ERISA Style Code",
				"Failed to enter RIA - ERISA Style Code : " + Common.strError);
	}

	@Then("^I select the ERISA RIA stylecode from the drop down$")
	public void selectTheERISARIAStyleCodeFromTheDropDown() {
		boolean blnResult = styleCodeMapping.selectRIAERISAStyleCode();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select RIA - ERISA Style Code",
				"User should be able to select RIA - ERISA Style Code",
				"Successfully able to select RIA - ERISA Style Code",
				"Failed to select RIA - ERISA Style Code : " + Common.strError);
	}

	@When("^I clear Model Style Code - LPL Corp ERISA field$")
	public void clearModelStyleCodeLPLCORPERISAField() {
		boolean blnResult = styleCodeMapping.clearModelStyleCodeLPLCORPERISAField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Clear Model Style Code - LPL Corp ERISA field",
				"User should be able to clear Model Style Code - LPL Corp ERISA field",
				"Successfully able to clear Model Style Code - LPL Corp ERISA field",
				"Failed to clear Model Style Code - LPL Corp ERISA field : " + Common.strError);
	}

	@Then("^I enter ERISA LPL Corp in Model Style Code - LPL Corp ERISA field$")
	public void enterERISARIAStyleCodeInTheModelStyleCodeLPLCORPERISAfield() {
		boolean blnResult = styleCodeMapping.enterLPLCORPERISAStyleCode();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter LPL Corp ERISA Style Code",
				"User should be able to enter LPL Corp ERISA Style Code",
				"Successfully able to enter LPL Corp ERISA Style Code",
				"Failed to enter LPL Corp ERISA Style Code : " + Common.strError);
	}

	@Then("^I select the ERISA LPL Corp stylecode from the drop down$")
	public void selectTheERISALPLCorpStyleCodeFromTheDropDown() {
		boolean blnResult = styleCodeMapping.selectLPLCORPERISAStyleCode();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select LPL Corp ERISA Style Code",
				"User should be able to select LPL Corp ERISA Style Code",
				"Successfully able to select LPL Corp ERISA Style Code",
				"Failed to select LPL Corp ERISA Style Code : " + Common.strError);
	}

	@Then("^I choose Submit button$")
	public void chooseSubmitButton() {
		boolean blnResult = styleCodeMapping.clickOnSubmitButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Choose Submit button",
				"User should able to choose Submit button", "Successfully able to choose Submit button",
				"Failed to choose Submit button :" + Common.strError);
	}

	@Then("^I choose Close button$")
	public void chooseCloseButton() {
		boolean blnResult = styleCodeMapping.clickOnCloseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Choose Close button",
				"User should able to choose Close button", "Successfully able to choose Close button",
				"Failed to choose Close button :" + Common.strError);
	}

	@Then("^I verify the RIA - ERISA displayed in the grid$")
	public void verifyTheRIAERISADisplayedInTheGrid() {
		boolean blnResult = styleCodeMapping.verifyTheRIAERISADisplayedInTheGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "RIA - ERISA displayed in the grid",
				"User should able to see RIA - ERISA displayed in the grid",
				"Successfully able to see RIA - ERISA displayed in the grid",
				"Failed to see RIA - ERISA displayed in the grid :" + Common.strError);
	}

	@Then("^I verify the LPL Corp ERISA displayed in the grid$")
	public void verifyTheLPLCORPERISADisplayedInTheGrid() {
		boolean blnResult = styleCodeMapping.verifyTheLPLCORPERISADisplayedInTheGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "LPL CORP ERISA displayed in the grid",
				"User should able to see LPL CORP ERISA displayed in the grid",
				"Successfully able to see LPL CORP ERISA displayed in the grid",
				"Failed to see LPL CORP ERISA displayed in the grid :" + Common.strError);
	}

	@Then("^I enter RIA Style Code in the Model Style Code - RIA field$")
	public void enterRIAStyleCodeInTheModelStyleCodeRIAField() {
		boolean blnResult = styleCodeMapping.enterRIAStyleCode();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter RIA Style Code",
				"User should be able to enter RIA Style Code", "Successfully able to enter RIA Style Code",
				"Failed to enter RIA Style Code : " + Common.strError);
	}

	@Then("^I select the RIA stylecode from the drop down$")
	public void selectTheRIAStyleCodeFromDropDown() {
		boolean blnResult = styleCodeMapping.selectRIAStyleCode();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select LPL Corp ERISA Style Code",
				"User should be able to select LPL Corp ERISA Style Code",
				"Successfully able to select LPL Corp ERISA Style Code",
				"Failed to select LPL Corp ERISA Style Code : " + Common.strError);
	}

	@Then("^I enter LPL Corp in Model Style Code - LPL Corp field$")
	public void enterLPLCorpInModelStyleCodeLPLCorpField() {
		boolean blnResult = styleCodeMapping.enterLPLCORPStyleCode();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter LPL Corp Style Code",
				"User should be able to enter LPL Corp Style Code", "Successfully able to enter LPL Corp Style Code",
				"Failed to enter LPL Corp Style Code : " + Common.strError);
	}

	@Then("^I select the LPL Corp stylecode from the drop down$")
	public void selectTheLPLCorpStyleCodeFromTheDropDown() {
		boolean blnResult = styleCodeMapping.selectLPLCORPStyleCode();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select LPL Corp ERISA Style Code",
				"User should be able to select LPL Corp ERISA Style Code",
				"Successfully able to select LPL Corp ERISA Style Code",
				"Failed to select LPL Corp ERISA Style Code : " + Common.strError);
	}

	@Then("^I choose Cancel button$")
	public void iChooseCancelButton() {
		boolean blnResult = styleCodeMapping.clickOnCancelButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Choose Cancel button",
				"User should able to choose Cancel button", "Successfully able to choose Cancel button",
				"Failed to choose Submit button :" + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
