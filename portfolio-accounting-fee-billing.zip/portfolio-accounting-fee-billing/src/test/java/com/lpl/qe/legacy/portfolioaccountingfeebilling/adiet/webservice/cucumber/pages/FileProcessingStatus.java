package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;

/**
 * <p>
 * <br>
 * <b> Title: </b> FileProcessingStatus.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for FileProcessingStatus</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class FileProcessingStatus extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 824;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String FILE_PROCESSING_STATUS_PAGE_HEADER = "File Processing Status Page Header";
	String strFileProcessingStatusHeaderXpath;

	public FileProcessingStatus(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strFileProcessingStatusHeaderXpath, LPLCoreConstents.getInstance().HIGHEST,
				FILE_PROCESSING_STATUS_PAGE_HEADER);
	}
}
