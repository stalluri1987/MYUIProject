package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.LPLAPICommon;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.LPLRestAPIInfo;
import com.lpl.wstester.WSTest;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WebServicesCommonStepDef extends LPLCoreDriver {

	String methodName;
	String response;
	String jsonResponseString;
	public String getJsonResponseString() {
		return jsonResponseString;
	}

	public void setJsonResponseString(String jsonResponseString) {
		this.jsonResponseString = jsonResponseString;
	}

	LPLRestAPIInfo restAPIInfo;

	private String mainObj="";
	private String objToValidate ="";
	private static final String EMPTYAPIRESPONSE = "API Response is empty";
	private static final String FAILEDRESPONSE = "Failed to get the result. Error: ";
	String apiName="";
	String methodType="";
	
	
	@Before
	public void beforeTest() {
		LPLCoreDriver.StartSessionForWSTest();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE, "", "", "", "");
	}

	@After
	public void writeReport() {
		// Write the results to the html report
		LPLCoreReporter.writeSummary();
	}

	/**
	 * 
	 * @param methodType
	 * @param apiName
	 */
	@When("^user calls a (.+) request for (.+) API$")
	public void makeRestServiceCall(String methodType, String apiName) {
		//boolean isValidResponse = false;

		this.apiName = apiName;
		this.methodType = methodType;
		restAPIInfo = LPLAPICommon.readAPIDetailsFromFarm(methodType);
		response = LPLAPICommon.getRestResponse(methodType, apiName, restAPIInfo);
		String jsonResponseString = LPLAPICommon.getRestResponse(methodType, apiName, restAPIInfo);
		
		System.out.println("Response - " + jsonResponseString);
		setJsonResponseString(jsonResponseString);
		//jsonResponseString = initializeRequestHeaderAndGetResponse( methodType);
			
	}
	
	/**
	 * This method reads the data from FARM, makes a call to API and returns the API's response.
	 * @param token
	 * @param methodType
	 * @return
	 * 
	 * @author vzendge - Veena
	 * @since 25-Mar-2020
	 */
	private String initializeRequestHeaderAndGetResponse(String methodType) {
		
		// Setting headers as token is getting generated at run time and header is defined in FARM
		Map<String, String> headers = new HashMap<>();
		//headers.put(testData.get("token_Key"), token);
		
		restAPIInfo = LPLAPICommon.readAPIDetailsFromFarm(methodType);
		restAPIInfo.addHeaders(headers);
		if ("POST".equalsIgnoreCase(methodType))
			restAPIInfo.setPayloadType("json");

		return LPLAPICommon.getRestResponse(methodType, apiName, restAPIInfo);

	}

	@Then("^user should see (.+) for status line$")
	public void validateStatusLine(String expectedStatusLine) {
		LPLAPICommon.validateStatusLine(methodName, response, expectedStatusLine);
	}
	
	
		
	/**
	 * This method checks if response has the json object/ data
	 * 
	 * @author vzendge - Veena
	 * @since 31-Aug-2020
	 */
	@Then("^Validate response to check if json object is present$")
	public void validateResponseToCheckIfJSONObjectIsPresent() {
	
		String jsonObject = getJsonObject();

		
		boolean result = jsonResponseString.contains(jsonObject);
		LPLCoreReporter.writeStepToReporter(result, LPLCoreConstents.TRUE, "Validate JSON object",
				"User should get the response for " + jsonObject + " object", "Successfully got response.",
				"Failed to get response. Actual response is: " + jsonResponseString);

	}
	
	/**
	 * This step definition method validates status code with expected status code 
	 * @param expectedStatusCode
	 * @author vzendge - Veena
	 * @since 25-Mar-2020
	 */
	@Then("^user should see (.+) for status code$")
	public void validateStatusCode(int expectedStatusCode) {
		
		LPLAPICommon.validateStatusCode(apiName, Integer.valueOf(restAPIInfo.getStatusCode()), expectedStatusCode);
	}
		
	// get the name of json object which needs to be validated to print in report
		/**
		 * @return
		 */
		private String getJsonObject() {
			String jsonObject = "";
			final String DEFAULT_NULL_ALLOWED_DELIMITER = "$";
			final String KEYDELIMITER = "\\";

			if (testData.containsKey("mainObj"))
				mainObj = testData.get("mainObj").trim();

			if (testData.containsKey("objToValidate"))
				objToValidate = testData.get("objToValidate").trim();

		if (!mainObj.isEmpty() && objToValidate.isEmpty()) {
			jsonObject = mainObj;
			}
			else if (!objToValidate.isEmpty()) {
			jsonObject = objToValidate;
			
			}

			if (jsonObject.contains(KEYDELIMITER)) {
				String[] tokens = jsonObject.split(Pattern.quote(KEYDELIMITER));
				jsonObject = tokens[tokens.length - 1];
			}

			if (jsonObject.contains(DEFAULT_NULL_ALLOWED_DELIMITER)) {
				String[] tokens = jsonObject.split(Pattern.quote(DEFAULT_NULL_ALLOWED_DELIMITER));
				jsonObject = tokens[0];
			}

			return jsonObject;
		}

	
	/**
	 * This method checks if json object has list if expected properties. expected
	 * list of properties needs to be defined in FARM as a test data. All properties
	 * needs to be added as one string and separated with comma (,)
	 * 
	 * @author vzendge - Veena
	 * @since 23-Feb-2021
	 */
	@Then("^Validate json object to check if it has properties with not null values$")
	public void validateJSONObjectToCheckIfItHasProperties() {
		String errorDescription = "";
		boolean isValidProperties = false;

		try {
			WSTest wstest = new WSTest();

			if (!jsonResponseString.isEmpty()) {
				isValidProperties = wstest.validateProperties(jsonResponseString,
						mainObj, objToValidate, testData.get("listOfProperties").trim());
				if (!isValidProperties)
					errorDescription = wstest.getErrorDescription();

			} else
				errorDescription = EMPTYAPIRESPONSE;
				
		} catch (Exception e) {
			errorDescription = e.toString();
		} finally {
			LPLCoreReporter.writeStepToReporter(isValidProperties, LPLCoreConstents.TRUE,
					"Validate " + getJsonObject() + " object's properties for null/ empty values",
					"User should get list of properties", "Successfully got the expected properties.",
					FAILEDRESPONSE + errorDescription);

		}
	}
	
	/**
	 * This method checks if json object has correct value for property expected
	 * values are getting read from FARM (test data)
	 * 
	 * @author vzendge - Veena
	 * @since 31-Aug-2020
	 */
	@Then("^Validate json object to check if it has correct value for \"([^\"]*)\" field$")
	public void validateJSONObjectToCheckIfItHasValuesAsPerDefinedValues(String propertyName) {
		String errorDescription = "";
		boolean isValid = false;
		try {

			WSTest wstest = new WSTest();

			if (!jsonResponseString.isEmpty()) {
				isValid = wstest.validatePropertyValues(restAPIInfo.getResponseData(),
						mainObj, objToValidate, testData.get("listOfProperties").trim(),
						testData.get("listOfDatatypes").trim(), testData.get("propertyValue").trim());

				if (!isValid)
					errorDescription = wstest.getErrorDescription();

			} else
				errorDescription = EMPTYAPIRESPONSE;
			
		} catch (Exception e) {
			errorDescription = e.toString();
		} finally {
			
			LPLCoreReporter.writeStepToReporter(isValid, LPLCoreConstents.TRUE,
					"Validate values for properties",
					"Response should have correct value for " + propertyName , "Response has correct value",
					FAILEDRESPONSE + errorDescription);
					
		}
	}
}
