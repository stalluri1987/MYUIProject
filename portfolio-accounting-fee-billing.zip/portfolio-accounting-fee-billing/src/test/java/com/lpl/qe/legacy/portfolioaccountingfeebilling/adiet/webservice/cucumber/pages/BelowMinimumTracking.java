package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> BelowMinimumTracking.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for BelowMinimumTracking</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * BelowMinimumTracking : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author Abdul Hadi
 * @since 06/11/2020
 *        </p>
 */

public class BelowMinimumTracking extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 903;
	public static final String BELOW_MINIMUM_TRACKING_PAGE_HEADER = "Below Minimum Tracking Page Header";
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String SUCESSFULLY_ABLE_TO_SEE = "Successfully be able to see ";
	public static final String EMPTY_STRING = "";
	public static final String ACCOUNT_TOTAL_COUNT = "Accounts Total count";
	public static final String OPTIONS = "options";
	public static final String ALL = "All";
	public static final String LPL = "LPL";
	public static final String SOURCE_DROPDOWN = "Source DropDown";
	public static final String TRACKING_STATUS_DROPDOWN = "Tracking status dropdown";
	public static final String AXA = "AXA";
	String strBelowMinimumTrackingHeaderXpath;
	String strCorrBDXpath;
	String strTrackingstatusXpath;
	String strCorrBDDropdownXpath;
	String strTrackingStatusDropdownXpath;
	String strAccountsTotalCountXpath;
	String strTotalRecordsFoundXpath;
	String strGridFieldsXpath;
	String strNoRecoundFoundXpath;
	Map<String, HashMap<String, String>> pageObjectMap;

	public BelowMinimumTracking(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/11/2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strBelowMinimumTrackingHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				BELOW_MINIMUM_TRACKING_PAGE_HEADER);
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param options
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 06/08/2020
	 */

	public boolean checkIfOptionsAvailableInCorrBDDropdown(String options) {
		return isElementPresentUsingXpath(getFormattedLocator(strCorrBDXpath, options),
				LPLCoreConstents.getInstance().HIGH, options);
	}

	/**
	 * This method is used to verify the options available in the dropdown CorrBD
	 * 
	 * @param searchFieldsOptions
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 06/30/2020
	 */

	public boolean verifyOptionsAvailableInCorrBDDropdown(DataTable searchFieldsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFieldsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfOptionsAvailableInCorrBDDropdown(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to select option All from the dropdown CorrBD
	 * 
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 07/10/2020
	 */

	public boolean selectAllOptionInCorrBDDropdownFields() {
		return selectValueFromDropdownUsingXpath(strCorrBDDropdownXpath, ALL, SOURCE_DROPDOWN);
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param options
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 06/30/2020
	 */

	public boolean checkIfOptionsAvailableInTrackingStatusDropdown(String options) {
		return isElementPresentUsingXpath(getFormattedLocator(strTrackingstatusXpath, options),
				LPLCoreConstents.getInstance().HIGH, options);
	}

	/**
	 * This method is used to verify the options available in the dropdown
	 * TrackingStatus
	 * 
	 * @param searchFieldsOptions
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 07/09/2020
	 */
	public boolean verifyOptionsAvailableInTrackingStatusDropdown(DataTable searchFieldsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFieldsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfOptionsAvailableInTrackingStatusDropdown(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to select option All from the dropdown TrackingStatus
	 * 
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 07/10/2020
	 */
	public boolean selectAllOptionInTrackingStatusDropdown(String dropDownOptionToSelect) {
		return selectValueFromDropdownUsingXpath(strTrackingStatusDropdownXpath, dropDownOptionToSelect,
				TRACKING_STATUS_DROPDOWN);
	}

	/**
	 * This method is used to verify count of accounts displayed
	 * 
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 07/10/2020
	 */
	public boolean verifyCountOfAccountsDisplayed() {
		return verifyCountOfAccountsDisplayed(strAccountsTotalCountXpath, strTotalRecordsFoundXpath,
				strNoRecoundFoundXpath);
	}

	/**
	 * This method is used to display the fields of the grid
	 * 
	 * @param fieldsInGrid
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 07/10/2020
	 */
	public boolean verifyAvailabilityOfAllFieldsInGrid(DataTable fieldsInGrid) {
		boolean blnResult = false;
		List<Map<String, String>> filters = fieldsInGrid.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfAllFieldsDisplayedInGrid(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check If Element Exist Using TableHeaderText
	 * 
	 * @param fieldsInGrid
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 07/14/2020
	 */
	public boolean checkIfAllFieldsDisplayedInGrid(String fieldsInGrid) {
		return isElementPresentUsingXpath(getFormattedLocator(strGridFieldsXpath, fieldsInGrid),
				LPLCoreConstents.getInstance().LOW, fieldsInGrid);
	}

	/**
	 * This method is used to select option AXA from the dropdown CorrBD
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 01/25/2020
	 */
	public boolean selectAXAOptionInCorrBDDropdownFields() {
		return selectValueFromDropdownUsingXpath(strCorrBDDropdownXpath, AXA, SOURCE_DROPDOWN);
	}

	/**
	 * This method is used to select option LPL from the dropdown CorrBD
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 02/17/2021
	 */
	public boolean selectLPLoptionInCorrBDdropdownfields() {
		return selectValueFromDropdownUsingXpath(strCorrBDDropdownXpath, LPL, SOURCE_DROPDOWN);
	}
}
