package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> AccountListToolStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for AccountListTool</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListToolStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class AccountListToolStepDef extends CommonStepDef {

	@When("^I click on Add List button$")
	public void iClickOnAddListButton() {
		boolean blnResult = accountListTool.clickOnAddListButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Add List button",
				"User should be able to click Add List button", "Successfully able to click Add List button",
				"Failed to click Add List button :" + Common.strError);
	}

	@When("^I enter list name in the text box$")
	public void iEnterListNameInTheTextBox() {
		boolean blnResult = accountListTool.enterListNameInTheTextBox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter list name in the text box",
				"User should be able to enter List name", "Successfully able to enter List name",
				"Failed to enter List name :" + Common.strError);
	}

	@Then("^I verify the screen to Modify list$")
	public void iVerifyTheScreenToModifyList() {
		boolean blnResult = accountListTool.verifyScreenToModifyList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the screen to Modify List",
				"User should be able to see the screen for Modify List",
				"Successfully able to see the screen for Modify List",
				"Failed to see the screen for Modify List :" + Common.strError);
	}

	@When("^I enter first Account number$")
	public void iEnterFirstAccountNumber() {
		boolean blnResult = accountListTool.enterFirstAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter first account number",
				"User should be able to enter first account number", "Successfully able to enter first account number",
				"Failed to enter first account number :" + Common.strError);
	}

	@When("^I click on Add Account$")
	public void iClickOnAddAccount() {
		boolean blnResult = accountListTool.clickOnAddAccountButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Add Account button",
				"User should be able to Click on Add Account button",
				"Successfully able to Click on Add Account button",
				"Failed to Click on Add Account button :" + Common.strError);
	}

	@Then("^I verify the first account is added to list$")
	public void iVerifyTheFirstAccountIsAddedToList() {
		boolean blnResult = accountListTool.verifyFirstAccountAddedToList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify first account is added to list",
				"First account should be added to list", "First account was added to list",
				"First account was not added to list :" + Common.strError);
	}

	@When("^I enter second Account number$")
	public void iEnterSecondAccountNumber() {
		boolean blnResult = accountListTool.enterSecondAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter second account number",
				"User should be able to enter second account number",
				"Successfully able to enter second account number",
				"Failed to enter second account number :" + Common.strError);
	}

	@Then("^I verify the second account is added to list$")
	public void iVerifyTheSecondAccountIsAddedToList() {
		boolean blnResult = accountListTool.verifySecondAccountAddedToList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify second account is added to list",
				"Second account should be added to list", "Second account was added to list",
				"Second account was not added to list :" + Common.strError);
	}

	@When("^I select first account in list$")
	public void iSelectFirstAccountInList() {
		boolean blnResult = accountListTool.selectFirstAccountInList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select first account in the list",
				"First account should be selected in the list", "First account was selected in the list",
				"First account was not selected in the list :" + Common.strError);
	}

	@When("^I click on Delete Account$")
	public void iClickOnDeleteAccount() {
		boolean blnResult = accountListTool.clickOnDeleteAccount();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete Account button",
				"User should be able to click on Delete Account button",
				"Successfully able to click on Delete Account button",
				"Failed to click on Delete Account button :" + Common.strError);
	}

	@When("^I click on OK$")
	public void iClickOnOK() {
		boolean blnResult = accountListTool.clickOnOk();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on OK button",
				"User should be able to click on OK button", "Successfully able to click on OK button",
				"Failed to click on OK button :" + Common.strError);
	}

	@Then("^I verify that the first account is deleted from list$")
	public void iVerifyThatTheFirstAccountIsDeletedFromList() {
		boolean blnResult = accountListTool.verifyFirstAccountDeletedFromList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify first account is deleted from list", "First account should be deleted from list",
				"First account deleted from list", "First account not deleted from list :" + Common.strError);
	}

	@When("^I click on Main Menu$")
	public void iClickOnMainMenu() {
		boolean blnResult = accountListTool.clickOnMainMenu();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Main Menu button",
				"User should be able to click on Main Menu button", "Successfully able to click on Main Menu button",
				"Failed to click on Main Menu button :" + Common.strError);
	}

	@When("^I scroll & select my list$")
	public void iScrollAndSelectMyList() {
		boolean blnResult = accountListTool.scrollAndSelectList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Scroll & Select List",
				"User should be able to scroll & select List", "Successfully able to scroll & select List",
				"Failed to scroll & select List :" + Common.strError);
	}

	@When("^I click on Delete List$")
	public void iClickOnDeleteList() {
		boolean blnResult = accountListTool.clickOnDeleteList();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete List button",
				"User should be able to click on Delete List button",
				"Successfully able to click on Delete List button",
				"Failed to click on Delete List button :" + Common.strError);
	}

	@Then("^I verify that my list is deleted from overall list$")
	public void iVerifyThatMyListIsDeletedFromOverallList() {
		boolean blnResult = accountListTool.verifyListDeleted();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify list is deleted from overall list", "List should be deleted from overall list",
				"List deleted from overall list", "List not deleted from overall list :" + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
