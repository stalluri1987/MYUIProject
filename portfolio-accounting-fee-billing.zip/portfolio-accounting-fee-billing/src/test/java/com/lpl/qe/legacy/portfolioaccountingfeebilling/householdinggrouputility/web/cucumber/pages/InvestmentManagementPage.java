package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreUtil;

public class InvestmentManagementPage extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 872;
	Map<String, HashMap<String, String>> pageObjectMap;
	String strInvestmentManagementHyperlinkXpath;
    String strInvestmentObjectiveOptionXpath;
    String strEditInvestmentObjectiveButtonXpath;
    String strEditInvestmentManagementPageXpath;
    String strFiveInvestmentObjectivesXpath;
    String strBlueAttestXpath;
    String strReviewInvestmentManagementPageXpath;
    //String strDeleteCapabilityButtonXpath;
    String strDeleteInvestmentManagementModalXpath;
    String strCreateInvestmentObjectiveButtonXpath;
    String strInvestmentManagementDetailInformationXpath;
    String strCurrentHouseholdIOXpath;
    String strPortfolioAllocationXpath;
    String strReviewButtonOverlayModalXpath;
    String strDeleteBillingAndInvestmentModalXpath;
    String strBackButtonOverlayModalXpath;
    String strDeletingInvestmentManagementModalXpath;
    String strDeleteInvestmentManagementButtonXpath;
    String strDeletingBillingAndInvestmentVerbiageXpath;
    String strDeleteTwoCapabilitiesButtonXpath;
    String strInvestmentManagementDropdownXpath;
    String strInvestmentManagementXpath;
    String strDeleteInvestmentManagementGreenBannerXpath;
    String strDeleteInvestmentManagementMessageXpath;
    String strSeePortfolioAllocationSectionHiddenXpath;
    String strHideDeleteIMGOverlyPageXpath;
    String strSeePortfolioAllocationSectionXpath;
    String strShowDeleteIMGOverlyPageXpath;
    String strManageInvestmentTextTitleXpath;
    String strManageInvestmentTextXpath;
    String strEligibleAccountHeaderXpath;
    String strEligibleAccountTextXpath;
    String strIMGAddressText1Xpath;
    String strIMGAddressText2Xpath;
    String strTargetAllocationHeaderXpath;
    String StrEquitiesXpath;
    String StrTargetCrossoverRangeXpath;
    String StrBondsXpath;
    String strPortfolioAllocationHeaderXpath;
    String strEquitiesPortfolioXpath;
    String strBondsPortfolioXpath;
    String strInvestmentManagementTileXpath;
    String strInvestmentManagementNameXpath;
	String strInvestmentMamagementEditIconXpath;
	String strIvestmentManagementActiveLabelXpath;
	String strDeselectAccountFromIMGXpath;
	String strRemoveAccMsgIMGXpath;
	String strRemoveAccOverlayPageXpath;
	String strRemoveAccIMGOverlayPageText1Xpath;
	String strRemoveAccIMGOverlayPageText2Xpath;
	String strRemoveAccIMGOverlayPageText3Xpath;
	String strRemovingAccOverlayPageXpath;
	String strFinalReviewButtonXpath;
	String strExcludedAcctsContentsXpath;
	String strProceedIMGOverlayXpath;
	String strExcludedContentTileXpath;
	String strAddAccMsg1IMGXpath;
	String strAddAccMsg2IMGXpath;
	String strIMGFormTileXpath;
	String strIMGFormXpath;
	String strActivationFormTextIMGXpath;
	String strIMfaqHyperLinkXpath;
	String strIMfaqPDFlinkXpath;
	String strFAQsLinkTextXpath;

public InvestmentManagementPage(WebDriver driver) {
	super(driver);
	lplCoreUtil = new LPLCoreUtil();
	/** Fetching page objects from FARM */
	pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
	checkForLocatorTypeAndInitializeFields(pageObjectMap, this.getClass().getDeclaredFields(), PAGE_IDENTIFIER);
}

public static final String NUMBER_OF_OBJECTIVES ="5";
public static final String IMG_TEXT_TITLE = "To manage the eligible investments as a household, please select a household investment objective below.";
public static final String IMG_TEXT = "Please note: The selected eligible household accounts will be managed collectively towards the chosen household investment objective. This may result in concentration of certain asset classes in one or more accounts, such as income producing assets in tax-deferred accounts. The level of risk as well as resulting performance of each account in the group may vary significantly from one another when viewed at the account level.";
public static final String  IMG_ELIGIBLE_ACCOUNT_HEADER = "ELIGIBLE ACCOUNTS SELECTED FOR HOUSEHOLD INVESTMENT MANAGEMENT";
public static final String IMG_ELIGIBLE_ACCOUNT_TEXT = "You may uncheck any accounts that you wish to continue managing to their own investment objective - doing so will exclude them from the Household Investment Management.";
public static final String IMG_ADDRESS_TEXT1 = "Ensure account addresses are the same.";
public static final String IMG_ADDRESS_TEXT2 = 	"Only accounts with the same addresses are eligible to be managed together";
public static final String   IMG_TARGET_ALLOCATION_HEADER = "TARGET ALLOCATION for Income with Capital Preservation";
public static final String IMG_EQUITIES = "EQUITIES";
public static final String IMG_TARGET_CROSSOVER_RANGE = "TARGET CROSSOVER RANGE";
public static final String IMG_BONDS = "BONDS/FIXED INCOME/CASH";
public static final String IMG_PORTFOLIO_ALLOCATION_HEADER = "PORTFOLIO ALLOCATION of eligible household accounts";
public static final String IMG_REMOVE_ACC_STATIC_MSG = "Removing account will exclude it from the Household Investment Management objective";
public static final String IMG_REMOVE_ACC_OVERLAYPAGE_TEXT1 = "If you remove these accounts from Household Investment Management, then:";
public static final String IMG_REMOVE_ACC_OVERLAYPAGE_TEXT2 = "Because these accounts will no longer be managed collectively to a household investment objective, each account will now need its own investment objective.";
public static final String IMG_REMOVE_ACC_OVERLAYPAGE_TEXT3 = "The investment Objective has been defaulted to the corresponding Target Allocation for each account, but you may change this selection to whichever IO you deem most appropriate for each accounts. Select SHOW to view an account’s current allocation details.";
public static final String IMG_ADD_ACC_STATIC_MSG1 = "Changing account level IO mapping to household level";
public static final String IMG_ADD_ACC_STATIC_MSG2 = "Please refer to FAQs to understand how the IO will get affected.";

/**
     * This method is used to click on Investment Management hyperlink
     * 
      *
     * @return boolean
     * @author awaeza
     */
     public boolean clickInvestmentManagementHyperlink() {
            return clickElementUsingXpath(strInvestmentManagementHyperlinkXpath,
                         "Investment Management hyperlink is clicked");
     }

/**
     * This method is used to click on one of the investment objective
     * 
      *
     * @return boolean
     * @author awaeza
    */
     public boolean clickInvestmentObjectiveOption() {
            return clickElementUsingXpath(strInvestmentObjectiveOptionXpath.replace("xxx", testData.get("investmentObjective")),
                         "Investment Objective Option is clicked");
     }


     /**
     * This method is used to click on Edit investment objective button
     * 
      *
     * @return boolean
     * @author awaeza
     */
     public boolean clickEditInvestmentObjectiveButton() {
            return clickElementUsingXpath(strEditInvestmentObjectiveButtonXpath,
                         "Edit Investment Objective Button is collapsed");
     }

/**
     * This method is used to validate Edit Investment management Page
     *
     * @return boolean
     * @author awaeza
     */
     public boolean seeEditInvestmentManagementPage() {
            return isElementPresentUsingXpath(strEditInvestmentManagementPageXpath, lplCoreConstents.HIGH,
                         "Edit Investment management Page is displayed");

     }
     
     /**
     * This method is used to validate five investment objectives
     *
     * @return boolean
     * @author awaeza
     */
     public boolean seeFiveInvestmentObjectives() {
     return Integer.toString(getWebElementsSizeUsingXpath(strFiveInvestmentObjectivesXpath)).equalsIgnoreCase(NUMBER_OF_OBJECTIVES);
     
     }
       
       /**
       * This method is used to click on Blue attest button
       *
       * @return boolean
       * @author awaeza
       */

       public boolean clickOnBlueAttestButton() {
              return clickElementUsingXpath(strBlueAttestXpath, lplCoreConstents.HIGHEST,
                           strBlueAttestXpath);
       }
       
       /**
       * This method is used to check if Review Investment Management page is displayed
       *
       * @return boolean
       * @author awaeza
       */
       public boolean reviewInvestmentManagementPageDisplayed() {
              return isElementPresentUsingXpath(strReviewInvestmentManagementPageXpath, lplCoreConstents.HIGH,
                           strReviewInvestmentManagementPageXpath);

       }
//       /**
//        * This method is used to click on Delete Capability Button
//        *
//        * @return boolean
//        * @author awaeza
//        */
//
//        public boolean clickOnDeleteCapabilityButton() {
//               return clickElementUsingXpath(strDeleteCapabilityButtonXpath, lplCoreConstents.HIGHEST,
//                            strDeleteCapabilityButtonXpath);
//        }
        /**
         * This method is used to validate Delete Household Investment Management Overlay modal
         *
         * @return boolean
         * @author awaeza
         */
         public boolean seeDeleteInvestmentMangementModal() {
              return isElementPresentUsingXpath(strDeleteInvestmentManagementModalXpath, lplCoreConstents.HIGH,
                            strDeleteInvestmentManagementModalXpath);    
        
         
         } 
         
         /**
          * This method is used to click on Create Investment Objective button
          * 
           *
          * @return boolean
          * @author awaeza
          */
          public boolean clickCreateInvestmentObjectiveButton() {
                 return clickElementUsingXpath(strCreateInvestmentObjectiveButtonXpath,
                              "Create Investment Objective button is clicked");
          }
          
          
          /**
           * This method is used to validate Household Investment Management detail information
           *
           * @return boolean
           * @author awaeza
           */
           public boolean seeInvestmentManagementDetailInformation() {
                return isElementPresentUsingXpath(strInvestmentManagementDetailInformationXpath, lplCoreConstents.HIGH,
                           strInvestmentManagementDetailInformationXpath);    
          
           
           }
           
           /**
            * This method is used to validate Current Household IO
            *
            * @return boolean
            * @author awaeza
            */
            public boolean seeCurrentHouseholdIO() {
                 return isElementPresentUsingXpath(strCurrentHouseholdIOXpath, lplCoreConstents.HIGH,
                            strCurrentHouseholdIOXpath);    
           
            
            }
            /**
             * This method is used to validate Portfolio Allocation
             *
             * @return boolean
             * @author awaeza
             */
             public boolean seePortfolioAllocation() {
                  return isElementPresentUsingXpath(strPortfolioAllocationXpath, lplCoreConstents.HIGH,
                             strPortfolioAllocationXpath);    
            
             
             }        
             /**
              * This method is used to click on review button in the Delete Investment and 
              * Billing Modal
              * 
               *
              * @return boolean
              * @author awaeza
              */
              public boolean clickReviewButtonOverlayModal() {
                     return clickElementUsingXpath(strReviewButtonOverlayModalXpath,
                                  strReviewButtonOverlayModalXpath);
              }
              /**
               * This method is used to validate Delete Household Billing and Investment Modal
               *
               * @return boolean
               * @author awaeza
               */
               public boolean seeDeleteBillingAndInvestmentModal() {
                    return isElementPresentUsingXpath(strDeleteBillingAndInvestmentModalXpath, lplCoreConstents.HIGH,
                                 strDeleteBillingAndInvestmentModalXpath);    
               
               } 
               
               
               /**
                * This method is used to click on back button in the Delete Investment and 
                * Billing Modals
                * 
                 *
                * @return boolean
                * @author awaeza
                */
                public boolean clickBackButtonOverlayModal() {
                       return clickElementUsingXpath(strBackButtonOverlayModalXpath,
                                    strBackButtonOverlayModalXpath);
                }
                
                
                /**
                 * This method is used to validate Deleting Investment Management overlay modal
                 *
                 * @return boolean
                 * @author awaeza
                 */
                 public boolean seeDeletingInvestmentManagementModal() {
                      return isElementPresentUsingXpath(strDeletingInvestmentManagementModalXpath, lplCoreConstents.HIGH,
                    		  strDeletingInvestmentManagementModalXpath);    
                 
                 }
                 
                 /**
                  * This method is used to click on Delete Investment Management capability button
                  * 
                  * @return boolean
                  * @author awaeza
                  */
                  public boolean clickDeleteInvestmentManagementButton() {
                         return clickElementUsingXpath(strDeleteInvestmentManagementButtonXpath,
                        		 strDeleteInvestmentManagementButtonXpath);
                  } 
                  
         
                  /**
                   * This method is used to validate static verbiages in Delete Billing and Investment Page
                   *
                   * @return boolean
                   * @author awaeza
                   */
                   public boolean seeStaticVerbiagesDeleteBillingAndInvestmentModal() {
                       return (getWebElementsSizeUsingXpath(strDeletingBillingAndInvestmentVerbiageXpath))>0; 
                                     
                   }
                   /**
                    * This method is used to click on Delete Investment Management and Billing Capabilities button
                    * 
                    * @return boolean
                    * @author awaeza
                    */
                    public boolean clickDeleteTwoCapabilitiesButton() {
                           return clickElementUsingXpath(strDeleteTwoCapabilitiesButtonXpath,
                                    strDeleteTwoCapabilitiesButtonXpath);
                    }  
                    
                    /**
                     * This method is used to click on Investment Management Dropdown button
                     * 
                     * @return boolean
                     * @author awaeza
                     */
                     public boolean clickInvestmentManagementDropdownButton() {
                            return clickElementUsingXpath(strInvestmentManagementDropdownXpath,
                                        strInvestmentManagementDropdownXpath);
                     } 
                     
                     /**
                      * This method is used to click on Investment Management option from Dropdown 
                      * 
                      * @return boolean
                      * @author awaeza
                      */
                      public boolean clickInvestmentManagementFromDropdown() {
                             return clickElementUsingXpath(strInvestmentManagementXpath.replace("xxx",testData.get("investmentObjective")),
                                         strInvestmentManagementXpath);
                             
                                                
//                          return clickElementUsingXpath("//span[contains(text(),'')].replace('',testData.get(InvestmentManagementObjective))",
//                               "");
                      } 
                      
                      
                      /**
                       * This method is used to validate Delete Investment Management green banner with message
                       * 
                       * @return boolean
                       * @author awaeza
                       */
                                     
                       public boolean seeDeleteInvestmentManagementGreenBanner() {
                            return isElementPresentUsingXpath(strDeleteInvestmentManagementGreenBannerXpath, lplCoreConstents.HIGH,
                                        strDeleteInvestmentManagementGreenBannerXpath) && isElementPresentUsingXpath(strDeleteInvestmentManagementMessageXpath, lplCoreConstents.HIGH,
                                                      strDeleteInvestmentManagementMessageXpath) ;    
                       
                       }
                       /**
                        * This method is used to click on SHOW link in delete IMG overlay page
                        * 
                         *
                        * @return boolean
                        * @author vparthas
                        */
                        public boolean clickShowOnDeleteIMGOverlayPage() {
                               return clickElementUsingXpath(strShowDeleteIMGOverlyPageXpath,
                                            "SHOW link is clicked");
                        }
                        
                        /**
                         * This method is used to enusure portfolio section is displayed when user clicks on SHOW link in delete IMG overlay page
                         * 
                          *
                         * @return boolean
                         * @author vparthas
                         */
                         public boolean seePortfolioAllocationSection() {
                                return isElementPresentUsingXpath(strSeePortfolioAllocationSectionXpath,
                                             "See Portflio Allocation section");
                         }
                         
                         /**
                          * This method is used to HIDE link in delete IMG overlay page
                          * 
                           *
                          * @return boolean
                          * @author vparthas
                          */
                          public boolean clickHideOnDeleteIMGOverlayPage() {
                                 return clickElementUsingXpath(strHideDeleteIMGOverlyPageXpath,
                                              "See Portflio Allocation section");
                          }
                          
                          /**
                           * This method is used to ensure portfolio section is hidden when user clicks on HIDE link in delete IMG overlay page
                           * 
                            *
                           * @return boolean
                           * @author vparthas
                           */
                           public boolean hiddenPortfolioAllocationSection() {
                                  return isElementPresentUsingXpath(strSeePortfolioAllocationSectionHiddenXpath,
                                               "See Portflio Allocation section");
                           }
                           
                           /**
                            * This method is used to verify the text below IMG title
                            * 
                             *
                            * @return boolean
                            * @author vparthas
                            */
                            public boolean verifyTextBelowIMGTitle() {
                            	System.out.println(getTextUsingXpath(strManageInvestmentTextTitleXpath,
                        				"IMG title text"));
                            	System.out.println(getTextUsingXpath(strManageInvestmentTextXpath,
                                				"IMG text"));
                            	return getTextUsingXpath(strManageInvestmentTextTitleXpath,
                        				"IMG title text").equals(IMG_TEXT_TITLE)&&getTextUsingXpath(strManageInvestmentTextXpath,
                                				"IMG text").equals(IMG_TEXT);
                                  
                            }
                            
                            /**
                             * This method is used to check target allocation section
                             * 
                              *
                             * @return boolean
                             * @author vparthas
                            */
                             public boolean verifyTargetAllocationSection() {
                            	 wait(3);
                            	 System.out.println(getTextUsingXpath(strTargetAllocationHeaderXpath,
                            				"Eligible account text"));
                            	 System.out.println(getTextUsingXpath(StrEquitiesXpath,
                                    				"IMG text"));
                            	 System.out.println(getTextUsingXpath(StrTargetCrossoverRangeXpath,
                                            				"IMG text"));
                            	 System.out.println(getTextUsingXpath(StrBondsXpath,
                                                    				"IMG text"));
                            	 return getTextUsingXpath(strTargetAllocationHeaderXpath,
                            				"Eligible account text").equals(IMG_TARGET_ALLOCATION_HEADER)&&getTextUsingXpath(StrEquitiesXpath,
                                    				"IMG text").equals(IMG_EQUITIES)&&getTextUsingXpath(StrTargetCrossoverRangeXpath,
                                            				"IMG text").equals(IMG_TARGET_CROSSOVER_RANGE)&&getTextUsingXpath(StrBondsXpath,
                                                    				"IMG text").equals(IMG_BONDS);
                             }
                           
                             /**
                              * This method is used to check portfolio allocation section
                              * 
                               *
                              * @return boolean
                              * @author vparthas
                             */
                              public boolean verifyPortfolioAllocationSection() {
                            	  System.out.println(getTextUsingXpath(strPortfolioAllocationHeaderXpath,
                          				"Eligible account text"));
                            	  System.out.println(getTextUsingXpath(strEquitiesPortfolioXpath,
                                  				"IMG text"));
                            	  System.out.println(getTextUsingXpath(strBondsPortfolioXpath,
                                                  				"IMG text"));
                            	  return getTextUsingXpath(strPortfolioAllocationHeaderXpath,
                          				"Eligible account text").contains(IMG_PORTFOLIO_ALLOCATION_HEADER)&&getTextUsingXpath(StrEquitiesXpath,
                                  				"IMG text").equals(IMG_EQUITIES)&&getTextUsingXpath(StrBondsXpath,
                                                  				"IMG text").equals(IMG_BONDS);
                              }
                              
                              /**
                               * This method is used to check Eligible account header and text section
                               * 
                                *
                               * @return boolean
                               * @author vparthas
                              */
                               public boolean verifyEligibleAccountHeadingAndText() {
                            	   System.out.println(getTextUsingXpath(strEligibleAccountHeaderXpath,
                           				"Eligible account text"));
                            	   System.out.println(getTextUsingXpath(strEligibleAccountTextXpath,
                                   				"IMG text"));
                            	   return getTextUsingXpath(strEligibleAccountHeaderXpath,
                           				"Eligible account text").contains(IMG_ELIGIBLE_ACCOUNT_HEADER)&&getTextUsingXpath(strEligibleAccountTextXpath,
                                   				"IMG text").equals(IMG_ELIGIBLE_ACCOUNT_TEXT);
                               }
                               
                               /**
                                * This method is used to check target allocation section
                                * 
                                 *
                                * @return boolean
                                * @author vparthas
                               */
                                public boolean verifyIMGAddressText() {
                                	System.out.println(getTextUsingXpath(strIMGAddressText1Xpath,
                            				"IMG Address text"));
                                	System.out.println(getTextUsingXpath(strIMGAddressText2Xpath,
                            				"IMG Address text"));
                             	   return getTextUsingXpath(strIMGAddressText1Xpath,
                            				"IMG Address text").equals(IMG_ADDRESS_TEXT1)&&getTextUsingXpath(strIMGAddressText2Xpath,
                                    				"IMG Address text").equals(IMG_ADDRESS_TEXT2);
                                }
                                
                                /**
                            	 * This method is used to check investment management tile displayed in
                            	 * dashboard page after adding investment Management capability
                            	 *
                            	 * @return boolean
                            	 * @author awaeza
                            	 */
                            	public boolean investmentmanagementtileDisplayed() {
                            		//String strInvestmentManagementTileXpath = "//*[text()=' INVESTMENT MANAGEMENT ']//..";
                            		return isElementPresentUsingXpath(strInvestmentManagementTileXpath, lplCoreConstents.HIGH,
                            				"investment mamagement tile is displayed in dashboard");

                            	}

                            	/**
                            	 * This method is used to check investment management name with edit icon in
                            	 * investment management tile displayed in dashboard page
                            	 * 
                            	 * @return boolean
                            	 * @author awaeza
                            	 */
                            	public boolean investmentmanagementnamewithediticonDisplayed() {
                            		//String strInvestmentManagementNameXpath = "//div[contains(@title,'Investment Management')]";
                            		//String strInvestmentMamagementEditIconXpath = "//a[contains(@title,'Edit Investment Management capability')]";
                            		System.out.println(getTextUsingXpath(strInvestmentManagementNameXpath,
                          				"investment management name is displayed in investment management tile in dashboard").trim());
                            		return(isElementPresentUsingXpath(strInvestmentManagementNameXpath, lplCoreConstents.HIGH,
                            				"investment management name is displayed in investment management tile in dashboard") &&
                            			isElementPresentUsingXpath(strInvestmentMamagementEditIconXpath, lplCoreConstents.HIGH,
                            					"investment management edit icon is displayed in investment management tile in dashboard"));
                            	}

                            	/**
                            	 * This method is used to check active label in investment management tile
                            	 * displayed in dashboard page after adding investment Management capability
                            	 *
                            	 * @return boolean
                            	 * @author awaeza
                            	 */
                            	public boolean investmentmanagementactivelabelDisplayed() {
                            		//String strIvestmentManagementActiveLabelXpath = "//a[contains(@title,'Edit Investment Management capability')]//../span[2]";
                            		return isElementPresentUsingXpath(strIvestmentManagementActiveLabelXpath, lplCoreConstents.HIGH,
                            				"active label is displayed in investment management tile in dashboard");
                            	}
                            	
                            	 /**
                                 * This method is used deselect the account from IMG
                                 * 
                                  *
                                 * @return boolean
                                 * @author vparthas
                                */
                                 public boolean deselectAccountFromIMG() {
                                 
                                	 return clickElementUsingXpath(strDeselectAccountFromIMGXpath, "See Portflio Allocation section");
                                 }
                           
                              	 /**
                                  * This method is used to verify remove account from IMG message
                                  * 
                                   *
                                  * @return boolean
                                  * @author vparthas
                                 */
                                  public boolean verifyRemoveAcccountIMGStaticMsg() {
                                	  System.out.println(getTextUsingXpath(strRemoveAccMsgIMGXpath,"IMG Address text"));
                                 	 return getTextUsingXpath(strRemoveAccMsgIMGXpath,"IMG Remove account text").equals(IMG_REMOVE_ACC_STATIC_MSG) ;
                                  }    
                                  
                             	 /**
                                   * This method is used to see Remove Account IMG overlay page
                                   * 
                                    *
                                   * @return boolean
                                   * @author vparthas
                                  */
                                   public boolean seeRemoveAccountsOverlayPage() {
                                  	 return isElementPresentUsingXpath(strRemoveAccOverlayPageXpath, lplCoreConstents.HIGH,"Remove accounts Overlay page from IMG");
                                   }   
                                   
                                   /**
                                    * This method is used to verify text in Remove Account IMG overlay page
                                    * 
                                     *
                                    * @return boolean
                                    * @author vparthas
                                   */
                                    public boolean verifyTextInRemoveAccountsOverlayPage() {
                                   	 return (getTextUsingXpath(strRemoveAccIMGOverlayPageText1Xpath,"IMG Remove account text").equals(IMG_REMOVE_ACC_OVERLAYPAGE_TEXT1)
                                   			 && getTextUsingXpath(strRemoveAccIMGOverlayPageText2Xpath,"IMG Remove account text").equals(IMG_REMOVE_ACC_OVERLAYPAGE_TEXT2)
                                   			 && getTextUsingXpath(strRemoveAccIMGOverlayPageText3Xpath,"IMG Remove account text").equals(IMG_REMOVE_ACC_OVERLAYPAGE_TEXT3));
                                    }
                                    
                                    /**
                                     * This method is used to see Remove Account IMG overlay page
                                     * 
                                      *
                                     * @return boolean
                                     * @author vparthas
                                    */
                                     public boolean seeRemovingAccountsOverlayPage() {
                                    	 return isElementPresentUsingXpath(strRemovingAccOverlayPageXpath, lplCoreConstents.HIGH,"Remove accounts Overlay page from IMG");
                                     } 
                                     
                                     /**
                                      * This method is to click on Final Review button
                                      * 
                                       *
                                      * @return boolean
                                      * @author vparthas
                                     */
                                      public boolean clickFinalReviewButtonIMG() {
                                      
                                     	 return clickElementUsingXpath(strFinalReviewButtonXpath, "click on Fianl Review button");
                                      }
                                      
                                      /**
                                       * This method is to see Excluded Contents Panel
                                       * 
                                        *
                                       * @return boolean
                                       * @author vparthas
                                      */
                                       public boolean seeExcludedContentsPanelIMG() {
                                      	 return clickElementUsingXpath(strExcludedAcctsContentsXpath, "click on Fianl Review button");
                                       }

                                       /**
                                        * This method is to click on Proceed to close button
                                        * 
                                         *
                                        * @return boolean
                                        * @author vparthas
                                       */
                                        public boolean clickProceedToCloseIMGOVerlay() {
                                       	 return clickElementUsingXpath(strProceedIMGOverlayXpath, "click on Proceed to close button");
                                        }
                                        
                                        /**
                                         * This method is to see Excluded Contents Panel
                                         * 
                                          *
                                         * @return boolean
                                         * @author vparthas
                                        */
                                         public boolean seeExcludedContentsTile() {
                                        	 return isElementPresentUsingXpath(strExcludedContentTileXpath, lplCoreConstents.HIGH,"Remove accounts Overlay page from IMG");
                                         }
                                         
                                         /**
                                          * This method is used to verify add account from IMG message
                                          * 
                                           *
                                          * @return boolean
                                          * @author vparthas
                                         */
                                          public boolean verifyAddAcccountIMGStaticMsg() {
                                        	  System.out.println(getTextUsingXpath(strAddAccMsg1IMGXpath,"IMG Address text"));
                                        	  System.out.println(getTextUsingXpath(strAddAccMsg2IMGXpath,"IMG Address text"));
                                         	 return (getTextUsingXpath(strAddAccMsg1IMGXpath,"IMG Remove account text").contentEquals(IMG_ADD_ACC_STATIC_MSG1) && 
                                         			getTextUsingXpath(strAddAccMsg2IMGXpath,"IMG Remove account text").contentEquals(IMG_ADD_ACC_STATIC_MSG2));                                 
                                     } 
                                          /**
                                           * This method is to see Excluded Contents Panel
                                           * 
                                            *
                                           * @return boolean
                                           * @author vparthas
                                          */
                                           public boolean seeIMGFormTile() {
                                          	 return isElementPresentUsingXpath(strIMGFormTileXpath, lplCoreConstents.HIGH,"Remove accounts Overlay page from IMG");
                                           }
                                           /**
                                            * This method is to click on Proceed to close button
                                            * 
                                             *
                                            * @return boolean
                                            * @author vparthas
                                           */
                                            public boolean clickOnSignatureFormForIMG() {
                                           	 return clickElementUsingXpath(strIMGFormXpath, "click on Proceed to close button");
                                            }
                                            /**
                                        	 * This method is used to Check element displayed
                                        	 *
                                        	 * @return boolean
                                        	 * @author vparthas
                                        	 */

                                        	public boolean CheckElementDisplayed() {
                                        		switchWindow(CHILD_WINDOW);
                                        		waitForPageLoading();
                                        		return isElementPresentUsingXpath("//*[text()='Documents for Investment Management']", lplCoreConstents.VERYHIGH,
                                        				"DocGrid page");
                                        	}
                                        	/**
                                             * This method is to see ! ACTIVATION REQUIRES 1 FORM text
                                             * 
                                              *
                                             * @return boolean
                                             * @author vparthas
                                            */
                                             public boolean seeActivationRequiredFormMsg() {
                                            	 return isElementPresentUsingXpath(strActivationFormTextIMGXpath, lplCoreConstents.HIGH,"Remove accounts Overlay page from IMG");
                                             }
                                             
                                             /**
                                              * This method is to click FAQ link in Widget
                                              * 
                                               *
                                              * @return boolean
                                              * @author vparthas
                                             */
                                             
                                             public boolean clickInvestmentManagementFAQsHyperlinkInFAQsWidget() {
                                                 return clickElementUsingXpath(strIMfaqHyperLinkXpath,
                                                              "Investment Management FAQs hyperlink is clicked");
                                          }
                                             
                                             /**
                                              * This method is to click on FAQ PDF in Widget
                                              * 
                                               *
                                              * @return boolean
                                              * @author vparthas
                                             */
                                             public boolean clickInvestmentManagementFAQsPDFlinkInFAQsWidget() {
                                                 return clickElementUsingXpath(strIMfaqPDFlinkXpath,
                                                              "Investment Management FAQs PDF link is clicked");
                                          }
                                             
                                             /**
                                              * This method is to click on FAQ link in Edit IMG page
                                              * 
                                               *
                                              * @return boolean
                                              * @author vparthas
                                             */
                                             
                                             public boolean clickOnFAQlinkText() {
                                                 return clickElementUsingXpath(strFAQsLinkTextXpath,
                                                              "FAQs link text clicked");
                                          }


                              
}
