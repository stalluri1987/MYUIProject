package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;

/**
 * <p>
 * <br>
 * <b> Title: </b> MenuStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for MenuStep</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * MenuStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class MenuStepDef extends CommonStepDef {

	@Then("^I choose (Account List Tool|Account Updates and Info|Activity Dashboard|Fee Billing|FBVA Dashboard|Non Billable Schedule|Program Fee Management|Rebilling|Reporting|Reporting NextGen|Source of Funds|Style Code Mapping|Below Minimum Tracking|Not Reached Tracking|Portfolio Accounting) from menu$")
	public void selectOptionFromMenu(String option) {
		boolean blnResult = menu.openMenu();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Hamburger Menu",
				"Hamburger Menu should be clicked", "Hamburger menu is clicked", "Unable to click on Hamburger menu");
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().HIGHEST);
		blnResult = menu.selectMenuOption(option);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on " + option + " option",
				option + " option should be clicked", option + " option  is clicked",
				"Unable to click on " + option + " option ");
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
