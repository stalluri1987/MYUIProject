package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.steps;

import java.util.List;
import java.util.Map;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class NewUserDefinedGroupStepDef extends CommonStepDef {
	
	public static final String MODALFRAME = "iframe-modal-frame";
	static final String TEST_DATA_PATH = "\\\\qa2000server\\QTP_Repository\\Grouping\\TestData\\Client_TestData.xlsx";
	public static final String FIELDS = "fields";
	public static final String USERNAME = "Username";
	public static final String PASSWORD = "Password";
	public static final String AXALOGIN = "strAXALogin";
	public static final String SUPPORTVIEWOPTION = "strSupportViewOption";
	public static final String SUPPORTVIEWDATA = "strSupportViewData";
	String firstName = "";
	String accountNumber = "";

	
	
	@Then("I click on Edit UDG name pencil icon")
	public void i_click_on_edit_udg_name_pencil_icon() {
		boolean blnResult = userDefinedGroupPage.clickonEditUDGNamePencilIcon();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit button from UDG dashboard page",
				"User is able to see Edit UDG",
				"User is able to click on Edit Group name pencil Icon successfully",
				"Failed to click on Edit Group name pencil Icon" + common.getStrError());  
	}
	
	@Then("I enter User Defined Group name")
	public void i_enter_user_defined_group_name() {
		boolean blnResult = userDefinedGroupPage.enterUDGName();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit UDG name pencil icon",
				"User is able to see Editable field to change UDG name",
				"User is able to enter household name successfully",
				"Failed to enter household name" + common.getStrError());

	}
	
	@Then("I should see Lets create a group page")
	public void i_should_see_lets_create_a_group_page() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeLetsCreateAGroupPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Review button",
				"User is able to Navigate",
				"User is able to see Lets Create a Group page successfully",
				"Failed to see Lets Create a Group page" + common.getStrError());
	}
	
	@When("I click in Create group button")
	public void i_click_in_create_group_button() {
		boolean blnResult = userDefinedGroupPage.clickOnCreateGroupButton();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Edit button from UDG dashboard page",
				"User is able to see Edit UDG",
				"User is able to click on Edit Group name pencil Icon successfully",
				"Failed to click on Edit Group name pencil Icon" + common.getStrError()); 
	}
	
	@Then("I should see UDG Dashboard page and success message")
	public void i_should_see_udg_dashboard_page_and_success_message() {
		boolean blnResult = userDefinedGroupPage.seeUDGDasboardPage();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Review button",
				"User is able to Navigate",
				"User is able to see Lets Create a Group page successfully",
				"Failed to see Lets Create a Group page" + common.getStrError());
	}
	
	@Then("I should see Clients tab preselected")
	public void i_should_see_clients_tab_preselected() {
		boolean blnResult = userDefinedGroupPage.seeClientsTabPreSelected();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Setup UDG page",
				"User is able to see the setup UDG page",
				"User is able to see Clients tab preselected",
				"Failed to see Clients tab preselected" + common.getStrError());
	}
	
	@Then("I should see Accounts tab preselected")
	public void i_should_see_accounts_tab_preselected() {
		boolean blnResult = userDefinedGroupPage.seeAccountsTabPreSelected();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Setup UDG page",
				"User is able to see the setup UDG page",
				"User is able to see Clients tab preselected successfully",
				"Failed to see Clients tab preselected" + common.getStrError());
	}
	
	@Then("Verify column names in the Clients tab")
	public void verify_column_names_in_the_clients_tab(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = userDefinedGroupPage.displaySummaryFieldsClientsTab(data.get("SummaryBannerFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("SummaryBannerFields") + " available",
					"User should able to see the  " + data.get("SummaryBannerFields") + "fields",
					" listed field values is " + data.get("SummaryBannerFields") + " visible",
					"Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");
	}
	}
	
	@Then("Verify column names in the Accounts tab")
	public void verify_column_names_in_the_accounts_tab(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = userDefinedGroupPage.displaySummaryFieldsAccountsTab(data.get("SummaryBannerFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("SummaryBannerFields") + " available",
					"User should able to see the  " + data.get("SummaryBannerFields") + "fields",
					" listed field values is " + data.get("SummaryBannerFields") + " visible",
					"Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");
	}
	}
	
	@Then("I edit and Enter Group Reporting tile")
	public void i_edit_and_enter_group_reporting_tile() {
		boolean blnResult = userDefinedGroupPage.enterGroupReportingTitle();
		common.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Review button",
				"User is able to Navigate",
				"User is able to see Lets Create a Group page successfully",
				"Failed to see Lets Create a Group page" + common.getStrError());
	}
	
	@Then("I should see Client Name preselcted on New User Defined Group Page")
	public void i_should_see_client_name_preselcted_on_new_user_defined_group_page() {
		common.waitForPageLoading();
		boolean blnResult = newHouseholdPage.preselectedClientNameDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "When User is on New Household Page",
				"User should successfully see Clients Name preselected",
				"User is able to see Client Name preselected on New Household Page successfully",
				"Failed to see Client Name preselected on New Household page" + common.getStrError());
	}
	
	@Then("I should see Account preselcted on New User Defined Group Page")
	public void i_should_see_account_preselcted_on_new_user_defined_group_page() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.preselectedAccountDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "when use is in setup UDG page",
				"User should successfully see Clients Name preselected",
				"User is able to see Client Name preselected on New Household Page successfully",
				"Failed to see Client Name preselected on New Household page" + common.getStrError());
	}
	
	@When("I click on Back to Groups button")
	public void i_click_on_back_to_groups_button() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.clickOnBactToGroupsLInk();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "when use clicks on Back to Groups link",
				"User should be able to click on Groups grid",
				"User is able to click on Back to Groups link",
				"Failed to click on Back to Groups link" + common.getStrError());
	}
	
	@When("I should land on Groups grid")
	public void i_should_land_on_groups_grid() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.verifyLandInGroupsGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify user lands in Groups grid",
				"User should be able to see Groups grid",
				"User is able to see Groups grid successfully",
				"Failed to see Groups grid" + common.getStrError());
	} 
	
	@Then("^I click on Create New User Defined Group Option$")
	public void i_click_on_create_new_user_defined_group_option() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.clickCreateUserDefinedGroup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Groups option in Client Context menu",
				"User should successfully click on Create New Household submenu",
				"User is able to click on Create New Household submenu successfully",
				"Failed to click on Create New Household submenu in client context menu" + common.getStrError());
	}
	
	@When("I click on Add to User Defined Group Option")
	public void i_click_on_add_to_user_defined_group_option() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.clickAddToUserDefinedGroup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Groups option in Client Context menu",
				"User should successfully click on Add to Groups submenu",
				"User is able to click on Add to Groups submenu successfully",
				"Failed to click on Add to Groups submenu in client context menu" + common.getStrError());
	}
	
	@Then("I see Add to Groups page")
	public void i_see_add_to_groups_page() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeAddToGroupsPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Groups option in Client Context menu",
				"User should successfully click on Add to Groups submenu",
				"User is able to see Add to groups page successfully",
				"Failed to see Add to Groups page" + common.getStrError());
	}
	
	@Then("I enter group name")
	public void i_enter_group_name() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.enterGroupNameInAddToGroupsPage(testData.get("enterGroupName"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the Client name",
				"Client name should be entered", "Client name is entered",
				"Failed to Enter Client Name." + common.getStrError());
	}
	
	@Then("I click on radio button to select group")
	public void i_click_on_radio_button_to_select_group() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.selectGroupForAddToGroups();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in Add to Groups page",
				"User should successfully click on Radio button to select the Group",
				"User is able to select radio button to select the Group successfully",
				"Failed to see Add to Groups page" + common.getStrError());
	}
	
	@When("I select Add to Groups button")
	public void i_select_add_to_Groups_button() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.selectAddToGroupsButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in Add to Groups page",
				"User should successfully click on Radio button to select the Group",
				"User is able to select radio button to select the Group successfully",
				"Failed to see Add to Groups page" + common.getStrError());
	}
	
	@Then("I should see lets update this page for UDG")
	public void i_should_see_lets_update_this_page_for_UDG() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeLetsUpdateThisPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on Add to Groups button",
				"User should click on Add to Groups button",
				"User is able to see Lets update this group page successfully",
				"Failed to see Lets update this group page" + common.getStrError());
	}
	
	@Then("I click on search button in Add to Groups page")
	public void i_click_on_search_button_in_add_to_groups_page() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.clickOnSearchAddToGroups();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in Add to Groups page",
				"User should successfully click on search button",
				"User is able to click on search button successfully",
				"Failed to click on Search button" + common.getStrError());
	}
	
	@Then("I ensure the client is added to the group")
	public void i_ensure_the_client_is_added_to_the_group() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeClientAddedToUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in Add to Groups page",
				"User should successfully add client to UDG",
				"User is able to add client to UDG successfully",
				"Failed to add client to UDG" + common.getStrError());
	}
	
	@Then("I ensure the account is added to the group")
	public void i_ensure_the_account_is_added_to_the_group() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeAccountAddedToUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in Add to Groups page",
				"User should successfully add account to UDG",
				"User is able to add account to UDG successfully",
				"Failed to add account to UDG" + common.getStrError());
	}
	
	@When("I click on Save Changes button")
	public void i_click_on_save_changes_button() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.clickOnSaveChangesUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in Add to Groups page",
				"User should successfully click on Save Changes button",
				"User is able to click on Save Changes button successfully",
				"Failed to click on Save Changes button" + common.getStrError());
	}
	
	@Then("I should see UDG dashboard page and update success message")
	public void i_should_see_UDG_dashboard_page_and_update_success_message() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeGroupUpdateMessage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in Add to Groups page",
				"User should successfully add client to UDG",
				"User is able to see the group updated message successfully",
				"Failed to see the group updated message" + common.getStrError());
	}
	
	@When("I click to unmask the account number")
	public void i_click_to_unmask_the_account_number() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.clickToUnmaskAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in New UDG page",
				"User should successfully click to unamsk the account number",
				"User is able to click to unmask the account number successfully",
				"Failed to click to unmask the account number" + common.getStrError());
	}
	
	@When("^I should select User Defined from create drop down$")
	public void ishould_select_user_defined_from_create_drop_down() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.selectCreateUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"User is able to select Create Group and User Defined", "New User Defined page should be loaded",
				"User is able to select Create Group and User Defined successfuly",
				"Failed to select Create Group and User Defined. Error message: " + common.getStrError());
	}
	
	@Then("I should see Group Name is required tag")
	public void i_should_see_group_name_is_required_tag() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeGroupNameRequiredTag();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets create group page",
				"User should see Group name required tag",
				"User is able to see Group name required tag successfully",
				"Failed to see Group name required tag" + common.getStrError());
	}
	
	@Then("I should see Please select a group content type tag")
	public void i_should_see_Please_select_a_group_content_type_tag() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seePleaseSelectGroupContentTag();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets create group page",
				"User should see Group name required tag",
				"User is able to see Group name required tag successfully",
				"Failed to see Group name required tag" + common.getStrError());
	}
	
	@Then("I should navigate to Lets create a group page")
	public void i_should_navigate_to_lets_create_a_group_page() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeNewUDGPage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets create group page",
				"User should see Group name required tag",
				"User is able to see Group name required tag successfully",
				"Failed to see Group name required tag" + common.getStrError());
	}
	
	@When("I select content type as Accounts")
	public void i_select_content_type_as_accounts() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.selectsAccountType();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in New UDG page",
				"User should successfully select Accounts type",
				"User is able to select Accounts as content type successfully",
				"Failed to select Accounts as content type" + common.getStrError());
	}
	
	@Then("Verify Group Contents widget visible")
	public void verify_group_contents_widget_visible() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeGroupContentWidget();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets create group page",
				"User does not have added any group member",
				"User is able to see Group Content widget",
				"Failed to see Group Content widget" + common.getStrError());
	}
	
	@Then("Verify No Primary is selected")
	public void verify_no_primary_is_selected() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeNoPrimaryIsSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets create group page",
				"User does not have added any group member",
				"User is able to see Group Content widget",
				"Failed to see Group Content widget" + common.getStrError());
	}
	
	@When("^I enter the account number in the search text box$")
	public void i_enter_the_account_number_in_the_search_text_box() {
		String accountNumber = testData.get("accountNumber");
		boolean blnResult = userDefinedGroupPage.enterAccountNumberInSearchBox(accountNumber);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter the first name[" + accountNumber + "]", "Account Number should be entered",
				"First name[" + accountNumber + "]  entered",
				"Failed To enter the first name." + common.getStrError());
	}
	
	@Then("^I should see results of clients$")
	public void i_should_see_results_of_clients() {
		common.wait(7);
		List<String> searchResults = userDefinedGroupPage.getSearchResults();
		boolean blnResult = !searchResults.isEmpty();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if the search results are retrived", "Search results should be retrieved",
				"Search results are retrieved. Results - [" + java.lang.String.join(",", searchResults) + "]",
				"Search result does not contains any results");
		for (String result : searchResults) {
			if (!result.toLowerCase().contains(accountNumber))
				LPLCoreReporter.writeStepToReporter(LPLCoreConstents.FALSE, LPLCoreConstents.TRUE,
						"Validate if each search result contains the search string[" + accountNumber + "]",
						"Search result contains the search string[" + accountNumber + "]",
						"Search result[" + result + "] contains the search string[" + accountNumber + "]",
						"Search result[" + result + "] does not contain the search string[" + accountNumber + "]");
		}
	}
	
	@When("^I select one of the account from search result$")
	public void i_select_one_of_the_account_from_search_result() {
		boolean blnResult = userDefinedGroupPage.selectClientPrimary();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on any one of the client name",
				"Client name should be clicked", "Client name is clicked",
				"Failed to click the client name." + common.getStrError());
	}
	
	@When("I select content type as Clients")
	public void i_select_content_type_as_clients() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.selectClientType();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in New UDG page",
				"User should successfully select Accounts type",
				"User is able to select Accounts as content type successfully",
				"Failed to select Accounts as content type" + common.getStrError());
	}
	
	@When("I select content type as Household")
	public void i_select_content_type_as_household() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.selectHouseholdType();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User in New UDG page",
				"User should successfully select Accounts type",
				"User is able to select Accounts as content type successfully",
				"Failed to select Accounts as content type" + common.getStrError());
	}
	
	@When("I enter the client name in the search text box")
	public void i_enter_the_client_name_in_the_search_text_box() {
		String clientName = testData.get("clientName");
		boolean blnResult = userDefinedGroupPage.enterAccountNumberInSearchBox(clientName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter the first name[" + clientName + "]", "Account Number should be entered",
				"First name[" + clientName + "]  entered",
				"Failed To enter the first name." + common.getStrError());
	}
	
	@When("I enter the household name in the search text box")
	public void i_enter_the_household_name_in_the_search_text_box() {
		String householdName = testData.get("householdName");
		boolean blnResult = userDefinedGroupPage.enterAccountNumberInSearchBox(householdName);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter the first name[" + householdName + "]", "Account Number should be entered",
				"First name[" + householdName + "]  entered",
				"Failed To enter the first name." + common.getStrError());
	}
	
	@When("^I click on a hyperlinked UDG Group name$")
	public void iclickonahyperlinkedudggroupname() {
		common.wait(5);
		boolean blnResult = userDefinedGroupPage.clickUDGName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User click on Hyperlinked Household Group name",
				"User should click successfully on Hyperlinked Household Group name",
				"User is able to click on Hyperlinked Household Group name successfully",
				"Failed to click Hyperlinked Household Group name." + common.getStrError());

	}
	
	@Then("I should see UDG dashbaord page")
	public void i_should_see_udg_dashbaord_page() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeUDGDashboard();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on Group name",
				"User is in UDG dasboard page",
				"User is able to see UDG dasboard page",
				"Failed to see UDG dasboard pageUDG dasboard page" + common.getStrError());
	}
	
	@Then("Verify column names in the UDG Dashboard summary banner")
	public void verify_column_names_in_the_udg_dashbaord_summary_banner(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = userDefinedGroupPage.displaySummaryFieldsAccountsTab(data.get("SummaryBannerFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("SummaryBannerFields") + " available",
					"User should able to see the  " + data.get("SummaryBannerFields") + "fields",
					" listed field values is " + data.get("SummaryBannerFields") + " visible",
					"Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");
	}
	}
	
	@Then("I see the Account tile and verify the column names in the tile")
	public void i_see_the_account_tile_and_verify_the_column_names_in_the_tile(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = userDefinedGroupPage.displayUDGDashbaordSummaryFields(data.get("SummaryBannerFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("SummaryBannerFields") + " available",
					"User should able to see the  " + data.get("SummaryBannerFields") + "fields",
					" listed field values is " + data.get("SummaryBannerFields") + " visible",
					"Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");
	}
	}
	
	@When("I click on Edit button in UDG dashbaord page")
	public void i_click_on_edit_button_in_udg_dashbaord_page() {
		boolean blnResult = userDefinedGroupPage.clickEditUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in User Defined Group dashboard page",
				"User should click on the Edit button",
				"User is able to click on Edit button on the UDG dashboard successfully",
				"Failed to click on Edit button on the UDG dashboard" + common.getStrError());
	}
	
	@When("I click on Review button in Edit UDG page")
	public void i_click_on_review_button_in_edit_udg_page() {
		boolean blnResult = userDefinedGroupPage.clickReviewbuttonUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets update this group page",
				"User should click on the Review button button",
				"User is able to click on Review button successfully",
				"Failed to click on Review button" + common.getStrError());
	}
	
	@Then("I verify tracker for add account in Lets update this group page")
	public void i_verify_tracker_for_add_account_in_lets_update_this_group_page() {
		boolean blnResult = userDefinedGroupPage.verifyTrackerUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets update this group page",
				"User is able to see the tracker for ass/remove account",
				"User is able to see the tracker for ass/remove account successfully",
				"Failed to see the tracker for ass/remove account" + common.getStrError());
	}
	
	@Then("I verify contents tile for newly added account")
	public void i_verify_contents_tile_for_newly_added_account() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeNewAddedClientAccountInContentTile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on Group name",
				"User is in UDG dasboard page",
				"User is able to see UDG dasboard page",
				"Failed to see UDG dasboard pageUDG dasboard page" + common.getStrError());
	}
	
	@Then("I see column names in the group member tile")
	public void i_see_column_names_in_the_account_tile(DataTable field) {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
		List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
		for (Map<String, String> data : userGuidesFields) {
			boolean blnResult = userDefinedGroupPage.displayAccountsTileColumnNames(data.get("SummaryBannerFields"));
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					"Validate that listed fields " + data.get("SummaryBannerFields") + " available",
					"User should able to see the  " + data.get("SummaryBannerFields") + "fields",
					" listed field values is " + data.get("SummaryBannerFields") + " visible",
					"Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");
	}
	}
	
	@When("I click on Edit group link")
	public void i_click_on_edit_group_link() {
		boolean blnResult = userDefinedGroupPage.clickEditGroupButtonUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets update this group page",
				"User should click on the Review button button",
				"User is able to click on Review button successfully",
				"Failed to click on Review button" + common.getStrError());
	}
	@Then("Veirfy only RepID is displayed in the group member tile")
	public void veirfy_only_rep_id_is_displayed_in_the_group_member_tile() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.seeRepIDOnlyInMemberTile();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks on Edit group link",
				"User is in Lets update this group page",
				"User is able to see only RepID in the group member tile",
				"Failed to see only RepID in the group member tile" + common.getStrError());
	}
	@When("I remove a member from UDG")
	public void i_remove_a_client_from_udg() {
		common.waitForPageLoading();
		boolean blnResult = userDefinedGroupPage.removeMemberUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User clicks remove member button",
				"User is able to click on remove button",
				"User is able to remove group memeber successfully",
				"Failed to remove group memeber" + common.getStrError());
	}
	@Then("I verify tracker for remove account in Lets update this group page")
	public void i_verify_tracker_for_remove_account_in_lets_update_this_group_page() {
		boolean blnResult = userDefinedGroupPage.verifyRemoveTrackerUDG();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"When User is in Lets update this group page",
				"User is able to see the tracker for ass/remove account",
				"User is able to see the tracker for ass/remove account successfully",
				"Failed to see the tracker for ass/remove account" + common.getStrError());
	}
	@Then("I see the Household tile and verify the column names in the tile")
    public void i_see_the_household_tile_and_verify_the_column_names_in_the_tile(DataTable field) {
           LPLCoreSync.staticWait(LPLCoreConstents.getInstance().FAIRINMILLISEC);
          List<Map<String, String>> userGuidesFields = field.asMaps(String.class, String.class);
          for (Map<String, String> data : userGuidesFields) {
                 boolean blnResult = userDefinedGroupPage.displayUDGHouseholdDashbaordSummaryFields(data.get("SummaryBannerFields"));
                 LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                              "Validate that listed fields " + data.get("SummaryBannerFields") + " available",
                              "User should able to see the  " + data.get("SummaryBannerFields") + "fields",
                              " listed field values is " + data.get("SummaryBannerFields") + " visible",
                              "Failed : listed field values " + data.get("SummaryBannerFields") + "are NOT visible");
    }
    }
	
	@When("I select primary check box in this group page")
    public void i_select_primary_check_box_in_this_group_page() {
          boolean blnResult = userDefinedGroupPage.selectsPrimaryType();
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When User in this group page",
                        "User should successfully select group type as primary",
                        "User is able to select group type as primary successfully",
                        "Failed to select group type as primary" + common.getStrError());
    }

    @Then("I verify Primary tag present for respective group in UDG dashboard page")
    public void i_verify_primary_tag_present_for_respective_group_in_udg_dashboard_page() {
          common.waitForPageLoading();
          boolean blnResult = userDefinedGroupPage.seePrimaryTagInRespectiveGroup();
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When User is Primary tag present for respective group in UDG dashboard page",
                        "User does not have Primary tag present for respective group in UDG dashboard page",
                        "User is able to see Primary tag present for respective group in UDG dashboard page sucessfully",
                        "Failed to see Primary tag present for respective group in UDG dashboard page" + common.getStrError());
    }

    @Then("I Verify Client placeholder name in textfield")
    public void i_verify_client_placeholder_name_in_textfield() {
          common.waitForPageLoading();
          boolean blnResult = userDefinedGroupPage.seePlaceholderNameInClientTextfield();
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When User in create User defined group page",
                        "User should the placeholder name in Client textfield",
                        "User is able to see the placeholder name in Client textfield successfully",
                        "Failed to see the placeholder name in Client textfield" + common.getStrError());
    }
    
    @Then("I Verify Household placeholder name in textfield")
    public void i_verify_household_placeholder_name_in_textfield() {
          common.waitForPageLoading();
          boolean blnResult = userDefinedGroupPage.seePlaceholderNameInHouseholdTextfield();
          LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                        "When User in create User defined group page",
                        "User should the placeholder name in Client textfield",
                        "User is able to see the placeholder name in Client textfield successfully",
                        "Failed to see the placeholder name in Client textfield" + common.getStrError());
    }

    @Then("I verify the error message displayed for unique group name")
    public void i_verify_the_error_message_displayed_for_unique_group_name() {
    	common.waitForPageLoading();
        boolean blnResult = userDefinedGroupPage.seeErrorMessageUniqueGroupName();
        LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
                      "When User in create User defined group page",
                      "User should the placeholder name in Client textfield",
                      "User is able to see the placeholder name in Client textfield successfully",
                      "Failed to see the placeholder name in Client textfield" + common.getStrError());
    }

}
