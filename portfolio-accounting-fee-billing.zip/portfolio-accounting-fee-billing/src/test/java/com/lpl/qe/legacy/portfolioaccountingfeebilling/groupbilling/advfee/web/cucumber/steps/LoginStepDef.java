package com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.steps;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import LPLCoreDriver.LPLCoreUtil;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDef extends CommonStepDef {
	Common commonMethods = new Common(driver);

	// New call
	@Before
	public void startSession(Scenario sc) {
		String[] scenarioTags = sc.getSourceTagNames().toArray(new String[0]);
		String scriptID = LPLCoreDriver.getScriptTagID(scenarioTags);
		if (scriptID != null) {
			LPLCoreDriver.StartSession(scriptID);
		} else {
			LPLCoreDriver.StartSession();
		}
		
		if (ocfg.getExecutionLocation().equals("saucelabs") || ocfg.getExecutionLocation().equals("blackbirdgrid"))
			((JavascriptExecutor) driver).executeScript("sauce:job-name=" + sc.getName());

	}

	@Given("^I login to ClientWorks application$")
	public void i_login_to_ClientWorks_application() {
		initialize();
		boolean blnResult = loginPage.login(loginCredentials.get("Username"), loginCredentials.get("Password"));
		commonMethods.waitForPageLoading();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Login to ClientWorks Application",
				"User should be able to login to ClientWorks Application",
				"Successfully logged in to ClientWorks Application",
				"Failed To Login to ClientWorks Application.Error message: " + loginPage.strError);
	}

	@Then("^I should land on ClientWorks Application Home page$")
	public void i_should_see_Client_Management_Page_is_displayed() {
		boolean blnResult;
		LPLCoreSync.waitTillVisible(driver, By.cssSelector(homePage.strApplauncher_CSS),
				LPLCoreConstents.getInstance().MEDIUM);
		blnResult = LPLCoreUtil.isElementPresent("DISPLAYED",
				driver.findElement(By.cssSelector(homePage.strApplauncher_CSS)));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate Client Management Page is displayed",
				"User should be able to see Client Management Page is displayed", "Client Management Page is displayed",
				"Failed To see Client Management Page. Error message:" + LPLCoreUtil.strError);
	}

	@When("^I logout of application$")
	public void i_logout_of_application() {
		boolean blnResult = tafsAdminGroupPage.clickLogOut();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "I logout of application",
				" should logout of application", "Sucessfullysee logout of application",
				"Failed to logout of application" + commonMethods.strError);
	}

	@After
	public void writeReport() {
		LPLCoreReporter.writeSummary();
	}
}
