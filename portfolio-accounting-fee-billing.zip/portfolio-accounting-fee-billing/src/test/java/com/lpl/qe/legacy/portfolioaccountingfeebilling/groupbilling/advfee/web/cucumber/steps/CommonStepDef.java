package com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.groupbilling.advfee.web.cucumber.pages.AdvisoryFee;

import LPLCoreDriver.LPLCoreDriver;
import PageObjectLibrary.ClientManagement_Common;
import PageObjectLibrary.HomePage;
import PageObjectLibrary.LoginPage;

public class CommonStepDef extends LPLCoreDriver {
	static ClientManagement_Common clientManagementCommon;
	static LoginPage loginPage;
	static HomePage homePage;
	static AdvisoryFee tafsAdminGroupPage;

	public static void initialize() {
		clientManagementCommon = new ClientManagement_Common(driver);
		loginPage = new LoginPage(driver);
		homePage = new HomePage(driver);
		tafsAdminGroupPage = new AdvisoryFee(driver);
	}
}
