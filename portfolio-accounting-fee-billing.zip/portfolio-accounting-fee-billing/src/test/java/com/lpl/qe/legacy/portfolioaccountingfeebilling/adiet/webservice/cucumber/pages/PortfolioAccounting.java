package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> PortfolioAccounting.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for PortfolioAccounting</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * PortfolioAccountingTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author Sanjana Dasari
 * @since 12/15/2020
 */

public class PortfolioAccounting extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 1071;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String PORTFOLIOACCOUNTS = "ADIET - Portfolio Accounts";
	public static final String PORTFOLIO_ACCOUNTING = "Portfolio Accounting Page";
	public static final String USERNAME = "Username";
	public static final String PASSWORD = "Password";
	public static final String ACCOUNT_NUMBER_TEXTBOX = "Account Number TextBox";
	public static final String SEARCHBUTTON = "Search Button";
	public static final String EXPORTBUTTON = "Export Button";
	public static final String PORTFOLIOACCOUNTINGTOOLFROMMENU = "Portfolio Accounting From Menu";
	public static final String OPTIONS = "options";
	public static final String FAILED_TO_SEE = " Failed to see ";
	public static final String ACCOUNT_NUMBER = "Account Number";
	public static final String BETA_TAB_ACTIVE = "Beta Tab Active";
	public static final String POSITIONS_TAB = "Positions Tab";
	public static final String ACCOUNT_DOES_NOT_EXIST = "Account does not exist";
	public static final String FBVA_TAB = "FBVA";
	public static final String DIRECTBUSINESS_FBVA_TAB = "DirectBusinessFBVA tab";

	String strAccountNoTextBoxXpath;
	String strSearchButtonPAXpath;
	String strPortfolioAccountingHeaderXpath;
	String strExportButtonXpath;
	String strBetaFBVAXpath;
	String strBetaTabActiveXpath;
	String strBetaFieldsXpath;
	String strDownloadedFileNameBeta;
	String strBetaGridXpath;
	String strInvalidAccountNoErrorMessageXpath;
	String strPositionsFieldsXpath;
	String strFBVATabXpath;
	String strFBVAFieldsXpath;
	String strFBVATransactionsGridXpath;
	String strFBVAPositionsGridXpath;
	String strPositionTaBXpath;
	String strPositionsGridXpath;
	String strDirectBusinessFBVATabXpath;
	String strDirectBusinessFBVAFieldsXpath;

	public PortfolioAccounting(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strPortfolioAccountingHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				PORTFOLIO_ACCOUNTING);
	}

	/**
	 * This method is used to check if the Text field for Account no. is present
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */

	public boolean verifytheavailabilityofsearchfieldLPLAccountNumber() {
		return clickElementUsingXpath(strAccountNoTextBoxXpath, ACCOUNT_NUMBER_TEXTBOX);
	}

	/**
	 * This method is used to enter Account Number
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */
	public boolean enterAccountNumber() {
		return enterTextUsingXpath(strAccountNoTextBoxXpath, testData.get(ACCOUNT_NUMBER), ACCOUNT_NUMBER_TEXTBOX);
	}

	/**
	 * This method is used to Click On Search Button
	 * 
	 * @return boolean
	 *
	 * @author Sanjana dasari
	 * @since 12/15/2020
	 */
	public boolean iClickOnSearchButton() {
		return clickElementUsingXpath(strSearchButtonPAXpath, SEARCHBUTTON);
	}

	/**
	 * This method is used to Verify the availablity of Beta & FBVA Tab
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */
	public boolean verifyTheAvailabilityOfTabs(DataTable tab) {
		return verifyFields(strBetaFBVAXpath, tab);
	}

	/**
	 * This method is used to Verify the Beta & FBVA Tab using PlaceholderLocator
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */
	public boolean verifyFields(String placeHolderLocator, DataTable searchFieldsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFieldsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkIfElementExistUsingPlaceholderText(placeHolderLocator, filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCESSFULLY_ABLE_SEE + filterName, FAILED_TO_SEE + filterName + strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to Verify the Beta & FBVA Tab using PlaceholderTextXpath
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */
	public boolean checkIfElementExistUsingPlaceholderText(String strPlaceholderTextXpath, String placeholderText) {
		return isElementPresentUsingXpath(getFormattedLocator(strPlaceholderTextXpath, placeholderText),
				LPLCoreConstents.getInstance().MEDIUM, placeholderText);
	}

	/**
	 * This method is used to Verify Beta Tab is selected by default
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 *
	 * @since 12/15/2020
	 */
	public boolean verifyBetaTabIsSelectedByDefault() {
		return clickElementUsingXpath(strBetaTabActiveXpath, BETA_TAB_ACTIVE);
	}

	/**
	 * This method is used to verify that the Beta tab has |Start Date, End Date,
	 * Security No| fields
	 * 
	 * @param betafields
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */
	public boolean verifyTheAvailabilityOfBetaFields(DataTable betafields) {
		return verifyFields(strBetaFieldsXpath, betafields);
	}

	/**
	 * This method is used verify whether the file is Downloaded And Deleted
	 * 
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */
	public boolean verifyDownloadedFileAndDeleteOnBeta() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileNameBeta"));
	}

	/**
	 * This method is used verify the display of fields in BETA grid header
	 * 
	 * @param betagridheader
	 * @return boolean
	 *
	 * @author Sanjana Dasari
	 * @since 12/15/2020
	 */
	public boolean verifyTheDisplayOfFieldsInBetaGridHeader(DataTable betaGridheader) {
		return verifyFields(strBetaGridXpath, betaGridheader);
	}

	/**
	 * This method is used to verify the display of error message in Beta Tab
	 * 
	 * @return boolean
	 *
	 * @author Rashika Balusamy
	 * @since 12/28/2020
	 */
	public boolean verifytheDisplayOfErrorMessageInBetaTab() {
		return isElementPresentUsingXpath(strInvalidAccountNoErrorMessageXpath, LPLCoreConstents.getInstance().LOWEST,
				ACCOUNT_DOES_NOT_EXIST);
	}

	/**
	 * This method is used to verify the display of error message in Positions Tab
	 * 
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 1/04/2021
	 */
	public boolean verifyTheAvailabilityOfPositionsFields(DataTable positionsfields) {
		return verifyFields(strPositionsFieldsXpath, positionsfields);
	}

	/**
	 * This method is used to verify the display of error message in Positions Tab
	 * 
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 1/04/2021
	 */
	public boolean verifyclickonPositionstab() {
		waitTillVisibleUsingXpath(strPositionTaBXpath, POSITIONS_TAB);
		return clickElementUsingXpath(strPositionTaBXpath, POSITIONS_TAB);
	}

	/**
	 * This method is used verify whether the file is Downloaded And Deleted
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/15/2021
	 */

	public boolean verifyDownloadedFileAndDeleteOnFBVA() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileNameFBVA"));
	}

	/**
	 * This method is used to verify the display of error message in Positions Tab
	 * 
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 1/04/2021
	 */

	public boolean verifyTheDisplayOfFieldsInPositionsGridHeader(DataTable positionsGridheader) {
		return verifyFields(strPositionsGridXpath, positionsGridheader);
	}

	/**
	 * 
	 * This method is used to Click On FBVA Tab
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/4/2021
	 */
	public boolean verifyiClickOnFBVATab() {
		return clickElementUsingXpath(strFBVATabXpath, FBVA_TAB);
	}

	/**
	 * This method is used to verify that the Positions tab has |ValuationDate,
	 * Cusip| fields
	 * 
	 * @param fbvaFields
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/4/2021
	 */
	public boolean verifyTheAvailabilityOfFBVAFields(DataTable fbvaFields) {
		return verifyFields(strFBVAFieldsXpath, fbvaFields);
	}

	/**
	 * This method is used verify the display of fields in FBVA Transaction grid
	 * header
	 * 
	 * @param fbvaTransactionsGridheader
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/4/2021
	 */

	public boolean verifyTheDisplayOfFieldsInFBVATransactionsGridHeader(DataTable fbvaTransactionsGridheader) {
		return verifyFields(strFBVATransactionsGridXpath, fbvaTransactionsGridheader);
	}

	/**
	 * This method is used verify the display of fields in FBVA Positions grid
	 * header
	 * 
	 * @param fbvaPositionsGridHeader
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/4/2021
	 */

	public boolean verifyTheDisplayOfFieldsInFBVAPositionsGridHeader(DataTable fbvaPositionsGridHeader) {
		return verifyFields(strFBVAPositionsGridXpath, fbvaPositionsGridHeader);
	}

	/**
	 * This method is used to Click On DirectBusinessFBVA Tab
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/25/2021
	 */
	public boolean verifyiClickOnDirectBusinessFBVATab() {
		return clickElementUsingXpath(strDirectBusinessFBVATabXpath, DIRECTBUSINESS_FBVA_TAB);
	}

	/**
	 * This method is used to verify that the DirectBusinessFBVA tab has below
	 * fields Cusip| fields
	 * 
	 * @param directBusinessFbvaFields
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/25/2021
	 */
	public boolean verifyTheAvailabilityOfDirectBusinessFBVAFields(DataTable directBusinessFbvaFields) {
		return verifyFields(strDirectBusinessFBVAFieldsXpath, directBusinessFbvaFields);
	}

	/**
	 * This method is used to verify the display of error message Account does not
	 * exist
	 * 
	 * @return boolean
	 *
	 * @author Neha Shimpi
	 * @since 1/26/2021
	 */
	public boolean verifytheDisplayOfErrorMessageAccountDoesNotExist() {
		return isElementPresentUsingXpath(strInvalidAccountNoErrorMessageXpath, LPLCoreConstents.getInstance().LOWEST,
				ACCOUNT_DOES_NOT_EXIST);
	}

	/**
	 * This method is used to verify the display of error message in Positions Tab
	 * 
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 1/27/2021
	 */
	public boolean verifytheDisplayOfErrorMessageInPositionsTab() {
		return isElementPresentUsingXpath(strInvalidAccountNoErrorMessageXpath, LPLCoreConstents.getInstance().LOWEST,
				ACCOUNT_DOES_NOT_EXIST);
	}

	/**
	 * This method is used verify whether the file is Downloaded And Deleted
	 * 
	 * @return boolean
	 *
	 * @author Naushad Ahamed
	 * @since 1/28/2021
	 */

	public boolean verifyDownloadedFileAndDeleteOnPositions() {
		return isFileDownloadedWithCorrectName(testData.get("strDownloadedFileNamePositions"));
	}
}