package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;

public class HistoricalCorrectionTestDataAutomation extends Common implements ILocatorInitialize {
	

	public static final String EMPTY_STRING = "";
	private static Connection connection = null;
	static boolean resultOutput = false;
	
	public HistoricalCorrectionTestDataAutomation(WebDriver browserDriver) {
		super(browserDriver);
	}
	
	public static void connectToBodsSqlServer() {
		connection = FeeBilling.getConnection(testData.get("strServerName"), testData.get("strDatabaseName"),
				testData.get("strIsWindowsAuthentication"), testData.get("strUserName"), "NA");
	}
	
	/**
	 * @author Sai Yata
	 * 
	 * @param groupId
	 * @param account4
	 * @param account3
	 * @param account2
	 * @param account1
	 * @return 
	 * 
	 * 
	 */
	public static void runTheSQLQueryToDeleteRecordsFromIdentifiedTables(String account1, String account2, String account3,
			String account4, String groupId) {
		
		String query = EMPTY_STRING;
		query = DatabaseQueries.FB_DELETE_QUERY_TO_DELETE_RECORDS_FROM_TARGET_TABLES;
		query = replaceParams(account1, account2, account3, account4, groupId, query);
		System.out.println(query);
		getQueryResult(connection, query);	
	}

	/**
	 * @author Sai Yata
	 * 
	 */
	public static void runTheSQLQueryToInsertRecordsInIdentifiedTables(String account1, String account2, String account3,
			String account4, String groupId, String type) {
		String query = EMPTY_STRING;
		switch (type.toLowerCase()) {
		case "one month":
			query = DatabaseQueries.FB_INSERT_QUERY_TO_INSERT_RECORDS_INTO_TARGET_TABLES_ONE_MONTH;
			break;
		case "same month":
			query = DatabaseQueries.FB_INSERT_QUERY_TO_INSERT_RECORDS_INTO_TARGET_TABLES_SAME_MONTH;
			break;
		case "two months":
			query = DatabaseQueries.FB_INSERT_QUERY_TO_INSERT_RECORDS_INTO_TARGET_TABLES_TWO_MONTHS;
			break;
		case "separate months":
			query = DatabaseQueries.FB_INSERT_QUERY_TO_INSERT_RECORDS_INTO_TARGET_TABLES_SEPARATE_MONTHS;
			break;
		case "one account":
			query = DbQueries.FB_INCEPITON_INSERT_QUERY_TO_INSERT_RECORDS_INTO_TARGET_TABLES_ONE_ACCOUNT;
			break;
		case "same month inception":
			query = DbQueries.FB_INCEPITON_INSERT_QUERY_TO_INSERT_RECORDS_INTO_TARGET_TABLES_SAME_MONTH;
			break;		
		case "separate months inception":
			query = DbQueries.FB_INCEPITON_INSERT_QUERY_TO_INSERT_RECORDS_INTO_TARGET_TABLES_SEPARATE_MONTHS;
			break;

		}
		query = replaceParams(account1, account2, account3, account4, groupId, query);
		System.out.println(query);
		getQueryResult(connection, query);	
	}

	/**
	 * @author Sai Yata
	 * 
	 */
	public static void runTheSQLQueryToRemoveFromAuditables(String account1, String account2, String account3, String account4,
			String groupId, String type) {
		String query = EMPTY_STRING;
		switch (type.toLowerCase()) {
		case "one month":
			query = DatabaseQueries.FB_QUERY_REMOVE_AUDIT_TABLES_ONE_MONTH;
			break;
		case "same month":
			query = DatabaseQueries.FB_QUERY_REMOVE_AUDIT_TABLES_SAME_MONTH;
			break;
		case "two months":
			query = DatabaseQueries.FB_QUERY_REMOVE_AUDIT_TABLES_TWO_MONTHS;
			break;
		case "separate months":
			query = DatabaseQueries.FB_QUERY_REMOVE_AUDIT_TABLES_SEPARATE_MONTHS;
			break;
		case "one account":
			query = DbQueries.FB_QUERY_INCEPITON_REMOVE_AUDIT_TABLES_ONE_ACCOUNT;
			break;
		case "same month inception":
			query = DbQueries.FB_QUERY_INCEPITON_REMOVE_AUDIT_TABLES_SAME_MONTH;
			break;		
		case "separate months inception":
			query = DbQueries.FB_QUERY_INCEPITON_REMOVE_AUDIT_TABLES_SEPARATE_MONTHS;
			break;

		}
		query = replaceParams(account1, account2, account3, account4, groupId, query);
		System.out.println(query);
		getQueryResult(connection, query);		
	}	

	private static String replaceParams(String account1, String account2, String account3, String account4, String groupId,
			String query) {
		query = query.replace("@Account1", "'" + account1 + "'");
		query = query.replace("@Account2", "'" + account2 + "'");
		query = query.replace("@Account3", "'" + account3 + "'");
		query = query.replace("@Account4", "'" + account4 + "'");
		query = query.replace("@GroupID", "'" + groupId + "'");
		return query;
	}
	
	private static void getQueryResult(Connection connection, String queryText) {
		try (Statement statement = connection.createStatement()) {
			System.out.println("Executing Scripts");
			statement.executeUpdate(queryText); //Returns an integer representing the number of rows affected by the SQL statement
			System.out.println("Execution Done");
		} catch (SQLException e) {
			printReport(queryText, e);
		}
	}
	
	private static void printReport(String queryText, SQLException e) {
		LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Execute the query [" + queryText + "]",
				"Query should be executed successfully", "Query is executed successfully",
				"Exception occurred when executing the query. Please recheck the query. Error message:  "
						+ e.getMessage(),
				false);
	}
}

