package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;

/**
 * <p>
 * <br>
 * <b> Title: </b> FeeBilling.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for FeeBilling</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class FeeBilling extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 817;
	Map<String, HashMap<String, String>> pageObjectMap;
	String strFeeBillingHeaderXpath;
	String strAddhocButtonXpath;
	String strQuarterlyButtonXpath;
	String strIfAnyUserRunningFeeBillingXpath;
	String strSelectBillingScreenXpath;
	String strQuaterEndDateXpath;
	String strAccountNumberXpath;
	String strAccountListXpath;
	String strGenerateFileCheckboxXpath;
	String strNextButtonXpath;
	String strConfirmAndProcessXpath;
	String strCancelButtonXpath;
	String strOkButtonXpath;
	String strAccountDetailsReportLinkXpath;
	String strAccountDetailsReportOptionsTitleXpath;
	String strAccountNumberTextBoxOnAccountDetailsXpath;
	String strRunReportButtonOnAccountDetailsXpath;
	String strAccountDetailsReportHeadingXpath;
	String strAccountnoInReportXpath;
	String strQuarterEndDateInReportXpath;
	String strAddhocHeaderTextInReportXpath;
	String strFeeBillingRunningAutomationUserXpath;
	String strConfirmFailureXpath;
	String strAccountDetailsHeaderInReport;
	String strAdminButtonXpath;
	String strSetStatusCompleteButtonXpath;
	ResultSet resultPremiumAccountData = null;
	ResultSet resultOutput = null;
	ResultSet resultEMAccountData = null;
	ResultSet resultProgramRate = null;

	static Connection connection = null;
	public static final String ADDHOC_BUTTON = "Add hoc Button";
	public static final String QUARTERLY_BUTTON = "Add hoc Button";
	public static final String GENERATE_FILE_OPTION_CHECKBOX = "Generate file option checkbox";
	public static final String NEXT_BUTTON = "Next Button";
	public static final String OK_BUTTON = "OK Button";
	public static final String CANCEL_BUTTON = "Cancel Button";
	public static final String GENERATE_FEE_SUCESS_MESSAGE = "Generate Fee Sucess Message";
	public static final String SELECT_BILLING_SCREEN = "Select Billing Screen";
	public static final String CONFIRM_AND_PROCESS_BUTTON = "Confirm and Process Button";
	public static final String QUARTER_ENDDATE_TEXT = "Quarter End Date";
	public static final String ACCOUNT_NUMBER_TEXT = "Account Number";
	public static final String QUERY = "Query";
	public static final String ADDHOC = "Add hoc";
	public static final String ANY_USER_RUNNING_ADHOC = "is currently using Ad-Hoc";
	public static final String ANY_USER_RUNNING_QUARTERLY = "is currently using Quarterly";
	public static final String CONFIRM_FAILURE_BUTTON = "Confirm failure button";
	public static final String DATABASE_PASSWORD = "h2}9MGYsh(=}+'EK";
	public static final String ACCOUNT_DETAILS_REPORT = "Account Details Report";
	public static final String RUN_REPORT_BUTTON = "Run Report button";
	public static final String FEEBILLING_RUNNING_USER = "Fee billing Running User";
	public static final String FEEBILLING_PAGE_HEADER = "Fee Billing Page Header";
	public static final String ACCOUNT_DETAILS_REPORT_OPTION_TITLE = "Account Details Report Options Title";
	public static final String DRIVER_CLASS_NAME = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static final String DB_CONNECT_URL = "jdbc:sqlserver://<<DB_SERVER>>;databaseName=<<DB_NAME>>;integratedSecurity=true";
	public static final String DB_SERVER_PLACEHOLDER = "<<DB_SERVER>>";
	public static final String DB_NAME_PLACEHOLDER = "<<DB_NAME>>";
	public static final String ADMIN_BUTTON = "Admin button";
	public static final String SET_STATUS_COMPLETE = "Set status complete button";
	public static final String ACCOUNT_LIST_NAME = "Account List Name";
	public static final String EMPTY_STRING = "";
	public static final String TRUE = "true";
	public static final String SWS_MS = "SWS MS";
	public static final String SWS_MWP = "SWS MWP";
	public static final String SWS_SAMII = "SWS SAM2";
	public static final String NON_SWS = "Non SWS";
	public static final String EM_MWP = "Employee Model MWP";
	public static final String EM_MS = "Employee Model MS";
	public static final String EM_SAMII = "Employee Model SAM2";
	public static final String EM_PWP = "Employee Model PWP";
	public static final String EM_OMP = "Employee Model OMP";
	public static final String NON_EM = "Non Employee Model";

	public FeeBilling(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strFeeBillingHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				FEEBILLING_PAGE_HEADER);
	}

	/**
	 * This method is used to verify if anyone Blocked FeeBilling Adhoc
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/26/2020
	 */
	public boolean completeTheProcessIfAnyUserBlockedFeeBilling() {
		// Complete fee-billing process
		return completeFeeBillingProcess();
	}

	/**
	 * This method is used to complete FeeBilling Process
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/01/2020
	 */
	private boolean completeFeeBillingProcess() {
		// check if any user is running fee-billing
		boolean blncheckIfAnyuserNotRunningFeeBiling = isElementNotPresentUsingXpath(
				strIfAnyUserRunningFeeBillingXpath);
		if (!blncheckIfAnyuserNotRunningFeeBiling) {
			// check if any user is running adhoc or quarterly
			String feebillingRunningUser = getTextUsingXpath(strFeeBillingRunningAutomationUserXpath,
					FEEBILLING_RUNNING_USER).trim();
			// If user running adhoc
			if (feebillingRunningUser.contains(ANY_USER_RUNNING_ADHOC)) {
				// complete Process For Adhoc
				return completeProcessForAdhoc();
			}
			// If user running quarterly
			else if (feebillingRunningUser.contains(ANY_USER_RUNNING_QUARTERLY))
				// complete Process For Quarterly
				return completeProcessForQuarterly();
			else
				// If no user is running Adhoc or Quarterly then return true
				return true;
		}
		// If no user is running Adhoc or Quarterly then return true
		return true;
	}

	/**
	 * This method is used to complete Process for Quarterly
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/01/2020
	 */
	private boolean completeProcessForQuarterly() {
		// Click on Quarterly button
		iClickOnQuarterlyButton();
		// Complete the Quarterly process
		return completeProcessforQuarterlyAndAdhoc();
	}

	/**
	 * This method is used to complete Process for both Quarterly and Adhoc
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/11/2020
	 */
	private boolean completeProcessforQuarterlyAndAdhoc() {
		// Check for Confirm failure button is present or not
		boolean blnConfirmFailureNotPresent = isElementNotPresentUsingXpath(strConfirmFailureXpath);
		// Check for Ok button is present or not
		boolean blnOkButtonNotPresent = isElementNotPresentUsingXpath(strOkButtonXpath);
		// Check for Cancel button is present or not
		boolean blnCancelButtonNotPresent = isElementNotPresentUsingXpath(strCancelButtonXpath);
		// Check for Admin button If Failed due to some issue
		boolean blnAdminButtonNotPresent = isElementNotPresentUsingXpath(strAdminButtonXpath);
		if (!blnConfirmFailureNotPresent) {
			// Click on confirm Failure button
			return clickElementUsingXpath(strConfirmFailureXpath, CONFIRM_FAILURE_BUTTON);
		} else if (!blnOkButtonNotPresent) {
			// Click on Ok and cancel button
			iclickonOkButton();
			return iclickonCancel();
		} else if (!blnCancelButtonNotPresent) {
			// Click on cancel button
			return iclickonCancel();
		} else if (!blnAdminButtonNotPresent) {
			// Click on Admin and set status to complete button if failed for some reason
			clickElementUsingXpath(strAdminButtonXpath, ADMIN_BUTTON);
			return clickElementUsingXpath(strSetStatusCompleteButtonXpath, SET_STATUS_COMPLETE);
		} else {
			// Adhoc or Quarterly fee-billing run is in -progress
			return false;
		}
	}

	/**
	 * This method is used to complete Process for Addhoc
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 09/01/2020
	 */
	private boolean completeProcessForAdhoc() {
		// Click on Addhoc button
		iClickOnAdhocButton();
		// Complete the Adhoc process
		return completeProcessforQuarterlyAndAdhoc();
	}

	/**
	 * This method is used to Click On Add-hoc Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/26/2020
	 */
	public boolean iClickOnAdhocButton() {
		return clickElementUsingXpath(strAddhocButtonXpath, ADDHOC_BUTTON);
	}

	/**
	 * This method is used to Click On Quarterly Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/17/2020
	 */
	public boolean iClickOnQuarterlyButton() {
		return clickElementUsingXpath(strQuarterlyButtonXpath, QUARTERLY_BUTTON);
	}

	/**
	 * This method is used to verify Select Billing screen displayed or Not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06-26-2020
	 */
	public boolean iShouldLandOnSelectBillingScreen() {
		return isElementPresentUsingXpath(strSelectBillingScreenXpath, LPLCoreConstents.getInstance().HIGH,
				SELECT_BILLING_SCREEN);

	}

	/**
	 * This method is used to enter quarter end date
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06-26-2020
	 */
	public boolean iEnterQuarterEndDate() {
		return enterTextUsingXpath(strQuaterEndDateXpath, testData.get("strQuaterEndDate"), QUARTER_ENDDATE_TEXT);
	}

	/**
	 * This method is used to verify Account Number entered or Not
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 08-17-2020
	 */
	public boolean iEnterAccountList() {
		waitTillVisibleUsingXpath(strAccountListXpath, LPLCoreConstents.getInstance().HIGH, ACCOUNT_LIST_NAME);
		return enterTextUsingXpath(strAccountListXpath, testData.get("strAccountList"), ACCOUNT_LIST_NAME);
	}

	/**
	 * This method is used to Click On Generate File option
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/26/2020
	 */
	public boolean iSelectGenerateFileoption() {
		return clickElementUsingXpath(strGenerateFileCheckboxXpath, GENERATE_FILE_OPTION_CHECKBOX);
	}

	/**
	 * This method is used to Click On Next Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/26/2020
	 */
	public boolean iClickonNextbutton() {
		return clickElementUsingXpath(strNextButtonXpath, NEXT_BUTTON);
	}

	/**
	 * This method is used to Click On Confirm Process Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/26/2020
	 */
	public boolean iClickonConfirmProcess() {
		// Check for Confirm and and Process button and then click
		waitTillVisibleUsingXpath(strConfirmAndProcessXpath, LPLCoreConstents.getInstance().HIGH,
				CONFIRM_AND_PROCESS_BUTTON);
		return clickElementUsingXpath(strConfirmAndProcessXpath, CONFIRM_AND_PROCESS_BUTTON);
	}

	/**
	 * This method is used to verify Ok button displayed or Not
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06-26-2020
	 */
	public boolean iShouldseeOkButtonDisplayed() {
		// hard coded maximum wait (1200) Since it will take 10 to 15 minutes to execute
		// the whole fee billing process and We doesn't have such number in
		// lplCoreConstants to use it
		return isElementPresentUsingXpath(strOkButtonXpath, 1200, OK_BUTTON);
	}

	/**
	 * This method is used to Click On OK Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/26/2020
	 */
	public boolean iclickonOkButton() {
		return clickElementUsingXpath(strOkButtonXpath, OK_BUTTON);
	}

	/**
	 * This method is used to Click On Account Details Report link
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 07/30/2020
	 */

	public boolean clickOnAccountDetailsReport() {
		return clickElementUsingXpath(strAccountDetailsReportLinkXpath, ACCOUNT_DETAILS_REPORT);
	}

	/**
	 * This method is used to verify Account Details Report Options
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 07/30/2020
	 */

	public boolean seeAccountDetailsReportOptions() {
		return isElementPresentUsingXpath(strAccountDetailsReportOptionsTitleXpath,
				ACCOUNT_DETAILS_REPORT_OPTION_TITLE);
	}

	/**
	 * This method is used to enter Account Number in Account Details Report Options
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 07/30/2020
	 */

	public boolean enterAccountNumberInAccountDetailReportOptions() {
		return enterTextUsingXpath(strAccountNumberTextBoxOnAccountDetailsXpath, testData.get("strAccountNumber"),
				ACCOUNT_NUMBER_TEXT);

	}

	/**
	 * This method is used to click on Run Report button
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 07/30/2020
	 */
	public boolean clickOnRunReport() {
		return clickElementUsingXpath(strRunReportButtonOnAccountDetailsXpath, RUN_REPORT_BUTTON);
	}

	/**
	 * This method is used to verify Account Details report is visible
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 08/03/2020
	 */
	public boolean verifyTheAccountDetailsReport() {
		return isElementPresentUsingXpath(strAccountDetailsHeaderInReport, LPLCoreConstents.getInstance().LOW, ADDHOC);
	}

	/**
	 * This method is used to validate Account Details Report data
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 08/06/2020
	 */
	public boolean validateAccountDetailsReportData() {
		return validateReportData();
	}

	/**
	 * This method is used to validate the Report Data
	 * 
	 * @return boolean
	 *
	 * @author H Abdul Hadi
	 * @since 08/05/2020
	 */
	private boolean validateReportData() {
		boolean blnAccountDisplayed;
		boolean blnQuarterEnddateDisplayed;
		boolean blnAddhocHeaderTextDisplayed;
		List<String> browserActiveTabs = getActiveBrowserTabs();
		switchToSecondTab(browserActiveTabs);
		refreshTheWebpage();
		logInNewTabOpening();
		blnAccountDisplayed = isElementPresentUsingXpath(
				getFormattedLocator(strAccountnoInReportXpath, testData.get("strAccountNumber")),
				LPLCoreConstents.getInstance().HIGH, ACCOUNT_NUMBER_TEXT);
		blnQuarterEnddateDisplayed = isElementPresentUsingXpath(
				getFormattedLocator(strQuarterEndDateInReportXpath, testData.get("strQuarterEndDate")),
				LPLCoreConstents.getInstance().LOW, QUARTER_ENDDATE_TEXT);
		blnAddhocHeaderTextDisplayed = isElementPresentUsingXpath(
				getFormattedLocator(strAddhocHeaderTextInReportXpath, ADDHOC), LPLCoreConstents.getInstance().LOW,
				ADDHOC);
		closeDriver();
		switchToFirstTab(browserActiveTabs);
		iclickonCancel();
		return (blnAccountDisplayed && blnQuarterEnddateDisplayed && blnAddhocHeaderTextDisplayed);
	}

	/**
	 * This method is used to Click On Cancel Button
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 06/26/2020
	 */
	public boolean iclickonCancel() {
		return clickElementUsingXpath(strCancelButtonXpath, CANCEL_BUTTON);
	}

	/**
	 * This method is used to connect To Bods SqlServer
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/21/2020
	 */
	public static void connectToBodsSqlServer() {
		Connection connection;
		connection = getConnection(testData.get("strServerName"), testData.get("strDatabaseName"),
				testData.get("strIsWindowsAuthentication"), testData.get("strUserName"), DATABASE_PASSWORD);
	}

	/**
	 * This method is used to run the SQL Query to validate if SWS Account exist in
	 * data
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 08/20/2020
	 */
	public void runTheSQLQueryToValidateIfSpecificAccountExistInData(String accountType) {
		String query = EMPTY_STRING;
		if (accountType.equals(SWS_MS))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_SWS_MS_ACCOUNT_EXIST_IN_DATA_SCENARIO1;
		if (accountType.equals(SWS_MWP))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_SWS_MWP_ACCOUNT_EXIST_IN_DATA_SCENARIO2;
		if (accountType.equals(SWS_SAMII))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_SWS_SAM2_ACCOUNT_EXIST_IN_DATA_SCENARIO3;
		if (accountType.equals(NON_SWS))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_NON_SWS_ACCOUNT_EXIST_IN_DATA_SCENARIO4;
		if (accountType.equals(EM_MWP))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_EM_MWP_ACCOUNT_EXIST_IN_DATA_SCENARIO6;
		if (accountType.equals(EM_MS))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_EM_MS_ACCOUNT_EXIST_IN_DATA_SCENARIO7;
		if (accountType.equals(EM_SAMII))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_EM_SAM2_ACCOUNT_EXIST_IN_DATA_SCENARIO8;
		if (accountType.equals(EM_PWP))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_EM_PWP_ACCOUNT_EXIST_IN_DATA_SCENARIO9;
		if (accountType.equals(EM_OMP))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_EM_OMP_ACCOUNT_EXIST_IN_DATA_SCENARIO10;
		if (accountType.equals(NON_EM))
			query = DatabaseQueries.FB_QUERY_TO_VALIDATE_IF_NON_EM_ACCOUNT_EXIST_IN_DATA_SCENARIO11;

		resultOutput = getQueryResult(connection, query);
	}

	/**
	 * This method is used to verify that SWS Account exist in the data
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 07/21/2020
	 */
	public boolean verifyResultsProveThatAccountExistInData() {
		boolean blnResult = false;
		try {
			while (resultOutput.next()) {
				int resultCount = resultOutput.getInt("result_count");
				if (resultCount != 0)
					blnResult = true;
			}
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			printReport(e);
		}
		resultOutput = null;
		return blnResult;
	}

	/**
	 * This method is used to run the SQL Query to validate Premium Fee rates
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/21/2020
	 */
	public void runTheSQLQueryToValidatePremiumFeeRatesAndFees() {
		resultPremiumAccountData = getQueryResult(connection,
				DatabaseQueries.FB_QUERY_TO_VALIDATE_PREMIUM_FEES_SCENARIO5);
	}

	/**
	 * This method is used to verify the Premium Fee Rates Calculated Accurately
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi
	 * @since 07/21/2020
	 */
	public boolean verifyResultsProveThatPremiumFeeRatesFeesCalculatedAccurately() {
		boolean blnResult = false;
		try {
			while (resultPremiumAccountData.next()) {
				int resultCount = resultPremiumAccountData.getInt("result_count");
				blnResult = resultCount == 0;
			}
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			printReport(e);
		}
		return blnResult;
	}

	/**
	 * This method is used to get SQL connection database
	 * 
	 * @param serverName
	 * @param databaseName
	 * @param isWindowsAuthentication
	 * @param userName
	 * @param password
	 * @return Connection
	 * @author Abdul Hadi
	 * @since 22-07-2020
	 */
	public static Connection getConnection(String serverName, String databaseName, String isWindowsAuthentication,
			String userName, String password) {
		try {
			String url = null;
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			url = generateConnectionString(serverName, databaseName, isWindowsAuthentication, userName, password);
			System.out.println("URL is " + url);
			connection = DriverManager.getConnection(url);
		} catch (Exception e) {
			LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Establishing the database connection",
					"Connection should be established successfully", "Connection is established successfully",
					"Exception occured while establishing the connection. Error message: " + e.getMessage(), false);
		}
		return connection;
	}

	/**
	 * This method is used to generate database connection string dynamically
	 * 
	 * @param serverName
	 * @param databaseName
	 * @param isWindowsAuthentication
	 * @param userName
	 * @param password
	 * @return connection string
	 * @author H Abdul Hadi
	 * @since 07-22-2020
	 */
	private static String generateConnectionString(String serverName, String databaseName,
			String isWindowsAuthentication, String userName, String password) {
		String url;
		if (isWindowsAuthentication != null && isWindowsAuthentication.equals(TRUE))
			url = "jdbc:sqlserver://" + serverName + ";databaseName=" + databaseName + ";integratedSecurity=true;";
		else
			url = "jdbc:sqlserver://" + serverName + ";databaseName=" + databaseName + ";user=" + userName
					+ ";password=" + password;
		return url;
	}

	/**
	 * This method is used to get resultset for given connection object and query
	 * 
	 * @param connection
	 * @param queryText
	 * @return ResultSet
	 * @author H Abdul Hadi
	 * @since 07-22-2020
	 */
	public static ResultSet getQueryResult(Connection connection, String queryText) {
		ResultSet queryResult = null;
		try (Statement statement = connection.createStatement()) {
			queryResult = statement.executeQuery(queryText);
		} catch (SQLException e) {
			printReport(queryText, e);
		}
		return queryResult;
	}

	/**
	 * This method is used to to print the report while executing the query
	 * 
	 * @param queryText
	 * @param SQLException
	 * @author Abdul Hadi
	 * @since 07-22-2020
	 */
	private static void printReport(String queryText, SQLException e) {
		LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Execute the query [" + queryText + "]",
				"Query should be executed successfully", "Query is executed successfully",
				"Exception occurred when executing the query. Please recheck the query. Error message:  "
						+ e.getMessage(),
				false);
	}

	/**
	 * This method is used to to print the report while fetching database data
	 * 
	 * @param SQLException
	 * @author Abdul Hadi
	 * @since 07-22-2020
	 */
	private static void printReport(SQLException e) {
		LPLCoreReporter.writeStepToReporter(false, LPLCoreConstents.TRUE, "Error on fetching database data",
				"Result should retrive successfully", "Result retrived successfully",
				"Exceptionoccured on  fetching database data. Please recheck the query. Error message:  "
						+ e.getMessage(),
				false);
	}

	/**
	 * This method is used to run sql query to find out expected Program Rate for
	 * MWP New Accounts on Schedule A
	 * 
	 * @author Sowmya Nagarajappa
	 * @since 09/15/2020
	 */
	public void runTheSQLQueryToIdentifyExpectedAndActualScheduleAProgramRateUsingAccountAUM() {
		resultProgramRate = getQueryResult(connection,
				DatabaseQueries.FEE_BILLING_QUERY_TO_VALIDATE_MWP_PROGRAMRATE_EXPECTED);

	}

	/**
	 * This method is used to verify the Premium Fee Rates Calculated Accurately
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 09/23/2020
	 */
	public boolean verifyThatResultsToProveThatScheduleAProgramRateUsedInFeeBillingIsDerivedFromAccountAUM() {
		boolean blnResult = false;
		try {
			while (resultProgramRate.next()) {
				int resultCount = resultProgramRate.getInt("result_count");
				if (resultCount == 0)
					blnResult = true;
			}
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			printReport(e);
		}
		return blnResult;
	}

	/**
	 * This method is used to close SQL connection
	 * 
	 * @param Connection
	 * @author Abdul Hadi
	 * @since 07-22-2020
	 */
	public static void closeDatabaseConnection(Connection connection) {
		try {
			connection.close();
		} catch (SQLException e) {
			LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
					"Closing the Database Connection", "Database Connection should be closed successfully",
					"Database Connection is closed successfully",
					"Error occured while closing the database connection: " + e.getMessage(), false);
		}
	}

	/**
	 * This method is used to run the SQL Query to validate Employee Rebate
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 01/14/2021
	 */
	public void runTheSQLQueryToValidateEmployeeRebate() {
		String connectionString = generateConnectionString(testData.get("strServerName"),
				testData.get("strDatabaseName"), testData.get("strIsWindowsAuthentication"),
				testData.get("strUserName"), DATABASE_PASSWORD);
		try (Connection con = DriverManager.getConnection(connectionString);
				Statement sqlStatement = con.createStatement()) {
			resultEMAccountData = sqlStatement.executeQuery(DatabaseQueries.FB_QUERY_TO_VALIDATE_EM_REBATES_SCENARIO12);
		} catch (SQLException e) {
			printReport(e);
		}
	}

	/**
	 * This method is used to verify the Employee Rebate Calculated Accurately
	 * 
	 * @return boolean
	 *
	 * @author Nikhil Bajaj
	 * @since 01/14/2021
	 */
	public boolean verifyResultsProveThatEmployeeRebateCalculatedAccurately() {
		boolean blnResult = false;
		try {
			while (resultEMAccountData.next()) {
				int resultCount = resultEMAccountData.getInt("result_count");
				if (resultCount == 0)
					blnResult = true;
			}
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			printReport(e);
		}
		return blnResult;
	}

}
