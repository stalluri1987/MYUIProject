package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreReporter;
import LPLCoreDriver.LPLCoreSync;
import io.cucumber.datatable.DataTable;

/**
 * <p>
 * <br>
 * <b> Title: </b> StyleCodeMapping.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for StyleCodeMapping</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author abagchi
 * @since 07/20/2020
 *        </p>
 */

public class StyleCodeMapping extends Common implements ILocatorInitialize {
	static final int PAGE_IDENTIFIER = 823;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String USER_SHOULD_BE_ABLE_TO_SEE = "User should be able to see ";
	public static final String SUCCESSFULLY_ABLE_TO_SEE = "Successfully able to see ";
	public static final String OPTIONS = "options";
	public static final String FAILED_TO_SEE = "Failed to see ";
	public static final String STYLE_CODE_MAPPING_PAGE_HEADER = "Style Code Mapping Page Header";
	public static final String FISERV_MAPPED_PAGE = "Fiserv Mapped Page";
	public static final String EDIT_MANAGER_STYLE_LINK = "Edit Manager Style Link";
	public static final String SEARCH_BUTTON = "Search Button";
	public static final String VESTMARK_UNMAPPED_PAGE = "Vestmark Unmapped Page";
	public static final String ADD_MANGER_STYLE_LINK = "Add Manager Style Link";
	public static final String SLEEVE_MAPPING_POPUP = "Sleeve Mapping pop up";
	public static final String SLEEVE_TAG = "Sleeve Tag";
	public static final String MODEL_NAME = "Model Name";
	public static final String PROGRAM = "Program";
	public static final String MODEL_STYLECODE_RIA = "Model Style Code RIA";
	public static final String MODEL_STYLECODE_LPLCORP = "Model Style Code LPL Corp";
	public static final String MODEL_STYLECODE_RIA_ERISA = "Model Style Code RIA ERISA";
	public static final String MODEL_STYLECODE_LPL_CORP_ERISA = "Model Style Code LPL Corp ERISA";
	public static final String DEFAULT_VALUE = "";
	public static final String SUBMIT_BUTTON = "Submit Button";
	public static final String STYLECODE_DROPDOWN = "Style Code Drop Down";
	public static final String CLOSE_BUTTON = "Close Button";
	public static final String CANCEL_BUTTON = "Cancel Button";

	String strStyleCodeMappingHeaderXpath;
	String strFiservUnMappedTabXpath;
	String strFiservUnMappedTableXpath;
	String strFiservTableHeadersXpath;
	String strSearchedFieldsXpath;
	String strSearchButtonXpath;
	String strTableHeadersXpath;
	String strEditManagerStyleLinkXpath;
	String strVestmarkTableHeadersXpath;
	String strVestmarkUnMappedTabXpath;
	String strVestmarkAddManagerStyleLinkXpath;
	String strSleeveMappingPopupVestmarkXpath;
	String strSleeveTagVestmarkXpath;
	String strmodelNameVestmarkXpath;
	String strProgramVestmarkXpath;
	String strModelStyleCodeRIAVestmarkXpath;
	String strModelStyleCodeLPLCorpVestmarkXpath;
	String strModelStyleCodeRIAERISAXpath;
	String strModelStyleCodeLPLCorpERISAXpath;
	String strFiservMappedTabXpath;
	String strRIAStyleCodeTextBoxXpath;
	String strRIATextBoxXpath;
	String strLPLCORPTextBoxXpath;
	String strRIAStyleCodeGridXpath;
	String strLPLCORPStyleCodeGridXpath;
	String strSubmitButtonXpath;
	String strMappedTabXpath;
	String strRIADropDownXpath;
	String strLPLCORPDropDownXpath;
	String strCloseButtonXpath;
	String strCancelButtonXpath;
	String strRIAERISATextBoxXpath;
	String strLPLCorpERISATextBoxXpath;
	String strFiservAddManagerStyleLinkXpath;
	String strLPLCORPERISADropDownXpath;
	String strRIAERISADropDownXpath;
	String strRIAERISATextBox = testData.get("strRIAERISATextBox");
	String strLPLCorpERISATextBox = testData.get("strLPLCorpERISATextBox");

	public StyleCodeMapping(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author abagchi
	 * @since 07-20-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strStyleCodeMappingHeaderXpath, LPLCoreConstents.getInstance().LOWEST,
				STYLE_CODE_MAPPING_PAGE_HEADER);
	}

	/**
	 * This method is used to check fiserv mapped page load
	 * 
	 * @return boolean
	 *
	 * @author abagchi
	 * @since 07-20-2020
	 */
	public boolean iShouldlandonFiservunMappedPage() {
		return isElementPresentUsingXpath(strFiservUnMappedTableXpath, LPLCoreConstents.getInstance().MEDIUM,
				FISERV_MAPPED_PAGE);
	}

	/**
	 * This method is used to verify the Availability of Fiserv Unmapped Sleeve
	 * Details Options
	 * 
	 * @return boolean
	 *
	 * @author abagchi
	 * @since 07-20-2020
	 */
	public boolean iVerifytheAvailabilityofFiservUnmappedSleeveDetailsOptions(DataTable sleeveDetailsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = sleeveDetailsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkSleeveDetailsOption(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check Sleeve Details Option
	 * 
	 * @return boolean
	 *
	 * @author abagchi
	 * @since 07-20-2020
	 */
	public boolean checkSleeveDetailsOption(String sleeveDetailsOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strFiservTableHeadersXpath, sleeveDetailsOption),
				sleeveDetailsOption);
	}

	/**
	 * This method is used to choose Mapped Tab
	 * 
	 * @return boolean
	 *
	 * @author ahadi
	 * @since 09-18-2020
	 */
	public boolean chooseTab(String selectTab) {
		String tabTypeLocator = getFormattedLocator(strFiservMappedTabXpath, selectTab);
		return clickElementUsingXpath(tabTypeLocator, selectTab);
	}

	/**
	 * This method is used to choose Fiserv UnMapped Tab
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 01-11-2021
	 */
	public boolean selectFiservUnmappedTab(String selectTab) {
		String tabTypeLocator = getFormattedLocator(strFiservUnMappedTabXpath, selectTab);
		return clickElementUsingXpath(tabTypeLocator, selectTab);
	}

	/**
	 * This method is used to verify the Availability Of Search Field Under Mapped
	 * Tab
	 * 
	 * @return boolean
	 *
	 * @author ahadi
	 * @since 09-18-2020
	 */
	public boolean verifyAvailabilityOfSearchFieldUnderMappedTab(String searchFields) {
		return isElementPresentUsingXpath(getFormattedLocator(strSearchedFieldsXpath, searchFields), searchFields);
	}

	/**
	 * This method is used to verify the Availability Of Search Fields Under Mapped
	 * Tab
	 * 
	 * @return boolean
	 *
	 * @author ahadi
	 * @since 09-18-2020
	 */
	public boolean verifyAvailabilityOfSearchFieldsUnderMappedTab(DataTable searchFields) {
		boolean blnResult = false;
		List<Map<String, String>> filters = searchFields.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyAvailabilityOfSearchFieldUnderMappedTab(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check whether search Button Displayed or not
	 * 
	 * @return boolean
	 *
	 * @author ahadi
	 * @since 09-18-2020
	 */
	public boolean searchButtonDisplayed() {
		return isElementPresentUsingXpath(strSearchButtonXpath, LPLCoreConstents.getInstance().MEDIUM, SEARCH_BUTTON);
	}

	/**
	 * This method is used to verify the Availability Of Search Field Under Mapped
	 * Tab
	 * 
	 * @return boolean
	 *
	 * @author ahadi
	 * @since 09-18-2020
	 */
	public boolean verifyAvailabilityOfGridHeaderUnderMappedTab(String gridHeader) {
		return isElementPresentUsingXpath(getFormattedLocator(strTableHeadersXpath, gridHeader), gridHeader);
	}

	/**
	 * This method is used to verify the Availability Of Grid Headers Under Mapped
	 * Tab
	 * 
	 * @return boolean
	 *
	 * @author ahadi
	 * @since 09-18-2020
	 */
	public boolean verifyAvailabilityOfGridHeadersUnderMappedTab(DataTable gridHeaders) {
		boolean blnResult = false;
		List<Map<String, String>> filters = gridHeaders.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = verifyAvailabilityOfGridHeaderUnderMappedTab(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check for Edit Manager Style link Under Grid
	 * 
	 * @return boolean
	 *
	 * @author ahadi
	 * @since 09-18-2020
	 */
	public boolean editManagerStylelinkDisplayedUnderGrid() {
		return isElementPresentUsingXpath(strEditManagerStyleLinkXpath, LPLCoreConstents.getInstance().MEDIUM,
				EDIT_MANAGER_STYLE_LINK);
	}

	/**
	 * This method is used to check Vestmark Unmapped page load
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-26-2020
	 */
	public boolean iShouldlandonVestmarkUnMappedPage() {
		return isElementPresentUsingXpath(strVestmarkUnMappedTabXpath, LPLCoreConstents.getInstance().MEDIUM,
				VESTMARK_UNMAPPED_PAGE);
	}

	/**
	 * This method is used to verify the Availability of Vestmark Unmapped Sleeve
	 * Details Options
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-25-2020
	 */
	public boolean iVerifytheAvailabilityofVestmarkUnmappedSleeveDetailsOptions(DataTable sleeveDetailsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = sleeveDetailsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkSleeveDetailsOptionVestmark(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to check Sleeve Details Option for Vestmark
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-25-2020
	 */
	public boolean checkSleeveDetailsOptionVestmark(String sleeveDetailsOption) {
		return isElementPresentUsingXpath(getFormattedLocator(strVestmarkTableHeadersXpath, sleeveDetailsOption),
				sleeveDetailsOption);
	}

	/**
	 * This method is used to click on Add Manager Sytle Link in Vestmark tab
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11/26/2020
	 */
	public boolean iClickonVestmarkAddManagerStyleLink() {
		return clickElementUsingXpath(strVestmarkAddManagerStyleLinkXpath, ADD_MANGER_STYLE_LINK);
	}

	/**
	 * This method is used to click on Add Manager Sytle Link in Fiserv tab
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11/26/2020
	 */
	public boolean iClickonFiservAddManagerStyleLink() {
		return clickElementUsingXpath(strFiservAddManagerStyleLinkXpath, ADD_MANGER_STYLE_LINK);
	}

	/**
	 * This method is used to check Sleeve Mapping pop up for Vestmark is displayed
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-25-2020
	 */
	public boolean sleeveMappingPopupVestmarkDisplayed() {
		return isElementPresentUsingXpath(strSleeveMappingPopupVestmarkXpath, LPLCoreConstents.getInstance().FAIR,
				SLEEVE_MAPPING_POPUP);
	}

	/**
	 * This method is used to check Sleeve Tag is displayed in Vestmark Sleeve
	 * Mapping pop up
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-27-2020
	 */
	public boolean sleeveTagVestmarkSleeveMappingPopUp() {
		return isElementPresentUsingXpath(strSleeveTagVestmarkXpath, LPLCoreConstents.getInstance().FAIR, SLEEVE_TAG);
	}

	/**
	 * This method is used to check Model Name is displayed in Vestmark Sleeve
	 * Mapping pop up
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-27-2020
	 */
	public boolean modelNameVestmarkSleeveMappingPopUp() {
		return isElementPresentUsingXpath(strmodelNameVestmarkXpath, LPLCoreConstents.getInstance().FAIR, MODEL_NAME);
	}

	/**
	 * This method is used to check Program is displayed in Vestmark Sleeve Mapping
	 * pop up
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-27-2020
	 */
	public boolean programVestmarkSleeveMappingPopUp() {
		return isElementPresentUsingXpath(strProgramVestmarkXpath, LPLCoreConstents.getInstance().FAIR, PROGRAM);
	}

	/**
	 * This method is used to check Model StyleCode RIA is displayed in Vestmark
	 * Sleeve Mapping pop up
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-27-2020
	 */
	public boolean modelStyleCodeRIAVestmarkSleeveMappingPopUp() {
		return isElementPresentUsingXpath(strModelStyleCodeRIAVestmarkXpath, LPLCoreConstents.getInstance().FAIR,
				MODEL_STYLECODE_RIA);
	}

	/**
	 * This method is used to check Model StyleCode LPLCorp is displayed in Vestmark
	 * Sleeve Mapping pop up
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-27-2020
	 */
	public boolean modelStyleCodeLPLCorpVestmarkSleeveMappingPopUp() {
		return isElementPresentUsingXpath(strModelStyleCodeLPLCorpVestmarkXpath, LPLCoreConstents.getInstance().FAIR,
				MODEL_STYLECODE_LPLCORP);
	}

	/**
	 * This method is used to check grid fields in Vestmark Sleeve Mapping pop up
	 * Details Options
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-29-2020
	 */
	public boolean sleeveTagMappingPopUp(DataTable sleeveDetailsOptions) {
		boolean blnResult = false;
		List<Map<String, String>> filters = sleeveDetailsOptions.asMaps(String.class, String.class);
		for (Map<String, String> data : filters) {
			String filterName = data.get(OPTIONS);
			blnResult = checkSleeveDetailsOptionVestmark(filterName);
			LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
					USER_SHOULD_BE_ABLE_TO_SEE + filterName, USER_SHOULD_BE_ABLE_TO_SEE + filterName,
					SUCCESSFULLY_ABLE_TO_SEE + filterName, FAILED_TO_SEE + filterName + " : " + Common.strError);
		}
		return blnResult;
	}

	/**
	 * This method is used to click on Mapped tab
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/01/2020
	 */
	public boolean ClickOnMappedTab() {
		return clickElementUsingXpath(strMappedTabXpath, LPLCoreConstents.getInstance().FAIR, FISERV_MAPPED_PAGE);
	}

	/**
	 * This method is used to click on Edit Manager Style Link
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11/30/2020
	 */
	public boolean ClickonEditManagerStyleLink() {
		isElementPresentUsingXpath(strEditManagerStyleLinkXpath, LPLCoreConstents.getInstance().HIGH, EDIT_MANAGER_STYLE_LINK);
		return clickElementUsingXpath(strEditManagerStyleLinkXpath, LPLCoreConstents.getInstance().FAIR,
				EDIT_MANAGER_STYLE_LINK);
	}

	/**
	 * This method is used to check Model Style Code - RIA - ERISA is displayed in
	 * Edit Manager Style pop up
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-30-2020
	 */
	public boolean modelStyleCodeRIAERISASleeveMappingPopUp() {
		return isElementPresentUsingXpath(strModelStyleCodeRIAERISAXpath, LPLCoreConstents.getInstance().FAIR,
				MODEL_STYLECODE_RIA_ERISA);
	}

	/**
	 * This method is used to check Model Style Code - LPL Corp - ERISA is displayed
	 * in Edit Manager Style pop up
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11-30-2020
	 */
	public boolean modelStyleCodeLPLCorpERISASleeveMappingPopUp() {
		return isElementPresentUsingXpath(strModelStyleCodeLPLCorpERISAXpath, LPLCoreConstents.getInstance().FAIR,
				MODEL_STYLECODE_LPL_CORP_ERISA);
	}

	/**
	 * This method is used to clear Model Style Code - RIA - ERISA field
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/01/2020
	 */
	public boolean clearModelStyleCodeRIAERISAField() {
		return enterTextUsingXpath(strRIAERISATextBoxXpath, DEFAULT_VALUE, MODEL_STYLECODE_RIA_ERISA);

	}

	/**
	 * This method is used to enter RIA ERISA Style Code
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/01/2020
	 */
	public boolean enterRIAERISAStyleCode() {
		return enterTextUsingXpath(strRIAERISATextBoxXpath, testData.get("strRIAERISATextBox"),
				MODEL_STYLECODE_RIA_ERISA);
	}

	/**
	 * This method is used to select RIA ERISA Style Code from drop down
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/08/2020
	 */
	public boolean selectRIAERISAStyleCode() {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		return clickElementUsingXpath(strRIAERISADropDownXpath, LPLCoreConstents.getInstance().FAIR,
				MODEL_STYLECODE_RIA_ERISA);
	}

	/**
	 * This method is used to clear Model Style Code - LPL Corp - ERISA field
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/01/2020
	 */

	public boolean clearModelStyleCodeLPLCORPERISAField() {
		return enterTextUsingXpath(strLPLCorpERISATextBoxXpath, DEFAULT_VALUE, MODEL_STYLECODE_LPL_CORP_ERISA);
	}

	/**
	 * This method is used to enter LPL Corp ERISA Style Code
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * 
	 * @since 12/01/2020
	 */
	public boolean enterLPLCORPERISAStyleCode() {
		return enterTextUsingXpath(strLPLCorpERISATextBoxXpath, testData.get("strLPLCorpERISATextBox"),
				MODEL_STYLECODE_LPL_CORP_ERISA);
	}

	/**
	 * This method is used to select LPL Corp ERISA Style Code from drop down
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/08/2020
	 */
	public boolean selectLPLCORPERISAStyleCode() {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		return clickElementUsingXpath(strLPLCORPERISADropDownXpath, LPLCoreConstents.getInstance().FAIR,
				MODEL_STYLECODE_LPL_CORP_ERISA);
	}

	/**
	 * This method is used to click on Submit button
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 11/30/2020
	 */
	public boolean clickOnSubmitButton() {
		return clickElementUsingXpath(strSubmitButtonXpath, LPLCoreConstents.getInstance().FAIR, SUBMIT_BUTTON);
	}

	/**
	 * This method is used to click on Close button
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/08/2020
	 */
	public boolean clickOnCloseButton() {
		return clickElementUsingXpath(strCloseButtonXpath, LPLCoreConstents.getInstance().FAIR, CLOSE_BUTTON);
	}

	/**
	 * This method is used to verify RIA - ERISA displayed in the grid
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/01/2020
	 */
	public boolean verifyTheRIAERISADisplayedInTheGrid() {
		String erisaRISStyleCode = getTextUsingXpath(strRIAStyleCodeGridXpath, MODEL_STYLECODE_RIA_ERISA).trim()
				.substring(0, 3);
		return testData.get("strRIAERISATextBox").equalsIgnoreCase(erisaRISStyleCode);
	}

	/**
	 * This method is used to verify LPL CORP ERISA displayed in the grid
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/01/2020
	 */
	public boolean verifyTheLPLCORPERISADisplayedInTheGrid() {
		String erisaLPLCORPStyleCode = getTextUsingXpath(strLPLCORPStyleCodeGridXpath, MODEL_STYLECODE_LPL_CORP_ERISA)
				.trim().substring(0, 3);
		return testData.get("strLPLCorpERISATextBox").equalsIgnoreCase(erisaLPLCORPStyleCode);
	}

	/**
	 * This method is used to enter RIA Style Code
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/11/2020
	 */
	public boolean enterRIAStyleCode() {
		return enterTextUsingXpath(strRIATextBoxXpath, testData.get("strRIATextBox"), MODEL_STYLECODE_RIA);
	}

	/**
	 * This method is used to select RIA Style Code from drop down
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/11/2020
	 */
	public boolean selectRIAStyleCode() {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		return clickElementUsingXpath(strRIADropDownXpath, LPLCoreConstents.getInstance().FAIR, MODEL_STYLECODE_RIA);
	}

	/**
	 * This method is used to enter LPL Corp Style Code
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/11/2020
	 */
	public boolean enterLPLCORPStyleCode() {
		return enterTextUsingXpath(strLPLCORPTextBoxXpath, testData.get("strLPLCorpTextBox"), MODEL_STYLECODE_LPLCORP);
	}

	/**
	 * This method is used to select LPL Corp Style Code from drop down
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/11/2020
	 */
	public boolean selectLPLCORPStyleCode() {
		LPLCoreSync.staticWait(LPLCoreConstents.getInstance().MediumInMiliSec);
		return clickElementUsingXpath(strLPLCORPDropDownXpath, LPLCoreConstents.getInstance().FAIR,
				MODEL_STYLECODE_LPLCORP);
	}

	/**
	 * This method is used to click on Cancel button
	 * 
	 * @return boolean
	 *
	 * @author Sowmya Nagarajappa
	 * @since 12/11/2020
	 */
	public boolean clickOnCancelButton() {
		return clickElementUsingXpath(strCancelButtonXpath, LPLCoreConstents.getInstance().FAIR, CANCEL_BUTTON);
	}
}
