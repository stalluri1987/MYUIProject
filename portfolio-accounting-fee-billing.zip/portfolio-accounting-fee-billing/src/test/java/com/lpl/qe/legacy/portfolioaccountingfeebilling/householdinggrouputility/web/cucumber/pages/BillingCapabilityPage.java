package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreUtil;

public class BillingCapabilityPage extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 872;
	Map<String, HashMap<String, String>> pageObjectMap;
	String strEditBillingSubmitChangesBtnXpath;
	String strEditStreamlineBillingPencilIconXpath;
	String strStreamlineBillingXpath;
	String strBillingCapabilityTrackerTitleXpath;
	String strBillingInProgressXpath;
	String strFormReadyTrackerXpath;
	String strBillingTitleInTrackerXpath;
	String strFlatFeeXpath;
	String strFlatFeeValueXpath;
	String strFlatFeeValueSelectedXpath;
	String strDoneButtonXpath;
	String strCreateHouseHoldBillingSetUpButtonXpath;
	String strBillingConfirmationMsgXpath;
	String strBillingCapabilityTitleInTrackerXpath;
	String strEditbillingpagexpath;
	String strBillingFormEditHouseholdPageXpath;
	String strBillingFormIDXpath;
	String strClickAccountxpath;
	String strDeleteBillingCapabilityXpath;
	String strDeleteBillingModalXpath;
	String strHighlightedTierValueXpath;
	String strTierValueinEditBPXpath;
	String strEditDetailsButtonInReviewHBDpageXpath;
	String strBreakPointXpath;
	String strAdditionalScheduleXpath;
	String strAdditionalScheduleValueXpath;	
	String strReviewHouseholdBDPageXpath;
	String strViewPayoutScheduleLinkXpath;

	public static final String BILLING = "Billing";
	public static final String FLAT = "Flat";
	public static final String FLAT_RATE = "FLAT RATE";
	public static final String FLOATING_POINT = "0.0";
	public static final String BILLING_NAME_IN_TRACKER = " HOUSEHOLD BILLING";
	public static final String RESOURSE_CENTER = "https://clientworksqa.lpl.com/cw/resourcecenter/content/rc/departments/products/insurance/insurance-news-and-updates/new-compensation-payout-calendar.html";
	public BillingCapabilityPage(WebDriver driver) {
		super(driver);
		lplCoreUtil = new LPLCoreUtil();
		/** Fetching page objects from FARM */
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		checkForLocatorTypeAndInitializeFields(pageObjectMap, this.getClass().getDeclaredFields(), PAGE_IDENTIFIER);
	}

	/**
	 * This method is used to click on Edit billing submit changes button
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickBillingEditSubmitChangesButton() {
		return clickElementUsingXpath(strEditBillingSubmitChangesBtnXpath, 45, "Edit billing submit changes button");
	}

	/**
	 * This method is used to click on Streamline Billing Edit pencil icon
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickOnEditStreamlineBillingPencilIcon() {
		return clickElementUsingXpath(strEditStreamlineBillingPencilIconXpath,
				"Streamline Billing Edit pencil icon clicked");
	}
	
	/**
	 * This method is used to set up the StreamlineBilling for Household Group
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickStreamlineBillingButton() {

		return clickElementUsingXpath(strStreamlineBillingXpath, "strStreamlineBilling setup page");
	}
	
	/**
	 * This method is used to verify In Progress Billing Capability on billing
	 * details page
	 *
	 * @return boolean
	 * @author prchavan
	 */
	public boolean verifyBillingCapabilityinBilling() {
		return isElementPresentUsingXpath(strBillingCapabilityTrackerTitleXpath, lplCoreConstents.HIGH,
				"Billing Capability")
				&& isElementPresentUsingXpath(strBillingInProgressXpath, lplCoreConstents.HIGH, "In Progress");
	}
	
	/**
	 * This method is used to validate Billing Capability Title in Capability
	 * Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayBillingCapabilityTrackerTitle() {
		return isElementPresentUsingXpath(strBillingCapabilityTrackerTitleXpath, lplCoreConstents.HIGH,
				"Combined Statement Title displayed");

	}
	
	/**
	 * This method is used to validate 'Forms Ready To sign' Verbiage on Capability
	 * Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displaycapabilityTrackerFormsVerbiage() {
		return isElementPresentUsingXpath(strFormReadyTrackerXpath, lplCoreConstents.HIGH,
				"FORMS READY TO SIGN Verbiage displayed");

	}
	
	/**
	 * This method is used to validate Billing Capability Name in Capability Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displayCapabilityTrackerBillingName() {
		String[] clientName = testData.get("firstName").split(" ");
		System.out.println(clientName[1] + BILLING_NAME_IN_TRACKER);
		System.out.println(getTextUsingXpath(strBillingTitleInTrackerXpath, "Capability Tracker Billing Name"));
		return (getTextUsingXpath(strBillingTitleInTrackerXpath, "Capability Tracker Billing Name").equalsIgnoreCase(clientName[1] + BILLING_NAME_IN_TRACKER));

	}
	
	/**
	 * This method is used to select the StreamlineBilling Fee Type Flat Fee
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickFlatFeeTypeButton() {

		return clickElementUsingXpath(strFlatFeeXpath, "Fee Type Flat Fee selected");
	}
	
	/**
	 * This method is used to enter the Flat Fee Value
	 *
	 * @return boolean
	 * @param�Enter flatfee Value
	 * @author dshukla
	 */

	public boolean enterFlatFeeValue(String flatFee) {
		clickElementUsingXpath("//div[@title='Current Default Rate']/div/button/i", "Click edit fee rate");
		return enterTextUsingXpath(strFlatFeeValueXpath, flatFee, "Enter Flat Fee Value");

	}
	
	/**
	 * This method is used to select the Flat Fee Value
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickFlatFeeValue() {

		return clickElementUsingXpath(strFlatFeeValueSelectedXpath, "FlatFee value selected");

	}
	
	/**
	 * This method is used to click the Done button
	 *
	 * @return boolean
	 * @author dshukla
	 */

	public boolean clickDoneButton() {
		return clickElementUsingXpath(strDoneButtonXpath, lplCoreConstents.HIGHEST, "Done button clicked");

	}
	
	/**
	 * This method is used to create household Billing setup button
	 *
	 * @param button - Create Billing setup button
	 * @return boolean
	 * @author dshukla
	 */
	public boolean clickCreateHouseHoldBillingSetUpButton() {
		return clickElementUsingXpath(strCreateHouseHoldBillingSetUpButtonXpath,
				"Create House Hold Billing Set up clicked");
	}
	
	/**
	 * This method is used to return the Billing setup confirmation for the
	 * HouseHold Group
	 *
	 * @return boolean
	 * @author dshukla
	 */
	public boolean verifyHouseholdGroupBillingCreated() {
		return isElementPresentUsingXpath(strBillingConfirmationMsgXpath, lplCoreConstents.HIGH, "Confirmation page");

	}
	
	/**
	 * This method is used to validate applied Billing Capability Title Capability
	 * Tracker
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean displaycapabilityTrackerAppliedBillingCapability() {
		return isElementPresentUsingXpath(strBillingCapabilityTitleInTrackerXpath, lplCoreConstents.HIGH,
				"Applied Billing Capability Title displayed");

	}
	
	
	/**
	 * This method is used to check if Edit Billing page is displayed
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean EditbillingPageDisplayed() {
		return isElementPresentUsingXpath(strEditbillingpagexpath, lplCoreConstents.HIGH,
				"Edit billing Page Displayed");

	}
	
	/**
	 * This method is used to validate household Capability tracker name with
	 * Billing Form button in Household Capability Tracker
	 *
	 * @return boolean
	 * @author awaeza
	 */
	public boolean householdCapabilityTrackerNameWithBillingForm() {
		return isElementPresentUsingXpath(strBillingFormEditHouseholdPageXpath, lplCoreConstents.HIGH,
				"Billing Form is displayed in Household capaility tracker");

	}
	
	/**
	 * This method is used to click on Billing FORM button on Edit Household Page
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */
	public boolean clickBillingFormButton() {
		return clickElementUsingXpath(strBillingFormEditHouseholdPageXpath,
				"Household Capability tracker is collapsed");
	}
	
	/**
	 * This method is used to click on button
	 *
	 * @return boolean
	 * @author abanker
	 */

	public boolean clickOnButton() {
		return clickElementUsingXpath(strBillingFormIDXpath, lplCoreConstents.HIGHEST,
				strBillingFormIDXpath);
	}
	
	/**
	 * This method is used to select Account Number hyperlink in Billing Capability
	 * Tile
	 * 
	 *
	 * @return boolean
	 * @author vsharma
	 */

	public boolean AccountNumberHyperlinkSelected() {
		String accountNo = testData.get("accountNo");
		return clickElementUsingXpath(strClickAccountxpath.replace("xxx", accountNo), "Household AccountNo is clicked");
	}
	
	/**
	 * This method is used to select Account Number hyperlink in Billing Capability
	 * Tile
	 * 
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean clickDeleteCapability() {
		return clickElementUsingXpath(strDeleteBillingCapabilityXpath, "Delete billing capability is clicked");
	}
	
	
	/**
     * This method is used to validate Delete Billing Modal
     * 
      *
     * @return boolean
     * @author awaeza
     */

     public boolean seeDeleteBillingModal() {
            return isElementPresentUsingXpath(strDeleteBillingModalXpath, lplCoreConstents.HIGH,
                         "Delete Billing Modal is getting Displayed");
     }    
     
     public boolean displayBillRateTileValuesInBillingPage(String field) {
         // This method is used to validate whether STO Team field is visible
                      return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
  }
  /**
  * This method is used to verify Review Household Billing Details page
  *
  * @return boolean
  * @author sethupar
  */
  public boolean verifyReviewHouseholdBillingDetailsPage() {
         return isElementPresentUsingXpath(strReviewHouseholdBDPageXpath, lplCoreConstents.HIGH,
                      "Review Household Billing Details page");
  }
  
  /**
  * This method is used to select the Breakpoint additional Schedule from
  * dropdown
  *
  * @return boolean
  * @author sethupar
  */
  public boolean selectAdditionalScheduleForBP(String additionalschedulenameForBP) {
         clickElementUsingXpath(strAdditionalScheduleXpath, "AdditionalSchedule dropdown");
         return clickElementUsingXpath(getFormattedLocator(strAdditionalScheduleValueXpath, additionalschedulenameForBP),
                      "Additional Schedule dropdown Value");

  }
  /**
  * This method is used to select the StreamlineBilling Fee Type Break Point
  *
  * @return boolean
  * @author sethupar
  */
  public boolean clickBreakPointFeeTypeButton() {

         return clickElementUsingXpath(strBreakPointXpath, "Fee Type Break Point selected");
  }
  /**
   * This method is used to click on Edit Details button in Review Household Billing Details Page
   *
   * @return boolean
   * @author sethupar
   */

  public boolean displayBillRateTileValuesInReviewHouseholdBillingDetailsPage(String field) {
         return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
  }
  /**
  * This method is used to click on Edit Details button in Review Household Billing Details Page
  *
  * @return boolean
  * @author sethupar
  */
  public boolean clickEditDetailsButtonInReviewHBDpage() {

         return clickElementUsingXpath(strEditDetailsButtonInReviewHBDpageXpath, "click Edit Details button in Review Household Billing Details Page");
  }
  /**
   * This method is used to click on Edit Details button in Review Household Billing Details Page
   *
   * @return boolean
   * @author sethupar
   */
  
  
  public boolean tierValueIsEqualToHighlightedvalueInBPdetails() {
         String actualre = getWebElement(By.xpath(strHighlightedTierValueXpath)).getText();
          return isElementPresentUsingXpath(getFormattedLocator(strTierValueinEditBPXpath, actualre), actualre);
         
 }
  /**
   * This method is used to verify BP billing in confiramtion page
   *
   * @return boolean
   * @author vparthas
   */

  public boolean verifyBreakpointBillingTileInConfPage(String field) {
         return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
  }

  /**
   * This method is used to ck=lcik in View Payout Schedule link in the billing tile in HH Dashbaord
   *
   * @return boolean
   * @author vparthas
   */

  public boolean clickViewPayoutSchedule() {
	  return clickElementUsingXpath(strViewPayoutScheduleLinkXpath, "click Edit Details button in Review Household Billing Details Page");
  }
  
  /**
	 * This method is used to see Clientworks Resourse Center page
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean seeClientworksResouseCenter() {
		switchToNextWindow();
		System.out.println(driver.getCurrentUrl());
		return getTheURL().equals(RESOURSE_CENTER);
		//switchToNextWindow();
		//clickElementUsingXpath("//div[@class='row neb-form-close-btn-container']/div/button/i", "click Edit Details button in Review Household Billing Details Page");
		//return isElementPresentUsingXpath("//*[@class='dig-form-language-en']", lplCoreConstents.VERYHIGH,"DocGrid page");
	}
	
	
	/**
	 * This method is used to verify column names in Dashboard page for BP billing
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyBreakpointBillingTileInDashboardPage(String field) {
        return isElementPresentUsingXpath(getFormattedLocator("//*[contains(text(),'%s')]", field), field);
}

	/**
     * This method is used to verify Eligible Accounts grid header displayed
     *
     * @return boolean
     * @author sethupar
     */
     public boolean EligibleAccountsHeaderDisplayed() {
           return isElementPresentUsingXpath("//*[contains(text(),' ELIGIBLE ACCCOUNTS SELECTED FOR HOUSEHOLD GROUP BILLING (')]", lplCoreConstents.HIGH,
                         "Eligible Accounts Grid Title displayed");
}
     /**
     * This method is used to verify Eligible Accounts grid sub header displayed
     *
     * @return boolean
     * @author sethupar
     */
     public boolean EligibleAccountsSubHeaderDisplayed() {
           return isElementPresentUsingXpath("//*[contains(text(),'You may uncheck any accounts that you wish to continue managing their billing at the account level')]", lplCoreConstents.HIGH,
                         "Eligible Accounts Grid Sub Title displayed");
}
     /**
      * This method is used to verify billing type not displayed
      *
      * @return boolean
      * @author sethupar
      */
      public boolean verifyBillingTypeNotDisplayed() {
            return isElementNotPresentUsingXpath("//*[contains(text(),'Fee Type')]");
 }
      /**
       * This method is used to verify Done editing button disabled
       *
       * @return boolean
       * @author sethupar
       */
       public boolean verifyDoneEditingButtonDisabled() {
             return !(isElementEnabled("//*[contains(text(),'Done Editing')]"));
  }

       /**
        * This method is used to click the checkbox of Eligible accounts billing grid
        *
        * @return boolean
        * @author sethupar
        */

       public boolean clickAlreadySelectedAccountCheckbox() {
     	  return clickElementUsingXpath("(//div[@class='dx-checkbox-container']/span)[2]", "click checkbox from eligible accounts grid");
       }

       /**
        * This method is used to click the checkbox of Eligible accounts billing grid
        *
        * @return boolean
        * @author sethupar
        */

       public boolean clickUnselectedAccountCheckbox() {
     	  return clickElementUsingXpath("(//div[@class='dx-checkbox-container']/span)[2]", "click checkbox from eligible accounts grid");
       }

       /**
        * This method is used to verify remove account Warning message displayed
        *
        * @return boolean
        * @author sethupar
        */
        public boolean verifyRemoveAcctWarningMsgDisplayed() {
              return isElementPresentUsingXpath("//*[contains(text(),'Removing account will exclude it from the Household Billing Group')]", lplCoreConstents.HIGH,
                            "Remove account warning message displayed");
   }

       /**
        * This method is used to verify add account Warning message displayed
        *
        * @return boolean
        * @author sethupar
        */
        public boolean verifyAddedAccountWarningMessage() {
              return isElementPresentUsingXpath("//*[contains(text(),'Changing account level billing to household billing')]", lplCoreConstents.HIGH,
                            "Add account warning message displayed");
   }
        /**
         * This method is used to verify billing type displayed
         *
         * @return boolean
         * @author sethupar
         */
         public boolean verifyBillingTypeGridDisplayed() {
               return isElementPresentUsingXpath("//*[contains(text(),'Fee Type')]",lplCoreConstents.HIGH,
                       "Billing Type Grid displayed");
    }

         /**
          * This method is used to click the Approve button
          *
          * @return boolean
          * @author sethupar
          */

         public boolean clickApproveButtonAtGroupLevel() {
       	  return clickElementUsingXpath("//*[contains(text(),'APPROVE BILLING')]", "click Approve button from eligible accounts grid");
         }

         /**
          * This method is used to verify remove account Warning message not displayed
          *
          * @return boolean
          * @author sethupar
          */
          public boolean verifyRemoveAcctWarningMsgNotDisplayed() {
                return isElementNotPresentUsingXpath("//*[contains(text(),'Removing account will exclude it from the Household Billing Group')]");
     }

         /**
          * This method is used to verify add account Warning message not displayed
          *
          * @return boolean
          * @author sethupar
          */
          public boolean verifyAddedAcctWarningMsgNotDisplayed() {
                return isElementNotPresentUsingXpath("//*[contains(text(),'Changing account level billing to household billing')]"); 
     }

	

}
