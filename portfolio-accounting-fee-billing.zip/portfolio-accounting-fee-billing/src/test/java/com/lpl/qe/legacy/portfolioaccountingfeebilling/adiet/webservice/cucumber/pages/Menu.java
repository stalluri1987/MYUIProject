package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;

/**
 * <p>
 * <br>
 * <b> Title: </b> Menu.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for Menu</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * Menu : </br>
 * <br>
 * openMenu : This method is used to open the hamburger menu since
 * 03-16-2020</br>
 * <br>
 * selectMenuOption : This method is used to select the given option from the
 * menu since 03-16-2020</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class Menu extends Common implements ILocatorInitialize {

	static final int PAGE_IDENTIFIER = 686;
	Map<String, HashMap<String, String>> pageObjectMap;
	public static final String HAMBURGER_MENU = "Hamburger Menu";
	String strHamburgerMenuXpath;
	String strMenuOptionXpath;

	public Menu(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to open the hamburger menu
	 * 
	 * @return boolean
	 *
	 * @author pmanohar since 03-16-2020
	 */
	public boolean openMenu() {
		// Check for Hamburger icon
		boolean blnIfHamburgerIconNotPresent = isElementNotPresentUsingXpath(strHamburgerMenuXpath);
		if (blnIfHamburgerIconNotPresent) {
			refreshTheWebpage();
			waitTillVisibleUsingXpath(strHamburgerMenuXpath, LPLCoreConstents.getInstance().HIGHEST, HAMBURGER_MENU);
		}
		return clickElementUsingXpath(strHamburgerMenuXpath, HAMBURGER_MENU);
	}

	/**
	 * This method is used to check for hamburger menu
	 * 
	 * @return boolean
	 *
	 * @author Abdul Hadi since 12-07-2020
	 */
	public boolean checkForHamburgerIcon() {
		return clickElementUsingXpath(strHamburgerMenuXpath, HAMBURGER_MENU);
	}

	/**
	 * This method is used to select the given option from the menu
	 * 
	 * @return boolean
	 *
	 * @author pmanohar since 03-16-2020
	 */
	public boolean selectMenuOption(String option) {
		return clickElementUsingXpath(getFormattedLocator(strMenuOptionXpath, option),
				LPLCoreConstents.getInstance().HIGHEST, option);
	}
}
