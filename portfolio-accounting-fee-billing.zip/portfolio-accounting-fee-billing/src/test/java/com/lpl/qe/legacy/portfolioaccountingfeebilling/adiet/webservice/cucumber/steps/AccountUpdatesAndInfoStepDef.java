package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import java.text.ParseException;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDriver;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> AccountUpdatesAndInfoStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for AccountUpdatesAndInfo</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountUpdatesAndInfoStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class AccountUpdatesAndInfoStepDef extends CommonStepDef {

	public static final String PAGEISLOADED = "Account Details page is loaded";
	public static final String POPUPISLOADED = " Update Fee Type pop up is loaded";
	// New call
	@Before
	public void startSession(Scenario sc) {
		String[] scenarioTags = sc.getSourceTagNames().toArray(new String[0]);
		String scriptID = LPLCoreDriver.getScriptTagID(scenarioTags);
		if (scriptID != null) {
			LPLCoreDriver.StartSession(scriptID);
		} else {
			LPLCoreDriver.StartSession();
		}

	}
	@Given("^I login to ADIET application$")
	public void ilogintoADIETapplication() {
		initialize();
		accountUpdatesAndInfoPage.logInToAdietApplication();
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE, "Log in to ADIET Application",
				"User should be able to Log in to ADIET Application",
				"Successfully able to Log in to ADIET Application",
				"Failed to Log in to ADIET Application: " + Common.strError);
	}

	@Then("^I verify the availability of search fields$")
	public void iverifytheavailabilityofsearchfields(DataTable searchFieldsOptions) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheAvailabilityOfSearchFields(searchFieldsOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of search fields", "User should be able to see all search field options",
				"Successfully able to see all search field options",
				"Failed to see all search field options : " + Common.strError);
	}

	@When("^I enter account number in the first field$")
	public void ienteraccountnumberinthefirstfield() {
		boolean blnResult = accountUpdatesAndInfoPage.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Account number",
				"User should be able to enter Account Number in the first field",
				"Successfully able to enter Account Number in the first field",
				"Failed to enter Account Number in the first field : " + Common.strError);
	}

	@When("^I click on Search button$")
	public void iclickonSearchbutton() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickOnSearchButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Search button",
				"User should able to click Search button", "Successfully able to click Search button",
				"Failed to click Search button :" + Common.strError);
	}

	@Then("^I verify that result shows the searched account$")
	public void iverifythatresultshowsthesearchedaccount() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyResultShowsTheSearchedAccount();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that results show for the searched account",
				"User should be able to see results for the searched account",
				"Successfully able to see results for the searched account",
				"Failed to see results for the searched account : " + Common.strError);
	}

	@Then("^I verify the display of fields in search results$")
	public void iverifythedisplayoffieldsinsearchresults(DataTable searchResultsOptions) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheDisplayOfFieldsInSearchResults(searchResultsOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in search results",
				"User should be able to see all search result results",
				"Successfully able to see all search result results",
				"Failed to see all search result results : " + Common.strError);
	}

	@When("^I click on Export button$")
	public void iclickonExportbutton() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickOnExportButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Export button",
				"User should able to click Export button", "Successfully able to click Export button",
				"Failed to click Export button :" + Common.strError);
	}

	@Then("^I verified file downloaded successfully$")
	public void iverifyifafilewasdownloaded() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyDownloadedFileAndDelete();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully",
				"Successfully able to see file downloaded successfully",
				"Failed to see file downloaded successfully : " + Common.strError);
	}

	@When("^I click on AccountNo Link$")
	public void iclickonAccountNoLink() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickOnAccountNoLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on AccountNo Link",
				"User should able to click AccountNo Link", "Successfully able to click AccountNo Link",
				"Failed to click AccountNo Link :" + Common.strError);
	}

	@Then("^I land on Account Details page$")
	public void isAccountDetailsPageLoaded() {
		boolean blnResult = accountUpdatesAndInfoPage.isAccountDetailsPageLoaded();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if " + PAGEISLOADED,
				" page should be loaded", PAGEISLOADED, " page is not loaded");
	}

	@When("^I click on icon beside Fee Type field$")
	public void clickOnIconBesideFeeTypefield() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickOnFeeTypeIconLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Fee Type Icon Link",
				"User should able to click Fee Type Icon Link", "Successfully able to click Fee Type Icon Link",
				"Failed to click Fee Type Icon Link :" + Common.strError);
	}

	@Then("^I land on Update Fee Types Flat or Tiered Pop Up$")
	public void isUpdateFeeTypesFlatOrTieredPopUpLoaded() {
		boolean blnResult = accountUpdatesAndInfoPage.isPopUpLoaded();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if " + POPUPISLOADED,
				" pop up should be loaded", POPUPISLOADED, " pop up is not loaded");
	}

	@Then("^I verify Fee Type label is present$")
	public void isFeeTypeLabelPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isFeeTypeLabelPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Fee Tpe label is present ",
				" Fee Type label should be present", "Fee Tpe label is present", "Fee Type label is not present");
	}

	@Then("^I verify radio button with Flat text is selected$")
	public void isFlatRadioButtonSelected() {
		boolean blnResult = accountUpdatesAndInfoPage.isFlatRadioButtonSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if flat radio button is selected", " Flat radio button should be selected",
				"Flat radio is selected", " Flat radio is not selected");
	}

	@Then("^I verify radio button with Flat text is not selected$")
	public void isFlatRadioButtonNotSelected() {
		boolean blnResult = accountUpdatesAndInfoPage.isFlatRadioButtonNotSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if flat radio button is not selected", " Flat radio button should not be selected",
				"Flat radio is not selected", " Flat radio is selected");
	}

	@Then("^I verify textbox for entering flat rate is present$")
	public void isTextBoxForFlatRatePresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isTextBoxForFlatRatePresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if flat text box is present",
				"Flat text box should be present", "Flat text box is present", "Flat text box is not present");
	}

	@Then("^I verify % icon is present beside textbox$")
	public void isIconBesideTextBoxPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isIconBesideTextBoxPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if text box icon is present",
				"Text box icon should be present", "Text box icon is present", "Text box icon is not present");
	}

	@Then("^I verify radio button with Tiered text is disabled$")
	public void isTieredRadioButtonDisabled() {
		boolean blnResult = accountUpdatesAndInfoPage.isTieredRadioButtonDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if tiered radio button is disabled", " Tiered radio button should be disabled",
				"Tiered radio button is disabled", "Tiered radio button is not disabled");
	}

	@Then("^I verify radio button with Tiered text is selected$")
	public void isTieredRadioButtonPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isTieredRadioButtonSelected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if tiered radio button is Selected", " Tiered radio button should be Selected",
				"Tiered radio button is Selected", "Tiered radio button is not Selected");
	}

	@Then("^I verify Schedule dropdown beside Tiered text is present$")
	public void isDropdownForTieredPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isDropdownForTieredPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if tiered dropdown is present",
				"Tiered dropdown should be present", "Tiered dropdown is present", "Tiered dropdown is not present");
	}

	@Then("^I verify the display of fields in Tiers table$")
	public void verifyTierScheduleTableFields(DataTable searchResultsOptions) {
		boolean blnResult = accountUpdatesAndInfoPage
				.verifyTheAvailabilityOfTierSCheduleTableFields(searchResultsOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in search results",
				"User should be able to see all search result results",
				"Successfully able to see all search result results",
				"Failed to see all search result results : " + Common.strError);
	}

	@Then("^I verify Cancel button is enabled$")
	public void isCancelButtonPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isCancelButtonEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Cancel button is Enabled",
				" Cancel button should be Enabled", "Cancel button is Enabled", "Cancel button is not Enabled");
	}

	@Then("^I verify Confirm Fee Changes button is disabled$")
	public void isConfirmFeeChangesButtonDisabled() {
		boolean blnResult = accountUpdatesAndInfoPage.isConfirmFeeChangesButtonDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Confirm Fee Changes button is disabled ", "Confirm Fee Changes button should be disabled",
				"Confirm Fee Changes button is disabled", "Confirm Fee Changes button is not disabled");
	}

	@Then("^I verify Fee Type field is present$")
	public void isFeeTypeFieldPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isFeeTypeFieldPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Fee Type field is present ",
				"Fee Type field should be present", "Fee Type field is present", "Fee Type field is not present");
	}

	@Then("^I verify Flat label is present at rightside of Fee Type field$")
	public void isFlatLabelPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isFlatLabelPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Flat label is present at rightside of Fee Type field ",
				"Flat label should be present at rightside of Fee Type field",
				"Flat label is present at rightside of Fee Type field",
				"Flat label is not present at rightside of Fee Type field");
	}

	@Then("^I verify Flat rate for the account with format$")
	public void isFlatRateIsCorrectWithFormat() {
		boolean blnResult = accountUpdatesAndInfoPage.isFlatRateIsCorrectWithFormat();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Flat fee for the account is correct ", "Flat fee should be correct",
				"Flat fee for the account is correct", "Flat fee is incorrect");
	}

	@Then("^I verify Tiered Label is present at rightside of Fee Type field$")
	public void isTieredLabelPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isTieredLabelPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Tiered label is present at rightside of Fee Type field ",
				"Tiered label should be present at rightside of Fee Type field",
				"Tiered label is present at rightside of Fee Type field",
				"Tiered label is not present at rightside of Fee Type field");
	}

	@Then("^I verify Tiered Schedule for the account$")
	public void isTieredScheduleCorrect() {
		boolean blnResult = accountUpdatesAndInfoPage.isTieredScheduleCorrect();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Tiered Schedule for the account is correct ", "Tiered Schedule should be correct",
				"Tiered Schedule for the account is correct", "Tiered Schedule is incorrect");
	}

	@Then("^I verify the availability of HH No in search field$")
	public void isHhNoFieldPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isHHNoFieldPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if HH No field is present ",
				"HH No field should be present", "HH No field is present", "HH No field is not present");
	}

	@Then("^I verify the availability of HH No column on search results$")
	public void isHhNoColumnPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isHHNoColumnPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of HH No column on search results  ",
				"User should be able to see HH No column on search results",
				"Successfully able to see HH No column on search results",
				"Failed to see HH No column on search results");
	}

	@Then("^I validate HH No value for Account$")
	public void toVerifyHhColumnValue() {
		boolean blnResult = accountUpdatesAndInfoPage.toVerifyHHColumnValue();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if HH No value for the account is correct ", "HH No value should be correct",
				"HH No value for the account is correct", "HH No value is incorrect");
	}

	@Then("^I verify Household field is present in Account Details$")
	public void isHouseholdFieldPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.isHouseholdFieldPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Household field is present ",
				"Household field should be present", "Household field is present", "Household field is not present");
	}

	@Then("^I verify GroupId and Group Name in Account Details$")
	public void toVerifyGroupIdAndGroupName() {
		boolean blnResult = accountUpdatesAndInfoPage.toVerifyGroupIdAndGroupName();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if GroupId and Group Name for the account is correct ",
				"GroupId and Group Name should be correct", "GroupId and Group Name for the account is correct",
				"GroupId and Group Name is incorrect");
	}

	@When("^I enter account number in the first field for AXA Flat SAM$")
	public void enterAxaFlatSamAccountNumber() {
		boolean blnResult = accountUpdatesAndInfoPage.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Account number in the first field for AXA Flat SAM",
				"User should be able to enter Account Number for AXA Flat SAM",
				"Successfully able to enter Account Number for AXA Flat SAM",
				"Failed to enter Account Number for AXA Flat SAM : " + Common.strError);
	}

	@When("^I enter account number in the first field for AXA Tiered SAM$")
	public void enterAxaTieredSamAccountNumber() {
		boolean blnResult = accountUpdatesAndInfoPage.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Account number in the first field for AXA Tiered SAM",
				"User should be able to enter Account Number for AXA Tiered SAM",
				"Successfully able to enter Account Number for AXA Tiered SAM",
				"Failed to enter Account Number for AXA Tiered SAM : " + Common.strError);
	}

	@When("^I enter account number in the first field for LPL Flat SAM$")
	public void enterLplFlatSamAccountNumber() {
		boolean blnResult = accountUpdatesAndInfoPage.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Account number in the first field for LPL Flat SAM",
				"User should be able to enter Account Number for LPL Flat SAM",
				"Successfully able to enter Account Number for LPL Flat SAM",
				"Failed to enter Account Numberfor LPL Flat SAM : " + Common.strError);
	}

	@When("^I enter account number in the first field for LPL Flat SWM$")
	public void enterLplFlatSwmAccountNumber() {
		boolean blnResult = accountUpdatesAndInfoPage.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Account number in the first field LPL Flat SWM",
				"User should be able to enter Account Number LPL Flat SWM",
				"Successfully able to enter Account Numbe LPL Flat SWMr",
				"Failed to enter Account Number LPL Flat SWM : " + Common.strError);
	}

	@When("^I enter account number in the first field for LPL Tiered SAM$")
	public void enterLplTieredSamAccountNumber() {
		boolean blnResult = accountUpdatesAndInfoPage.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Account number in the first field for LPL Tiered SAM",
				"User should be able to enter Account Number for LPL Tiered SAM",
				"Successfully able to enter Account Number for LPL Tiered SAM",
				"Failed to enter Account Number for LPL Tiered SAM : " + Common.strError);
	}

	@When("^I enter account number in the first field for LPL Tiered SWM$")
	public void enterLplTieredSwmAccountNumber() {
		boolean blnResult = accountUpdatesAndInfoPage.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Account number in the first field for LPL Tiered SWM",
				"User should be able to enter Account Number for LPL Tiered SWM",
				"Successfully able to enter Account Number for LPL Tiered SWM",
				"Failed to enter Account Number for LPL Tiered SWM : " + Common.strError);
	}

	@When("^I click on Fee Credits tab$")
	public void iClickonFeesCreditsTab() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickonFeesCreditsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Fees Credits tab",
				"User should able to click Fees Credits tab", "Successfully able to click Fees Credits tab",
				"Failed to click Fees Credits tab :" + Common.strError);
	}

	@Then("^I verify the display of fields in Fees Credits tab$")
	public void verifyDisplayOfFieldsInFeesCreditsTab(DataTable fieldsFeesCredits) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyDisplayOfFieldsInFeesCreditsTab(fieldsFeesCredits);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in Fees Credits tab",
				"User should be able to see all fields in Fees Credits tab",
				"Successfully able to see all fields in Fees Credits tab",
				"Failed to see all fields in Fees Credits tab : " + Common.strError);
	}

	@Then("^I verify the display of fields in grid header$")
	public void verifyDisplayOfFieldsInGridHeaders(DataTable gridHeaders) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyDisplayOfFieldsInGridHeaders(gridHeaders);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in grid header", "User should be able to see all fields in grid header",
				"Successfully able to see all fields in grid header",
				"Failed to see all fields in grid header : " + Common.strError);
	}

	@When("^I enter a value in the Fee credit Adj field$")
	public void enterValueInFeeCreditAdjField() {
		boolean blnResult = accountUpdatesAndInfoPage.enterValueInFeeCreditAdjField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter value in the Fee credit Adj field",
				"User should be able to enter value in the Fee credit Adj field",
				"Successfully able to enter value in the Fee credit Adj field",
				"Failed to enter value in the Fee credit Adj field : " + Common.strError);
	}

	@Then("^I verify Add Button is disabled$")
	public void isConfirmAddButtonButtonDisabled() {
		boolean blnResult = accountUpdatesAndInfoPage.isConfirmAddButtonButtonDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Confirm Add button is disabled ", "Confirm Add button should be disabled",
				"Confirm Add button is disabled", "Confirm Add button is not disabled");
	}

	@When("^I delete text from description field$")
	public void iDeleteTextFromDescriptionField() {
		boolean blnResult = accountUpdatesAndInfoPage.iDeleteTextFromDescriptionField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Delete text from description field",
				"User should be able to delete text from description field",
				"Successfully deleted text from description field",
				"Failed to delete text from description field : " + Common.strError);
	}

	@When("^I click on Audit log tab$")
	public void clickOnAuditLogTab() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnAuditLogTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Audit log tab",
				"User should be able to click on Audit log tab", "Successfully able to click on Audit log tab",
				"Failed to click on Audit log tab " + Common.strError);
	}

	@Then("^I verify Date Range label is present$")
	public void verifyDateRangeLabelIsPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyDateRangeLabelIsPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Audit log tab",
				"User should be able to see Date range label", "Successfully able to see Date range label",
				"Failed to see Date range label" + Common.strError);
	}

	@Then("^I verify the availability of Date range dropdown field options$")
	public void verifyFieldsDisplayedDateRangeDropDown(DataTable dateRangeDropDownfields) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyFieldsDisplayedDateRangeDropDown(dateRangeDropDownfields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the fields in Date range dropdown",
				"User should be able to see all fields in Date range dropdown",
				"Successfully able to see all fields in Date range dropdown",
				"Failed to see all fields in Date range dropdown : " + Common.strError);
	}

	@Then("^I verify Search button is present and enabled$")
	public void isSearchButtonEnabled() {
		boolean blnResult = accountUpdatesAndInfoPage.isSearchButtonEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Search button is Enabled",
				" Search button should be Enabled", "Search button is Enabled", "Search button is not Enabled");
	}

	@Then("^I verify Export button is present and enabled$")
	public void isExportButtonEnabled() {
		boolean blnResult = accountUpdatesAndInfoPage.isExportButtonEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Export button is Enabled",
				" Export button should be Enabled", "Export button is Enabled", "Export button is not Enabled");
	}

	@Then("^I verify the display of fields in Audit log tab$")
	public void verifyFieldsDisplayedInAuditLogTab(DataTable auditlogTableFields) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyFieldsDisplayedInAuditLogTab(auditlogTableFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in Audit log tab",
				"User should be able to see all fields in Audit log tab",
				"Successfully able to see all fields in Audit log tab",
				"Failed to see all fields in Audit log tab : " + Common.strError);
	}

	@When("^I click on Fiserv Info tab$")
	public void clickOnFiservInfoTab() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnFiservInfoTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Fiserv Info tab",
				"User should be able to click on Fiserv Info tab", "Successfully able to click on Fiserv Info tab",
				"Failed to click on Fiserv Info tab " + Common.strError);
	}

	@Then("^I verify the fields displayed in Fiserv Info tab$")
	public void verifyFieldsDisplayedInFiservInfoTab(DataTable fiservInfoFields) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyFieldsDisplayedInFiservInfoTab(fiservInfoFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in Fiserv Info tab",
				"User should be able to see all fields in Fiserv Info tab",
				"Successfully able to see all fields in Fiserv Info tab",
				"Failed to see all fields in Fiserv Info tab : " + Common.strError);
	}

	@Then("^I verify Termdate value as Red color$")
	public void I_verify_Termdate_value_as_Red_color() {
		String redcolr = "#e50000";
		boolean blnResult = accountUpdatesAndInfoPage.verifyTermDateColor(redcolr);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify Term date value has to color  in the account updates information page  ",
				"User should be able to get Term date as red color ",
				"Successfully Term date as red color  in the account updates information page",
				"Failed to get Term date as red color : " + Common.strError);
	}

	@Then("^I verify FiservInfo Tab is visble$")
	public void I_verify_FiservInfo_Tab_is_visble() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyPageLoadsFisevInfo();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify FiservInfo Tab visible in the account updates information page  ",
				"User should be able to visible FiservInfo Tab",
				"FiservInfo Tab has been displaying in the account updates information page",
				"Failed to see FiservInfo Tab  : " + Common.strError);
	}

	@Then("^I verify Fee Cycle value is Red color$")
	public void iVerifyFeeCycleRedColor() {
		String redcolr = "#e50000";
		boolean blnResult = accountUpdatesAndInfoPage.verifyFeeCycleColor(redcolr);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify Fee cycle value has to color  in the account updates information page  ",
				"User should be able to get Fee cycle as red color ",
				"Successfully fee cycle as red color  in the account updates information page",
				"Failed to get fee cycle as red color : " + Common.strError);
	}

	@When("^I click on TIDS tab$")
	public void clickOnTIDSTab() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnTIDSTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on TIDS tab",
				"User should be able to click on TIDS tab", "Successfully able to click on TIDS tab",
				"Failed to click on TIDS tab " + Common.strError);
	}

	@When("^I click on Transactions tab$")
	public void clickOnTransactionsTab() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnTransactionsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Transactions tab",
				"User should be able to click on Transactions tab", "Successfully able to click on Transactions tab",
				"Failed to click on Transactions tab " + Common.strError);
	}

	@Then("^I verify the display of fields in TIDS tab$")
	public void verifyFieldsDisplayedInTIDSTab(DataTable tIDSFields) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyFieldsDisplayedInTIDSTab(tIDSFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in TIDS tab", "User should be able to see all fields in TIDS tab",
				"Successfully able to see all fields in TIDS tab",
				"Failed to see all fields in TIDS tab : " + Common.strError);
	}

	@Then("^I verify the grid headers under transaction tab$")
	public void verifyGridHeadersUnderTransactionTab(DataTable tableHeaders) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyGridHeadersUnderTransactionTab(tableHeaders);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in Transaction tab",
				"User should be able to see all fields in Transaction tab",
				"Successfully able to see all fields in Transaction tab",
				"Failed to see all fields in Transaction tab : " + Common.strError);
	}

	@Then("^I verify that Inception To Date option is selected by default$")
	public void verifyInceptionToDateOptionIsSelectedByDefault() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyInceptionToDateOptionIsSelectedByDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Inception To Date option is selected by default",
				"User should be able to see Inception To Date option is selected by default",
				"Successfully able to see Inception To Date option is selected by default",
				"Failed to see Inception To Date option is selected by default : " + Common.strError);
	}

	@Then("^I verify Sleeves field is present$")
	public void verifySleevesfieldispresent() {
		boolean blnResult = accountUpdatesAndInfoPage.verifySleevesfieldispresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Sleeves filed is Present",
				"Sleeves Field should be present", "Sleeves field is present", "Sleeves field is not present");
	}

	@When("^I click on Sleeves tab$")
	public void clickOnSleevesTab() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnSleevesTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Sleeves tab",
				"User should be able to click on Sleeves tab", "Successfully able to click on Sleeves tab",
				"Failed to click on Sleeves tab " + Common.strError);
	}

	@Then("^I verify the fields displayed in Sleeves tab$")
	public void verifyFieldsDisplayedInSleevesTab(DataTable sleevesFields) {
		boolean blnResult = accountUpdatesAndInfoPage.verifythefieldsdisplayedinSleevestab(sleevesFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in Sleeves tab", "User should be able to see all fields in Sleeves tab",
				"Successfully able to see all fields in Sleeves tab",
				"Failed to see all fields in Sleeves tab : " + Common.strError);
	}

	@When("^I verify Billing Settings tab is displayed$")
	public void verifyBillingSettingsTabIsDisplayed() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyBillingSettingsTabIsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Billing Settings Tab is displayed", "User should be able to see Billing Settings Tab",
				"Successfully Billing Settings Tab is displayed",
				"Failed to see Billing Settings Tab : " + Common.strError);
	}

	@Then("^I verify the display of fields in Billing Settings tab$")
	public void verifyTheDisplayOfFieldsInBillingSettingsTab(DataTable fieldsFeesCredits) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyDisplayOfFieldsInFeesCreditsTab(fieldsFeesCredits);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in Billing Settings tab",
				"User should be able to see all fields in Billing Settings tab",
				"Successfully able to see all fields in Billing Settings tab",
				"Failed to see all fields in Billing Settings tab : " + Common.strError);
	}

	@Then("^I verify the display of fields in search results in Account details page$")
	public void verifyTheDisplayOfFieldsInSearchResultsAcc(DataTable searchResultsOptions) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheDisplayOfFieldsInSearchResultsAcc(searchResultsOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in search results",
				"User should be able to see all search result results",
				"Successfully able to see all search result results",

				"Failed to see all search result results : " + Common.strError);
	}

	@Then("^I verified Transaction Log CSV file downloaded successfully$")
	public void verifyTransactionFileDownloadedSucessfully() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTransactionLogCsvFileDownloadedSucessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify if a file downloaded or not",
				"User should be able to see file downloaded successfully",
				"Successfully able to see file downloaded successfully",
				"Failed to see file downloaded successfully : " + Common.strError);
	}

	@Then("^I verify B2AConvDate value is blank$")
	public void verifyB2AConvDateValueShouldBlank() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyB2AConvDateValueShouldBlank();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify B2AConvDate value",
				"User should be able to see B2AConvDate value is blank",
				"Successfully able to see B2AConvDate value is blank",
				"Failed to see B2AConvDate value is blank : " + Common.strError);
	}

	@Then("^I verify Account status value is displayed$")
	public void verifyAccountStatusValue() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyAccountStatusValue();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Account status value",
				"User should be able to see Account status value is displayed",
				"Successfully able to see Account status value is displayed",
				"Failed to see Account status value: " + Common.strError);
	}

	@Then("^I verify Program SN value also displayed$")
	public void verifyProgramSNValue() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyProgramSNValue();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Program SN value",
				"User should be able to see Program SN value", "Successfully able to see Program SN value",
				"Failed to see Program SN value : " + Common.strError);
	}

	@When("^I click on Performance tab$")
	public void clickOnPerformanceTab() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnPerformanceTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to click on Performance tab", "User should be able to click on Performance tab",
				"Successfully able to click on Performance tab",
				"Failed to click on Performance tab : " + Common.strError);
	}

	@Then("^I verify that Last 180 days option is selected by default$")
	public void verify180DaysOptionIsSelectedByDefault() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyLast180DaysOptionIsSelectedByDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Last 180 days option is selected by default",
				"User should be able to see Last 180 days option is selected by default",
				"Successfully able to see Last 180 days option is selected by default",
				"Failed to see Last 180 days option is selected by default : " + Common.strError);
	}

	@Then("^I verify the display of fields in Performance tab$")
	public void verifyTheDisplayOfFieldsInPerformanceTab(DataTable fieldsPerformance) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheDisplayOfFieldsInPerformanceTab(fieldsPerformance);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in Performance tab",
				"User should be able to see all fields in Performance tab",
				"Successfully able to see all fields in Performance tab",
				"Failed to see all fields in Performance tab : " + Common.strError);
	}

	@Then("^I validate that warning message displayed for the account which is not in LPLMastered_accounts table$")
	public void verifyWarningMessageForMissingAccount() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyWarningMessageForMissingAccount();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify warning message displayed for the account which is not in LPLMastered_accounts table",
				"User should be able to see warning message displayed for the account which is not in LPLMastered_accounts table",
				"Successfully able to see warning message displayed for the account which is not in LPLMastered_accounts table",
				"Failed to see warning message displayed for the account which is not in LPLMastered_accounts table : "
						+ Common.strError);
	}

	@When("^I click on Create link$")
	public void clickOnCreateLink() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnCreateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to click on Create link", "User should be able to click on Create link",
				"Successfully able to click on Create link", "Failed to click on Create link : " + Common.strError);
	}

	@Then("^I validate Add missing account record to LPLMastered_Accounts popup is displayed$")
	public void verifyMissingAccountPopUpDisplayed() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyMissingAccountPopUpDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Add missing account record to LPLMastered_Accounts popup is displayed",
				"User should be able to see Add missing account record to LPLMastered_Accounts popup",
				"Successfully able to see Add missing account record to LPLMastered_Accounts popup",
				"Failed to see Add missing account record to LPLMastered_Accounts popup : " + Common.strError);
	}

	@Then("^I validate fields present in the displayed popup$")
	public void verifyTheDisplayOfFieldsInDisplayedPopup(DataTable popupFields) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheDisplayOfFieldsInDisplayedPopup(popupFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the display of fields in Popup",
				"User should be able to see all fields in Popup", "Successfully able to see all fields in Popup",
				"Failed to see all fields in Popup : " + Common.strError);
	}

	@Then("^I validate Small Account Fee field dropdown values$")
	public void verifyTheDisplayOfOptionsForSmallAccountFeeDropdown(DataTable dropdownOptions) {
		boolean blnResult = accountUpdatesAndInfoPage
				.verifyTheDisplayOfOptionsForSmallAccountFeeDropdown(dropdownOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of Small Account Fee field dropdown values",
				"User should be able to see Small Account Fee field dropdown values",
				"Successfully able to see all fields in PopupSmall Account Fee field dropdown values",
				"Failed to see Small Account Fee field dropdown values : " + Common.strError);
	}

	@Then("^I validate Fee Cycle field dropdown values$")
	public void verifyTheDisplayOfOptionsForFeeCycleDropdown(DataTable dropdownOptions) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheDisplayOfOptionsForFeeCycleDropdown(dropdownOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of Fee Cycle field dropdown values",
				"User should be able to see Fee Cycle field dropdown values",
				"Successfully able to see all Fee Cycle field dropdown values",
				"Failed to see Fee Cycle field dropdown values : " + Common.strError);
	}

	@Then("^I validate Fee Type field has both flat and tiered options$")
	public void verifyTheDisplayOfOptionsForFeeTypeField(DataTable options) {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheDisplayOfOptionsForFeeTypeField(options);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the display of Fee Type options",
				"User should be able to see Fee Type options", "Successfully able to see Fee Type options",
				"Failed to see Fee Type options : " + Common.strError);
	}

	@Then("^I validate that Insert account record button disabled$")
	public void validateInsertAccountRecordButtonDisabled() {
		boolean blnResult = accountUpdatesAndInfoPage.validateInsertAccountRecordButtonDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Insert account record button is disabled",
				" Insert account record button should be disabled", "Insert account record button is disabled",
				"Insert account record button is not disabled");
	}

	@When("^I click on Cancel button present at the bottom of the popup$")
	public void clickOnCancelButtonInPopup() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnCancelButtonInPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to click on Cancel button ", "User should be able to click on Cancel button ",
				"Successfully able to click on Cancel button ",
				"Failed to click on Cancel button  : " + Common.strError);
	}

	@When("^I enter date in Advisory Rate Change field for the account$")
	public void enterDateInAdvisoryRateChangeField() {
		boolean blnResult = accountUpdatesAndInfoPage.enterDateInAdvisoryRateChangeField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to enter date in Advisory Rate Change field for the account",
				"User should be able to enter date in Advisory Rate Change field for the account ",
				"Successfully able to enter date in Advisory Rate Change field for the account ",
				"Failed to enter date in Advisory Rate Change field for the account  : " + Common.strError);
	}

	@When("^I click on Save button at the bottom$")
	public void clickOnSaveButton() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnSaveButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to click on Save button ", "User should be able to click on Save button ",
				"Successfully able to click on Save button ", "Failed to click on Save button  : " + Common.strError);
	}

	@When("^I click on confirm button in confirm popup$")
	public void clickOnConfirmButton() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnConfirmButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to click on confirm button ", "User should be able to click on confirm button ",
				"Successfully able to click on confirm button ",
				"Failed to click on confirm button  : " + Common.strError);
	}

	@When("^I have deleted date in Advisory Rate Change field for the account$")
	public void deleteDateInAdvisoryRateChangeField() {
		boolean blnResult = accountUpdatesAndInfoPage.deleteDateInAdvisoryRateChangeField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to delete date in Advisory Rate Change field for the account",
				"User should be able to delete date in Advisory Rate Change field for the account ",
				"Successfully able to delete date in Advisory Rate Change field for the account ",
				"Failed to delete date in Advisory Rate Change field for the account  : " + Common.strError);
	}

	@When("^I click On Headers Sort Button of below options$")
	public void iclickOnAllPerformanceHeader(DataTable headerOptions) {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnAllPerformanceHeader(headerOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on All Headers to Sort",
				"User should be able to click all Header options to sort",
				"Successfully able to click all Header options to sort",
				"Failed to click all Header options : " + Common.strError);

	}

	@Then("^I verify Last 180 Days is selected in Date Range dropdown$")
	public void verify180DaysIsSelectedInDateRangeDropdown() {
		boolean blnResult = accountUpdatesAndInfoPage
				.verifyValueIsSelectedInDateRangeDropdown(testData.get("strLast180Days"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to see Last 180 Days in Date Range dropdown",
				"User should be able to see Last 180 Days in Date Range dropdown",
				"Successfully able to Last 180 Days in Date Range dropdown",
				"Failed to see Last 180 Days in Date Range dropdown: " + Common.strError);
	}

	@Then("^I verify Transaction is displayed$")
	public void verifyTransactionIsDisplayed() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTransactionDataIsDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to see transaction grid under Transactions tab",
				"User should be able to see transaction grid under Transactions tab",
				"Successfully able to see transaction grid under Transactions tab",
				"Failed to see transaction grid under Transactions tab : " + Common.strError);
	}

	@Then("^I verify the Transaction date is within Year to Date range$")
	public void verifyTheTransactionDateIsWithinYearToDateRange() throws ParseException {
		boolean blnResult = accountUpdatesAndInfoPage.checkDateInYearToDateRange();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to see Transaction date is within Year to Date range",
				"User should be able to see Transaction date is within Year to Date range",
				"Successfully able to see Transaction date is within Year to Date range",
				"Failed to see Transaction date is within Year to Date range : " + Common.strError);
	}

	@Then("^I select Inception To Date from Date Range dropdown$")
	public void selectInceptionToDateFromDateRangeDropdown() {
		boolean blnResult = accountUpdatesAndInfoPage
				.selectValueInDateRangeDropdown(testData.get("strInceptionToDate"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to select Inception To Date from Date Range dropdown",
				"User should be able to select Inception To Date from Date Range dropdown",
				"Successfully able to select Inception To Date from Date Range dropdown",
				"Failed to select Inception To Date from Date Range dropdown : " + Common.strError);
	}

	@When("^I click on Search button under Transaction tab$")
	public void iClickOnSearchButtonUnderTransactionTab() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickOnSearchButtonUnderTransactionTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Search button under Transaction tab",
				"User should able to click Search button under Transaction tab",
				"Successfully able to click Search button under Transaction tab",
				"Failed to click Search button under Transaction tab :" + Common.strError);
	}

	@Then("^I verify the Transaction date is within Inception to Date range$")
	public void iVerifyTheTransactionDateIsWithinInceptionToDateRange() throws ParseException {
		boolean blnResult = accountUpdatesAndInfoPage.checkDateInInceptionToDateRange();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to see Transaction date is within Inception to Date range",
				"User should be able to see Transaction date is within Inception to Date range",
				"Successfully able to see Transaction date is within Inception to Date range",
				"Failed to see Transaction date is within Inception to Date range : " + Common.strError);
	}

	@Then("^I select Last 30 Days from Date Range dropdown$")
	public void selectLast30DaysFromDateRangeDropdown() {
		boolean blnResult = accountUpdatesAndInfoPage.selectValueInDateRangeDropdown(testData.get("strLast30Days"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to select Last 30 Days from Date Range dropdown",
				"User should be able to select Last 30 Days from Date Range dropdown",
				"Successfully able to select Last 30 Days from Date Range dropdown",
				"Failed to select Last 30 Days from Date Range dropdown : " + Common.strError);
	}

	@Then("^I verify the Transaction date is within Last 30 Days range$")
	public void iVerifyTheTransactionDateIsWithinLast30DaysRange() throws ParseException {
		int thirty = Integer.parseInt(testData.get("strThirty"));
		boolean blnResult = accountUpdatesAndInfoPage.checkDateInDateRange(thirty);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to see Transaction date is within Last 30 Days range",
				"User should be able to see Transaction date is within Last 30 Days range",
				"Successfully able to see Transaction date is within Last 30 Days range",
				"Failed to see Transaction date is within Last 30 Days range : " + Common.strError);
	}

	@Then("^I select Last 90 Days from Date Range dropdown$")
	public void selectLast90DaysFromDateRangeDropdown() {
		boolean blnResult = accountUpdatesAndInfoPage.selectValueInDateRangeDropdown(testData.get("strLast90Days"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to select Last 90 Days from Date Range dropdown",
				"User should be able to select Last 90 Days from Date Range dropdown",
				"Successfully able to select Last 90 Days from Date Range dropdown",
				"Failed to select Last 90 Days from Date Range dropdown : " + Common.strError);
	}

	@Then("^I verify the Transaction date is within Last 90 Days range$")
	public void iVerifyTheTransactionDateIsWithinLast90DaysRange() throws ParseException {
		int ninty = Integer.parseInt(testData.get("strNinty"));
		boolean blnResult = accountUpdatesAndInfoPage.checkDateInDateRange(ninty);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to see Transaction date is within Last 90 Days range",
				"User should be able to see Transaction date is within Last 90 Days range",
				"Successfully able to see Transaction date is within Last 90 Days range",
				"Failed to see Transaction date is within Last 90 Days range : " + Common.strError);
	}

	@Then("^I select Year To Date from Date Range dropdown$")
	public void selectYearToDateFromDateRangeDropdown() {
		boolean blnResult = accountUpdatesAndInfoPage.selectValueInDateRangeDropdown(testData.get("strYearToDate"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to select Year To Date from Date Range dropdown",
				"User should be able to select Year To Date from Date Range dropdown",
				"Successfully able to select Year To Date from Date Range dropdown",
				"Failed to select Year To Date from Date Range dropdown : " + Common.strError);
	}

	@Then("^I verify the Transaction date is within Last 180 Days range$")
	public void iVerifyTheTransactionDateIsWithinLast180DaysRange() throws ParseException {
		int oneEighty = Integer.parseInt(testData.get("strOneEighty"));
		boolean blnResult = accountUpdatesAndInfoPage.checkDateInDateRange(oneEighty);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to see Transaction date is within Last 180 Days range",
				"User should be able to see Transaction date is within Last 180 Days range",
				"Successfully able to see Transaction date is within Last 180 Days range",
				"Failed to see Transaction date is within Last 180 Days range : " + Common.strError);
	}
	

	@Then("^I click On Sleeves Headers Sort Button of below options$")
	public void iclickOnAllSleevesHeader(DataTable headerOptions) {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnAllSleevesHeader(headerOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on All Headers to Sort",
				"User should be able to click all Header options to sort",
				"Successfully able to click all Header options to sort",
				"Failed to click all Header options : " + Common.strError);
	}

	@Then("^I select Custom from Date Range dropdown$")
	public void selectCustomFromDateRangeDropdown() {
		boolean blnResult = accountUpdatesAndInfoPage.selectValueInDateRangeDropdown(testData.get("strCustom"));
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to select Custom from Date Range dropdown",
				"User should be able to select Custom from Date Range dropdown",
				"Successfully able to select Custom from Date Range dropdown",
				"Failed to select Custom from Date Range dropdown : " + Common.strError);
	}

	@Then("^I enter the Start Date$")
	public void iEnterTheStartDate() {
		boolean blnResult = accountUpdatesAndInfoPage.startDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify user able to enter Start Date",
				"User should be able to enter Start Date", "Successfully able to enter Start Date",
				"Failed to enter Start Date : " + Common.strError);
	}

	@Then("^I enter the End Date$")
	public void iEnterTheEndDate() {
		boolean blnResult = accountUpdatesAndInfoPage.endDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify user able to enter End Date",
				"User should be able to enter End Date", "Successfully able to enter End Date",
				"Failed to enter End Date : " + Common.strError);
	}

	@Then("^I verify the Transaction date is within Custom Date range$")
	public void iVerifyTheTransactionDateIsWithinCustomDateRange() {
		boolean blnResult = accountUpdatesAndInfoPage.checkDateInCustomRange();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify user able to see Transaction date is within custom date range",
				"User should be able to see Transaction date is within custom date range",
				"Successfully able to see Transaction date is within custom date range",
				"Failed to see Transaction date is within custom date range : " + Common.strError);
	}

	@When("^I enter account number in the first field for Inception Date$")
	public void iEnterAccountNumberInTheFirstFieldForInceptionDate() {
		boolean blnResult = accountUpdatesAndInfoPage.enterAccountNumberForInceptionDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Account number for Inception Date",
				"User should be able to enter Account Number in the first field",
				"Successfully able to enter Account Number in the first field",
				"Failed to enter Account Number in the first field : " + Common.strError);
	}

	@Then("^I verify Inception Date value as Red color$")
	public void iVerifyInceptionDateValueAsRedColor() {
		String redcolr = "#e50000";
		boolean blnResult = accountUpdatesAndInfoPage.verifyInceptionDateValueAsRedColor(redcolr);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"verify Inception Date value has to color in the Account Updates Information page ",
				"User should be able to get Inception Date as red color ",
				"Successfully Inception Date as red color in the Account Updates Information page ",
				"Failed to get Inception Date as red color : " + Common.strError);
	}

	@When("^I enter LPL account number in the first field$")
	public void iEnterLPLAccountNumberInTheFirstField() {
		boolean blnResult = accountUpdatesAndInfoPage.enterLPLAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter LPL Account number",
				"User should be able to enter LPL Account Number in the first field",
				"Successfully able to enter LPL Account Number in the first field",
				"Failed to LPL enter Account Number in the first field : " + Common.strError);
	}

	@And("^I enter Invalid Date in the FlatFeeCalcDate field$")
	public void iEnterInvalidDateInTheFlatFeeCalcDateField() {
		boolean blnResult = accountUpdatesAndInfoPage.enterInvalidDateInTheFlatFeeCalcDateField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Invalid Date in the FlatFeeCalcDate field",
				"User should be able to enter Invalid Date in the FlatFeeCalcDate field",
				"Successfully able to enter Invalid Date in the FlatFeeCalcDate field",
				"Failed to enter Invalid Date in the FlatFeeCalcDate field : " + Common.strError);
	}

	@And("^I verify the Invalid Date Error message$")
	public void iVerifyTheInvalidDateErrorMessage() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheInvalidDateErrorMessage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Invalid Date Error message for FlatFeeCalcDate in Billing Setting Tab",
				"User should be able to see Invalid Date Error message",
				"Successfully able to see Invalid Date Error message",
				"Failed to see Invalid Date Error message : " + Common.strError);
	}

	@And("^I click on PayingLPLAccountNo Field$")
	public void iClickOnPayingLPLAccountNoField() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnPayingLPLAccountNoField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on PayingLPLAccountNo Field",
				"User should able to click on PayingLPLAccountNo Field",
				"Successfully able to click on PayingLPLAccountNo Field",
				"Failed to click on PayingLPLAccountNo Field :" + Common.strError);
	}

	@When("^I click on Account Details Search$")
	public void iClickOnAccountDetailsSearch() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnAccountDetailsSearch();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Account Details Search",
				"User should able to click on Account Details Search",
				"Successfully able to click on Account Details Search",
				"Failed to click on Account Details Search :" + Common.strError);
	}

	@Then("^I enter Closed or Terminated Account$")
	public void iEnterClosedOrTerminatedAccount() {
		boolean blnResult = accountUpdatesAndInfoPage.enterClosedOrTerminatedAccount();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Closed or Terminated Account",
				"User should be able to enter Closed or Terminated Account",
				"Successfully able to enter Closed or Terminated Account",
				"Failed to enter Closed or Terminated Account : " + Common.strError);
	}

	@And("^I search for Closed or Terminated Account$")
	public void iSearchForClosedOrTerminatedAccount() {
		boolean blnResult = accountUpdatesAndInfoPage.searchForClosedOrTerminatedAccount();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Search for Closed or Terminated Account",
				"User should able to search for Closed or Terminated Account",
				"Successfully able to search for Closed or Terminated Account",
				"Failed to search for Closed or Terminated Account :" + Common.strError);
	}

	@And("^I verify the PayingLPLAccountNo TextBox is Disabled$")
	public void iVerifyThePayingLPLAccountNoTextBoxIsDisabled() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyThePayingLPLAccountNoTextBoxIsDisabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the PayingLPLAccountNo TextBox is Disabled",
				"User should able to verify the PayingLPLAccountNo TextBox is Disabled",
				"Successfully able to verify the PayingLPLAccountNo TextBox is Disabled",
				"Failed to verify the PayingLPLAccountNo TextBox is Disabled :" + Common.strError);
	}

	@Then("^I click on Target Icon$")
	public void iClickOnTargetIcon() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnTargetIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Target Icon",
				"User should able to click on Target Icon", "Successfully able to click on Target Icon",
				"Failed to click on Target Icon : " + Common.strError);
	}

	@And("^I enter the Target Fee Credit Balance$")
	public void iEnterTheTargetFeeCreditBalance() {
		boolean blnResult = accountUpdatesAndInfoPage.enterTheTargetFeeCreditBalance();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter the Target Fee Credit Balance",
				"User should able to enter the Target Fee Credit Balance",
				"Successfully able to enter the Target Fee Credit Balance",
				"Failed to enter the Target Fee Credit Balance : " + Common.strError);
	}

	@And("^I verify the balance in New Fee Credit Balance Field$")
	public void iVerifyTheBalanceInNewFeeCreditBalanceField() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheBalanceInNewFeeCreditBalanceField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the balance in New Fee Credit Balance Field",
				"User should able to verify the balance in New Fee Credit Balance Field",
				"Successfully able to verify the balance in New Fee Credit Balance Field",
				"Failed to verify the balance in New Fee Credit Balance Field : " + Common.strError);
	}

	@And("^I verify the amount in Fee credit Adj Field$")
	public void iVerifyTheAmountInFeeCreditAdjField() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheAmountInFeeCreditAdjField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the amount in Fee credit Adj Field",
				"User should able to verify the amount in Fee credit Adj Field",
				"Successfully able to verify the amount in Fee credit Adj Field",
				"Failed to verify the amount in Fee credit Adj Field : " + Common.strError);
	}

	@Then("^I click on Add Button$")
	public void iClickOnAddButton() {
		boolean blnResult = accountUpdatesAndInfoPage.clickOnAddButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Add Button",
				"User should able to click on Add Button", "Successfully able to click on Add Button",
				"Failed to click on Add Button : " + Common.strError);
	}

	@And("^I verify the New Row Inserted in Grid$")
	public void iVerifyTheNewRowInsertedInGrid() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheNewRowInsertedInGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the New Row Inserted in Grid",
				"User should able to verify the New Row Inserted in Grid",
				"Successfully able to verify the New Row Inserted in Grid",
				"Failed to verify the New Row Inserted in Grid : " + Common.strError);
	}

	@When("^I click on UnTerm button$")
	public void iclickonUntermbutton() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickOnUntermButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on UnTerm button",
				"User should able to click UnTerm button", "Successfully able to click UnTerm button",
				"Failed to click UnTerm button :" + Common.strError);
	}

	@Then("^I verify Termdate is removed$")
	public void iVerifyTermDateIsRemoved() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTermDateIsRemoved();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Term Date is removed",
				"User should able to verify the Term Date is removed",
				"Successfully able to verify the Term Date is removed",
				"Failed to verify the Term Date is removed : " + Common.strError);
	}

	@And("^I verify Term Reason is removed$")
	public void iVerifyTermReasonIsRemoved() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTermReasonIsRemoved();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Term Reason is removed",
				"User should able to verify the Term Reason is removed",
				"Successfully able to verify the Term Reason is removed",
				"Failed to verify the Term Reason is removed : " + Common.strError);
	}

	@And("^I verify Term Letter Date is removed$")
	public void iVerifyTermLetterDateIsRemoved() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTermLetterdateIsRemoved();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Term Letter Date is removed",
				"User should able to verify the Term Letter Date is removed",
				"Successfully able to verify the Term Letter Date is removed",
				"Failed to verify the Term Letter Date is removed : " + Common.strError);
	}

	@Then("^I check for the presence of Pricing Model Field$")
	public void icheckPricingModelFieldPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.checkPricingModelFieldPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Pricing Model field is present ", "Pricing Model field should be present",
				"Pricing Model field is present", "Pricing Model field is not present");
	}

	@Then("^I check (.+) Pricing Model displayed$")
	public void checkPricingModelType(String pricingModelType) {
		boolean blnResult = accountUpdatesAndInfoPage.checkPricingModelFieldWithType(pricingModelType);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if Pricing Model field is Displayed as " + pricingModelType,
				"Pricing Model field should be Displayed as" + pricingModelType,
				"Pricing Model field is Displayed as LPL SWS",
				"Pricing Model field is NOT Displayed as " + pricingModelType);
	}

	@When("^I click on Unincept button$")
	public void iclickonUninceptbutton() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickOnUninceptButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Unincept button",
				"User should able to click Unincept button", "Successfully able to click Unincept button",
				"Failed to click Unincept button :" + Common.strError);
	}

	@Then("^I verify Incept date is removed$")
	public void iVerifyInceptDateIsRemoved() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyInceptDateRemoved();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Validate if Incept Date is removed",
				"Incept date should be removed", "Successfully removed the Incept Date",
				"Failed to remove Incept Date :" + Common.strError);
	}

	@And("^I verify DO NOT Incept checkbox is visible$")
	public void iVerifyDoNotInceptCheckboxIsVisible() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyDoNotInceptCheckboxIsVisible();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if DO NOT Incept checkbox is visible", "DO NOT Incept checkbox should be visible",
				"Successfully able to see DO NOT Incept checkbox",
				"Failed to see DO NOT Incept checkbox :" + Common.strError);
	}

	@Then("^I click on DO NOT Incept checkbox$")
	public void clickonDoNotInceptCheckbox() {
		boolean blnResult = accountUpdatesAndInfoPage.iClickonDoNotInceptCheckbox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on DO NOT Incept checkbox",
				"User should able to click DO NOT Incept checkbox", "Successfully able to click DO NOT Incept checkbox",
				"Failed to click DO NOT Incept checkbox :" + Common.strError);
	}

	@And("^I verify DO NOT Incept checkbox is checked$")
	public void checkDonotInceptCheckBoxState() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyDoNotInceptCheckboxIsChecked();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Validate if DO NOT Incept checkbox is checked", "DO NOT Incept checkbox should be checked",
				"Successfully able to check DO NOT Incept checkbox",
				"Failed to check DO NOT Incept checkbox :" + Common.strError);
	}

	@And("^I enter Invalid Date in the TermLetterDate field$")
	public void iEnterInvalidDateInTheTermLetterDateDateField() {
		boolean blnResult = accountUpdatesAndInfoPage.enterInvalidDateInTheTermLetterDateField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Invalid Date in the TermLetterDate field",
				"User should be able to enter Invalid Date in the TermLetterDate field",
				"Successfully able to enter Invalid Date in the TermLetterDate field",
				"Failed to enter Invalid Date in the TermLetterDate field : " + Common.strError);
	}

	@And("^I verify the Invalid Date Error message for TermLetterDate$")
	public void verifyTheInvalidDateErrorMessageForTermLetterDate() {
		boolean blnResult = accountUpdatesAndInfoPage.verifyTheInvalidDateErrorMessageForTermLetterDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Invalid Date Error message for TermLetterDate in Billing Setting Tab",
				"User should be able to see Invalid Date Error message",
				"Successfully able to see Invalid Date Error message",
				"Failed to see Invalid Date Error message : " + Common.strError);
	}

	@Then("^I verify Reactivation Date field added$")
	public void iVerifyReactivationDateFieldPresent() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyReactivationDateFieldPresent();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Reactivation Date field is present",
				"User should able to verify Reactivation Date field is present",
				"Successfully able to verify Reactivation Date field is present",
				"Failed to verify Reactivation Date field is present : " + Common.strError);
	}

	@Then("^I verify by default Reactivation Date field has value as null$")
	public void iVerifyReactivationDateHasNullValue() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyReactivationDateHasNullValue();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Reactivation Date field has value as null",
				"User should able to verify Reactivation Date field has value as null",
				"Successfully able to verify Reactivation Date field has value as null",
				"Failed to verify Reactivation Date field has value as null : " + Common.strError);
	}

	@Then("^I verify Reactivation Date field enabled$")
	public void iVerifyReactivationDateHasEnabledAndHasTodayDate() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyReactivationDateHasEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that Reactivation Date field has enabled",
				"User should able to verify Reactivation Date field has enabled",
				"Successfully able to verify Reactivation Date field has enabled",
				"Failed to verify Reactivation Date field has enabled : "
						+ Common.strError);
	}

	@Then("^I verify different date can be entered$")
	public void iVerifyReactivationDateCanHaveDifferentDate() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyReactivationDateCanHaveDifferentDate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify that different date can be entered for Reactivation Date",
				"User should able to verify different date can be entered for Reactivation Date",
				"Successfully able to verify different date can be entered for Reactivation Date",
				"Failed to verify different date can be entered for Reactivation Date : " + Common.strError);
	}

	@Then("^I verify confirm popup displayed$")
	public void iVerifyConfirmPopupDisplayed() {
		boolean blnResult = accountUpdatesAndInfoPage.iVerifyConfirmPopupDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify that confirm popup displayed",
				"User should able to verify confirm popup displayed",
				"Successfully able to verify confirm popup displayed",
				"Failed to verify confirm popup displayed : " + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
