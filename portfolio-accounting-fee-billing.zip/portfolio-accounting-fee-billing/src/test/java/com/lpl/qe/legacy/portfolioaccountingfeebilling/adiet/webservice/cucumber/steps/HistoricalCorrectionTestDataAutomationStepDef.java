package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;
import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.HistoricalCorrectionTestDataAutomation;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HistoricalCorrectionTestDataAutomationStepDef extends CommonStepDef {

	private String Account1;
	private String Account2;
	private String Account3;
	private String Account4;
	private String GroupId;
	
	@When("^I connect to historical BODS SQL Server$")
	public void connectToBodsSqlServer() {
		HistoricalCorrectionTestDataAutomation.connectToBodsSqlServer();
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE, "Connect to BODS SQL Server",
				"User should be able to Connect to BODS SQL Server", "Successfully able to Connect to BODS SQL Server",
				"Failed to see Connect to BODS SQL Server : " + Common.strError);
	}

	@When("^I Delete records for targeted accounts from identified source & target tables for the accounts \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" with group \"([^\"]*)\"$")
	public void i_Delete_records_for_targeted_accounts_from_identified_source_target_tables_for_the_accounts_with_group(
			String account1, String account2, String account3, String account4, String groupId) throws Throwable {
		Account1 = account1;
		Account2 = account2;
		Account3 = account3;
		Account4 = account4;
		GroupId = groupId;
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToDeleteRecordsFromIdentifiedTables(Account1, Account2, Account3, Account4,
				GroupId);
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to delete records for targeted accounts from identified source & target tables",
				"SQL delete queries should run successfully", "SQL delete queries ran successfully", 
				"Failed to run SQL delete queries" + Common.strError);
	}

	@When("^I Insert records in identified source tables for one month$")
	public void i_Insert_records_in_identified_source_tables() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToInsertRecordsInIdentifiedTables(Account1, Account2, Account3, Account4,
				GroupId, "one Month");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for one month",
				"SQL insert queries should run successfully", "SQL insert queries ran successfully",
				"Failed to run SQL insert queries" + Common.strError);

	}

	@Then("^I Remove from Audit Tables for one month$")
	public void i_Remove_From_Audit_table() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToRemoveFromAuditables(Account1, Account2, Account3, Account4, GroupId,
				"one Month");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to update records in audit tables",
				"SQL update queries should run successfully", "SQL update queries ran successfully",
				"Failed to run SQL update queries" + Common.strError);

	}

	@Then("^I Insert records in identified source tables for the same month$")
	public void i_Insert_records_in_identified_source_tables_for_the_same_month() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToInsertRecordsInIdentifiedTables(Account1, Account2, Account3, Account4,
				GroupId, "same Month");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for the same month :"
						+ Common.strError,
				null, null, null);
	}

	@Then("^I Remove from Audit Tables for the same month$")
	public void i_Remove_from_Audit_Tables_for_the_same_month() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToRemoveFromAuditables(Account1, Account2, Account3, Account4, GroupId,
				"same Month");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for the same month :"
						+ Common.strError,
				null, null, null);
	}

	@Then("^I Insert records in identified source tables for two months$")
	public void i_Insert_records_in_identified_source_tables_for_two_months() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToInsertRecordsInIdentifiedTables(Account1, Account2, Account3, Account4,
				GroupId, "two Months");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for two months :" + Common.strError,
				null, null, null);
	}

	@Then("^I Remove from Audit Tables for two months$")
	public void i_Remove_from_Audit_Tables_for_two_months() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToRemoveFromAuditables(Account1, Account2, Account3, Account4, GroupId,
				"two Months");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for two months :" + Common.strError,
				null, null, null);
	}

	@Then("^I Insert records in identified source tables for two separate months$")
	public void i_Insert_records_in_identified_source_tables_for_two_separate_months() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToInsertRecordsInIdentifiedTables(Account1, Account2, Account3, Account4,
				GroupId, "separate Months");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for the separte months :"
						+ Common.strError,
				null, null, null);
	}

	@Then("^I Remove from Audit Tables for two separate months$")
	public void i_Remove_from_Audit_Tables_for_two_separate_months() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToRemoveFromAuditables(Account1, Account2, Account3, Account4, GroupId,
				"separate Months");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for separate months :"
						+ Common.strError,
				null, null, null);
	}

//	@When("^I Delete records for targeted accounts from identified source & target tables for the accounts \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" with group \"([^\"]*)\" for Inception MV change$")
//	public void i_Delete_records_for_targeted_accounts_from_identified_source_target_tables_for_the_accounts_with_group_for_Inception_MV_change(
//			String account1, String account2, String account3, String account4, String groupId) throws Throwable {
//		Account1 = account1;
//		Account2 = account2;
//		Account3 = account3;
//		Account4 = account4;
//		GroupId = groupId;
//		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToDeleteRecordsFromIdentifiedTables(Account1,
//				Account2, Account3, Account4, GroupId);
//		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
//				"Run the SQL query to validate if Delete records for "
//						+ "targeted accounts from identified source & target tables for one month :" + Common.strError,
//				null, null, null);
//	}

	@Then("^I Insert records in identified source tables for one account$")
	public void i_Insert_records_in_identified_source_tables_for_one_account() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToInsertRecordsInIdentifiedTables(Account1,
				Account2, Account3, Account4, GroupId, "one account");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for one account :" + Common.strError,
				null, null, null);

	}

	@Then("^I Remove from Audit Tables for one account$")
	public void i_Remove_from_Audit_Tables_for_one_account() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToRemoveFromAuditables(Account1, Account2,
				Account3, Account4, GroupId, "one account");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for one account :" + Common.strError,
				null, null, null);

	}

	@Then("^I Insert records in identified source tables for two accounts for the same month$")
	public void i_Insert_records_in_identified_source_tables_for_two_accounts_for_the_same_month() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToInsertRecordsInIdentifiedTables(Account1,
				Account2, Account3, Account4, GroupId, "same month inception");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for same month:" + Common.strError,
				null, null, null);
	}

	@Then("^I Remove from Audit Tables for two accounts for the same month$")
	public void i_Remove_from_Audit_Tables_for_two_accounts_for_the_same_month() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToRemoveFromAuditables(Account1, Account2,
				Account3, Account4, GroupId, "same month inception");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for same month :" + Common.strError,
				null, null, null);

	}

	@Then("^I Insert records in identified source tables for two accounts for two separate months$")
	public void i_Insert_records_in_identified_source_tables_for_two_accounts_for_two_separate_months()
			throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToInsertRecordsInIdentifiedTables(Account1,
				Account2, Account3, Account4, GroupId, "separate months inception");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for separate months:"
						+ Common.strError,
				null, null, null);

	}

	@Then("^I Remove from Audit Tables for two accounts for two separate months$")
	public void i_Remove_from_Audit_Tables_for_two_accounts_for_two_separate_months() throws Throwable {
		HistoricalCorrectionTestDataAutomation.runTheSQLQueryToRemoveFromAuditables(Account1, Account2,
				Account3, Account4, GroupId, "separate months inception");
		LPLCoreReporter.writeStepToReporter(true, LPLCoreConstents.TRUE,
				"Run the SQL query to Insert records in identified source tables for separate months :"
						+ Common.strError,
				null, null, null);

	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
