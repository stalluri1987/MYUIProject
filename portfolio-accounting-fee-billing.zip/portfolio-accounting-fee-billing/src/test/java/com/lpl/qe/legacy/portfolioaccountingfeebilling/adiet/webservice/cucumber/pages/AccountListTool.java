package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreDBConnect;

/**
 * <p>
 * <br>
 * <b> Title: </b> AccountListTool.java</br>
 * <br>
 * <b> Description: </b> Page Object Library for AccountListTool</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * AccountListTool : </br>
 * <br>
 * isPageLoaded : This method is used to check if the page is the loaded</br>
 *
 * @author pmanohar
 * @since 03/16/2020
 *        </p>
 */

public class AccountListTool extends Common implements ILocatorInitialize {
	static final int PAGE_IDENTIFIER = 814;
	Map<String, HashMap<String, String>> pageObjectMap;
	String strListName;
	String strFirstAccountNumber;
	String strSecondAccountNumber;
	String strAccountListToolHeaderXpath;
	String strAddListButtonXpath;
	String strListNameTextBoxXpath;
	String strModifyListLabelXpath;
	String strAccountNoTextBoxXpath;
	String strAddAccountButtonXpath;
	String strOptionFirstAccountXpath;
	String strOptionSecondAccountXpath;
	String strDeleteAccountButtonXpath;
	String strMainMenuButtonXpath;
	String strAccountListXpath;
	String strDeleteListButtonXpath;
	String strListNameXpath;
	public static final String ACCOUNT_LIST_TOOL_PAGE_HEADER = "Account List Tool Page Header";
	public static final String ACCOUNT_LIST_BUTTON = "Add List Button";
	public static final String LIST_NAME = "List Name";
	public static final String MODEL_LIST_LABEL = "Modify List Label";
	public static final String ADD_ACCOUNT_BUTTON = "Add Account Button";
	public static final String FIRST_ACCOUNT = "First Account";
	public static final String ACCOUNT_NUMBER_TEXTBOX = "Account No Text Box";
	public static final String SECOND_ACCOUNT = "Second Account";
	public static final String DELETE_ACCOUNT_BUTTON = "Delete Account Button";
	public static final String MAIN_MENU_BUTTON = "Main Menu button";
	public static final String MY_LIST = "My List";
	public static final String DELETE_LIST_BUTTON = "Delete List button";

	public AccountListTool(WebDriver driver) {
		super(driver);
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			checkForLocatorTypeAndInitialize(pageObjectMap, field, PAGE_IDENTIFIER);
		}
	}

	/**
	 * This method is used to check if the page is the loaded
	 * 
	 * @return boolean
	 *
	 * @author pmanohar
	 * @since 03-16-2020
	 */
	public boolean isPageLoaded() {
		return isElementPresentUsingXpath(strAccountListToolHeaderXpath, LPLCoreConstents.getInstance().LOW,
				ACCOUNT_LIST_TOOL_PAGE_HEADER);
	}

	/**
	 * This method is used to check if the Add List button was clicked
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-08-2020
	 */
	public boolean clickOnAddListButton() {
		return clickElementUsingXpath(strAddListButtonXpath, ACCOUNT_LIST_BUTTON);
	}

	/**
	 * This method is used to enter the List name in text box
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-14-2020
	 */
	public boolean enterListNameInTheTextBox() {
		return enterTextUsingXpath(strListNameTextBoxXpath, testData.get("strListName"), LIST_NAME);
	}

	/**
	 * This method is used to verify the screen to Modify List
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-14-2020
	 */
	public boolean verifyScreenToModifyList() {
		return isElementPresentUsingXpath(strModifyListLabelXpath, LPLCoreConstents.getInstance().LOWEST,
				MODEL_LIST_LABEL);
	}

	/**
	 * This method is used to enter the first account number
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-14-2020
	 */
	public boolean enterFirstAccountNumber() {
		return enterTextUsingXpath(strAccountNoTextBoxXpath, testData.get("strFirstAccountNumber"),
				ACCOUNT_NUMBER_TEXTBOX);
	}

	/**
	 * This method is used to enter the first account number
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-14-2020
	 */
	public boolean clickOnAddAccountButton() {
		return clickElementUsingXpath(strAddAccountButtonXpath, ADD_ACCOUNT_BUTTON);
	}

	/**
	 * This method is used to verify that first account is added to list
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-15-2020
	 */
	public boolean verifyFirstAccountAddedToList() {
		return isElementPresentUsingXpath(strOptionFirstAccountXpath, FIRST_ACCOUNT);
	}

	/**
	 * This method is used to enter the second account number
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-15-2020
	 */
	public boolean enterSecondAccountNumber() {
		return enterTextUsingXpath(strAccountNoTextBoxXpath, testData.get("strSecondAccountNumber"),
				ACCOUNT_NUMBER_TEXTBOX);
	}

	/**
	 * This method is used to verify that second account is added to list
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-15-2020
	 */
	public boolean verifySecondAccountAddedToList() {
		return isElementPresentUsingXpath(strOptionSecondAccountXpath, SECOND_ACCOUNT);
	}

	/**
	 * This method is used to verify that second account is added to list
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-16-2020
	 */
	public boolean selectFirstAccountInList() {
		return clickElementUsingXpath(strOptionFirstAccountXpath, FIRST_ACCOUNT);
	}

	/**
	 * This method is used to verify that second account is added to list
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-16-2020
	 */
	public boolean clickOnDeleteAccount() {
		return clickElementUsingXpath(strDeleteAccountButtonXpath, DELETE_ACCOUNT_BUTTON);
	}

	/**
	 * This method is used to verify that second account is added to list
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-16-2020
	 */
	public boolean clickOnOk() {
		return acceptAlert();
	}

	/**
	 * This method is used to verify that first account is deleted from list
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-16-2020
	 */
	public boolean verifyFirstAccountDeletedFromList() {
		return isElementNotPresentUsingXpath(strOptionFirstAccountXpath);
	}

	/**
	 * This method is used to click on Main Menu
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-16-2020
	 */
	public boolean clickOnMainMenu() {
		return clickElementUsingXpath(strMainMenuButtonXpath, MAIN_MENU_BUTTON);
	}

	/**
	 * This method is used to scroll & select list
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-16-2020
	 */
	public boolean scrollAndSelectList() {
		return selectValueFromDropdownUsingXpath(strAccountListXpath, testData.get("strListName"), MY_LIST);
	}

	/**
	 * This method is used to click on Delete list
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-16-2020
	 */
	public boolean clickOnDeleteList() {
		return clickElementUsingXpath(strDeleteListButtonXpath, DELETE_LIST_BUTTON);
	}

	/**
	 * This method is used to verify that list is deleted
	 * 
	 * @return boolean
	 *
	 * @author nbajaj
	 * @since 07-16-2020
	 */
	public boolean verifyListDeleted() {
		return isElementNotPresentUsingXpath(strListNameXpath);
	}
}
