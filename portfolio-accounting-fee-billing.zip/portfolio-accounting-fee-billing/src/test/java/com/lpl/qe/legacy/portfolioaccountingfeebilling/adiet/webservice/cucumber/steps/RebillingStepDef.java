package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import java.io.IOException;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> RebillingStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for Rebilling</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * RebillingStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class RebillingStepDef extends CommonStepDef {

	@Given("^I verify Uploads tab is selected by default$")
	public void verifyUploadstabIsSelectedByDefault() {
		boolean blnResult = rebilling.iverifyUploadsTabisSelectedByDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Uploads tab is selected by default",
				"User should be able to see Uploads tab is selected by default",
				"Successfully able to see Uploads tab is selected by default",
				"Failed to see Uploads tab is selected by default : " + Common.strError);
	}

	@When("^I click on File type Drop down$")
	public void clickonFiletypeDropdown() {
		boolean blnResult = rebilling.iClickonFileTypeDropDown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on File type Drop down",
				"User should able to click File type Drop down", "Successfully able to click File type Drop down",
				"Failed to click File type Drop down :" + Common.strError);
	}

	@Then("^I verify the availability of File Type drop down options$")
	public void verifytheAvailabilityofFileTypeDropdownOptions(DataTable fileTypeOptions) {
		boolean blnResult = rebilling.iVerifytheAvailabilityofFileTypeOptions(fileTypeOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of File Type drop down options",
				"User should be able to see all File Type drop down options",
				"Successfully able to see all File Type drop down options",
				"Failed to see all File Type drop down options : " + Common.strError);
	}

	@Given("^I verify Browse button should be displayed in Uploads tab$")
	public void verifyBrowseButtonShouldbeDisplayedInUploadsTab() {
		boolean blnResult = rebilling.iVerifyBrowsebuttonShouldbeDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the availablity of Browse button",
				"User should be able to see Browse Button", "Successfully able to see Browse Button",
				"Failed to see Browse Button : " + Common.strError);
	}

	@Given("^I verify Upload button should be disable in Uploads tab$")
	public void iverifyUploadbuttonShouldbeDisableinUploadstab() {
		boolean blnResult = rebilling.iVerifyUploadbuttonShouldbeDisable();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Upload button is disable on Intial page load",
				"User should be able to see Upload button is disable on Intial page load",
				"Successfully able to see Upload button is disable on Intial page load",
				"Failed to see Upload button is disable on Intial page load : " + Common.strError);
	}

	@Given("^I verify file format hint should be displayed in Uploads tab$")
	public void verifyFileFormatHintshouldbeDisplayedinUploadsTab() {
		boolean blnResult = rebilling.iVerifyFileFormatHintMessage();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify file format hint text",
				"User should be able to see file format hint text", "Successfully able to see file format hint text",
				"Failed to see file format hint text : " + Common.strError);
	}

	@When("^I click on Precalc Sample Template download link$")
	public void clickonPrecalcSampleTemplateDownloadlink() {
		boolean blnResult = rebilling.iClickonPrecalcSampleTemplateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Precalc Sample Template link",
				"User should able to click Precalc Sample Template link",
				"Successfully able to click Precalc Sample Template link",
				"Failed to click Precalc Sample Template link :" + Common.strError);
	}

	@Then("^I verify PreCalc Template downloaded successfully$")
	public void ishouldSeeTemplateDownloadedsuccessfully() {
		boolean blnResult = rebilling.iShouldseeTemplateDownloadedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Template downloading status",
				"User should be able to see Template downloaded successfully",
				"Successfully able to see Template downloaded successfully",
				"Failed to see Template downloaded successfully : " + Common.strError);
	}

	@When("^I entered required data in downloaded sample template and Saved successfully$")
	public void ienteredRequiredDatainDownloadedSampleTemplateAndSavedsuccessfully() throws IOException {
		rebilling.iEnteredRequiredData();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Enter data in downloaded template file",
				"User should be able to Enter data in downloaded template file",
				"Successfully able to Enter data in downloaded template file",
				"Failed to Enter data in downloaded template file : " + Common.strError);
	}

	@When("^I select PreCalculation option from File Type drop down$")
	public void iselectPreCalculationoptionfromFileTypeDropDown() {
		boolean blnResult = rebilling.iSelectPreCalculationOptionFromFileTypeDropDown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select PreCalculation in File Type drop down list",
				"User should able to select PreCalculation from File Type drop down",
				"Successfully able to select PreCalculation from File Type drop down",
				"Failed to select PreCalculation from File Type drop down :" + Common.strError);
	}

	@When("^I click on Browse button$")
	public void iclickOnBrowsebutton() {
		boolean blnResult = rebilling.iClickonBrowseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "click on Browse button",
				"User should able to click Browse button", "Successfully able to click Browse button",
				"Failed to click Browse button :" + Common.strError);
	}

	@When("^I selected the filled sample downloaded template$")
	public void iselectedThefilledSampleDownloadedTemplate() {
		boolean blnResult = rebilling.iSelectedSampleDownloadedTemplate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select filled sample downloaded template",
				"User should able to Select filled sample downloaded template",
				"Successfully able to Select filled sample downloaded template",
				"Failed to Select filled sample downloaded template :" + Common.strError);
	}

	@When("^I verify Upload button should get enabled$")
	public void iverifyUploadbuttonshouldgetenabled() {
		boolean blnResult = rebilling.iVerifyUploadButtonGetEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Upload button status",
				"User should able to see Upload button get enabled",
				"Successfully able to see Upload button get enabled",
				"Failed to see Upload button get enabled :" + Common.strError);
	}

	@When("^I click on Upload button$")
	public void iclickonUploadbutton() {
		boolean blnResult = rebilling.iClickOnUploadButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Upload button",
				"User should able to click Upload button", "Successfully able to click Upload button",
				"Failed to click Upload button :" + Common.strError);
	}

	@Then("^I verify file uploaded successfully$")
	public void iverifyFileuploadedSuccessfully() {
		boolean blnResult = rebilling.iVerifyFileUploadedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify file uploaded sucessfully or not",
				"User should able to see file uploaded successfully", "Successfully able to see file uploaded",
				"Failed to see file uploaded :" + Common.strError);
	}

	@When("^I click on Adjustment tab$")
	public void iclickonAdjustmentTab() {
		boolean blnResult = rebilling.iClickOnAdjustmentTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Adjustment button",
				"User should able to click Adjustment button", "Successfully able to click Adjustment button",
				"Failed to click Adjustment button :" + Common.strError);
	}

	@When("^I select Precal in Source dropdown$")
	public void iselectPrecalinSourcedropdown() {
		boolean blnResult = rebilling.iSelectPrecalInSourceDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select Precal in the Source dropdown list", "User should able to select Precal",
				"Successfully able to select Precal", "Failed to select Precal :" + Common.strError);
	}

	@Then("^I select user from User dropdown$")
	public void selectUserFromUserDropdown() {
		boolean blnResult = rebilling.selectUserFromUserDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select user in the User dropdown list",
				"User should able to select user from User dropdown",
				"Successfully able to select user from User dropdown",
				"Failed to select user from User dropdown :" + Common.strError);
	}

	@And("^I click on Search button under Adjustment Tab$")
	public void iclickonSearchbuttonunderAdjustmentTab() {
		boolean blnResult = rebilling.iClickOnSearchButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Search button",
				"User should able to click Search button", "Successfully able to click Search button",
				"Failed to click Search button :" + Common.strError);
	}

	@Then("^I verify newly added record added successfully$")
	public void iVerifyNewlyAddedRecordSuccessfully() {
		boolean blnResult = rebilling.iVerifyNewlyAddedRecordSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify newly added record added successfully or not",
				"User should able to see newly added record added successfully",
				"Successfully able to see newly added record added successfully",
				"Failed to see newly added record :" + Common.strError);
	}

	@When("^I click on Delete icon in results table$")
	public void iclickonDeleteiconinResultstable() {
		boolean blnResult = rebilling.clickOnDeleteIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete icon",
				"User should able to click Delete icon", "Successfully able to click Delete icon",
				"Failed to click Delete icon :" + Common.strError);
	}

	@Then("^I should see delete confirmation pop up should be displayed$")
	public void ishouldSeedeleteConfirmationPopupshouldbeDisplayed() {
		boolean blnResult = rebilling.deleteConfirmationPopupDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Delete confirmation pop up",
				"User should be able to see Delete confirmation pop up",
				"Successfully able to see Delete confirmation pop up",
				"Failed to see Delete confirmation pop up : " + Common.strError);
	}

	@And("^I deleted newly added record successfully$")
	public void clickOnDeleteButton() {
		boolean blnResult = rebilling.clickOnDeleteButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Delete newly added record",
				"User should able to Delete newly added record", "Successfully able to Delete newly added record",
				"Failed to Delete newly added record :" + Common.strError);
	}

	@Then("^I verify the availability of search field options in Adjustment tab$")
	public void iverifyTheAvailabilityofSearchfieldOptionsinAdjustmentTab(DataTable searchFieldOptions) {
		boolean blnResult = rebilling.verifySearchFieldOptionsInAdjustmentTab(searchFieldOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Search field options", "User should be able to see Search field options",
				"Successfully able to see Search field options",
				"Failed to see Search field options : " + Common.strError);
	}

	@Then("^I verify the default value is selected in Source drop down$")
	public void iverifythedefaultvalueisselectedinSourcedropdown() {
		boolean blnResult = rebilling.verifyDefaultValueInSourceDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify default value in Source drop down",
				"User should be able to see default value in Source drop down",
				"Successfully able to see default value in Source drop down",
				"Failed to see default value in Source drop down : " + Common.strError);
	}

	@Then("^I verify the default value is selected in Status drop down$")
	public void iverifyTheDefaultValueisSelectedinStatusdropdown() {
		boolean blnResult = rebilling.verifyDefaultValueInStatusDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify default value in status drop down",
				"User should be able to see default value in status drop down",
				"Successfully able to see default value in status drop down",
				"Failed to see default value in status drop down : " + Common.strError);
	}

	@When("^I click on Source drop down$")
	public void iclickonSourceDropdown() {
		boolean blnResult = rebilling.clickOnSourceDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Source Dropdown",
				"User should able to click Source Dropdown", "Successfully able to click Source Dropdown",
				"Failed to click Source Dropdown :" + Common.strError);
	}

	@Then("^I verify the availability of Source drop down options$")
	public void verifyAvailabilityOfSourceDropdownOptions(DataTable sourceOptions) {
		boolean blnResult = rebilling.verifyAvailabilityOfSourceDropdownOptions(sourceOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Source drop down options",
				"User should be able to see all Source drop down options",
				"Successfully able to see Source drop down options",
				"Failed to see all Source drop down options : " + Common.strError);
	}

	@When("^I click on Status drop down$")
	public void clickOnStatusDropdown() {
		boolean blnResult = rebilling.clickOnStatusDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Status Dropdown",
				"User should able to click Status Dropdown", "Successfully able to click Status Dropdown",
				"Failed to click Status Dropdown :" + Common.strError);
	}

	@Then("^I verify the availability of Status drop down options$")
	public void verifyAvailabilityOfStatusDropdownOptions(DataTable statusOptions) {
		boolean blnResult = rebilling.verifyAvailabilityOfStatusDropdownOptions(statusOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Status drop down options",
				"User should be able to see all Status drop down options",
				"Successfully able to see all Status drop down options",
				"Failed to see all Status drop down options : " + Common.strError);
	}

	@And("^I click on Users drop down$")
	public void clickOnUsersDropdown() {
		boolean blnResult = rebilling.clickOnUsersDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Users drop down",
				"User should able to click Users drop down", "Successfully able to click Users drop down",
				"Failed to click Users drop down :" + Common.strError);
	}

	@Then("^I verify the availability of the Users drop down options$")
	public void verifyAvailabilityOfUsersDropdownOptions() {
		boolean blnResult = rebilling.verifyAvailabilityOfUsersDropdownOptions();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of the Users drop down options",
				"User should be able to see Users drop down options",
				"Successfully able to see Users drop down options",
				"Failed to see Users drop down options : " + Common.strError);
	}

	@When("^I click on Pricing Model drop down$")
	public void clickOnPricingModelDropdown() {
		boolean blnResult = rebilling.clickOnPricingModelDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Pricing Model Dropdown",
				"User should able to click Pricing Model Dropdown", "Successfully able to click Pricing Model Dropdown",
				"Failed to click Pricing Model Dropdown :" + Common.strError);
	}

	@Then("^I verify the availability of the Pricing Model drop down options$")
	public void verifyAvailabilityOfPricingModelDropdownOptions(DataTable pricingModelOptions) {
		boolean blnResult = rebilling.verifyAvailabilityOfPricingModelDropdownOptions(pricingModelOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Status drop down options",
				"User should be able to see all Status drop down options",
				"Successfully able to see all Status drop down options",
				"Failed to see all Status drop down options : " + Common.strError);
	}

	@Then("^I verify Search button should be displayed$")
	public void checkForSearchButton() {
		boolean blnResult = rebilling.checkForSearchButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Veridy Search button",
				"User should be able to see Search button", "Successfully able to see Search button",
				"Failed to see Search button : " + Common.strError);
	}

	@Then("^I verify Add Adjustment button should also be displayed$")
	public void iverifyAddAdjustmentbuttonShouldAlsobeDisplayed() {
		boolean blnResult = rebilling.checkForAdjustmentButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Add Adjustment button",
				"User should be able to see Add Adjustment button", "Successfully able to see Add Adjustment button",
				"Failed to see Add Adjustment button : " + Common.strError);
	}

	@When("^I click on Add Adjustment button$")
	public void clickOnAddAdjustmentButton() {
		boolean blnResult = rebilling.clickOnAddAdjustmentButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Add Adjustment button",
				"User should able to click Add Adjustment button", "Successfully able to click Add Adjustment button",
				"Failed to click Add Adjustment button:" + Common.strError);
	}

	@And("^I select Precalc$")
	public void selectPrecalc() {
		boolean blnResult = rebilling.selectPrecalc();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select Precalc",
				"User should able to Select Precalc", "Successfully able to Select Precalc",
				"Failed to click Select Precalc :" + Common.strError);
	}

	@Then("^I see a Add Adjustment for PreCalc pop up$")
	public void seeaAddAdjustmentforPreCalcPopup() {
		boolean blnResult = rebilling.seeaAddAdjustmentforPreCalcPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of PreCalc pop up", "User should be able to see PreCalc pop up",
				"Successfully able to see PreCalc pop up", "Failed to see PreCalc pop up : " + Common.strError);
	}

	@Then("^I see a Edit Adjustment for PreCalc pop up$")
	public void seeaEditAdjustmentforPreCalcPopup() {
		boolean blnResult = rebilling.seeaEditAdjustmentforPreCalcPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Edit PreCalc pop up", "User should be able to see Edit PreCalc pop up",
				"Successfully able to see PreCalc pop up", "Failed to see Edit PreCalc pop up : " + Common.strError);
	}

	@When("^I enter Portfolio number$")
	public void enterPortfolioNumber() {
		boolean blnResult = rebilling.enterPortfolioNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter ",
				"User should be able to enter Portfolio number", "Successfully able to enter Portfolio number",
				"Failed to enter Portfolio number : " + Common.strError);
	}

	@And("^I select Quarter end date$")
	public void selectQuarterEnddate() {
		boolean blnResult = rebilling.selectQuarterEnddate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Quarter end date",
				"User should be able to enter Quarter end date", "Successfully able to enter Quarter end date",
				"Failed to enter Quarter end date : " + Common.strError);
	}

	@And("^I select Effective date$")
	public void selectEffectivedate() {
		boolean blnResult = rebilling.selectEffectivedate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Effective date",
				"User should be able to enter Effective date", "Successfully able to enter Effective date",
				"Failed to enter Effective date : " + Common.strError);
	}

	@When("^I enter Net client charge$")
	public void enterNetclientCharge() {
		boolean blnResult = rebilling.enterNetclientCharge();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Net client charge",
				"User should be able to enter Net client charge", "Successfully able to enter Net client charge",
				"Failed to enter Net client charge : " + Common.strError);
	}

	@And("^I enter Gross broker payout$")
	public void enterGrossBrokerPayout() {
		boolean blnResult = rebilling.enterGrossBrokerPayout();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Gross broker payout",
				"User should be able to enter Gross broker payout", "Successfully able to enter Gross broker payout",
				"Failed to enter Gross broker payout : " + Common.strError);
	}

	@When("^I modify Gross broker payout$")
	public void modifyGrossBrokerPayout() {
		boolean blnResult = rebilling.modifyGrossBrokerPayout();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Modify Gross broker payout",
				"User should be able to Modify Gross broker payout", "Successfully able to Modify Gross broker payout",
				"Failed to Modify Gross broker payout : " + Common.strError);
	}

	@When("^I clear Net client charge$")
	public void clearNetClientChargeText() {
		boolean blnResult = rebilling.clearNetClientChargeText();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Clear Net client charge",
				"User should be able to clear Net client charge", "Successfully able to clear Net client charge",
				"Failed to clear Net client charge : " + Common.strError);
	}

	@When("^I clear Gross broker payout$")
	public void clearGrossBrokerPayoutText() {
		boolean blnResult = rebilling.clearGrossBrokerPayoutText();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Modify Gross broker payout",
				"User should be able to Modify Gross broker payout", "Successfully able to Modify Gross broker payout",
				"Failed to Modify Gross broker payout : " + Common.strError);
	}

	@When("^I enter Notes$")
	public void enterNotes() {
		boolean blnResult = rebilling.enterNotes();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Notes",
				"User should be able to enter Notes", "Successfully able to enter Notes",
				"Failed to enter Notes : " + Common.strError);
	}

	@When("^I click on Save$")
	public void clickonSave() {
		boolean blnResult = rebilling.clickonSave();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Save",
				"User should able to click Save", "Successfully able to click Save",
				"Failed to click Save :" + Common.strError);
	}

	@When("^I enter account number$")
	public void enterAccountNumber() {
		boolean blnResult = rebilling.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Account No.",
				"User should be able to enter Account No.", "Successfully able to enter Account No.",
				"Failed to enter Account No. : " + Common.strError);
	}

	@When("^I enter Account number in Add Adjustment pop up$")
	public void iEnterAccountNumberInAddAdjPopUp() {
		boolean blnResult = rebilling.enterAccountNoInAddAdjPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Enter Account No in Add Adjustment pop up", "User should be able to enter Account No",
				"Successfully able to enter Account No", "Failed to enter Account No : " + Common.strError);
	}

	@When("^I enter account number in search field$")
	public void enterAccountNumberinSearchField() {
		boolean blnResult = rebilling.enterAccountNumberSearchField();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Account No.",
				"User should be able to enter Account No.", "Successfully able to enter Account No.",
				"Failed to enter Account No. : " + Common.strError);
	}

	@Then("^I verify Adjustment added successfully$")
	public void verifyAdjustmentAddedSuccessfully() {
		boolean blnResult = rebilling.verifyAdjustmentAddedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Adjustment newly added record",
				"User should be able to see Adjustment newly added record",
				"Successfully able to see Adjustment newly added record",
				"Failed to see Adjustment newly added record : " + Common.strError);
	}

	@When("^I click Portfolio link$")
	public void clickPortfolioLink() {
		boolean blnResult = rebilling.clickPortfolioLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Portfolio link",
				"User should able to click Portfolio link", "Successfully able to click Portfolio link",
				"Failed to click Portfolio link :" + Common.strError);
	}

	@When("^I modify Admin fee$")
	public void modifyAdminFee() {
		boolean blnResult = rebilling.modifyAdminFee();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Modify Admin fee",
				"User should be able to Modify Admin fee", "Successfully able to Modify Admin fee",
				"Failed to Modify Admin fee : " + Common.strError);
	}

	@When("^I modify Net client charge$")
	public void modifyNetclientCharge() {
		boolean blnResult = rebilling.modifyNetclientCharge();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Modify Net client charge",
				"User should be able to Modify Net client charge", "Successfully able to Modify Net client charge",
				"Failed to Modify Net client charge : " + Common.strError);
	}

	@Then("^I verify details saved successfully$")
	public void verifyDetailsSavedSuccessfully() {
		boolean blnResult = rebilling.verifyDetailsSavedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the details saved successfully or not", "User should be able to verify details successfully",
				"Successfully able to verify details successfully", "Failed to verify details: " + Common.strError);
	}

	@When("^I click on Close$")
	public void clickonClose() {
		boolean blnResult = rebilling.clickonClose();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Close button",
				"User should able to click Close button", "Successfully able to click Close button",
				"Failed to click Close button:" + Common.strError);
	}

	@When("^I click on Close on Edit Adjustment Pop Up$")
	public void clickonCloseEditAdjustmentPopUp() {
		boolean blnResult = rebilling.clickonCloseEditAdj();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Close button",
				"User should able to click Close button", "Successfully able to click Close button",
				"Failed to click Close button:" + Common.strError);
	}

	@Then("^I verify Adjustment details updated successfully$")
	public void verifyAdjustmentDetailsUpdatedSuccessfully() {
		boolean blnResult = rebilling.verifyAdjustmentDetailsUpdatedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Adjustment details", "User should be able to see Adjustment details",
				"Successfully able to see Adjustment details", "Failed to see Adjustment details : " + Common.strError);
	}

	@Then("^I verify sws fee calculated successfully$")
	public void verifySwsFeeCalculatedSuccessfully() {
		boolean blnResult = rebilling.verifyPremiumFeeCalculatedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify sws fee calculation",
				"User should be able verify sws fee calculated successfully",
				"Successfully able to verify sws fee calculated successfully",
				"Failed to verify sws fee calculated successfully : " + Common.strError);
	}

	@Then("^I verify sws fee not calculated as expected$")
	public void verifySwsFeeNotCalculatedAsExpected() {
		boolean blnResult = rebilling.verifyPremiumFeeNotCalculatedAsExpected();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify sws fee",
				"User should be able verify sws fee not calculated as expected",
				"Successfully able to verify sws fee not calculated as expected",
				"Failed to verify sws fee calculation : " + Common.strError);
	}

	@When("^I click on Delete icon$")
	public void clickOnDeleteIcon() {
		boolean blnResult = rebilling.clickOnDelete();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete icon",
				"User should able to click Delete icon", "Successfully able to click Delete icon",
				"Failed to click Delete icon :" + Common.strError);
	}

	@Then("^I see delete confirmation pop up$")
	public void deleteConfirmationpopupDisplayed() {
		boolean blnResult = rebilling.checkIfDeleteConfirmationPopupDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of delete confirmation pop up",
				"User should be able to see delete confirmation pop up",
				"Successfully able to see delete confirmation pop up",
				"Failed to see delete confirmation pop up : " + Common.strError);
	}

	@When("^I click on Delete in confirmation pop up$")
	public void clickonDeleteinConfirmationPopup() {
		boolean blnResult = rebilling.clickonDeleteinConfirmationPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete",
				"User should able to click Delete", "Successfully able to click Delete",
				"Failed to click Delete :" + Common.strError);
	}

	@Then("^I verify record deleted successfully$")
	public void verifyRecordDeletedSuccessfully() {
		boolean blnResult = rebilling.verifyRecordDeletedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the record deletion",
				"User should be able to see record deleted successfully",
				"Successfully able to see record deleted successfully",
				"Failed to see record deleted successfully : " + Common.strError);
	}

	@Then("^I verify the availability of header fields in Adjustment Grid$")
	public void verifytheavailabilityofHeaderfieldsinAdjustmentGrid(DataTable gridHeaderFields) {
		boolean blnResult = rebilling.verifyAvailabilityOfHeaderfieldsinAdjustmentGrid(gridHeaderFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Adjustment Grid Header Fields",
				"User should be able to see all Adjustment Grid Header Fields",
				"Successfully able to see all Adjustment Grid Header Fields",
				"Failed to see all Adjustment Grid Header Fields : " + Common.strError);
	}

	@Then("^I select all user from User dropdown$")
	public void selectAllUserFromUserDropdown() {
		boolean blnResult = rebilling.selectAllUserFromUserDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Select user in the User dropdown list",
				"User should able to select user from User dropdown",
				"Successfully able to select user from User dropdown",
				"Failed to select user from User dropdown :" + Common.strError);
	}

	@Then("^I verify Pricing Model displayed Add Adjustment Pop Up$")
	public void verifyPricingModelDisplayedAddAdjustmentPopUp() {
		boolean blnResult = rebilling.iVerifyPricingModelDisplayedAddPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify Pricing Model displayed in the grid$")
	public void verifyPricingModelDisplayedIntheGrid() {
		boolean blnResult = rebilling.iVerifyPricingModelDisplayedGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify Pricing Model displayed Edit Adjustment Pop Up$")
	public void verifyPricingModelDisplayedEditAdjsutmentPopUp() {
		boolean blnResult = rebilling.iVerifyPricingModelDisplayedEditPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify Employee Model Pricing Model displayed Add Adjustment Pop Up$")
	public void verifyEMPricingModelDisplayedAddAdjustmentPopUp() {
		boolean blnResult = rebilling.iVerifyEMPricingModelDisplayedAddPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify Employee Model Pricing Model displayed in the grid$")
	public void verifyEMPricingModelDisplayedIntheGrid() {
		boolean blnResult = rebilling.iVerifyEMPricingModelDisplayedGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@And("^I verify Employee Model Pricing Model displayed Edit Adjustment Pop Up$")
	public void verifyEMPricingModelDisplayedEditAdjsutmentPopUp() {
		boolean blnResult = rebilling.iVerifyEMPricingModelDisplayedEditPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify REP AUM Pricing Model displayed Add Adjustment Pop Up$")
	public void verifyREPAUMPricingModelDisplayedAddAdjustmentPopUp() {
		boolean blnResult = rebilling.iVerifyREPAUMPricingModelDisplayedAddPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify REP AUM Pricing Model displayed in the grid$")
	public void verifyREPAUMPricingModelDisplayedIntheGrid() {
		boolean blnResult = rebilling.iVerifyREPAUMPricingModelDisplayedGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify REP AUM Pricing Model displayed Edit Adjustment Pop Up$")
	public void verifyREPAUMPricingModelDisplayedEditAdjsutmentPopUp() {
		boolean blnResult = rebilling.iVerifyREPAUMPricingModelDisplayedEditPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify No Pricing Model displayed Add Adjustment Pop Up$")
	public void verifyNoPricingModelDisplayedAddAdjustmentPopUp() {
		boolean blnResult = rebilling.iVerifyNoPricingModelDisplayedAddPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify No Pricing Model displayed in the grid$")
	public void verifyNoPricingModelDisplayedIntheGrid() {
		boolean blnResult = rebilling.iVerifyNoPricingModelDisplayedGrid();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify No Pricing Model displayed Edit Adjustment Pop Up$")
	public void verifyNoPricingModelDisplayedEditAdjsutmentPopUp() {
		boolean blnResult = rebilling.iVerifyNoPricingModelDisplayedEditPopUp();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Pricing Model displayed",
				"User should be able verify Pricing Model displayed",
				"Successfully able to verify Pricing Model displayed",
				"Failed to verify Pricing Model displayed : " + Common.strError);
	}

	@Then("^I verify Trade Admin Fee is displayed on Adjustment Popup$")
	public void verifyTradeAdminFeeIsDisplayedOnAdjustmentPopup() {
		boolean blnResult = rebilling.iVerifyTradeAdminFeeIsDisplayedOnAdjustmentPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Trade Admin Fee is displayed on Adjustment popup",
				"User should able to verify Trade Admin Fee is displayed on  Adjustment popup",
				"Successfully able to verify Trade Admin Fee is displayed on Adjustment popup",
				"Failed to see Trade admin Fee on Adjustment Popup :" + Common.strError);
	}

	@Then("^I verify Trade Admin Fee is non editable on Edit Adjustment Popup$")
	public void verifyTradeAdminFeeIsNonEditableOnEditAdjustmentPopup() {
		boolean blnResult = rebilling.iVerifyTradeAdminFeeIsNonEditableOnEditAdjustmentPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Trade Admin Fee is non editable on Edit Adjustment popup",
				"User should able to verify Trade Admin Fee is non editable on Edit Adjustment popup",
				"Successfully able to verify Trade Admin Fee is non editable on Edit Adjustment popup",
				"Failed Trade admin field is editable on Edit Adjustment popup:" + Common.strError);
	}

	@Then("^I verify Trade Admin Fee is non editable on Add Adjustment Popup$")
	public void verifyTradeAdminFeeIsNonEditableOnEditableAddAdjustmentPopup() {
		boolean blnResult = rebilling.iVerifyTradeAdminFeeIsNonEditableOnAddAdjustmentPopup();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Trade Admin Fee is non editable on Add Adjustment popup",
				"User should able to verify Trade Admin Fee is non editable on Add Adjustment popup",
				"Successfully able to verify Trade Admin Fee is non editable on Add Adjustment popup",
				"Failed Trade admin field is editable on Add Adjustment popup:" + Common.strError);
	}

	@Then("^I verify recalculation for GBP$")
	public void verifyRecalculationForGBP() {
		boolean blnResult = rebilling.iVerifyRecalculationForGBP();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify GBP recalculation on Edit Adjustment popup",
				"User should able to verify GBP recalculation on Edit Adjustment popup",
				"Successfully able to verify GBP recalculation on Edit Adjustment popup",
				"Failed GBP recalculation not considering Trade Admin Fee value :" + Common.strError);
	}

	@When("^I select REP AUM in Pricing Model dropdown$")
	public void selectRepAumInPricingModelDropdown() {
		boolean blnResult = rebilling.iSelectRepAumFromPricingModelDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select Precal in the Source dropdown list", "User should able to select Precal",
				"Successfully able to select Precal", "Failed to select Precal :" + Common.strError);
	}

	@Then("^I delete already existing adjustment for the account$")
	public void DeleteExistingAdjustmentRecord() {
		boolean blnResult = rebilling.clickOnDeleteButtonExistingRecords();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Delete existing PreCalc Adjustment record for the account",
				"User should able to Delete existing PreCalc Adjustment record for the account",
				"Successfully able to Delete newly added record",
				"Failed to Delete existing PreCalc Adjustment record for the account :" + Common.strError);
	}

	@And("^I close the user dropdown$")
	public void closeTheUserDropdown() {
		boolean blnResult = rebilling.closeTheUserDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Close the User dropdown list",
				"User should able to close User dropdown", "Successfully able to close User dropdown",
				"Failed to close User dropdown :" + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
