package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> PortfolioAccountingStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for PortfolioAccounting</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * PortfolioAccountingStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class PortfolioAccountingStepDef extends CommonStepDef {

	@Given("^I verify LPL Account Number search field displayed$")
	public void verifyTheLPLAccountNumberSearchFieldDisplayed() {
		boolean blnResult = portfolioAccounting.verifytheavailabilityofsearchfieldLPLAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the LPL account number serach field",
				"User should be able to see LPL account number search field options",
				"Successfully able to see LPL account number search field ",
				"Failed to see LPL account number search field  : " + Common.strError);
	}

	@When("^I enter account number on Portfolio Accounting Page$")
	public void enterAccountNumber() {
		boolean blnResult = portfolioAccounting.enterAccountNumber();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Enter Account number",
				"User should be able to enter Account Number in the field",
				"Successfully able to enter Account Number in the first field",
				"Failed to enter Account Number in the field : " + Common.strError);
	}

	@And("^I click on Search button on Portfolio Accounting page$")
	public void clickOnSearchButton() {
		boolean blnResult = portfolioAccounting.iClickOnSearchButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click On Search button",
				"User should be able to click on Search button", "Successfully able to click on Search button",
				"Failed to click on Search button : " + Common.strError);
	}

	@Then("^I verify the availablity of the below tabs$")
	public void verifyThatTwoTabsArePresentBETAAndFBVATab(DataTable tab) {
		boolean blnResult = portfolioAccounting.verifyTheAvailabilityOfTabs(tab);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the below tabs-Beta and FBVA Tab ",
				"User should be able to see the Beta and FBVA Tab", "Successfully able to see  the Beta and FBVA Tab",
				"Failed to see  the Beta and FBVA Tab: " + Common.strError);
	}

	@And("^I verify that Beta tab is selected by default$")
	public void verifyThatBETATabIsSelectedByDefault() {
		boolean blnResult = portfolioAccounting.verifyBetaTabIsSelectedByDefault();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Beta tab is selected by default ", "User should be able to see the Beta Tab",
				"Successfully able to see  the Beta Tab", "Failed to see  the Beta Tab: " + Common.strError);
	}

	@And("^I verify that the Beta tab has below fields$")
	public void verifyThatTheBETATabHasBelowFields(DataTable betafields) {
		boolean blnResult = portfolioAccounting.verifyTheAvailabilityOfBetaFields(betafields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the fields on Beta Tab ",
				"User should be able to see the fields on Beta Tab", "Successfully able to see the fields on Beta Tab",
				"Failed to see the fields on Beta Tab: " + Common.strError);
	}

	@When("^I click on Export button $")
	public void clickOnExportButton() {
		final boolean blnResult = accountUpdatesAndInfoPage.iClickOnExportButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Export button",
				"User should able to click Export button", "Successfully able to click Export button",
				"Failed to click Export button :" + Common.strError);
	}

	@Then("^I verified file downloaded successfully on Beta tab$")
	public void verifiedFileDownloadedSuccessfully() {
		boolean blnResult = portfolioAccounting.verifyDownloadedFileAndDeleteOnBeta();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully",
				"Successfully able to see file downloaded successfully",
				"Failed to see file downloaded successfully : " + Common.strError);
	}

	@And("^I verify the display of fields in BETA grid header$")
	public void verifyTheDisplayOfFieldsInBetaGridHeader(DataTable betaGridheader) {
		boolean blnResult = portfolioAccounting.verifyTheDisplayOfFieldsInBetaGridHeader(betaGridheader);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in BETA grid header ",
				"User should be able to see the fields in BETA grid header",
				"Successfully able to see the fields in BETA grid header",
				"Failed to see the fields in BETA grid header: " + Common.strError);
	}

	@Then("^I verify the display of error message$")
	public void verifytheDisplayOfErrorMessageAccountDoesNotExist() {
		boolean blnResult = portfolioAccounting.verifytheDisplayOfErrorMessageAccountDoesNotExist();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of error message in Beta Tab",
				"User should be able to see error message in Beta Tab",
				"Successfully able to see error message in Beta Tab",
				"Failed to see error message in Beta Tab  : " + Common.strError);
	}

	@Then("^I verify the display of error message in Positions tab$")
	public void verifyTheDisplayOfErrorMessageInPositionsTab() {
		boolean blnResult = portfolioAccounting.verifytheDisplayOfErrorMessageInPositionsTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of error message in Positions Tab",
				"User should be able to see error message in Positions Tab",
				"Successfully able to see error message in Positions Tab",
				"Failed to see error message in Positions Tab  : " + Common.strError);
	}

	@And("^I click on FBVA tab on Portfolio Accounting page$")
	public void clickOnFBVATabOnPortfolioAccountingPage() {
		boolean blnResult = portfolioAccounting.verifyiClickOnFBVATab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click On FBVA tab",
				"User should be able to click on FBVA tab", "Successfully able to click on FBVA tab",
				"Failed to click on FBVA tab : " + Common.strError);
	}

	@And("^I verify that the FBVA tab has below fields$")
	public void verifyTheFBVATabHasBelowFields(DataTable fbvaFields) {
		boolean blnResult = portfolioAccounting.verifyTheAvailabilityOfFBVAFields(fbvaFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the fields on FBVA Tab ",
				"User should be able to see the fields on FBVA Tab", "Successfully able to see the fields on FBVA Tab",
				"Failed to see the fields on FBVA Tab: " + Common.strError);
	}

	@And("^I verify the display of fields in FBVATransactions grid header$")
	public void verifyTheDisplayOfFieldsInFBVATransactionsGridHeader(DataTable fbvaTransactionsGridHeader) {
		boolean blnResult = portfolioAccounting
				.verifyTheDisplayOfFieldsInFBVATransactionsGridHeader(fbvaTransactionsGridHeader);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in FBVATransactions grid header ",
				"User should be able to see the fields in FBVATransactions grid header",
				"Successfully able to see the fields in FBVATransactions grid header",
				"Failed to see the fields in FBVATransactions grid header: " + Common.strError);
	}

	@And("^I verify the display of fields in FBVAPositions grid header$")
	public void verifyTheDisplayOfFieldsInFBVAPositionsGridHeader(DataTable fbvaPositionsGridHeader) {
		boolean blnResult = portfolioAccounting
				.verifyTheDisplayOfFieldsInFBVAPositionsGridHeader(fbvaPositionsGridHeader);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in FBVAPositions grid header ",
				"User should be able to see the fields in FBVAPositions grid header",
				"Successfully able to see the fields in FBVAPositions grid header",
				"Failed to see the fields in FBVAPositions grid header: " + Common.strError);
	}

	@Then("^I verified file downloaded successfully on FBVA tab$")
	public void verifiedFileDownloadedSuccessfullyOnFbvaTab() {
		boolean blnResult = portfolioAccounting.verifyDownloadedFileAndDeleteOnFBVA();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully",
				"Successfully able to see file downloaded successfully",
				"Failed to see file downloaded successfully : " + Common.strError);
	}

	@And("^I verify that the DirectBusinessFBVA tab has below fields$")
	public void verifyThatTheDirectBusinessFbvaTabHasBelowFields(DataTable directBusinessFbvaFields) {
		boolean blnResult = portfolioAccounting
				.verifyTheAvailabilityOfDirectBusinessFBVAFields(directBusinessFbvaFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the fields on FBVA Tab ",
				"User should be able to see the fields on FBVA Tab", "Successfully able to see the fields on FBVA Tab",
				"Failed to see the fields on FBVA Tab: " + Common.strError);
	}

	@And("^I click on DirectBusinessFBVA tab on Portfolio Accounting page$")
	public void clickOnDirectBusinessFbvaTabOnPortfolioAccountingPage() {
		boolean blnResult = portfolioAccounting.verifyiClickOnDirectBusinessFBVATab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click On FBVA tab",
				"User should be able to click on FBVA tab", "Successfully able to click on FBVA tab",
				"Failed to click on FBVA tab : " + Common.strError);
	}

	@And("^I verify that the Positions tab has below fields$")
	public void verifyThatThePositionsTabHasBelowFields(DataTable betaFields) {
		boolean blnResult = portfolioAccounting.verifyTheAvailabilityOfPositionsFields(betaFields);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availablity of the fields on Positions Tab ",
				"User should be able to see the fields on Positions Tab",
				"Successfully able to see the fields on Positions Tab",
				"Failed to see the fields on Positions Tab: " + Common.strError);
	}

	@And("^I click on Positions tab$")
	public void verifyclickonPositionstab() {
		boolean blnResult = portfolioAccounting.verifyclickonPositionstab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click On Positions tab",
				"User should be able to click on Positions tab", "Successfully able to click on Positions tab",
				"Failed to click on Positions tab : " + Common.strError);
	}

	@And("^I verify the display of fields in Positions grid header$")
	public void verifyTheDisplayOfFieldsInPositionsGridHeader(DataTable positionsGridheader) {
		boolean blnResult = portfolioAccounting.verifyTheDisplayOfFieldsInPositionsGridHeader(positionsGridheader);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the display of fields in Positions grid header ",
				"User should be able to see the fields in Positions grid header",
				"Successfully able to see the fields in Positions grid header",
				"Failed to see the fields in Positions grid header: " + Common.strError);
	}

	@Then("^I verify the file is downloaded successfully on Positions tab$")
	public void verifiedFileDownloadedSuccessfullyPositionsTab() {
		boolean blnResult = portfolioAccounting.verifyDownloadedFileAndDeleteOnPositions();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify if a file downloaded and delete file",
				"User should be able to see file downloaded successfully",
				"Successfully able to see file downloaded successfully",
				"Failed to see file downloaded successfully : " + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}