package com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.steps;

import java.io.IOException;

import com.lpl.qe.legacy.portfolioaccountingfeebilling.adiet.webservice.cucumber.pages.Common;

import LPLCoreDriver.LPLCoreConstents;
import LPLCoreDriver.LPLCoreReporter;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * <p>
 * <br>
 * <b> Title: </b> RebillingTerminationStepDef.java</br>
 * <br>
 * <b> Description: </b> Step Definition for RebillingTermination</br>
 * <br>
 * <b>Usage:</b></br>
 * <br>
 * RebillingTerminationStepDef : </br>
 * <br>
 *
 * @author ahadi
 * @since 03/16/2020
 *        </p>
 */
public class RebillingTerminationStepDef extends CommonStepDef {

	@When("^I click on Account Termination tab$")
	public void iclickonAccountTerminationtab() {
		boolean blnResult = rebilling.clickOnAccountTerminationTab();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Account Termination Tab",
				"User should able to click Account Termination Tab",
				"Successfully able to click Account Termination Tab",
				"Failed to click Account Termination Tab :" + Common.strError);
	}

	@Then("^I verify the default value ADHOC Termination selected in Termination Source drop down$")
	public void iverifythedefaultvalueselectedinTerminationSourcedropdown() {
		boolean blnResult = rebilling.verifyDefaultValueInTerminationSourceDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the default value in Termination Source drop down",
				"User should be able to see default value in Termination Source drop down",
				"Successfully able to see default value in Termination Source drop down",
				"Failed to see default value in Termination Source drop down : " + Common.strError);
	}

	@Then("^I verify the availability of Termination Source drop down options$")
	public void iverifytheavailabilityofTerminationSourcedropdownoptions(DataTable terminationSourceOptions) {
		boolean blnResult = rebilling.verifyTerminationSourceDropdownOptions(terminationSourceOptions);
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the availability of Termination Source drop down options",
				"User should be able to see all Termination Source drop down options",
				"Successfully able to see all Termination Source drop down options",
				"Failed to see all Termination Source drop down options : " + Common.strError);
	}

	@Then("^I verify Browse button should be displayed in Account Termination tab$")
	public void iverifyBrowsebuttonshouldbedisplayedinAccountTerminationtab() {
		boolean blnResult = rebilling.checkForBrowseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Browse button",
				"User should be able to see Browse button", "Successfully able to see Browse button",
				"Failed to see Browse button : " + Common.strError);
	}

	@Then("^I verify Upload button should be disable in Account Termination tab$")
	public void iverifyUploadbuttonshouldbedisableinAccountTerminationtab() {
		boolean blnResult = rebilling.checkForUploadButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify the Upload button",
				"User should be able to see Upload button", "Successfully able to see Upload button",
				"Failed to see Upload button : " + Common.strError);
	}

	@Then("^I verify Adhoc Termination Sample Template link should be displayed$")
	public void iverifyAdhocTerminationSampleTemplatelinkshouldbedisplayed() {
		boolean blnResult = rebilling.checkForAdhocTerminationSampleTemplateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Adhoc Termination Sample Template link",
				"User should be able to see Adhoc Termination Sample Template link",
				"Successfully able to see Adhoc Termination Sample Template link",
				"Failed to see Adhoc Termination Sample Template link : " + Common.strError);
	}

	@When("^I click on ADHOC Termination Sample Template download link$")
	public void iClickonADHOCTerminationSampleTemplatedownloadlink() {
		boolean blnResult = rebilling.iClickonAdhocTermSampleTemplateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on ADHOC Termination Sample Template link",
				"User should able to click ADHOC Termination Sample Template link",
				"Successfully able to click ADHOC Termination Sample Template link",
				"Failed to click ADHOC Termination Sample Template link :" + Common.strError);
	}

	@Then("^I verify Adhoc Term Template downloaded successfully$")
	public void ishouldseeAdhocTermTemplatedownloadedsuccessfully() {
		boolean blnResult = rebilling.iShouldseeAdhocTermTemplateDownloadedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Adhoc Term Template downloading status",
				"User should be able to see Adhoc Term Template downloaded successfully",
				"Successfully able to see Adhoc Term Template downloaded successfully",
				"Failed to see Adhoc Term Template downloaded successfully : " + Common.strError);
	}

	@When("^I entered required data in downloaded Adhoc Term sample template and Saved successfully$")
	public void ienteredrequireddataindownloadedAdhocTermsampletemplateandSavedsuccessfully() throws IOException {
		rebilling.iEnteredRequiredAdhocTermData();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Enter data in downloaded template file",
				"User should be able to Enter data in downloaded template file",
				"Successfully able to Enter data in downloaded template file",
				"Failed to Enter data in downloaded template file : " + Common.strError);
	}

	@When("^I click on Browse button on Account Termination screen$")
	public void iclickonBrowsebuttononAccountTerminationScreen() {
		boolean blnResult = rebilling.iClickonTerminationBrowseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "click on Browse button",
				"User should able to click Browse button", "Successfully able to click Browse button",
				"Failed to click Browse button :" + Common.strError);
	}

	@When("^I selected the filled Adhoc Term sample downloaded template$")
	public void iselectedthefilledAdhocTermsampledownloadedtemplate() {
		boolean blnResult = rebilling.iSelectedAdhocTermSampleDownloadedTemplate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select filled sample downloaded template",
				"User should able to Select filled sample downloaded template",
				"Successfully able to Select filled sample downloaded template",
				"Failed to Select filled sample downloaded template :" + Common.strError);
	}

	@And("^I verify Upload button should get enabled on Account Termination screen$")
	public void iverifyUploadbuttonshouldgetenabledonAccountTerminationScreen() {
		boolean blnResult = rebilling.iVerifyUploadButtonGetEnabled();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Upload button status",
				"User should able to see Upload button get enabled",
				"Successfully able to see Upload button get enabled",
				"Failed to see Upload button get enabled :" + Common.strError);
	}

	@When("^I click on Upload button on Account Termination screen$")
	public void iclickonUploadbuttononAccountTerminationScreen() {
		boolean blnResult = rebilling.iClickOnUploadButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Upload button",
				"User should able to click Upload button", "Successfully able to click Upload button",
				"Failed to click Upload button :" + Common.strError);
	}

	@Then("^I verify file uploaded successfully on Account Termination screen$")
	public void iverifyfileuploadedsuccessfullyonAccountTerminationScreen() {
		boolean blnResult = rebilling.iVerifyFileUploadedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify file uploaded sucessfully or not",
				"User should able to see file uploaded successfully", "Successfully able to see file uploaded",
				"Failed to see file uploaded :" + Common.strError);
	}

	@When("^I select TerminatedAccounts in Source dropdown$")
	public void iselectTerminatedAccountsinSourcedropdowninSourcedropdown() {
		boolean blnResult = rebilling.iSelectTerminatedAccountsInSourceDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select Precal in the Source dropdown list", "User should able to select Precal",
				"Successfully able to select Precal", "Failed to select Precal :" + Common.strError);
	}

	@Then("^I verify newly added Term record added successfully$")
	public void iverifynewlyaddedTermrecordaddedsuccessfully() {
		boolean blnResult = rebilling.iVerifyNewlyAddedRecordSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify newly added record added successfully or not",
				"User should able to see newly added record added successfully",
				"Successfully able to see newly added record added successfully",
				"Failed to see newly added record :" + Common.strError);
	}

	@When("^I click on Delete icon next to Term Adjustment in results table$")
	public void iclickonDeleteiconnexttoTermAdjustmentinresultstable() {
		boolean blnResult = rebilling.clickOnDeleteIcon();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Delete icon",
				"User should able to click Delete icon", "Successfully able to click Delete icon",
				"Failed to click Delete icon :" + Common.strError);
	}

	@Then("^I should see delete confirmation pop up for Term Adjustment$")
	public void ishouldseedeleteconfirmationpopupforTermAdjustment() {
		boolean blnResult = rebilling.deleteConfirmationPopupDisplayed();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Verify Delete confirmation pop up",
				"User should be able to see Delete confirmation pop up",
				"Successfully able to see Delete confirmation pop up",
				"Failed to see Delete confirmation pop up : " + Common.strError);
	}

	@When("^I deleted newly added Term Adjustment record successfully$")
	public void ideletednewlyaddedTermAdjustmentrecordsuccessfully() {
		boolean blnResult = rebilling.clickOnDeleteButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Delete newly added record",
				"User should able to Delete newly added record", "Successfully able to Delete newly added record",
				"Failed to Delete newly added record :" + Common.strError);
	}

	@When("^I click on drop down$")
	public void iClickonTerminationdropdown() {
		boolean blnResult = rebilling.clickOnTerminationDropdown();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the User can click Termination Selection Dropdown",
				"User should be able to Click Termination Dropdown", "Successfully to Click Termination Dropdown",
				"Failed to to Click Termination Dropdown : " + Common.strError);
	}

	@When("^I select ACAT Termination from drop down$")
	public void iSelectACATTerminationfromDropdown() {
		boolean blnResult = rebilling.selectAcat();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the ACAT Option is selected in Dropdown",
				"User should be able to select ACAT Termination Dropdownitem",
				"Successfully able to see ACAT Termination Selected",
				"Failed to select ACAT Termination  : " + Common.strError);
	}

	@Then("^I verify ACAT Termination Sample Template link should be displayed$")
	public void iverifyACATTerminationSampleTemplatelinkshouldbedisplayed() {
		boolean blnResult = rebilling.checkForAcatTerminationSampleTemplateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the ACAT Termination Sample Template link",
				"User should be able to see ACAT Termination Sample Template link",
				"Successfully able to see ACAT Termination Sample Template link",
				"Failed to see ACAT Termination Sample Template link : " + Common.strError);
	}

	@When("^I click on ACAT Termination Sample Template download link$")
	public void iclickonACATTerminationSampleTemplatedownloadLink() {
		boolean blnResult = rebilling.iClickonAcatTermSampleTemplateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on ACAT Termination Sample Template link",
				"User should able to click ACAT Termination Sample Template link",
				"Successfully able to click ACAT Termination Sample Template link",
				"Failed to click ACAT Termination Sample Template link :" + Common.strError);
	}

	@Then("^I verify ACAT Term Template downloaded successfully$")
	public void ishouldseeACATTermTemplatedownloadedsuccessfully() {
		boolean blnResult = rebilling.iShouldseeACATTermTemplateDownloadedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify ACAT Term Template downloading status",
				"User should be able to see ACAT Term Template downloaded successfully",
				"Successfully able to see ACAT Term Template downloaded successfully",
				"Failed to see Adhoc Term Template downloaded successfully : " + Common.strError);
	}

	@When("^I enter required data in downloaded ACAT Term sample template and Saved successfully$")
	public void ienteredrequireddataindownloadeACATTermsampletemplateandSavedsuccessfully() throws IOException {
		rebilling.iEnteredRequiredACATTermData();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Enter data in downloaded template file",
				"User should be able to Enter data in downloaded template file",
				"Successfully able to Enter data in downloaded template file",
				"Failed to Enter data in downloaded template file : " + Common.strError);
	}

	@And("^I click on ACATBrowse button on Account Termination screen$")
	public void iclickonACATBrowsebuttononAccountTerminationScreen() {
		boolean blnResult = rebilling.iClickonACATTerminationBrowseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Browse button",
				"User should able to click Browse button", "Successfully able to click Browse button",
				"Failed to click Browse button :" + Common.strError);
	}

	@When("^I selected the filled ACAT Term sample downloaded template$")
	public void iselectedthefilledACATTermsampledownloadedtemplate() {
		boolean blnResult = rebilling.iSelectedACATTermSampleDownloadedTemplate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select filled sample downloaded template",
				"User should able to Select filled sample downloaded template",
				"Successfully able to Select filled sample downloaded template",
				"Failed to Select filled sample downloaded template :" + Common.strError);
	}

	@And("^I click on Upload button on ACAT Account Termination screen$")
	public void iclickonUploadbuttononACATAccountTerminationScreen() {
		boolean blnResult = rebilling.iClickOnACATUploadButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on ACAT Upload button",
				"User should able to click ACAT Upload button", "Successfully able to click ACAT Upload button",
				"Failed to click ACAT Upload button :" + Common.strError);
	}

	@When("^I select the checkbox$")
	public void iSelecttheCheckbox() {
		boolean blnResult = rebilling.iClickOnCheckBox();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on CheckBox",
				"User should able to click CheckBoxn", "Successfully able to click Check Box",
				"Failed to click CheckBox :" + Common.strError);
	}

	@When("^I click on Process Adjustment button$")
	public void iSelecttheProcessButton() {
		boolean blnResult = rebilling.iClickOnProcessButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Process Button",
				"User should able to click Process Button", "Successfully able to click ProcessButton",
				"Failed to click Process Button :" + Common.strError);
	}

	@And("^I enter Account number in Portfolio$")
	public void iEnterAccountnumberinPortfolio() {
		boolean blnResult = rebilling.enterAccountNumberinAdjustment();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Provide Account Number in Portfolio",
				"User should able to enter Account Number", "Successfully able to enter Account Number",
				"Failed to enter Account Number :" + Common.strError);
	}

	@When("^I select Global Broker Termination from drop down$")
	public void iSelectGlobalBrokerTerminationfromDropdown() {
		boolean blnResult = rebilling.selectGlobalBrokerTermination();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Global Broker Termination Option is selected in Dropdown",
				"User should be able to select Global Broker Termination Dropdownitem",
				"Successfully able to see Global Broker Termination Selected",
				"Failed to select Global Broker Termination  : " + Common.strError);
	}

	@Then("^I verify Global Broker Termination Sample Template link should be displayed$")
	public void iverifyGlobalBrokerTerminationSampleTemplatelinkshouldbedisplayed() {
		boolean blnResult = rebilling.checkForGlobalBrokerTerminationSampleTemplateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify the Global Broker Termination Sample Template link",
				"User should be able to see Global Broker Termination Sample Template link",
				"Successfully able to see Global Broker Termination Sample Template link",
				"Failed to see Global Broker Termination Sample Template link : " + Common.strError);
	}

	@When("^I click on Global Broker Termination Sample Template download link$")
	public void iclickonGlobalBrokerTerminationSampleTemplatedownloadLink() {
		boolean blnResult = rebilling.iClickonGlobalBrokerTermSampleTemplateLink();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Click on Global Broker Termination Sample Template link",
				"User should able to click Global Broker Termination Sample Template link",
				"Successfully able to click Global Broker Termination Sample Template link",
				"Failed to click Global Broker Termination Sample Template link :" + Common.strError);
	}

	@Then("^I verify Global Broker Term Template downloaded successfully$")
	public void ishouldseeGlobalBrokerTermTemplatedownloadedsuccessfully() {
		boolean blnResult = rebilling.iShouldseeGlobalBrokerTermTemplateDownloadedSuccessfully();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Verify Global Broker Term Template downloading status",
				"User should be able to see Global Broker Term Template downloaded successfully",
				"Successfully able to see Global Broker Term Template downloaded successfully",
				"Failed to see Global Broker Term Template downloaded successfully : " + Common.strError);
	}

	@When("^I enter required data in downloaded Global Broker Term sample template and Saved successfully$")
	public void ienteredrequireddataindownloadeGlobalBrokerTermsampletemplateandSavedsuccessfully() throws IOException {
		rebilling.iEnteredRequiredGlobalBrokerTermData();
		LPLCoreReporter.writeStepToReporter(LPLCoreConstents.TRUE, LPLCoreConstents.TRUE,
				"Enter data in downloaded template file",
				"User should be able to Enter data in downloaded template file",
				"Successfully able to Enter data in downloaded template file",
				"Failed to Enter data in downloaded template file : " + Common.strError);
	}

	@And("^I click on Global Broker Browse button on Account Termination screen$")
	public void iclickonGlobalBrokerBrowsebuttononAccountTerminationScreen() {
		boolean blnResult = rebilling.iClickonACATTerminationBrowseButton();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE, "Click on Browse button",
				"User should able to click Browse button", "Successfully able to click Browse button",
				"Failed to click Browse button :" + Common.strError);
	}

	@When("^I selected the filled Global Broker Term sample downloaded template$")
	public void iselectedthefilledGlobalBrokerTermsampledownloadedtemplate() {
		boolean blnResult = rebilling.iSelectedGlobalBrokerTermSampleDownloadedTemplate();
		LPLCoreReporter.writeStepToReporter(blnResult, LPLCoreConstents.TRUE,
				"Select filled sample downloaded template",
				"User should able to Select filled sample downloaded template",
				"Successfully able to Select filled sample downloaded template",
				"Failed to Select filled sample downloaded template :" + Common.strError);
	}

	@After
	public void writeToReport() {
		LPLCoreReporter.writeSummary();
	}
}
