package com.lpl.qe.legacy.portfolioaccountingfeebilling.householdinggrouputility.web.cucumber.pages;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import LPLCoreDriver.LPLConfig;
import LPLCoreDriver.LPLCoreDBConnect;
import LPLCoreDriver.LPLCoreUtil;

public class UserDefinedGroupPage  extends Common implements ILocatorInitialize {
	
	static final int PAGE_IDENTIFIER = 872;
	Map<String, HashMap<String, String>> pageObjectMap;
	String strLetsCreateGroupPageXpath;
	String strCreateGroupButtonXpath;
	String strUDGDashboardSuccessPageXpath;
	String strClientsTabPreselectedXpath;
	String strSummaryFieldsContentTabXpath;
	String strAccountsTabPreselectedXpath;
	String strSummaryFieldsAccountTabXpath;
	String strPreselectAccountNumberXpath;
	String strRepIDEditIconXpath;
	String strBackToGroupsLinkXpath;
	String strGroupsGridXpath;
	String strAddToGroupXpath;
	String strGroupNameAddToGroupsXpath;
	String strRadioButtonAddToGroupsXpath;
	String StrAddToGroupsButtonXpath;
	String strLetsUpdateThisGroupPageXpath;
	String strSearchButtonAddToGroupXpath;
	String strClientAddedToUDGXpath;
	String strSaveChangesUDGXpath;
	String strGroupUpdateSuccessMsgXpath;
	String strAccountAddedToUDGXpath;
	String strUnamskAccountNUmberXpath;
	String strCreateGroupNameXpath;
	String strCreateUserDefinedGroupXpath;
	String strGroupNameRequiredTagXpath;
	String strPleaseSelectGroupContentTagXpath;
	String strNewUDGPageXpath;
	String strAccountContentTypeXpath;
	String strGroupContentXpath;
	String strNoPrimarySelectedXpath;
	String strEnterMemberDetailsXpath;
	String strSearchResultsXpath;
	String strSelectGroupMemberXpath;
	String strClientsContentTypeXpath;
	String strHouseholdContentTypeXpath;
	String strclickHHGroupnamexpath;
	String strUDGDashboardPageXpath;
	String strSummaryFieldsDashboardXpath;
	String strEditUDGXpath;
	String strReviewButtonEditUDGXpath;
	String strTrackerUDGAddedXpath;
	String strTrackerUDGClientNameXpath;
	String strNewClientTileReviewUDGXpath;
	String strEditGroupUDGXpath;
	String strRepIdOnlyXpath;
	String strRemoveMemberXpath;
	String strTrackerUDGRemovedXpath;
	String strTrackerUDGClientNameRemovedXpath;
	String strSummaryFieldsHouseholdDashboardXpath;
	String strRemoveHouseholdMemberXpath;
	String strPrimaryCheckBoxXpath;
	String strPrimaryTagXpath;
	
	
	public static final int REP_ID_LENGTH = 4;
	public static final String ERROR_MSG_UNIQUE_UDG_NAME = "You cannot have user defined groups with the same name, please update and try again";
	
	public UserDefinedGroupPage(WebDriver driver) {
		super(driver);
		lplCoreUtil = new LPLCoreUtil();
		/** Fetching page objects from FARM */
		pageObjectMap = LPLCoreDBConnect.getObjectsFromDB(PAGE_IDENTIFIER, new LPLConfig().getEnvId());
		checkForLocatorTypeAndInitializeFields(pageObjectMap, this.getClass().getDeclaredFields(), PAGE_IDENTIFIER);
	}
	
	/**
	 * This method is used to click on Create New User Defined Group sub menu in client
	 * context menu
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickCreateUserDefinedGroup() {
		return clickElementUsingXpath("//*[text()='Create New User Defined Group']", lplCoreConstents.HIGH,"Create New User Defined Group sub-menu is clicked");
		//return clickElementUsingXpath("((//ul[@id='context-menu']/li)[3]/ul/li)[1]", lplCoreConstents.HIGH,"Create New User Defined Group sub-menu is clicked");
	}
	
	/**
	 * This method is used to click on Edit Group name pencil icon in Edit household
	 * page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickonEditUDGNamePencilIcon() {
		return clickElementUsingXpath("//div[@class='udg-static']/button/i",
				"Edit Household group name in Edit household page is clicked");
	}
	
	/**
	 * This method is used to enter the text in Household group name in Edit
	 * household page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean enterUDGName() {
		return enterTextUsingXpath("//div//input[@aria-label='User-Defined Group Name']", testData.get("enterUDGName"),
				"Enter Group Name");
	}
	
	/**
	 * This method is used to validate Lets create  group page is displayed
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeLetsCreateAGroupPage() {
		return isElementPresentUsingXpath(strLetsCreateGroupPageXpath,
				"Lets Create a group page");
	}
	
	/**
	 * This method is used to validate Lets create  group page is displayed
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnCreateGroupButton() {
		return clickElementUsingXpath(strCreateGroupButtonXpath,
				"Household Capabilities section is displayed in the dashboard Page");
	}
	
	/**
	 * This method is used to validate Lets create  group page is displayed
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeUDGDasboardPage() {
		return isElementPresentUsingXpath(strUDGDashboardSuccessPageXpath,
				"Household Capabilities section is displayed in the dashboard Page");
	}
	
	/**
	 * This method is used to validate Lets create  group page is displayed
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeClientsTabPreSelected() {
		return isElementPresentUsingXpath(strClientsTabPreselectedXpath,
				"Household Capabilities section is displayed in the dashboard Page");
	}
	
	/**
	 * This method is used to validate Lets create  group page is displayed
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeAccountsTabPreSelected() {
		return isElementPresentUsingXpath(strAccountsTabPreselectedXpath,
				"Household Capabilities section is displayed in the dashboard Page");
	}
	
	/**
	 * This method is used to validate CS summary banner fields on
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displaySummaryFieldsClientsTab(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator(strSummaryFieldsContentTabXpath, field), field);

	}
	
	/**
	 * This method is used to validate CS summary banner fields on
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displaySummaryFieldsAccountsTab(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator(strSummaryFieldsAccountTabXpath, field), field);

	}
	
	/**
	 * This method is used to validate CS summary banner fields on
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean enterGroupReportingTitle() {
		//clearTextUsingXpath(strEditGroupNameXpath, "Group Name");
		boolean result = false;
		clickElementUsingXpath("//button[@title='Edit Group Reporting Title']","Household Capabilities section is displayed in the dashboard Page");
		//return enterTextUsingXpath("//div[@class='udg-name-edit']",testData.get("groupReportingTitle"), "Group Reporting Title");
		enterText("//div[@class='udg-name-edit']");	
		return true;
	}
	
	/**
	 * This method is used to check if account number is added on New Household
	 * Page
	 * 
	 * @return boolean
	 * @author vparthas
	 */

	public boolean preselectedAccountDisplayed() {
		clickElementUsingXpath("//span[@class='account-mask']/a/i","Click on Mask to unlock account number");
		System.out.println(strPreselectAccountNumberXpath.replace("xxx", testData.get("enterAccountNumber")));
		return isElementPresent(DISPLAYED, "XPATH", strPreselectAccountNumberXpath.replace("xxx", testData.get("enterAccountNumber")),
				"Verify the account is added in UDG");
	}
	
	/**
	 * This method is used to validate Lets create  group page is displayed
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickRepIDEditIcon() {
		return clickElementUsingXpath(strRepIDEditIconXpath,
				"Click on RepID Edit pencil icon");
	}
	
	/**
	 * This method is used to click on Back to Groups grid
	 * 
	 * 
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnBactToGroupsLInk() {
		return clickElementUsingXpath(strBackToGroupsLinkXpath,
				"Click on Back to Groups link");
	}
	
	/**
	 * This method is used to validate CS summary banner fields on
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyLandInGroupsGrid() {
		return isElementPresentUsingXpath(strGroupsGridXpath,
				"Household Capabilities section is displayed in the dashboard Page");
	} 
	
	/**
	 * This method is used to click on Add to User Defined Group sub menu in client
	 * context menu
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickAddToUserDefinedGroup() {
		return clickElementUsingXpath("//*[text()='Add to User Defined Group']", lplCoreConstents.HIGH,"Create New User Defined Group sub-menu is clicked");
		//return clickElementUsingXpath("((//ul[@id='context-menu']/li)[3]/ul/li)[1]", lplCoreConstents.HIGH,"Create New User Defined Group sub-menu is clicked");
	}
	
	/**
	 * This method is to verify the user is on the User Defined group page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeAddToGroupsPage() {
		return isElementPresentUsingXpath(strAddToGroupXpath, "Add to Group page");
	}
	/**
	 * This method is enter group name
	 * 
	 * @param�Enter Client name Value
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean enterGroupNameInAddToGroupsPage(String groupName) {
		return enterTextUsingXpath(strGroupNameAddToGroupsXpath, groupName, "Enter Group Name");
	}
	
	/**
	 * This method is used to click on Radio button on Add to User Defined Group 
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectGroupForAddToGroups() {
		return clickElementUsingXpath(strRadioButtonAddToGroupsXpath.replace("xxx", testData.get("enterGroupName")), lplCoreConstents.HIGH,"Radio button of the group selected");
	}
	
	/**
	 * This method is used to click on Radio button on Add to User Defined Group 
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectAddToGroupsButton() {
		return clickElementUsingXpath(StrAddToGroupsButtonXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is to verify the user is on the Lets update this page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeLetsUpdateThisPage() {
		//wait(40);
		return isElementPresentUsingXpath(strLetsUpdateThisGroupPageXpath, "Add to Group page");
	}
	
	/**
	 * This method is used to click on Search button in Add to Groups page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnSearchAddToGroups() {
		return clickElementUsingXpath(strSearchButtonAddToGroupXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is to verify client added to group
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeClientAddedToUDG() {
		wait(60);
		return isElementPresentUsingXpath(strClientAddedToUDGXpath.replace("xxx", testData.get("EnterclientName")), "Client added to Group page");
	}
	
	/**
	 * This method is to verify account added to group
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeAccountAddedToUDG() {
		wait(60);
		return isElementPresentUsingXpath(strAccountAddedToUDGXpath.replace("xxx", testData.get("verifyAccountNumber")), "Account added to Group page");
	}
	
	/**
	 * This method is used to click on Save Changes button in Add to Groups page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickOnSaveChangesUDG() {
		return clickElementUsingXpath(strSaveChangesUDGXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is used to click on Save Changes button in Add to Groups page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeGroupUpdateMessage() {
		return clickElementUsingXpath(strGroupUpdateSuccessMsgXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is used to click to unmask the account number
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickToUnmaskAccountNumber() {
		return clickElementUsingXpath(strUnamskAccountNUmberXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is used to select the Household from create group dropdown
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean selectCreateUDG() {
		clickElementUsingXpath(strCreateGroupNameXpath, lplCoreConstents.HIGHEST, "Create Group dropdown");
		return clickElementUsingXpath(strCreateUserDefinedGroupXpath, lplCoreConstents.HIGHEST,
				"Create Group dropdown Value select as Household");
	}
	
	/**
	 * This method is to verify Group name required message
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeGroupNameRequiredTag() {
		return isElementPresentUsingXpath(strGroupNameRequiredTagXpath, "UDG group name required message");
	}
	
	/**
	 * This method is to verify Group name required message
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seePleaseSelectGroupContentTag() {
		return isElementPresentUsingXpath(strPleaseSelectGroupContentTagXpath, "UDG group name required message");
	}
	
	/**
	 * This method is to verify the user is on the Lets update this page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeNewUDGPage() {
		//wait(40);
		return isElementPresentUsingXpath(strNewUDGPageXpath, "Add to Group page");
	}
	
	/**
	 * This method is used to click to unmask the account number
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectsAccountType() {
		return clickElementUsingXpath(strAccountContentTypeXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is to verify the user is on the Lets update this page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeGroupContentWidget() {
		//wait(40);
		return isElementPresentUsingXpath(strGroupContentXpath, "Add to Group page");
	}
	
	/**
	 * This method is to verify the user is on the Lets update this page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeNoPrimaryIsSelected() {
		//wait(40);
		return isElementPresentUsingXpath(strNoPrimarySelectedXpath, "Add to Group page");
	}
	
	/**
	 * This method is used to enter the text in Client search text box
	 *
	 * @param text - Search text
	 * @return boolean
	 * @author vparthas
	 */
	public boolean enterAccountNumberInSearchBox(String text) {
		clickElementUsingXpath(strEnterMemberDetailsXpath, 120, "Search Text for Client ");
		return enterTextUsingXpath(strEnterMemberDetailsXpath, text, "Search Text for Client ");
	}
	
	/**
	 * This method is used to return the search results for client name search
	 *
	 * @return List<String>
	 * @author pmanohar
	 */
	public List<String> getSearchResults() {
		isElementPresentUsingXpath(strSearchResultsXpath, lplCoreConstents.HIGH, "Primary Client Search Results");
		return getTextForWebElementsUsingXpath(strSearchResultsXpath, "Primary Client Search Results");
	}
	
	/**
	 * This method is used to select one of the client name from the client name
	 * search results
	 *
	 * @return boolean
	 * @author pmanohar
	 */
	public boolean selectClientPrimary() {
		return clickElementUsingXpath(strSelectGroupMemberXpath, "Client Primary Search Result");
	}
	
	/**
	 * This method is to click on group content
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectClientType() {
		return clickElementUsingXpath(strClientsContentTypeXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is to click on group comtent
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean selectHouseholdType() {
		return clickElementUsingXpath(strHouseholdContentTypeXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is used to click on Household Group name
	 *
	 * @return boolean
	 * @author vparthas
	 */

	public boolean clickUDGName() {
		String groupID = testData.get("groupID");
		wait(5);
		return clickElementUsingXpath(strclickHHGroupnamexpath.replace("xxx", groupID),
				"Household Group name is clicked");

	}
	
	/**
	 * This method is to verify the user is on the Lets update this page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeUDGDashboard() {
		//wait(40);
		return isElementPresentUsingXpath(strUDGDashboardPageXpath, "Add to Group page");
	}
	
	/**
	 * This method is used to validate CS summary banner fields on
	 * Streamline/Confirmation page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displayUDGDashbaordSummaryFields(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator(strSummaryFieldsDashboardXpath, field), field);

	}
	
	/**
	 * This method is to click on Edit button in UDG dashbaord
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickEditUDG() {
		return clickElementUsingXpath(strEditUDGXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is to click on Review button in Edit UDG dashbaord
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickReviewbuttonUDG() {
		return clickElementUsingXpath(strReviewButtonEditUDGXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is to check tracker in Edit UDG page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyTrackerUDG() {
		String[] clientName = testData.get("firstName").split(" ");
		return isElementPresentUsingXpath(strTrackerUDGAddedXpath, "Client added tracker") && 
				isElementPresentUsingXpath(strTrackerUDGClientNameXpath.replace("xxx", clientName[0]), "Client added tracker");
	}
	
	/**
	 * This method is to check tracker in Edit UDG page
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean verifyRemoveTrackerUDG() {
		String[] clientName = testData.get("firstName").split(" ");
		return isElementPresentUsingXpath(strTrackerUDGRemovedXpath, "Client added tracker") && 
				isElementPresentUsingXpath(strTrackerUDGClientNameRemovedXpath.replace("xxx", clientName[0]), "Client added tracker");
	}
	
	/**
	 * This method is to see the newly added cleint tile in contents widget
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeNewAddedClientAccountInContentTile() {
		String[] clientName = testData.get("firstName").split(" ");
		return isElementPresentUsingXpath(strNewClientTileReviewUDGXpath.replace("xxx", clientName[0]), "Client added tracker");
	}
	/**
	 * This method is used to validate column names in account tile
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean displayAccountsTileColumnNames(String field) {
		// This method is used to validate whether STO Team field is visible
		return isElementPresentUsingXpath(getFormattedLocator("//section[contains(@class,'tiles-wrapper')]//*[contains(text(),'%s')]", field), field);

	}
	
	/**
	 * This method is to click on Review button in Edit UDG dashbaord
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean clickEditGroupButtonUDG() {
		return clickElementUsingXpath(strEditGroupUDGXpath, lplCoreConstents.HIGH,"Click on Add to Groups button");
	}
	
	/**
	 * This method is used to validate only RepID is displayed in the group member tile for UDG
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean seeRepIDOnlyInMemberTile() {
		int textLen = getTextUsingXpath(strRepIdOnlyXpath, "RepID").length();
		if(textLen==REP_ID_LENGTH) {
			return true;
		}else {
			return false;
			
		}

	}
	
	/**
	 * This method is to remove group member
	 *
	 * @return boolean
	 * @author vparthas
	 */
	public boolean removeMemberUDG() {
		String[] clientName = testData.get("firstName").split(" ");
		return clickElementUsingXpath(strRemoveMemberXpath.replace("xxx", clientName[0]), lplCoreConstents.HIGH,"Click on remove member from Groups button");
	}
	
	
	/**
	 * This method is to verify column names for household UDG
	 *
	 * @return boolean
	 * @author vparthas
	 */	
	public boolean displayUDGHouseholdDashbaordSummaryFields(String field) {
        
        return isElementPresentUsingXpath(getFormattedLocator(strSummaryFieldsHouseholdDashboardXpath, field), field);

  }
	/**
	 * This method is to select primary for UDG
	 *
	 * @return boolean
	 * @author sethupar
	 */	
	public boolean selectsPrimaryType() {
        String[] clientName = testData.get("firstName").split(" ");
        return clickElementUsingXpath(strPrimaryCheckBoxXpath.replace("xxx", clientName[0]), lplCoreConstents.HIGH,"Click on Group type as Primary checkbox");}
  
	/**
	 * This method is to verify Primary in UDG Dashboard
	 *
	 * @return boolean
	 * @author sethupar
	 */	
  public boolean seePrimaryTagInRespectiveGroup() {
        wait(4);
        String[] clientName = testData.get("firstName").split(" ");
        return isElementPresentUsingXpath(strPrimaryTagXpath.replace("xxx", clientName[0]), lplCoreConstents.HIGH,"Verify primary tag");
  }
  
  /**
   * This method is to verify Client selection field Placeholder Name
   *
   * @return boolean
   * @author sethupar
   */    
public boolean seePlaceholderNameInClientTextfield() {
         return isElementPresentUsingXpath("//input[@placeholder='Enter Client Name, SSN/Tax ID']", "Verify Client selection field Placeholder Name");
   }

/**
 * This method is to verify Client selection field Placeholder Name
 *
 * @return boolean
 * @author vparthas
 */    
public boolean seePlaceholderNameInHouseholdTextfield() {
       return isElementPresentUsingXpath("//input[@placeholder='Enter Household Group Name']", "Verify Household selection field Placeholder Name");
 }

/**
 * This method is to verify Client selection field Placeholder Name
 *
 * @return boolean
 * @author vparthas
 */    
public boolean seeErrorMessageUniqueGroupName() {
	return getTextForWebElementsUsingXpath("//section[@class='ud-group-component']/section/div/div/div", "Primary Client Search Results").contains(ERROR_MSG_UNIQUE_UDG_NAME);
 }

	
	
}
