package com.lpl.qe.portfolioaccountingfeebilling.householding.constants;

public enum CombinedStatementEnum {
	
NEWCOMBINEDSTATEMENTHEADERTEXT(" New Combined Statement Details "), COMBINEDSTATEMENTTEXT(" COMBINED STATEMENT "),
COMBINEDSTATEMENTSTATICTEXT(" Please note that the address associated with the primary account you select will be the mailing address for this combined statement. You may choose any eligible account from the household’s primary client. Note: Only eligible accounts are displayed."),
COMBINESSTMTADDRESSFIELD("ADDRESS"), COMBINEDSTMTSSNTAXIDFIELD("SSN/Tax ID"), COMBINEDSTMTLETTERWIDGETTITLE("Letter"),
COMBINEDSTMTLETTERWIDGETCONTENT("We will be sending out a letter about any changes to these clients that is read only once household is submitted View Letter"),
PRIMARYACCOUNTFIELD(" PRIMARY ACCOUNT "), MAILINGADDRESSFIELD(" MAILING ADDRESS "), COMBINEDSTMTSTREAMLINEPAGECONTENTSFIELD1("CLIENT"),
COMBINEDSTMTSTREAMLINEPAGECONTENTSFIELD2("VALUE"), COMBINEDSTMTSTREAMLINEPAGECONTENTSFIELD3("ACCOUNTS");
	
	String strValue;
	private CombinedStatementEnum(String value) {
		this.strValue = value;
	}

}
