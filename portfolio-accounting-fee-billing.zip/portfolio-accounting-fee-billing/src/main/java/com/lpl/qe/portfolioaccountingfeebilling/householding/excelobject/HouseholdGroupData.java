package com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
public @Data class HouseholdGroupData {
	private String testID;
	private String groupName;
	private String groupID;
	private String repID;
	private String userName;
	private String password;

}
