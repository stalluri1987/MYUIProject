package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;

import com.lpl.qe.blackbird.wait.BaseWaitActions;
import com.lpl.qe.blackbird.wait.GeneralUtils;
import com.lpl.qe.blackbird.wait.TimeoutType;
import com.lpl.qe.CAG.ClientworksCommon;
import com.lpl.qe.CAG.HouseholdCreate;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.asserts.BlackbirdAsserts;
import com.lpl.qe.blackbird.logger.SimpleLogger;
import com.lpl.qe.blackbird.pagefactory.BasePage;

public class CommonUtility {
	RemoteWebDriver driver = DriverFactory.getDriver();
	public String groupNameStringXpath1 = "//a[contains(@href,'";
	public String groupNameStringXpath2 = "')]";
	
	public void clickOnGroupsTab() throws InterruptedException {
		ClientworksCommon clientworksLogin = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		clientworksLogin.clickGroupsTab();
		clientworksLogin.pageLoadWait();
		}
	
	public void enterHouseholdNameToSearch(String householdName) throws InterruptedException {
		ClientworksCommon clientworksLogin = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		//clientworksLogin.pageLoadWait();
		GeneralUtils.waitSeconds(5);
		
		clientworksLogin.waitUntilClickable(clientworksLogin.getHouseholdSearchField(), TimeoutType.TWO_MINUTES);
		//clientworksLogin.setHouseholdSearchFieldValue(householdName);
		clientworksLogin.setHouseholdSearchFieldValue(householdName);
	}
	
	public void clickSearchHouseholdButton() throws InterruptedException {
		ClientworksCommon clientworksLogin = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		clientworksLogin.waitUntilClickable(clientworksLogin.getHouseholdSearchButton(), TimeoutType.TWO_MINUTES);
		clientworksLogin.waitUntilVisible(clientworksLogin.getHouseholdSearchButton(), TimeoutType.TWO_MINUTES);
		GeneralUtils.waitSeconds(25);
		clientworksLogin.clickHouseholdSearchButton();
		
	}
	
	public void clickOnHouseholdName(String groupID) throws InterruptedException {
		GeneralUtils.waitSeconds(25);
		driver.findElement(By.xpath(groupNameStringXpath1+groupID+groupNameStringXpath2)).click();
	}

	
	public void isHouseholdDashbaordPageDisplayed() {
		ClientworksCommon clientworksLogin = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		clientworksLogin.waitUntilClickable(clientworksLogin.getHouseholdDashboardPage(), TimeoutType.TWO_MINUTES);
		clientworksLogin.getHouseholdDashboardPage();
	}
	
	public void clickEditHouseholdButton() {
		ClientworksCommon clientworksLogin = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		GeneralUtils.waitSeconds(10);
		clientworksLogin.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(clientworksLogin.getEditHouseholdButton()), "Edit button visible in dashboard page", TimeoutType.TEN_SECONDS);
		clientworksLogin.clickEditHouseholdButton();
	}
	
	public void selectDeleteFromContextMenu() {
		ClientworksCommon clientworksLogin = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		GeneralUtils.waitSeconds(15);
//		Actions act = new Actions(driver);
//		act.moveToElement(clientworksLogin.getHouseholdContextMenu()).build().perform();;
		clientworksLogin.waitHouseholdContextMenuAndClick();
		GeneralUtils.waitSeconds(10);
		//driver.switchTo().frame("iframe-modal-frame");
		clientworksLogin.clickHouseholdDeleteOption();
	}
	
	public void deleteHouseholdAndReturnToGroupsTab() {
		ClientworksCommon clientworksLogin = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		driver.switchTo().frame("iframe-modal-frame");
		clientworksLogin.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(clientworksLogin.getDeleteThisHouseholdButton()), "Yes, Delete this household button", TimeoutType.TEN_SECONDS);
		clientworksLogin.clickDeleteThisHouseholdButton();
		clientworksLogin.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(clientworksLogin.getReturnToHouseholdButton()), "Return to household button", TimeoutType.TEN_SECONDS);
		clientworksLogin.clickReturnToHouseholdButton();
	}
	
	public void isGroupsTabDisplayed() {
		ClientworksCommon clientworksLogin = BasePage.initialize(DriverFactory.getDriver(), ClientworksCommon.class);
		GeneralUtils.waitSeconds(10);
		clientworksLogin.getGroupsTabPage();
		}
	
	
}
