package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.lpl.qe.CAG.HouseholdEdit;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.blackbird.wait.GeneralUtils;
import com.lpl.qe.blackbird.wait.TimeoutType;

public class HouseholdEditUtility {
	
	RemoteWebDriver driver = DriverFactory.getDriver();
	public String primaryRadioBtnXpath1 = "//div[contains(text(), '";
	public String primaryRadioBtnXpath2 = "')]/../../../../../section[1]/dx-radio-group/div/div/div/div";
	public String removeClientXpath1 = "(//div[text()=' ";
	public String removeClientXpath2 = " '])[1]//..//../div[4]/button";
	public String clientAddedTrackerXpath1 = "//div[@class='summary-changes']/div//section/div//strong[text()= '";
	public String clientAddedTrackerXpath2 = "']/..//span[contains(text(), ' Added ')]";
	public String undoButtonInTrackerXpath1 = "(//div[@class='summary-changes']//*[text()='";
	public String undoButtonInTrackerXpath2 = "'])[2]/../../../../div/div/div[2]/button";
	public String removedClientAddedXpath1 = "//section[@class='client-tiles-wrapper']/div//div[contains(text(),'";
	public String removedClientAddedXpath2 = "')]";
	public String accountChevronReviewHHpageXpath1 = "//div[contains(text(),'";
	public String accountChevronReviewHHpageXpath2 = "')]/../../../following-sibling::section[1]/button/i";
	public String accountDetailsXpath1 = "//div[contains(text(),'";
	public String accountDetailsXpath2 = "')]/../..//../../div/div/div[2]/div/dx-list/div[1]/div/div[1]/div[2]/div/div/div/div[ii]";
	public String defaultNoOfAccountsDsipalyedXpath1 = "//div[contains(text(),'";
	public String defaultNoOfAccountsDsipalyedXpath2 = "')]/../../../following-sibling::div[1]//div[@class='dx-template-wrapper dx-item-content dx-list-item-content']";

		public void clickEditHHpencilIcon() {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			//householdEdit.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdEdit.getEditHhGroupPencilIcon()),"Edit Household Page", TimeoutType.TEN_SECONDS);
			GeneralUtils.waitSeconds(7);
			householdEdit.waitEditHhGroupPencilIconAndClick();
		}
		
		public void isEditHouseholdPageDisplayed() {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			householdEdit.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdEdit.getEditHouseholdPage()),"Edit Household Page", TimeoutType.TEN_SECONDS);
			householdEdit.getEditHouseholdPage();
		}
		
		public void clickOnPrimaryRadioButton(String clientName) {
			GeneralUtils.waitSeconds(5);
			driver.findElement(By.xpath(primaryRadioBtnXpath1 +clientName+primaryRadioBtnXpath2)).click();
		}
		
		public void removeClient(String clientName) {
			GeneralUtils.waitSeconds(10);
			driver.findElement(By.xpath(removeClientXpath1 +clientName+removeClientXpath2)).click();
		}
		
		public void verifySelectPrimaryErrorMsg() {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			householdEdit.getSelectPrimaryErrorMessage();
			
		}
		
		public void verifyTrackerForAddedClient(String clientName) {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			householdEdit.getTrackerForAddedClient();
			GeneralUtils.waitSeconds(5);
			driver.findElement(By.xpath(clientAddedTrackerXpath1+clientName+clientAddedTrackerXpath2));
		}
		
		public void verifyExpandedChevron() {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			householdEdit.getExpandedClientChevronInTracker();
		}
		
		public void verifyTrackerForRemovedClient(String clientName) {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			householdEdit.getTrackerForRemovedClient();
			driver.findElement(By.xpath(clientAddedTrackerXpath1+clientName+clientAddedTrackerXpath2));
		}
		
		public void clickUndoButtonOnTracker(String clientName) {
			
			driver.findElement(By.xpath(undoButtonInTrackerXpath1+clientName+undoButtonInTrackerXpath2)).click();
		}
		
		public void verifyRemovedClientAddedTile(String clientName) {
			
			driver.findElement(By.xpath(removedClientAddedXpath1+clientName+removedClientAddedXpath2));
		}
		
		public void clickReviewHouseholdButton() {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			householdEdit.clickHouseholdReviewButton();
		}
		
		public void clickContentsChevronReviewHHpage() {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			householdEdit.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdEdit.getContentsChevronReviewHHPage()),"Review Household Page", TimeoutType.TEN_SECONDS);
			householdEdit.clickContentsChevronReviewHHPage();
		}
		
		public void clickAccountChevronReviewHHPage(String clientName) {
			driver.findElement(By.xpath(accountChevronReviewHHpageXpath1+clientName+accountChevronReviewHHpageXpath2));
		}
		
		public void verifyAccountDetails(String clientName) {
			for(int i=1; i<=5; i++) {
				driver.findElement(By.xpath(accountDetailsXpath1+clientName+accountDetailsXpath2.replace("ii", Integer.toString(i))));
				
			}
			
		}
		
		public Boolean verifyDefaultNoOfAccountsDisplayed(String clientName) {
			
			String count = driver.findElement(By.xpath(defaultNoOfAccountsDsipalyedXpath1+clientName+defaultNoOfAccountsDsipalyedXpath2)).getSize().toString();
			if(count.equals("5")) {
				return true;
			}else {
				return false;
			}
		}
		
		public void clickSubmitChanges() {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			householdEdit.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdEdit.getEditHHSubmitChangesButton()),"Review Household Page", TimeoutType.TEN_SECONDS);
			householdEdit.clickEditHHSubmitChangesButton();
		}
		
		public void verifyConfirmationPageHHUpdatedMsg() {
			HouseholdEdit householdEdit = BasePage.initialize(DriverFactory.getDriver(), HouseholdEdit.class);
			GeneralUtils.waitSeconds(10);
			householdEdit.getHouseholdUpdatedConfirmationPageMsg();		}
		
		
		
		
		
}
