package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.lpl.qe.CAG.CombinedStatementCapability;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.blackbird.wait.GeneralUtils;

public class CombinedStatementCapabilityUtility {
	RemoteWebDriver driver = DriverFactory.getDriver();
	JavascriptExecutor js = (JavascriptExecutor)driver;
	
	String noOfAccountsEachClient1 = "//div[@title='client and account confirmation']/section/div[";
	String noOfAccountsEachClient2 = "]/div/section[1]/div/div[3]/div/div";
	String totalNoOfClients = "//div[@class='card client-account-tile']";
	String trackerBankSweepName1 = "//*[contains(text(),' " ;
    String trackerBankSweepName2 = 	" Bank Sweep ')]";
	
	
	public void verifyCombinedStmtOptionalText() {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		combinedStmtCapability.getCombinedStatementOptionalText().getText().equals(" Household Combined Statement ");
	}
	
	public void clickCombinedStatementLink() {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		GeneralUtils.waitSeconds(7);
		combinedStmtCapability.clickCombinedStatementLink();
	}
	
	public void validateNewCombinedStmtPage(String headerText, String staticText, String combinedStmtName, String groupName) {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		GeneralUtils.waitSeconds(10);
		combinedStmtCapability.getNewHouseholdCSPageTitle().isDisplayed();
		combinedStmtCapability.isTextPresentForNewCombinedStatementHeaderText(headerText);
		combinedStmtCapability.getCombinedStatementName().getText().contains(groupName+combinedStmtName);
		combinedStmtCapability.isTextPresentForCombinedStatementStaticText(staticText);
	}
	
	public void validateContentsPanelCombinedStmt() {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		int noOfClients = driver.findElements(By.xpath(totalNoOfClients)).size();
		int total = 0;
		System.out.println("clients = "+noOfClients);
		for (int i = 1; i <= noOfClients; i++) {
			String value = driver.findElement(By.xpath(noOfAccountsEachClient1+i+noOfAccountsEachClient2)).getText();
			
			System.out.println(Integer.parseInt(value));
			total = total + Integer.parseInt(value);
		}
		String str1;
		if(total==1) {
			str1 = Integer.toString(total) + " ACCT |";
		}else {
			str1 = Integer.toString(total) + " ACCTS |";
		}
		//String str1 = Integer.toString(total) + " ACCTS |";
		String str2 = combinedStmtCapability.getNoOfAccountsContentsPanel().getText();
		System.out.println(str1);
		System.out.println(str2);
		Assert.assertEquals(str1, str2);
	}
	
	public void validateContentsPanelClientsCombinedStmt() {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		int noOfClients = driver.findElements(By.xpath(totalNoOfClients)).size();
		String str1;
		if(noOfClients==1) {
			str1 = driver.findElements(By.xpath(totalNoOfClients)).size() + " CLIENT";
		}else {
			str1 = driver.findElements(By.xpath(totalNoOfClients)).size() + " CLIENTS";
		}
		String str2 = combinedStmtCapability.getNoOfClientsContentsPanel().getText();
		System.out.println(str1);
		System.out.println(str2);
		Assert.assertEquals(str1, str2);
	}
	
	public void validateAccountValueContentPanelCombinedStmt() {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		combinedStmtCapability.getAccountValueContentsPanel().isDisplayed();
	}
	
	public void verifyTrackerForHousehold(String groupName) {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		combinedStmtCapability.getTrackerWidgetTitle().getText().equalsIgnoreCase(groupName);
		combinedStmtCapability.clickTrackerChevronClickToClose();
		GeneralUtils.waitSeconds(2);
		combinedStmtCapability.clickTrackerChevronClickToExpand();
	}
	
	public void verifyTrackerForBankSweep(String groupName) {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		combinedStmtCapability.getTrackerBSTitle().isDisplayed();
		System.out.println(trackerBankSweepName1+groupName+trackerBankSweepName2);
		driver.findElement(By.xpath(trackerBankSweepName1+groupName+trackerBankSweepName2)).isDisplayed();
	}
	
	public void verifyTrackerForCombinedStmt() {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		combinedStmtCapability.getTrackerCSTitle().isDisplayed();
		combinedStmtCapability.getCombinedStmtNameInTracker().getText().equalsIgnoreCase("Johnson HOUSEHOLD COMBINED STATEMENT");
	}
	
	public void verifyCombinedStmtSection(String address, String fieldSSN) {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		combinedStmtCapability.getExpandedContentsChevronCS().isDisplayed();
		combinedStmtCapability.getCombinedStmtAddressField().getText().equals(address);
		combinedStmtCapability.getCombinedStmtSSNTaxIdField().getText().equals(fieldSSN);
		
	}
	
	
	public void validateEditCombinedStmtPage() {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		GeneralUtils.waitSeconds(3);
		js.executeScript("window.scrollBy(0,350)", "");
		combinedStmtCapability.checkCombinedStmtPrimary();
		combinedStmtCapability.clickCombinedStmtDoneEditingButton();
		
	}
	
	public void validateReviewCombinedStmtPage(String letterWidgetTitle, String letterWidgetContent, String combinedStmtName, 
			String primaryAccField, String mailingAddField, String mailingAddLine1, String mailingAddLine2) {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		combinedStmtCapability.getReviewCombinedStmtPage().isDisplayed();
		combinedStmtCapability.getCombinedStmtLetterWidgetTitle().getText().equals(letterWidgetTitle);
		combinedStmtCapability.getCombinedStmtLetterWidgetContent().getText().equals(letterWidgetContent);
		combinedStmtCapability.getCombinedStmtViewLetterLink().isDisplayed();
		combinedStmtCapability.clickEditCombinedStmtName();
		combinedStmtCapability.clearAndSetEnterCombinedStmtNameValue(combinedStmtName);
		combinedStmtCapability.isTextPresentForPrimaryAccountFieldReviewCSPage(primaryAccField);
		combinedStmtCapability.isTextPresentForMailingAddressFieldReviewCSPage(mailingAddField);
		combinedStmtCapability.isTextPresentForCombinedStmtMailingAddressLine1(mailingAddLine1);
		combinedStmtCapability.isTextPresentForCombinedStmtMailingAddressLine2(mailingAddLine2);
		
	}
	
	public void clickCreateCombinedStmtButton() {
		CombinedStatementCapability combinedStmtCapability = BasePage.initialize(DriverFactory.getDriver(), CombinedStatementCapability.class);
		combinedStmtCapability.clickCreateCombinedStmtButton();
	}
	
	
}
