package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.lpl.qe.CAG.HouseholdDashboardPage;
import com.lpl.qe.CAG.HouseholdEdit;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.blackbird.wait.GeneralUtils;
import com.lpl.qe.blackbird.wait.TimeoutType;

public class HouseholdDashbaordUtility {
	RemoteWebDriver driver = DriverFactory.getDriver();
	public void clickBackToGroupsLink() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getBackToGroupsLink()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.clickBackToGroupsLink();
	}
	
	public void isSummaryTabDisplayed() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getDashboardSummaryTab()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.clickDashboardSummaryTab();
	}
	
	public void isInvestmentsTabDisplayed() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getDashboardInvestmentTab()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.clickDashboardInvestmentTab();
		GeneralUtils.waitSeconds(7);
		householdDashbaordPage.getDashbaordTabsPageloaded();
	}
	
	public void isOrdersTabDisplayed() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getDashboardOrdersTab()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.clickDashboardOrdersTab();
		GeneralUtils.waitSeconds(7);
		householdDashbaordPage.getDashbaordTabsPageloaded();
	}
	
	public void isActivityTabDisplayed() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getDashboardActivityTab()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.clickDashboardActivityTab();
		GeneralUtils.waitSeconds(7);
		householdDashbaordPage.getDashbaordTabsPageloaded();
	}
	
	public void isRequestsTabDisplayed() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getDashboardRequestsTab()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.clickDashboardRequestsTab();
		GeneralUtils.waitSeconds(7);
		householdDashbaordPage.getDashbaordTabsPageloaded();
	}
	
	public void isDocumentsTabDisplayed() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getDashboardDocumentsTab()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.clickDashboardDocumentsTab();
		GeneralUtils.waitSeconds(7);
		householdDashbaordPage.getDashbaordTabsPageloaded();
	}
	
	public void isBalancesAndInvestmentSectionDisplayed() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		GeneralUtils.waitSeconds(5);
		householdDashbaordPage.getBalancesAndInvestmentsSection();
		householdDashbaordPage.getSecuritiesValueField();
		householdDashbaordPage.getFundsAvailableField();
		householdDashbaordPage.getTotalAccountsValueField();
		householdDashbaordPage.getMarginField();
	/*	householdDashbaordPage.getTrailingText();
		householdDashbaordPage.getGraphSectionVOT();
		householdDashbaordPage.getGraphXaxisVOT();
		householdDashbaordPage.getGraphYaxisVOT();  */
		
	}
	
	public void verifyHouseholdSummaryTile() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.getHouseholdNameSummary();
		householdDashbaordPage.getHouseholdNameSummaryRepID();
		
	}
	
	public void clickShowDetailsLinkAndVerifyColumnName(String field1, String field2, String field3) {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.clickBalancesAndInvestmentShowFullDetailsLink();
		GeneralUtils.waitSeconds(10);
		householdDashbaordPage.isTextPresentForBalancesAndInvestmentSummaryColumn(field1);
		householdDashbaordPage.isTextPresentForBalancesAndInvestmentSummaryColumn(field2);
		householdDashbaordPage.isTextPresentForBalancesAndInvestmentSummaryColumn(field3);
	}
	
	public void clickHideDetailsLinkAndVerifyColumnName() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.clickBalancesAndInvestmentHideFullDetailsLink();
		householdDashbaordPage.getBalancesAndInvestmentShowFullDetailsLink();
		householdDashbaordPage.getSecuritiesValueIn$().getText().startsWith("$");
	}
	
	public void verifyJumpToDetailsLink() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.clickJumpToDetailsLink();
		householdDashbaordPage.getHouseholdCapabilitiesSection();
	}
	
	public void verifyScrollBarForClientsSection() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.getScrollbarDashbaordClientsSection();
		householdDashbaordPage.getHouseholdCapabilitiesSection();
	}
	
	public void enterAndValidateNoteSection(String title, String text, String type) {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.getNotesSection();
		householdDashbaordPage.clickAddNoteLink();
		householdDashbaordPage.getAddNoteWindow();
		householdDashbaordPage.setAddNoteTitleFieldValue(title);
		householdDashbaordPage.setAddNoteTextFieldValue(text);
		//driver.findElement(By.xpath("//select[@formcontrolname='noteTypeId']")).click();
		//GeneralUtils.waitSeconds(10);
		householdDashbaordPage.getSelectNoteType().click();
		householdDashbaordPage.getSelectNoteType1().click();
		householdDashbaordPage.clickSaveNoteButton();
	}
	
	public void seeNoteCreated() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getNewNoteAddedTile()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.getNewNoteAddedTile();
	}
	
	public void validateDeleteAndPopUpNoteSection() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getNewNoteAddedTile()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.clickDeleteNoteButton();
		householdDashbaordPage.getDeleteNotePopUp();
		GeneralUtils.waitSeconds(5);
		householdDashbaordPage.clickDeleteNotePopUpNoButton();
		GeneralUtils.waitSeconds(5);
		householdDashbaordPage.clickDeleteNoteButton();
		householdDashbaordPage.getDeleteNotePopUp();
		GeneralUtils.waitSeconds(5);
		householdDashbaordPage.clickDeleteNotePopUpYesButton();
	}
	
	public void verifyNoteIsDeleted() {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getAddDataNote()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		householdDashbaordPage.getAddDataNote();
	}
	
	public void updateFrequencyDropdown(String text1, String text2) {
		HouseholdDashboardPage householdDashbaordPage = BasePage.initialize(DriverFactory.getDriver(), HouseholdDashboardPage.class);
		//householdDashbaordPage.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdDashbaordPage.getAddDataNote()),"Household Dashbaord Page", TimeoutType.TEN_SECONDS);
		GeneralUtils.waitSeconds(15);
		householdDashbaordPage.clickFrequencyUpdateButton();
		GeneralUtils.waitSeconds(3);
		householdDashbaordPage.getPreviousMarketCloseButton().getText().equals(text1);
		householdDashbaordPage.getIntradayUpdateBalancesButton().getText().equals(text2);
		householdDashbaordPage.clickIntradayUpdateBalancesButton();
		householdDashbaordPage.clickFrequencyUpdateButton();
		householdDashbaordPage.clickPreviousMarketCloseButton();
	}
	

}
