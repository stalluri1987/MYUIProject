package com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public @Data class CombinedStatementData {
	private String testID;
	private String groupName;
	private String repID;
	private String clientName1;
	private String userName;
	private String password;
	private String combinedStatementName;
	private String environment;
	private String mailingAddLine1;
	private String mailingAddLine2;
}
