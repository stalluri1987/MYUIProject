package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.JavascriptExecutor;

import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.clientworks.web.utils.LoginUtility;
import com.lpl.qe.blackbird.configuration.BlackbirdConfiguration;
import com.lpl.qe.blackbird.configuration.model.GuiConfig;
import com.lpl.qe.blackbird.utility.EnvironmentConfig;
import com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web.WebConfigUtility.configKey;
import com.lpl.qe.clientworks.LoginPage;
import com.lpl.qe.CAG.BillingCapability;
import com.lpl.qe.blackbird.pagefactory.BasePage;


public class LoginLogoutUtility{
	 
	
	public static void loginToCW() throws InterruptedException {
		
		RemoteWebDriver driver = DriverFactory.getDriver();
		driver.get(WebConfigUtility.getURL(configKey.cwUrl));
		driver.manage().window().maximize();
					
		}
	
	
	public static void closeBrowser() throws InterruptedException {
		RemoteWebDriver driver = DriverFactory.getDriver();
		driver.close();
		driver.quit();;
					
		}

}
