package com.lpl.qe.portfolioaccountingfeebilling.householding.constants;

public enum BillingCapabilityEnum {

	BILLINGFLATHEADER(" What will the flat fee be for this household's assets? "), UPDATEDCONFMSG("BILLING successfully updated!"), UPDATEDCONFMSG1("BILLING"), ALERTTEXT("!ACTIVATION REQUIRES FORMS"),
	COL1("SCHEDULE"),COL2("FLAT RATE"),COL3("TOTAL ASSETS"),COL4("EST. ANNUAL FEE"),COL5("FEE FROM");
	
	String strValue;
	private BillingCapabilityEnum(String value) {
		this.strValue = value;
	}
}
