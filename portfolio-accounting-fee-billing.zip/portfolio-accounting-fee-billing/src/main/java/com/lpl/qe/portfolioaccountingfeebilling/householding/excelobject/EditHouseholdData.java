package com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
public @Data class EditHouseholdData {
	private String testID;
	private String groupName;
	private String groupID;
	private String repID;
	private String clientName1;
	private String userName;
	private String password;
	private String environment;
	private String noteTitle;
	private String noteText;
	private String noteType;

}
