package com.lpl.qe.portfolioaccountingfeebilling.householding.constants;

public enum CreateHouseholdEnum {
	
	HOUSEHOLDPAGECOLUMN1("HOUSEHOLD CLIENTS"), HOUSEHOLDPAGECOLUMN2("HOUSEHOLD ACCOUNTS"), HOUSEHOLDPAGECOLUMN3("HOUSEHOLD VALUE"),
	HOUSEHOLDPAGECOLUMN4(" HOUSEHOLD REP ID "), TOOLTIPCONFPAGEHEADER("Why Streamline?"),
	TOOLTIPCONFPAGETEXT1(" Streamlining your household can provide you the flexibility and the holistic view you need to effectively manage your clients and their assets. "),
	TOOLTIPCONFPAGETEXT2(" You can streamline your management by adding capabilities detailed on this page which can help provide the efficiencies you need in evaluating your clients’ portfolios. ");
	
	String strValue;
	private CreateHouseholdEnum(String value) {
		this.strValue = value;
	}

}
