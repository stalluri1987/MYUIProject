package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.pagefactory.BasePage;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.lpl.qe.blackbird.wait.GeneralUtils;
import com.lpl.qe.blackbird.wait.TimeoutType;
import com.lpl.qe.CAG.BillingCapability;

public class BillingCapabilityUtility {
	public void clickStreamlineBilling() {
		GeneralUtils.waitSeconds(5);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
//		groupBilling.waitUntilClickable(groupBilling.getStreamlineBilling(), TimeoutType.TWO_MINUTES);
//				groupBilling.clickStreamlineBilling();
		groupBilling.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(groupBilling.getStreamlineBilling()),"billing buttone disabled", TimeoutType.FIVE_SECONDS);
		groupBilling.clickStreamlineBilling();
	}
	
	public void verifyEligibleAcctsGridHeaders() {
		GeneralUtils.waitSeconds(10);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.getEligibleAccountGridheader();
		groupBilling.getEligibleAccountGridSubheader();
	}
	
	public void removeAcctFromEligibleAcctGrid() {
		GeneralUtils.waitSeconds(3);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.getEligibleAccountGridCheckboxForUnCheck().click();
	}

	public void verifyRemoveAcctWarningMsg() {
		GeneralUtils.waitSeconds(3);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.getRemoveAcctWarningMsg();
	}
	public void addAcctFromEligibleAcctGrid() {
		GeneralUtils.waitSeconds(3);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.getEligibleAccountGridCheckboxForCheck().click();
	}
	public void verifyAddAcctWarningMsg() {
		GeneralUtils.waitSeconds(3);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.getAddAcctWarningMsg();
	}

	public void clickApprovebillingButton() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickBillingApproveButton();
	}
	public void clickDoneEditingButton() {
		GeneralUtils.waitSeconds(10);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.clickBillingDoneEditing();
	}
	public void verifyRemoveAcctWarningMsgNotDisplayed() {
		GeneralUtils.waitSeconds(3);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.verifyElementNotPresent(groupBilling.getRemoveAcctWarningMsg(), TimeoutType.TWO_MINUTES);
	}
	public void verifyAddAcctWarningMsgNotDisplayed() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.verifyElementNotPresent(groupBilling.getAddAcctWarningMsg(), TimeoutType.TWO_MINUTES);
	}
	public void verifyFlatFeeHeader(String flatFeeHeaderTile) {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.isTextPresentForFlatFeeValueSelectedHeader(flatFeeHeaderTile);
	}
	public void clickFlatFeeSelectedHeader() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.getFlatFeeValueSelectedHeader().click();
	}
	public void verifyFlatFeeDecimalConfirmationPage(String flatFeeDecimalBillingPage) {
		GeneralUtils.waitSeconds(10);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.isTextPresentForFlatFeeDecimalBillingDetailsPage(flatFeeDecimalBillingPage);
	}
	public void verifyFlatFeeDecimalBillingPage(String flatFeeDecimalBillingPage) {
		GeneralUtils.waitSeconds(10);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.isTextPresentForFlatFeeDecimalBillingDetailsPage(flatFeeDecimalBillingPage);
	}
	public void verifyFlatFeeDecimalReviewPage(String flatFeeDecimalReviewPage) {
		GeneralUtils.waitFiveSeconds();
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.isTextPresentForFlatFeeDecimalReviewPage(flatFeeDecimalReviewPage);
	}
	public void verifyFlatFeeDecimalDashboardPage(String flatFeeDecimalDashboardPage) {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.isTextPresentForFlatFeeDecimalDashboardPage(flatFeeDecimalDashboardPage);
	}
	public void clickFlatFeeTab() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickBillingTypeFlat();
	}
	public void clickProgressiveTieredTab() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickBillingTypeFlat();
	}
	public void clickFlatValueEditIcon() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.clickFlatEditValue();
	}
	
	public void enterFlatValue(String enterFlatFeeValue) {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.setEnterFlatFeeValueValue(enterFlatFeeValue);
	}
	public void clickCreateHouseholdBillingSet() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickCreateHouseholdBillingSet();
	}
	public void clickCloseButtonInConfirmationPage() {
		GeneralUtils.waitSeconds(10);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickCloseButtonConfirmationPage();
	}
	public void verifyHouseholdCapabilityTraker() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getHouseholdBillingCapabilityTraker();
	}
	public void verifyHouseholdNameInCapabilityTraker(String householdnameintraker) {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		String[] clientName = householdnameintraker.split(" ");
		groupBilling.isTextPresentForHouseholdNameInTraker(clientName[1]);
	}
	public void verifyBillingTrakerchevronDisplayed() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getCapabilityTrackerChevron();
	}
	public void verifyBankSweepGridInTraker() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getBankSweepGridInTraker();
	}
	public void verifyBankSweepTitleInTraker() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getBankSweepTitleInTraker();
	}
	public void verifyBankSweepNameInTraker() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getBankSweepNameInTraker();
	}
	public void verifyBillingCapabilityTitleInTraker() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getBillingCapabilityTitleInTraker();
	}
	public void verifyInProgressStatusInTraker() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getInProgressStatusInTraker();
	}
	public void verifyReadyToSignHeaderInTraker() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getReadyToSignHeaderInTraker();
	}
	public void verifyBillingNameInTraker(String billingNameInTraker) {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.isTextPresentForBillingNameInTraker(billingNameInTraker);
	}
	public void verifyReviewPageIsDisplayed() {
		GeneralUtils.waitSeconds(10);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.getVerifyReviewPageDisplayed();
	}
	public void clickScheduleEditIcon() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickScheduleDropdownEditIcon();
	}
	public void clickScheduleValue1() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickScheduleValue1();
	}
	public void clickScheduleValue2() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickScheduleValue2();
	}
	public void verifyCreateBillingConfMsgDisplayed() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getCreateBillingConfirmationMessage();
	}
	public void clickEditBillingPencilIcon() {
		GeneralUtils.waitSeconds(5);
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickStreamlineEditBillingIcon();
	}
	public void clickEditDetailsInReviewPage() {
		GeneralUtils.waitFiveSeconds();
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		groupBilling.clickEditDetailsReviewPage();
	}
	public void clickContentPanelInBillingDetailsPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickContentPanelInBillingDetailsPage();
	}
	public void clickAcctPanelInBillingDetailsPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickAccountsPanelInBillingDetailsPage();
	}
	public void verifyEditBillingDetailsPageIsDisplayed() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getEditBillingDetailsPageDisplayed();
	}
	public void acctPanelInReviewPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickAccountsPanelInReviewPage();
	}
	public void acctDetailsPanelInReviewPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickAccountDetailsPanelReviewPage();
	}
	public void verifyEditBillingSucessMsg() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getEditBillingConfirmationSucessMessage();
	}
	public void verifyPrepareToSignaturePresent() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getPrepareFormForSignature();
	}
	public boolean verifyBillingNameInConfirmationPage(String groupname, String verifyText1) {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		String str1 = groupBilling.getBillingNameInConfirmationPage().getText();
		String str2 = groupname + verifyText1;
		return (str1.equalsIgnoreCase(str2));
	}
	public boolean verifyAlrtMsgInBillingGrid(String alertText) {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		String str1 = groupBilling.getAlertMsgInBillingGrid().getText();
		String str2 = alertText;
		return (str1.equalsIgnoreCase(str2));
		
	}
//	public boolean verifyColumnNamesInBillingGrid(String col1,String col2,String col3,String col4,String col5) {
//		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
//		GeneralUtils.waitFiveSeconds();
//		
//		boolean result = false;
//		for (int i = 1; i <= groupBilling.getNoOfColumnNameforBillingGrid().getSize(); i++) {
//			if (i == 1) {
//				String str1 = groupBilling.getColumnName1forBillingGrid();
//				String str2 = col1;
//				System.out.println(str1);
//				return str1.equalsIgnoreCase(str2);
//				
//			} else if (i == 2) {
//				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
//						"FLAT RATE column");
//				String str2 = col2;
//				return str1.equalsIgnoreCase(str2);
//			} else if (i == 3) {
//				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
//						"TOTAL ASSETS column");
//				String str2 = col3;
//				return str1.equalsIgnoreCase(str2);
//			} else if (i == 4) {
//				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
//						"EST. ANNUAL FEE column");
//				String str2 = col4;
//				return str1.equalsIgnoreCase(str2);
//			} else if (i == 5) {
//				String str1 = getTextUsingXpath(strBillingColumnNameXpath.replace("z", Integer.toString(i)),
//						"FEE FROM column");
//				String str2 = col5;
//				return str1.equalsIgnoreCase(str2);
//			}
//		}
//		return result;
//		groupBilling.getNoOfBillingEligibleAccounts();
//	}
	public void contentChevronInBillingConfPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickContentChevronBillingConfPage();
	}
	public void verifycontentChevronExpandedInBillingConfPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getVerifyContentChevronExpandedBillingConfPage();
	}
	public void verifyAcctPanelNotExpandedInBillingConfPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.verifyElementNotPresent(groupBilling.getVerifyAcctPanelNotExpandedBillingConfPage(), TimeoutType.TWO_MINUTES);
	}
	public void clickAcctChevronBillingConfPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickAcctChevronBillingConfPage();
	}
	public void verifyAcctPanelExpandedInBillingConfPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getVerifyAcctPanelExpandedBillingConfPage();
	}
	public void verifyContentchevronCollapsedBillingConfPage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getVerifyContentChevronCollapsedBillingConfPage();
	}
	public void deleteBillingCapabilityButton() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickDeleteBillingCapability();
	}
	public void verifyGoBackButtonFromDeletePopup() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getVerifyGoBackButtonFromDeletePopup();
	}
	public void verifyDeleteButtonFromDeletePopup() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getVerifyDeleteButtonFromDeletePopup();
	}
	public void goBackButtonFromDeletePopup() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickGoBackButtonFromDeletePopup();
	}
	public void deleteButtonFromDeletePopup() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickDeleteButtonFromDeletePopup();
	}
	public void seeRedColorDeleteBillingTraker() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getSeeRedColorDeleteBillingTraker();
	}
	public void doneDeletingButton() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickDoneDeleting();
	}
	public void deleteBillingCapabilityConfMessage() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getDeletionOfBillingConfirmationMsg();
	}
	public void verifyHouseholdStreamlineBilling() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.getVerifyHouseholdStreamlineBilling();
	}	
	public void submitChangesButton() {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		GeneralUtils.waitFiveSeconds();
		groupBilling.clickSubmitChanges();
		GeneralUtils.waitSeconds(10);
	}
	public boolean seeBillingUpdatedMsgInConfPage(String groupName, String verifyText ) {
		BillingCapability groupBilling = BasePage.initialize(DriverFactory.getDriver(), BillingCapability.class);
		String str1 =groupBilling.getEditBillingConfirmationSucessMessage().getText();
		System.out.println(str1);
		String str2 = groupName + verifyText;
		System.out.println(str2);
		return (str1.equalsIgnoreCase(str2));
	}
	
	
}
