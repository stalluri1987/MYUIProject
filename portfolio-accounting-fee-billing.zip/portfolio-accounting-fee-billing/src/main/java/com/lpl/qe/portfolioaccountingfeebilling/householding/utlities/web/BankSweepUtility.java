package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import com.lpl.qe.CAG.BankSweepCapability;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.blackbird.wait.GeneralUtils;

public class BankSweepUtility {
	
	public void clickBankSweepLink() {
		BankSweepCapability bankSweepCapability = BasePage.initialize(DriverFactory.getDriver(), BankSweepCapability.class);
		bankSweepCapability.clickStreamlineBankSweepLink();
	}
	
	public void verifyBankSweepCreatedSuccessMsg(String groupName) {
		BankSweepCapability bankSweepCapability = BasePage.initialize(DriverFactory.getDriver(), BankSweepCapability.class);
		GeneralUtils.waitSeconds(7);
		bankSweepCapability.isTextPresentForBankSweeepCreatedMsg(groupName + " Bank Sweep successfully created!");
	}

}
