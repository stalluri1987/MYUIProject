package com.lpl.qe.portfolioaccountingfeebilling.householding.constants;

public enum HouseholdDashboardEnum {
	
	BALANDINVHIDECOLUMN1("Summary"), BALANDINVHIDECOLUMN2("Cash Accounts"), BALANDINVHIDECOLUMN3("Market Value of Securities"),
	PREVIOUSMARKETCLOSE("Previous Market Close"), INTRADAYBALANCESUPDATE("Intraday Updated Balances");
	
	String strValue;
	private HouseholdDashboardEnum(String value) {
		this.strValue = value;
	}

}
