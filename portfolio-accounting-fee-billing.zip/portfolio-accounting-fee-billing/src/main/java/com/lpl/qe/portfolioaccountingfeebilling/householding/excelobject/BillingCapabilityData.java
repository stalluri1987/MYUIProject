package com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

	@AllArgsConstructor
	@NoArgsConstructor
	public @Data class BillingCapabilityData {
		private String testID;
		private String flatFeeValue;
		private String decimalFlatValue;
		private String schedule;
		private String userName;
		private String password;
		private String groupName;
		private String groupID;
	}

