package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.lpl.qe.CAG.HouseholdCreate;
import com.lpl.qe.blackbird.DriverFactory;
import com.lpl.qe.blackbird.pagefactory.BasePage;
import com.lpl.qe.blackbird.wait.GeneralUtils;
import com.lpl.qe.blackbird.wait.TimeoutType;

public class HouseholdCreateUtility {
	RemoteWebDriver driver = DriverFactory.getDriver();
	public void clickCreateGroup() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		GeneralUtils.waitSeconds(25);
		householdCreate.clickCreateGroupButton();
	}
	
	public void clickCreateGroupHousehold() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.clickCreateGroupHouseholdButton();
	}
	
	public void isNewHouseholdPageDisplayed() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		driver.switchTo().frame("iframe-modal-frame");
		householdCreate.getNewHouseholdPage();
		
	}
	
	public void enterClientNames(String clientName) {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		System.out.println("client name is "+clientName);
		householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getEnterClientNameTextBox()),"billing buttone disabled", TimeoutType.FIVE_SECONDS);
		householdCreate.clearAndSetEnterClientNameTextBoxValue(clientName);
		
	}
	
	public void selectClientName() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		GeneralUtils.waitSeconds(15);
		householdCreate.clickSelectClientNameFromSmartSearchResult();
		
	}
	
	public void clickCreateHousehold() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		GeneralUtils.waitSeconds(10);
		householdCreate.clickCreateHouseholdButton();
		
	}
	
	public void verifyHHCreatedMesgConfPage() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getConfPageHHCreatedMsg()),"Household successfully created", TimeoutType.TWENTY_SECONDS);
		//GeneralUtils.waitSeconds(10);
		householdCreate.getConfPageHHCreatedMsg();
		
	}
	
	public void clickCloseButton() {

		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		//householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getConfPageHHCreatedMsg()),"Household successfully created", TimeoutType.TWENTY_SECONDS);
		GeneralUtils.waitSeconds(5);
		householdCreate.clickCloseButton();
	}
	
	public void clickGroupNameGroupTab(String groupName) {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		GeneralUtils.waitSeconds(15);
		driver.findElement(By.xpath("//a[contains(text(),'"+groupName+"')]")).click();
	}
	
	public void clickEditHouseholdNamePencilIcon() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getEditGroupNameButton()),"Edit group name", TimeoutType.TWENTY_SECONDS);
		GeneralUtils.waitSeconds(15);
		householdCreate.clickEditGroupNameButton();
	}
	
	public void enterHHNameExceedingLimit(String householdNameExceedingLimit) {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		//householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getEditGroupNameButton()),"Edit group name", TimeoutType.TWENTY_SECONDS);
		householdCreate.setUpdateGroupNameValue(householdNameExceedingLimit);
	}
	
	public void verifyHouseholdNameExceedingMsg() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getHouseholdNameExceedingLimitMsg()),"Edit group name", TimeoutType.TWENTY_SECONDS);
		householdCreate.getHouseholdNameExceedingLimitMsg();
	}
	
	public void isChangesNotSavedPopUpDisplayed() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getWarningPopupModal()),"Changes Not Saved Modal", TimeoutType.TWENTY_SECONDS);
		householdCreate.getWarningPopupModal();
	}
	
	public void clickProceedToClose() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getPopUpProceedButton()),"Proceed to close", TimeoutType.TWENTY_SECONDS);
		householdCreate.clickPopUpProceedButton();
	}
	
	public void clickGoBack() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getPopUpGoBackButton()),"Go Back on Pop-up", TimeoutType.TWENTY_SECONDS);
		householdCreate.clickPopUpGoBackButton();
	}
	
	public void verifyColumnNames(String HouseholdColumnName1, String HouseholdColumnName2, String HouseholdColumnName3, String HouseholdColumnName4) {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		GeneralUtils.waitSeconds(7);
		//householdCreate.waitOnExpectedCondition(ExpectedConditions.visibilityOfAllElements(householdCreate.getPopUpProceedButton()),"Proceed to close", TimeoutType.TWENTY_SECONDS);
		householdCreate.isTextPresentForHouseholdColumnName1(HouseholdColumnName1);
		householdCreate.isTextPresentForHouseholdColumnName2(HouseholdColumnName2);
		householdCreate.isTextPresentForHouseholdColumnName3(HouseholdColumnName3);
		householdCreate.isTextPresentForHouseholdColumnName4(HouseholdColumnName4);
	}
	
	public void verifyHouseholdDetailsInConfPage() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.getHouseholdNameInConfPage();
		householdCreate.getRepIDInConfPage();
		householdCreate.getStatusActiveHHConfPage();
	}
	
	public void clickXToCloseTheGreenBanner() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.clickCloseXbutton();
	}
	
	public void clickOnContentChevronConfPage() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.clickContentsChevronConfPage();
	}
	
	public void verifyToolTipText(String toolTipHeader, String toolTipText1, String toolTipText2) {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.isTextPresentForStreamlineTooltipHeader(toolTipHeader);
		householdCreate.isTextPresentForStreamlineTooltipText1(toolTipText1);
		householdCreate.isTextPresentForStreamlineTooltipText2(toolTipText2);
		
	}
	
	public void viewCapabilitiesInConfPage() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.getCombinedStatementLink();
		householdCreate.getStreamlineBillingLink();
		householdCreate.getInvestmentManagementLink();
		
	}
	
	public void verifyBankSweepSection() {
		HouseholdCreate householdCreate = BasePage.initialize(DriverFactory.getDriver(), HouseholdCreate.class);
		householdCreate.getBackSweepSectionConfPage();
		householdCreate.clickContentsChevronBankSweepLink();
		
	}
	
	

}
