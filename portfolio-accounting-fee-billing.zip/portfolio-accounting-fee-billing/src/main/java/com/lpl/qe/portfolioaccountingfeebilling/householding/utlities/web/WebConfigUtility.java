package com.lpl.qe.portfolioaccountingfeebilling.householding.utlities.web;

import com.lpl.qe.blackbird.configuration.BlackbirdConfiguration;
import com.lpl.qe.blackbird.configuration.model.EnvironmentConfig;
import org.apache.log4j.Logger;

public class WebConfigUtility {
	
	private final static Logger logger = Logger.getLogger(WebConfigUtility.class);

	public enum configKey {
		apiBaseUrl, secureKey, bundleId, cwUrl, avURL , webUrl
	}

	/**
	 * This function is used to get the URL values from the Blackbird.json 
	 *
	 * @author Naga Praveen
	 **/
	// Method to get values from Blackbird.json
	public static String getURL(configKey key) {
		String value = null;
		EnvironmentConfig environmentConfig = BlackbirdConfiguration.getEnvironmentsConfig().get();
		value = getValueOfEnvVar(environmentConfig, key);
		logger.info(key + " value from Blackbird json " + value);
		return value;
	}
   
	/**
	 * This function is used to get the the Value of Environment variable 
	 * 
	 * @param envConfig - Environment config
	 * @param key - value of Key
	 * @author Naga Praveen
	 **/
	private static String getValueOfEnvVar(EnvironmentConfig envConfig, configKey key) {
		String value = "";
		String defaultEnv = envConfig.getDefaultEnvironment();
		logger.info("Default Env: " + defaultEnv);

		if (defaultEnv.equalsIgnoreCase("dev"))
			value = (String) envConfig.getDev().get(key.toString());
		else if (defaultEnv.equalsIgnoreCase("qaf1"))
			value = (String) envConfig.getQAF1().get(key.toString());
		else if (defaultEnv.equalsIgnoreCase("qaf2"))
			value = (String) envConfig.getQAF2().get(key.toString());
		else if (defaultEnv.equalsIgnoreCase("qaf3"))
			value = (String) envConfig.getQAF3().get(key.toString());
		else if (defaultEnv.equalsIgnoreCase("qaf6"))
			value = (String) envConfig.getQAF6().get(key.toString());
		else if (defaultEnv.equalsIgnoreCase("staging"))
			value = (String) envConfig.getStaging().get(key.toString());
		else if (defaultEnv.equalsIgnoreCase("prod"))
			value = (String) envConfig.getProd().get(key.toString());

		return value;
	}

}
