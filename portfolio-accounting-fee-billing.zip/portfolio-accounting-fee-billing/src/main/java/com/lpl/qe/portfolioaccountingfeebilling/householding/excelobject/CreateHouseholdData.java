package com.lpl.qe.portfolioaccountingfeebilling.householding.excelobject;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
public @Data class CreateHouseholdData {
	private String testID;
	private String clientName1;
	private String clientName2;
	private String clientName3;
	private String userName;
	private String password;
	private String groupName;
	private String groupNameExceeedingLimit;
}
