## Sample Automation

### Setup

1. JDK 1.8
2. Appium npm package in $PATH (Latest)
3. Apache Maven in $PATH (Latest)
4. iOS Simulator.
5. Android SDK, Tools, Platform tools in $PATH.
6. Android AVD created. ( > Android 7)
7. Selenium drivers, (Create a folder called driver and place the above driver files in that folder. Add this folder to $PATH variable)
   - gecko driver -> https://github.com/mozilla/geckodriver/releases
   - chrome driver -> https://sites.google.com/a/chromium.org/chromedriver/downloads

### Profiles

Any number of `Profiles` can be added in configuration JSON file as DesiredCapabilities Map. Currently included profile names are,

* `local-chrome` (Default)
* `local-firefox`
* `local-iphone-x-simulator`
* `local-android-pixel`

### Mobile

For mobile execution, we need not start Appium manually. By setting the capability `autoAppium` as `true`, framework will auto-start and kill Appium instance.

### Profile Configuration

The JVM parameters to provide run time profile values are,

1. profile.name

To set the profile that needs to be used. The below command will set the default profile as `local-android-pixel`

```-Dprofile.name=local-android-pixel```

The below command will set the default profile as `local-firefox`

```-Dprofile.name=local-firefox```

2. profile.type

To set the profile type as either `multiProfile` or `randomProfile`.
From the configuration JSON file, the profiles set in `multiProfile` or `randomProfile` will be picked and executed.

To execute the tests on multiple profiles, `multiProfile` value from the configuration JSON file will be picked and executed.

```-Dprofile.type=multiProfile```

To execute the tests on a random profile, `randomProfile` value from the configuration JSON file will be picked and executed.

```-Dprofile.type=randomProfile```

### IDE Execution

Open the relevant TestNG suite xml file and run it via configuration. The profile values can be passed as JVM parameters.
